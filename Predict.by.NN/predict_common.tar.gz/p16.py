#!/usr/bin/python3
# script to perform protein local structure (by Protein Blocks) prediction by precomputed NN model
# (C) Yuri V. Milchevskiy, Yuri V. Kravatsky
# email: milch@eimb.ru
#
# Dependencies:
#  1. python 3 (tested with python 3.8.10)
#  2. numpy (tested with 1.22.3), pandas (tested with 1.5.1)
#  3. PyTorch (tested with 1.12.1)
#
################################################################################################################
################################# PREDICTION USING A PRE-MADE MODEL "REAL_DATA_MODEL" ##########################
################################################################################################################ 
from pandas import read_csv
from torch import Tensor
from torch.nn import Linear
from torch.nn import Module
from torch.nn.init import kaiming_uniform_
import torch
import numpy
import sys
import pandas as pd

import sys

def printf(format, *args):
    sys.stdout.write(format % args)
def accuracy(yt, y_pred):
  # assumes model.eval()
  # granular but slow approach
  n_correct = 0; n_wrong = 0
  for i in range(len(yt)):
   t_index=torch.argmin(yt[i])
   pred_index=torch.argmin(y_pred[i])
    
   if t_index == pred_index:
    n_correct += 1
   else:
      n_wrong += 1

  acc = (n_correct * 1.0) / (n_correct + n_wrong)
  return acc
# model definition

def get_predicted_PB_set(y_pred):
  # assumes model.eval()
  # granular but slow approach

  PB='abcdefghijklmnop'
  PB_set=''

  n_correct = 0; n_wrong = 0
  for i in range(len(y_pred)):
   pred_index=torch.argmin(y_pred[i])
   PB_set +=PB[pred_index] 

   return PB_set

# model definition
class MultiOutputRegression(torch.nn.Module):
    # define model elements
    def __init__(self):
        super(MultiOutputRegression, self).__init__()
        # input to first hidden layer
        self.hidden1 = Linear(380, 320)
        kaiming_uniform_(self.hidden1.weight, nonlinearity='sigmoid')
        self.act1 = torch.nn.Sigmoid()

        # 2 hidden layer
        self.hidden2 = Linear(320, 180)
        kaiming_uniform_(self.hidden2.weight, nonlinearity='sigmoid')
        self.act2 = torch.nn.Sigmoid()

        # 3 hidden layer
        self.hidden3 = Linear(180, 90)
        kaiming_uniform_(self.hidden3.weight, nonlinearity='sigmoid')
        self.act3 = torch.nn.Sigmoid()

        # 4 hidden layer
        self.hidden4 = Linear(90, 50)
        kaiming_uniform_(self.hidden4.weight, nonlinearity='sigmoid')
        self.act4 = torch.nn.Sigmoid()

        # 5 hidden layer and output
        self.hidden5 = Linear(50, 16)

    # forward propagate input
    def forward(self, X):
        # input to first hidden layer
        X = self.hidden1(X)
        X = self.act1(X)
        # 2 hidden layer
        X = self.hidden2(X)
        X = self.act2(X)
        # 3 hidden layer
        X = self.hidden3(X)
        X = self.act3(X)
        # 4 hidden layer
        X = self.hidden4(X)
        X = self.act4(X)

        # output layer
        X = self.hidden5(X)
        return X

#

model = MultiOutputRegression()

dev = "cpu"
device = torch.device(dev)

model.load_state_dict(torch.load('p16_MODEL_CPU',device))
model = model.to(device)

name = sys.argv[1]

Xname=name

dfX = pd.read_csv(Xname, header=None,delimiter='\t')

X = dfX.values[:, :]
 
# ensure input data is floats
X = X.astype('float16')

Xt=torch.from_numpy(X).float().to(device)
del X
y_pred = model(Xt)

length = Xt.size(dim=0)

PB_set=get_predicted_PB_set(y_pred)

print(PB_set)
