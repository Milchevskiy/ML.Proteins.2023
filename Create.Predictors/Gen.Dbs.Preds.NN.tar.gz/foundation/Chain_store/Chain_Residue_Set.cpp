#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "Chain_Residue_Set.h"

#include "Residue.h"

#include "../Censorship.h"
#include "../Geometry_util/Geometry_util.h"

#include "PDB_util.h"

#include "Chain_sequence.h"

#include "Perotoptatsja.h"

#include "../CommonFunc.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <map>
#include <cassert>

#include "tri_to_one_and_vice_versa_aa_translation.h"


using namespace Geometry_util;

extern Censorship configuration;
extern ofstream log_stream;

// ****local function ***
bool find_substring (
	const vector < string > & base,
	const  vector < Residue * > &  shablon,
	int & start_pos,
	map <int,Residue * > & is_present_index ) ;

int find_coincidence_position (
    vector < string> & subset,
    const int start_position_in_chain,
    vector < Residue * > & chain_);

void    add_coord_data_to_chain (
    vector <string> & atom_record_pull,
    vector < Residue * > & chain);


void    check_geometry_admissible (
    vector < Residue * > & chain,
    const double distance_epsilon,
    const double angle_epsilon,
    vector <string > & Error_message_set_for_protocol );



Chain_Residue_Set:: Chain_Residue_Set (
        const string &full_path_to_pdb_file,//PDB_chain_ID ,
        char  chain_ID,
        const double Treshold_C_N_Distance,
        const double distance_epsilon,
        const double angle_epsilon):
            is_pdb_file_(true),
            is_accord_seqres_atom_(true),
            is_there_chain_ (true),
            is_standard_aminoacisds_(true),
            is_present_CA_C_N_backbone_(true)

{

	{
		Chain_sequence cs (
            full_path_to_pdb_file,
            chain_ID);
		tri_letter_sequence_by_seqres_ = cs.get_tri_letter_sequence ();
	}

	is_standard_aminoacisds_ = is_standard_tri_letter_aminoacid_sequence (tri_letter_sequence_by_seqres_);

	if(!is_standard_aminoacisds_)
	{
        log_stream	<< "stange amino acids found in sequence:" ;
        for (int ii=0;ii<tri_letter_sequence_by_seqres_.size();ii++ )
               log_stream	<< tri_letter_sequence_by_seqres_[ii] << " " ;
        log_stream	<< endl;

        return;

	}



	ifstream source_stream ( full_path_to_pdb_file.c_str() );
	if ( ! source_stream )
	{
		cout		<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		log_stream	<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		is_pdb_file_ = false;
		return;
	}

	string current_line;
	getline(source_stream,current_line,'\n' );
	string rude_pdb_ID = current_line.substr(59,current_line.size()-58);

	string pdb_ID;
	istringstream ist ( rude_pdb_ID  );
	ist >> pdb_ID;

    chain_ID = toupper(chain_ID);

	pdb_chain_ID_ = pdb_ID + chain_ID;

	//for (int kk=0;kk<pdb_chain_ID_.size();kk++) 		pdb_chain_ID_[kk] = tolower(pdb_chain_ID_[kk]);



	char altLoc = 'A';
	vector <string> atom_record_pull = get_ATOM_lines	( source_stream, chain_ID,  altLoc);

	if ( atom_record_pull.size() ==0 )
	{
        is_there_chain_ = false;
        return;
    }

//
	fill_up_chain (
		atom_record_pull,
		Treshold_C_N_Distance,
		distance_epsilon,
		angle_epsilon);

}



/// Working variant
Chain_Residue_Set::
Chain_Residue_Set (
	const string & pdb_chain_ID,
	const double Treshold_C_N_Distance,
	const double distance_epsilon,
	const double angle_epsilon):
 pdb_chain_ID_( pdb_chain_ID ),
 is_accord_seqres_atom_ (true),
 is_pdb_file_           (true),
           is_there_chain_ (true),
            is_standard_aminoacisds_(true),
            is_present_CA_C_N_backbone_(true)

{

	{
		Chain_sequence cs ( pdb_chain_ID );
		tri_letter_sequence_by_seqres_ = cs.get_tri_letter_sequence ();
	}

	if ( pdb_chain_ID.size() != 5 )
	{
		cout		<<	pdb_chain_ID  << ": strange pdb_chain_ID " << endl;
		log_stream	<<	pdb_chain_ID  << ": strange pdb_chain_ID " << endl;
		is_pdb_file_ = false;
		return;
	}

	//char	chain_ID =  toupper ( pdb_chain_ID[4] );  // convert to lower letter case
	//for (int ii=0;ii<pdb_chain_ID.size(); ii++)

	char	chain_ID =  pdb_chain_ID[4];  /// НЕ НАДО ДЕЛАТИЬ БОЛЬШИХ БУКВ !!!!

	string	pdb_ID   =  pdb_chain_ID.substr(0,4);

	for (int kk=0;kk<pdb_ID.size();kk++)
		pdb_ID[kk] = tolower(pdb_ID[kk]);

    if (chain_ID == '_')
		chain_ID = ' ';


/// file storing like original new protein bank style
    string full_path_to_pdb_store  =
        configuration.option_meaning("Path_to_PDB_store") ;

    string local_pdbbank_path = solve_the_rebus_to_find_file_by_pdbid (pdb_ID);

    string full_path_to_pdb_file = full_path_to_pdb_store + local_pdbbank_path;



 // 	string full_path_to_pdb_file =
//		configuration.option_meaning("Path_to_PDB_store") + string ("pdb")	+
//		pdb_ID + string (".ent");

	ifstream source_stream ( full_path_to_pdb_file.c_str() );
	if ( ! source_stream )
	{
		cout		<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		log_stream	<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		is_pdb_file_ = false;
		return;
	}

	char altLoc = 'A';
	vector <string> atom_record_pull = get_ATOM_lines	( source_stream, chain_ID,  altLoc);

	/// previous version
	/*fill_up_chain (
		atom_record_pull,
		Treshold_C_N_Distance,
		distance_epsilon,
		angle_epsilon);
*/
/// new version
 fill_up_chain_improved (
		atom_record_pull,
		Treshold_C_N_Distance,
		distance_epsilon,
		angle_epsilon);


}
void Chain_Residue_Set::
fill_up_chain_improved (
	vector <string> & atom_record_pull,
	const double Treshold_C_N_Distance,
	const double distance_epsilon,
	const double angle_epsilon)
{

    int number_of_residues  = tri_letter_sequence_by_seqres_.size();
    for (int ii = 0; ii < number_of_residues; ii++)
    {
        Residue *current_residue = new Residue ( ii, tri_letter_sequence_by_seqres_ [ii] );
        chain_.push_back(current_residue);
    }




/// find all continuous chain subsets ResNu_fitting_set
    vector <vector < string > > ResNu_fitting_set;

    int fixed_yet_residue_number = -99999;

    vector <vector <string> > continues_sets;
    vector <vector <int> >   point_to_continues_sets;  /// point to atom_record_pull string where starts desired residue record

    vector <string> current_continues_set;
    vector <int>    current_point_to_continues_set;

    bool is_there_first_case = false;
	for (int ii=0; ii< atom_record_pull.size(); ii++ )
	{

		string word	= atom_record_pull[ii].substr(22,5);
		string current_in_chain_residue_number;
		{
			istringstream ist ( word );
			ist >> current_in_chain_residue_number;
		}
		int     in_chain_residue_number_i   = atoi( current_in_chain_residue_number.c_str() );

		word = atom_record_pull[ii].substr(17,3);
		string current_residue_name;
		{
			istringstream ist ( word );
			ist >> current_residue_name;
		}

        if ( fixed_yet_residue_number != in_chain_residue_number_i)
        {
            if ( fixed_yet_residue_number + 1 != in_chain_residue_number_i && current_continues_set.size()!=0 ) /// start next residue
            {
                continues_sets.push_back(current_continues_set);
                current_continues_set.resize(0);

                point_to_continues_sets.push_back(current_point_to_continues_set);
                current_point_to_continues_set.resize(0);
            }
            current_continues_set.push_back(current_residue_name);
            current_point_to_continues_set.push_back(ii);

            fixed_yet_residue_number = in_chain_residue_number_i;


        }

    }
	if (current_continues_set.size() != 0)  /// if If there is anything left in the current array, add that remainder to the global array
	{
        continues_sets.push_back(current_continues_set);
        point_to_continues_sets.push_back(current_point_to_continues_set);
    }


	/// check continues_sets & and point_to_continues_sets

	log_stream << "Check heck continues_sets & and point_to_continues_sets:" << endl;


    for (int kk=0;kk<continues_sets.size();kk++)
    {
        for (int zz=0;zz<continues_sets[kk].size();zz++)
            PutVa(continues_sets[kk][zz],           log_stream,6,1,'l');log_stream << endl;

        for (int zz=0;zz<continues_sets[kk].size();zz++)
            PutVa(point_to_continues_sets[kk][zz],  log_stream,6,1,'l');log_stream << endl;
    }

    vector <vector <int> >   point_to_chain_serial_number_sets;  /// point to chain_. For sharing with chain_
    vector <int>             current_point_to_chain_serial_number_set;

    int start_position_in_chain = 0;
    for (int kk=0; kk< continues_sets.size();kk++)
	{
        /// Here we find the position where the fragment coincides with the main sequence
        int coincidence_pos_in_chain = find_coincidence_position (continues_sets[kk],start_position_in_chain,chain_);

        if (coincidence_pos_in_chain == -1 )
        {
            log_stream << pdb_chain_ID_ << "Error - cant find coincedence for subset " << kk << endl;


        }
        else
        {
          log_stream << "coincidence for chain " << kk << endl;


        log_stream <<  "index in set "  ;
        for (int zz=0;zz<continues_sets[kk].size();zz++)
            PutVa(point_to_continues_sets[kk][zz],  log_stream,6,1,'l');log_stream << endl;

        log_stream <<  "By fragment " ;
        for (int zz=0;zz<continues_sets[kk].size();zz++)
            PutVa(continues_sets[kk][zz],  log_stream,6,1,'l');log_stream << endl;

        log_stream <<  " By chain   " ;
        for (int zz=0;zz<continues_sets[kk].size();zz++)
        {
            PutVa(chain_[coincidence_pos_in_chain+zz]->get_residue_name(),  log_stream,6,1,'l');log_stream << endl;
            chain_[coincidence_pos_in_chain+zz]->set_point_to_continues_set ( point_to_continues_sets[kk][zz] );   /// vital string

        }

            start_position_in_chain = coincidence_pos_in_chain + continues_sets[kk].size();


        }
	}
    add_coord_data_to_chain (
        atom_record_pull,
        chain_);

  //  vector <string > Error_message_set_for_protocol;
     check_geometry_admissible (
        chain_,
        distance_epsilon,
        angle_epsilon,
        Error_message_set_for_protocol_);


}

/*
#define N_CA    1.453
#define CA_C    1.53
#define C_N     1.325

#define C_N_CA 121.0
#define N_CA_С 109
#define CA_C_N 115.0
*/

void    check_geometry_admissible (
    vector < Residue * > & chain,
    const double distance_epsilon,
    const double angle_epsilon,
    vector <string > & Error_message_set_for_protocol )
{
    double coord [9];
    int sequence_length = chain.size();



    Error_message_set_for_protocol.resize(sequence_length);


    double c_n_dist     =-1;
    double n_ca_dist    =-1 ;
    double ca_c_dist    =-1;


    bool  is_c_n_good  =false;
    bool  is_n_ca_good =false ;
    bool  is_ca_c_good =false;


    double prev_n[3];

    bool  is_exist_prev = false;


    bool  is_there_coord = chain[0]->get_is_there_coord();
    if (is_there_coord)
    {
        memcpy(coord,chain[0]->get_coord(),9*sizeof(double) );
        n_ca_dist =  Geometry_util::distance (coord  ,coord+3 ) ;
        ca_c_dist =  Geometry_util::distance (coord+3,coord+6 ) ;

   //     memcpy (prev_n,coord+6,3*sizeof(double) );

        if ( fabs (n_ca_dist - N_CA ) > distance_epsilon )
        {
            ostringstream ost;
            ost << "! deviation from N -CA standard distance exceed standard 1.453 more than " << distance_epsilon  << ": " << n_ca_dist ;
            string buffer = ost.str() ;
            Error_message_set_for_protocol[0]  += buffer;
            is_n_ca_good=false;
        }
        else
            is_n_ca_good=true;

        //if ( fabs (ca_c_dist - CA_С ) > distance_epsilon )

         if ( fabs (ca_c_dist - CA_C ) > distance_epsilon )
        {
            ostringstream ost;
            ost << "! deviation from CA-С standard distance exceed standard 1.53 more than " << distance_epsilon  << ": " << ca_c_dist ;  ;
            string buffer = ost.str() ;
            Error_message_set_for_protocol[0]  += buffer;
            is_ca_c_good =false ;
        }
        else
            is_ca_c_good =true ;


         memcpy(prev_n,chain[0]->get_coord()+6,3*sizeof(double) );
         is_exist_prev = true;

         if ( is_n_ca_good & is_ca_c_good  )
            chain[0]->set_is_geometry_admissible(true);
         else
            chain[0]->set_is_geometry_admissible(false);
    }


    // handle the first resifue
    for (int ii=1;ii<sequence_length;ii++)
    {
        is_there_coord = chain[ii]->get_is_there_coord();
        if (is_there_coord)
        {
            memcpy(coord,chain[ii]->get_coord(),9*sizeof(double) );

            if ( is_exist_prev )
            {
                c_n_dist =  Geometry_util::distance (prev_n  ,coord) ;

                double test_C_N = C_N;
                double dumy_test =c_n_dist - C_N;

                if ( fabs (c_n_dist - C_N ) > distance_epsilon )
                {
                    ostringstream ost;
                    ost << "! deviation from C-N standard distance exceed standard 1.325 more than " << distance_epsilon  << ": " << c_n_dist  << "   "
                        << chain[ii]->get_residue_name() << chain[ii]->get_in_chain_residue_number();

                    string buffer = ost.str() ;
                    Error_message_set_for_protocol[ii]  += buffer;
                    is_c_n_good=false;
                }
                else
                    is_c_n_good=true;

            }
            else
                is_c_n_good=false;




            n_ca_dist =  Geometry_util::distance (coord  ,coord+3 ) ;
            ca_c_dist =  Geometry_util::distance (coord+3,coord+6 ) ;

    //        memcpy (prev_n,coord+6,3*sizeof(double) );

            if ( fabs (n_ca_dist - N_CA ) > distance_epsilon )
            {
                ostringstream ost;
                ost << "! deviation from N -CA standard distance exceed standard 1.453 more than " << distance_epsilon  << ": " << n_ca_dist ;
                string buffer = ost.str() ;
                Error_message_set_for_protocol[ii]  += buffer;
                is_n_ca_good=false;
            }
            else
                is_n_ca_good=true;

            //if ( fabs (ca_c_dist - CA_С ) > distance_epsilon )

             if ( fabs (ca_c_dist - CA_C ) > distance_epsilon )
            {
                ostringstream ost;
                ost << "! deviation from CA-С standard distance exceed standard 1.53 more than " << distance_epsilon  << ": " << ca_c_dist ;  ;
                string buffer = ost.str() ;
                Error_message_set_for_protocol[ii]  += buffer;
                is_ca_c_good =false ;
            }
            else
                is_ca_c_good =true ;



            if ( is_exist_prev )
            {
                 if ( is_n_ca_good & is_ca_c_good  & is_c_n_good)
                    chain[ii]->set_is_geometry_admissible(true);
                 else
                    chain[ii]->set_is_geometry_admissible(false);
            }
            else
            {
                if ( is_n_ca_good & is_ca_c_good )
                    chain[ii]->set_is_geometry_admissible(true);
                 else
                    chain[ii]->set_is_geometry_admissible(false);
            }
            memcpy(prev_n,chain[ii]->get_coord()+6,3*sizeof(double) );
            is_exist_prev = true;
        }
        else
            is_exist_prev = false;

    }
    // handle the first resifue
}
void    add_coord_data_to_chain (
    vector <string> & atom_record_pull,
    vector < Residue * > & chain)

{
    double coord [9];
    for (int ii=0;ii<chain.size();ii++)
    {
        int point_to_continues_set = chain[ii]->get_point_to_continues_set();
        if ( point_to_continues_set != -1 )
        {
            int start = point_to_continues_set;

            string in_chain_residue_number	= atom_record_pull[start].substr(22,5);
            string start_in_chain_residue_number;
            {
                istringstream ist ( in_chain_residue_number	 );
                ist >> start_in_chain_residue_number;
            }
            string current_in_chain_residue_number;
            chain[ii]->set_in_chain_residue_number(start_in_chain_residue_number);


            bool is_N   = false;
            bool is_CA  = false;
            bool is_C   = false;

            int  counter = start;
            do {

                string in_chain_residue_number	= atom_record_pull[counter].substr(22,5);

                {
                    istringstream ist ( in_chain_residue_number	 );
                    ist >> current_in_chain_residue_number;
                }

                	string source_word;

                source_word= atom_record_pull[counter].substr(13,4) ;
                string current_atom_name;
                {

                    istringstream ist ( source_word  );
                    ist >> current_atom_name;
                }

                double x,y,z;
                source_word= atom_record_pull[counter].substr(29,26) ;
                {
                    istringstream ist ( source_word  );
                    ist >> x >> y >> z;
                }

                if ( current_atom_name=="N" && is_N == false )
                {
                    is_N = true;

                    coord [0] = x ;
                    coord [1] = y ;
                    coord [2] = z ;

                }

                if ( current_atom_name=="CA" && is_CA == false )
                {
                    is_CA = true;

                    coord [3] = x ;
                    coord [4] = y ;
                    coord [5] = z ;

                }

                if ( current_atom_name=="C" && is_C == false )
                {
                    is_C = true;

                    coord [6] = x ;
                    coord [7] = y ;
                    coord [8] = z ;
                }


                if (counter == atom_record_pull.size() - 1 )
                    break;

            /*    log_stream << "counter  "<< counter <<" " <<current_atom_name <<  " " << in_chain_residue_number;
                PutVaDouble(x,log_stream,8,3,'l');
                PutVaDouble(y,log_stream,8,3,'l');
                PutVaDouble(z,log_stream,8,3,'l');
                */

                counter ++;
            }
            while ( start_in_chain_residue_number == current_in_chain_residue_number );

            if ( is_N & is_CA & is_C )
            {
               chain[ii]->full_up_coordinates (coord) ;
               chain[ii]->set_is_there_coord(true);

               log_stream << ii << " " << start_in_chain_residue_number << " " << chain[ii]->get_residue_name() ;
               for (int zzz=0;zzz<9;zzz++)
                    PutVaDouble( chain[ii]->get_coord()[zzz],log_stream,8,3,'l');
                log_stream << endl;
            }
            else
                chain[ii]->set_is_there_coord(false);

        }
        else
            chain[ii]->set_is_there_coord(false);
    }
}

int find_coincidence_position (
    vector < string> & subset,
    const int start_position_in_chain,
    vector < Residue * > & chain)
{
    int chain_len   = chain.size();
    int subset_len  = subset.size();
    for (int ii=start_position_in_chain;ii<chain_len-subset_len+1;ii++ )
    {
        int conincedence = 0;
        for (int jj=0;jj<subset_len;jj++)
        {
            string ReNa_subset = subset[jj];
            string ReNa_chain  = chain[ii+jj]->get_residue_name();

            if ( ReNa_subset == ReNa_chain )
                conincedence++;
        }
        if (conincedence == subset_len)
            return ii;
    }
    return -1;;

}
void Chain_Residue_Set::
fill_up_chain (
	vector <string> atom_record_pull,
	const double Treshold_C_N_Distance,
	const double distance_epsilon,
	const double angle_epsilon)
{

// Íàäî ïîäóìàòü îòêóäà áðàòü **************************************************************
//	 double Treshold_C_N_Distance = 3; //***************************************************
// *****************************************************************************************
	map <string, Perotoptatsja > peretoptatsja_map;
	vector < string > in_chain_residue_number_SET;

	map <string, Residue * > residue_map;

//	123456789 123456789 123456789 123456789 123456789 123456789 123456789
//	ATOM   1215  CA  CYS B 103      25.881  19.429  18.080  1.00 24.79      CHNB C


    log_stream << "before Chain_residue_set kine 215 " << endl;
    int tttt= atom_record_pull.size();
    log_stream << "atom_record_pull.size(): " << tttt << endl;

	for (int ii=0; ii< atom_record_pull.size(); ii++ )
	{

   ///01234567890123456789
   ///ATOM     51  CA BSER A 243      19.126  59.696  10.000  0.20 11.51           C
   //     char test_char= atom_record_pull[ii][16];
     //   log_stream << ii << " " <<  test_char << "   " << atom_record_pull[ii] << endl;
//
    /*    if (    atom_record_pull[ii][16]=='B' ||
                atom_record_pull[ii][16]=='C' ||
                atom_record_pull[ii][16]=='D' ||
                atom_record_pull[ii][16]=='E' )
        {
                log_stream << "Extra backbone atom found like CA B,N  B etc" << endl;


                continue;

        }
*/

		string source_word;

		source_word= atom_record_pull[ii].substr(13,4) ;
		string current_atom_name;
		{

			istringstream ist ( source_word  );
			ist >> current_atom_name;
		}

		if ( ! is_main_chain_atom ( current_atom_name )  )
			continue;

		source_word				= atom_record_pull[ii].substr(17,3);
		string current_residue_name;
		{
			istringstream ist ( source_word  );
			ist >> current_residue_name;
		}

		string in_chain_residue_number	= atom_record_pull[ii].substr(22,5);
		string current_in_chain_residue_number;
		{
			istringstream ist ( in_chain_residue_number	 );
			ist >> current_in_chain_residue_number;
		}

		double x,y,z;
		source_word= atom_record_pull[ii].substr(29,26) ;
		{
			istringstream ist ( source_word  );
			ist >> x >> y >> z;
		}

		Perotoptatsja current_peretoptatsja (
			current_in_chain_residue_number,
			current_atom_name,
			current_residue_name,
			x,
			y,
			z) ;

		ostringstream ost ;
		ost << current_in_chain_residue_number << " " << current_atom_name;
		string current_key_word = ost.str();

		peretoptatsja_map [ current_key_word ] = current_peretoptatsja;

		if (  current_atom_name == "N")
			in_chain_residue_number_SET.push_back(current_in_chain_residue_number);

	}

	/// если in_chain_residue_number_SET.size() == 0, то тут только CA атомы - нехер обрабатвать
	int test_1= in_chain_residue_number_SET.size();
    if (in_chain_residue_number_SET.size() == 0 )
    {
        is_present_CA_C_N_backbone_ = false;

        log_stream  << "Not found all types backbone atoms: N,Ca,C. May be CA only present" << endl;

        return;
    }
	vector < string > perfect_in_chain_residue_number_SET;
	int ii;
	for ( ii=0; ii < in_chain_residue_number_SET.size(); ii++)
	{

		string N_key;
		{
			ostringstream ost ;
			ost << in_chain_residue_number_SET[ii] << " " << "N";
			N_key= ost.str();
		}

		string CA_key;
		{
			ostringstream ost ;
			ost << in_chain_residue_number_SET[ii] << " " << "CA";
			CA_key= ost.str();
		}
		string C_key;
		{
			ostringstream ost ;
			ost << in_chain_residue_number_SET[ii] << " " << "C";
			C_key= ost.str();
		}

		if ( peretoptatsja_map.find(N_key)  != peretoptatsja_map.end()  &&
			 peretoptatsja_map.find(CA_key) != peretoptatsja_map.end()  &&
			 peretoptatsja_map.find(C_key)  != peretoptatsja_map.end()  	)

		{
				Perotoptatsja N_prer  = peretoptatsja_map[N_key] ;
				Perotoptatsja CA_prer = peretoptatsja_map[CA_key];
				Perotoptatsja C_prer  = peretoptatsja_map[C_key] ;

				double coord [9];

				coord [0] = N_prer.get_x () ;
				coord [1] = N_prer.get_y () ;
				coord [2] = N_prer.get_z () ;

				coord [3] = CA_prer.get_x () ;
				coord [4] = CA_prer.get_y ();
				coord [5] = CA_prer.get_z ();

				coord [6] = C_prer.get_x ();
				coord [7] = C_prer.get_y ();
				coord [8] = C_prer.get_z ();

				string residue_name = C_prer.get_residue_name();

				Residue *current_residue = new Residue (
						in_chain_residue_number_SET[ii],
						residue_name ,
						coord );

				residue_map [in_chain_residue_number_SET[ii]] = current_residue;
				perfect_in_chain_residue_number_SET.push_back( in_chain_residue_number_SET[ii] );
		}
	}

	vector < Residue * > current_fragment;
	vector < vector < Residue * > > fragment_set;

	for ( ii=0; ii < perfect_in_chain_residue_number_SET.size() - 1; ii++)
	{

	   if ( is_valid_CN_neighbour_distance (
         residue_map [ perfect_in_chain_residue_number_SET[ii  ] ],
		 residue_map [ perfect_in_chain_residue_number_SET[ii+1] ],
		 Treshold_C_N_Distance ) )
			current_fragment.push_back ( residue_map [ perfect_in_chain_residue_number_SET[ii] ] );
		else
		{
			if ( current_fragment.size() )
				fragment_set.push_back ( current_fragment );

			current_fragment.clear();
		}
	}

// Handling the last element & last fragment
	if ( current_fragment.size() != 0 )
	{
		current_fragment.push_back ( residue_map [ perfect_in_chain_residue_number_SET[ii] ] );
		fragment_set.push_back ( current_fragment );
	}


	int start_pos = 0;
	map <int,Residue * >  is_present_index ;

	for ( int kk=0;kk<fragment_set.size();kk++ )
	{
		start_pos = 0;

		bool is_there_substring =  find_substring (
			tri_letter_sequence_by_seqres_,
			fragment_set[kk],start_pos ,is_present_index );
		if ( is_there_substring )
		{
//			start_pos -=70;
		}
		else
		{

			is_accord_seqres_atom_ = false;

			cout << "Defect in " << pdb_chain_ID_ << ": " << endl;

// ************** ó÷èíèòü òîëüêî øóõåð â log_stream
			log_stream <<  "Defect in " << pdb_chain_ID_ << ": " << endl;
			log_stream <<  " can't find sublsting:  ";
			for ( int tt=0; tt < fragment_set[kk].size(); tt++ )
			{
				log_stream <<  fragment_set[kk][tt]->get_residue_name() << " ";
			}
			log_stream <<  endl;

			log_stream <<  " can't find sublsting:  ";
			int tt;
			for (  tt=0; tt < fragment_set[kk].size(); tt++ )
			{
//				log_stream <<  fragment_set[kk][tt]->get_in_chain_residue_number() << " ";
				PutVa (fragment_set[kk][tt]->get_in_chain_residue_number(),log_stream,4,3,'l' );
			}
			log_stream <<  endl;


			log_stream <<  "SIZE: !!! " << tri_letter_sequence_by_seqres_.size() << endl;
			log_stream <<  " in SEQRES sequence :  ";
			for (  tt=0; tt < tri_letter_sequence_by_seqres_.size(); tt++ )
				log_stream <<  tri_letter_sequence_by_seqres_[tt]<< " ";
			log_stream <<  endl;

			log_stream <<  " in SEQRES sequence :  ";
			for (  tt=0; tt < tri_letter_sequence_by_seqres_.size(); tt++ )
					PutVa (tt,log_stream,4,3,'l' );
			log_stream <<  endl;
// ***********************************

		}
	}

// *******************************************************************************************************************
// *******************************************************************************************************************

	for ( ii = 0; ii < tri_letter_sequence_by_seqres_.size(); ii++ )
	{
		if ( is_present_index.find (ii) != is_present_index.end() )
		{
			chain_.push_back ( is_present_index [ii] );
		}
		else
		{
			Residue *current_residue = new Residue ( ii, tri_letter_sequence_by_seqres_ [ii] );
			chain_.push_back ( current_residue );
		}
	}

// ****** assigne geometry flag
// FIX ********************** íàäî áû ýòî çàäàâàòü êàê ïàðàìåòðû
//	double distance_epsilon	= 0.15;
//	double angle_epsilon	= 0.3;

	int test = chain_.size();
	for ( ii=0; ii< chain_.size() - 1;ii++)
	{
		analyse_backbone_geometry (	chain_[ii],	chain_[ii+1],distance_epsilon,angle_epsilon);
	}
}

bool find_substring (
	const vector < string > & base,
	const  vector < Residue * > &  shablon,
	int & start_pos,
	map <int,Residue * > & is_present_index )
{
	int len_base	= base.		size();
	int len_shablon = shablon.	size();

	for (int ii=start_pos ; ii < len_base - len_shablon + 1 ; ii++ )
	{
		int  mismatch =0;
		int	 coincidence = 0;

		for ( int kk=0; kk < len_shablon ; kk++ )
		{
			string base_residue		= base   [ii + kk ];
			string shablon_residue	= shablon[kk]->get_residue_name();

			if ( base_residue  != shablon_residue )
				mismatch ++;
			else
				coincidence ++ ;

			if ( mismatch == 5 )
				break;

		}

		if ( coincidence == len_shablon )
		{
			for ( int pp=0;pp<len_shablon;pp++  )
			{
				int index = ii + pp ;

				shablon[pp]->set_serial_index( index  );
				is_present_index [ index  ] = shablon[pp];
			}
			start_pos = ii+1;

			return true;
		}
	}
	return false;
}

int Chain_Residue_Set::get_residue_number_by_coord  ()  const
{
	int counter = 0;
	for (int ii=0; ii < chain_.size() ; ii++ )
	{
		if ( chain_[ii]->get_coord() != 0 )
			counter ++;
	}

	return counter ;
}


bool Chain_Residue_Set::
is_valid_CN_neighbour_distance (
	const Residue * current,
	const Residue * next,
	const double threshold_distance )
{

	double current_coord[9], next_coord[9];

	if ( ! current->get_is_there_coord() || ! next->get_is_there_coord()  )
		return false;
	else
	{
		memcpy (current_coord,current->get_coord(),9*sizeof(double) );
		memcpy (next_coord,   next   ->get_coord(),9*sizeof(double) );

		double result = sqrt (
			( current_coord[6] - next_coord[0] ) * ( current_coord[6] - next_coord[0] ) +
			( current_coord[7] - next_coord[1] ) * ( current_coord[7] - next_coord[1] ) +
			( current_coord[8] - next_coord[2] ) * ( current_coord[8] - next_coord[2] )
			);


		bool check = ( threshold_distance > result );
		return check ;
	}
}

void Chain_Residue_Set::
print_protocol ()
{

	string full_path_to_protocol_file =
		configuration.option_meaning("Path_to_Chain_store") +
		 string ("/protocol/") + string (pdb_chain_ID_)  + string (".protocol");

	ofstream out ( full_path_to_protocol_file.c_str() );
	if ( ! out )
	{
		out			<<	full_path_to_protocol_file  << " can't create " << endl;
		log_stream	<<	full_path_to_protocol_file  << " can't create " << endl;
		return;
	}

	if ( ! is_pdb_file_ )
	{
		out	<< " Can't find PDB file " << endl;
		return ;
	}

	if ( ! is_accord_seqres_atom_ )
	{
		out	<< " SEQRES record does not accord ATOM record " << endl;
		return ;
	}

	if ( ! is_present_CA_C_N_backbone_ )
	{
		out	<< " Not all backbone type atom (N,Ca,C) present in pdb file " << endl;
		return ;
	}
	if ( ! is_there_chain() )
	{
		out	<< " Setted by chain ID not found in PDB " << endl;
		return ;
	}



	for ( int ii=0; ii < tri_letter_sequence_by_seqres_.size(); ii++ )
	{
		string current_chain_rena = chain_[ii]->get_residue_name();
		string current_seqres = tri_letter_sequence_by_seqres_ [ii];

		assert ( chain_[ii]->get_residue_name() ==  tri_letter_sequence_by_seqres_ [ii]);
		if ( chain_[ii]->get_residue_name() !=  tri_letter_sequence_by_seqres_ [ii] )
			cout << " error resna not coincides" << endl;

		PutVa ( tri_letter_sequence_by_seqres_ [ii],out, 5,4,'l');
		PutVa ( chain_[ii]->get_residue_name(),				out, 5,4,'l');
		PutVa ( chain_[ii]->get_in_chain_residue_number (), out, 6,5,'l');

		if ( chain_[ii]->get_is_there_coord () ) 	out << "C";
		else										out << "-";

		if ( chain_[ii]->get_is_geometry_admissible () ) 	out << "G";
		else										out << "-";

/// ONLY FOR NEW VERSION
//		out << Error_message_set_for_protocol_[ii];

		out << endl;

	}
}



void Chain_Residue_Set::
save_as_binary ()
{
	string binary_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		string ("binary/") + string (pdb_chain_ID_)  + string (".bin");


	ofstream binary_stream ( binary_file_name.c_str(),ios::binary );

	if ( ! binary_stream )	{
		log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
		cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
		exit (1);
	}
	else
	{
        log_stream	 << "OK  saved binary file" << binary_file_name<< endl;
	}

	double *coord = new double [9];


// *** pdb_chain_ID_  : 4*sizeof (char)
//	binary_stream.write( (char* ) pdb_chain_ID_.c_str(), 4*sizeof (char) );
	binary_stream.write( (char* ) pdb_chain_ID_.c_str(), 5*sizeof (char) );


// **** number of residues
	int number_of_residue = chain_.size();
	binary_stream.write( (char* ) & number_of_residue , sizeof (int) );


// **** residues names  : 3*sizeof (char) * chain_.size()
	for (int ii=0;ii<chain_.size();ii++)
	{
		string residue_name = chain_[ii]->get_residue_name ();
		binary_stream.write( (char* ) residue_name.c_str() , 3*sizeof (char) );
	}


// **** in chain residue number : 5 * sizeof (char) * chain_.size()  -  identificator from PDB file )
	char buff [5];
	int ii;
	for (ii=0;ii<chain_.size();ii++)
	{
		memset (buff,0,sizeof (5) );

		string  in_chain_residue_number = chain_[ii]->get_in_chain_residue_number ();
		int size = strlen (in_chain_residue_number.c_str() )  ;

		memcpy (buff,in_chain_residue_number.c_str(), size * sizeof (char) );

		binary_stream.write( (char* ) buff, 5 * sizeof (char)  );
	}

// **** serial indfex : sizeof (int) * chain_.size()
	for (ii=0;ii<chain_.size();ii++)
	{
		int serial_index = chain_[ii]->get_serial_index ();
		binary_stream.write( (char* ) & serial_index  , sizeof (int) );
	}

// *** is there coordinates : sizeof (bool) * chain_.size()
	for (ii=0;ii<chain_.size();ii++)
	{
		bool is_there_coord = chain_[ii]->get_is_there_coord ();
		binary_stream.write( (char* ) & is_there_coord , sizeof (bool) );
	}

// *** is geometry admissible : sizeof (bool) * chain_.size()
	for (ii=0;ii<chain_.size();ii++)
	{
		bool is_geometry_admissible = chain_[ii]->get_is_geometry_admissible();
		binary_stream.write( (char* ) & is_geometry_admissible , sizeof (bool) );
	}

// *** coordinates : 9 * sizeof (double) *  chain_.size()
	for (ii=0;ii<chain_.size();ii++)
	{
		bool is_there_coord = chain_[ii]->get_is_there_coord ();
		if ( is_there_coord )
			coord = chain_[ii]->get_coord();
		else
			memset (coord,0,9 * sizeof (double) );

		binary_stream.write( (char* ) coord, 9 * sizeof (double)  );
	}

	delete [] coord ;
}


int Chain_Residue_Set::
get_valid_residue_number ()	const
{
	int counter = 0 ;
	for ( int ii=0; ii < get_length ()	; ii++ )
	{
		if (  chain_[ii]->get_is_there_coord() )
			counter ++;
	}
	return counter ;
}


