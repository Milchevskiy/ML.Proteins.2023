#ifndef FRAGMENT_BASE_DSSP_BRIDGE_H
#define FRAGMENT_BASE_DSSP_BRIDGE_H

#include <string>
#include <fstream>
#include <vector>
#include <map>


#include "Single_dssp_word_container.h"

enum Fragment_base_DSSP_bridge_run_mode
{
	FULL_UP_FRAGMENT_BASE_DSSP_BRIDGE,
	GENERAL_FRAGMENT_BASE_DSSP_BRIDGE_MODE
} 
;

class	Sheduler;
class	Fragment_base_subtle;

using namespace std; 

class  Fragment_base_DSSP_bridge
{

public:
	Fragment_base_DSSP_bridge () {}  ;

	Fragment_base_DSSP_bridge ( 
		const string & bridge_name,
		const Fragment_base_DSSP_bridge_run_mode run_mode) ;

	~Fragment_base_DSSP_bridge ();

	vector <int >get_base_indexes_for_dssp_class ( const string & index_set_name) ;

	Fragment_base_subtle	 * get_fragment_base () const { return fragment_base_; } 

	int get_fragment_length() const {return fragment_length_ ;}

	void print_dssp_word_index_correspondence (const string & dssp_word );


private:
	Sheduler	*sheduler_;			

	string bridge_name_;

	string fragment_base_subtle_name_;

	string fill_up_mode_;

	Fragment_base_subtle	 * fragment_base_;
	int fragment_length_; 

	string dssp_eight_names_ ;


	map <string, vector <int> > dssp_word_to_in_base_index_set_;
	vector <Single_dssp_word_container> dssp_word_and_base_index_container_;

	void fill_up_primitive();
	void fill_up_dssp_word();

	void init_bridge();

	int collect_base_indexes_for_dssp_class_primitive(
		const string &fragment_extended_DSSP_sequence);

	void print_result_for_primitive_index ( 
		vector <vector <int> > & base_indexes_for_dssp_class );

	void print_result_for_dssp_words_by_content ();

	void collect_base_indexes_for_all_possible_dssp_word(
			const string &fragment_extended_DSSP_sequence,
			const int fragment_index_in_base);

	void sort_out_dssp_words_by_content_size();

	

};



#endif