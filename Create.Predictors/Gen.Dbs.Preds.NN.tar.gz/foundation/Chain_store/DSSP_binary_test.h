#ifndef CHAIN_BINARY_TEST_H
#define CHAIN_BINARY_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  DSSP_binary_test : public Simple_test
{
public:
	~DSSP_binary_test ();

    void run()
    {
//		fill_up_test ();
		fill_up_data ();
	//	dummy_dssp_getting_out();


//		fill_up_true_dssp_seq_and_seq_test ();
//		check_some_chain();


        ///find_good_bin_dssp_list();  /// выдает список цепей, которые успешно обработаны DSSP 4.0
      //  analyse_and_compare_DSSP_PB_assignment ();

	}
	void fill_up_test ();
	void fill_up_data ();
	void fill_up_true_dssp_seq_and_seq_test ();
	void check_some_chain();


    void find_good_bin_dssp_list();
    void analyse_and_compare_DSSP_PB_assignment ();
    void dummy_dssp_getting_out();




	};

#endif
