#ifndef PDB_UTIL_H
#define PDB_UTIL_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>

using namespace std;

// gets all lines containing SEQRES in appropriate position
vector < vector <string> >  get_sequence_by_SEQRES ( const vector <string> & seqres_record_pull );

// gets string pull containing SEQRES key word & chain_ID
vector <string>		get_SEQRES_lines ( ifstream & source_stream, const char chain_ID );

// gets string pull containing ATOM   key word & chain_ID
vector <string> get_ATOM_lines (
	ifstream & source_stream,
	const char chain_ID,
	const char  altLoc );

vector <string>		get_chain_sequence_by_SEQRES ( const vector <string> & seqres_record_pull );


bool is_seqres_line (const string & line );
bool is_seqres_line (const string & line, const char chain_ID  );

bool is_atom_line ( const string & line );
bool is_atom_line ( const string & line, const char chain_ID, const int  altLoc  );

bool is_main_chain_atom ( const string & current_atom_name );

bool is_anisou_line ( const string & line,  char chain_ID  ) ;

bool is_TER_line ( const string & line );

vector <string> get_pdb_list (const string & teplate_list_filename);
vector <string> get_pdb_list (); // gets list from default location setted in config file

string solve_the_rebus_to_find_file_by_pdbid (  string & pdb_ID);

#endif
