#include "PDB_util.h"

#include "../Censorship.h"

extern Censorship configuration;
extern ofstream log_stream;


vector < string > get_pdb_list ( )
{
	 string full_path_pdb_chain_file_list = 
		configuration.option_meaning("PDBSELECT_file_list_location") ; 	
		

	vector < string > pdb_list;

	vector <string> empty;

	ifstream source_stream ( full_path_pdb_chain_file_list.c_str() );
	if ( ! source_stream ) 	
	{
		cout		<<	full_path_pdb_chain_file_list << " not found in local PDB bank" << endl;
		log_stream	<<	full_path_pdb_chain_file_list  << " not found in local PDB bankc" << endl;
		//return 0;  
		return empty;
	}

	string current_line , word;
	while( source_stream >> word  )
	{
		if (   word [0] != '/' &&  word [0] != '\0' &&  word [0] != '\n' )
			pdb_list.push_back (word);

	}

	return pdb_list;
}