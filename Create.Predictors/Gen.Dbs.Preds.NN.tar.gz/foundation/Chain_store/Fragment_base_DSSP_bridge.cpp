#include "Fragment_base_DSSP_bridge.h"

#include "../Sheduler.h"
#include "../Censorship.h"
#include "../CommonFunc.h"
#include "../Fragment_base/accepted_chain_data.h"
#include "../Fragment_base/Fragment_base_subtle.h" 

#include "DSSP_binary.h"

#include "Single_dssp_word_container.h"

#include <cassert>
#include <locale>
#include <algorithm>


extern ofstream log_stream;
extern Censorship configuration;

Fragment_base_DSSP_bridge ::~Fragment_base_DSSP_bridge ()
{
	 if ( fragment_base_  )
		 delete fragment_base_;
}
 
Fragment_base_DSSP_bridge::
Fragment_base_DSSP_bridge ( 
	const string & bridge_name,
	const Fragment_base_DSSP_bridge_run_mode run_mode) : 
		bridge_name_ ( bridge_name ),
		fragment_base_(0)
{
	sheduler_					= new Sheduler     ( configuration.option_meaning("Path_to_Fragment_base_DSSP_bridge")  + bridge_name_ + string ("/sheduler") ) ;
	fragment_base_subtle_name_	= sheduler_->option_meaning ("FRAGMENT_BASE_SUBTLE_NAME");

	fill_up_mode_				= sheduler_->option_meaning ("FILL_UP_MODE");

	fragment_base_  = new Fragment_base_subtle ( fragment_base_subtle_name_ , FRAGMENT_BASE_SUBTLE_COMMON_USAGE);

	fragment_length_ = fragment_base_ ->get_fragment_length();

	dssp_eight_names_ = "HGIEBSTC?";

	switch ( run_mode  )
	{
		case FULL_UP_FRAGMENT_BASE_DSSP_BRIDGE: 
			if (fill_up_mode_ == "PRIMITIVE_DSSP_CLASS" )
				fill_up_primitive();
			else if (fill_up_mode_ == "DSSP_WORDS" )
				fill_up_dssp_word() ;
			else 
			{
				log_stream	<< "Inadmissible fill_up_mode_ " << endl;
				cout		<< "Inadmissible fill_up_mode_ " << endl;
				throw;
			}
			
			break;
		case GENERAL_FRAGMENT_BASE_DSSP_BRIDGE_MODE:
			init_bridge();
			break;

		default :
			log_stream	<< "Inadmissible run mode for Fragment_base_DSSP_bridge " << endl;
			cout		<< "Inadmissible run mode for Fragment_base_DSSP_bridge " << endl;
			cout		<< "Inadmissible run mode for Frequency class" << endl;
			throw;
	}
}

void Fragment_base_DSSP_bridge::
fill_up_dssp_word() 
{
	int total_fragment_number = fragment_base_->get_total_fragment_number(); 

	string current_pdb_ID_chain_ID = "***";
	DSSP_binary *current_dssp=0;
	string sequence_by_DSSP;		
	string extended_DSSP_sequence;

	int dssp_eight_class_number = dssp_eight_names_.size();
	vector <vector <int> > base_indexes_for_dssp_class; 
	base_indexes_for_dssp_class.resize(dssp_eight_class_number);
/// FIX /// FIX /// FIX /// FIX /// FIX /// FIX /// FIX /// FIX  total_fragment_number/1000 
	int ready_chain_counter = 0;
	for (int ii=0; ii<total_fragment_number ;ii++ )
	{
			string	 pdb_ID_chain_ID;
			string	 fragment_sequence_by_base;
			int		 serial_number;
			string   pdb_resudue_number;

			fragment_base_->fill_up_record_items ( 
				ii,
				pdb_ID_chain_ID,
				fragment_sequence_by_base,
				serial_number,
				pdb_resudue_number);

			
			map<int,string> serial_index_to_bridge_partners;

			if (pdb_ID_chain_ID !=  current_pdb_ID_chain_ID )
			{
				ready_chain_counter ++;
				cout << pdb_ID_chain_ID << "  " << ii << "  " << ready_chain_counter << endl;

				if (  current_dssp)
					delete current_dssp;
				
				current_dssp = new DSSP_binary(pdb_ID_chain_ID,COMMON_USAGE) ;
				current_pdb_ID_chain_ID = pdb_ID_chain_ID;
				serial_index_to_bridge_partners =  current_dssp->get_serial_index_to_bridge_partners();
				sequence_by_DSSP			= current_dssp->get_sequence();
				extended_DSSP_sequence	= current_dssp->get_extended_DSSP_sequence();
			}

			//string sequence_by_DSSP			= current_dssp->get_sequence();
			//string extended_DSSP_sequence	= current_dssp->get_extended_DSSP_sequence();

			//current_dssp->get_serial_index_to_bridge_partners()

			string fragment_sequence_by_DSSP   =  sequence_by_DSSP.substr(serial_number,fragment_length_);
			fragment_sequence_by_DSSP = correct_fummy_DSSP_aa_seq (fragment_sequence_by_DSSP);


			string fragment_extended_DSSP_sequence = extended_DSSP_sequence.substr(serial_number,fragment_length_);
			fragment_extended_DSSP_sequence = correct_extended_DSSP_sequence (fragment_extended_DSSP_sequence);
			 

			assert (fragment_sequence_by_DSSP  == fragment_sequence_by_base );

			collect_base_indexes_for_all_possible_dssp_word(
				fragment_extended_DSSP_sequence,
				ii);

	//		int index_for_add = collect_base_indexes_for_dssp_class_primitive(fragment_extended_DSSP_sequence);
	//		base_indexes_for_dssp_class[index_for_add].push_back(ii);
	
	}
// ����������� �� ������� ��������� ���������� dssp_word_to_in_base_index_set_ (�.�. �� ����� ��������� index_set.size() )
// ��� ����������� Single_dssp_word_container
	sort_out_dssp_words_by_content_size();

	print_result_for_dssp_words_by_content ();

/*	for (int ii=0;ii<dssp_word_and_base_index_container_.size();ii++ )
	{
		
	}
*/
	//print_result_for_primitive_index (base_indexes_for_dssp_class); 

}

void Fragment_base_DSSP_bridge::
print_result_for_dssp_words_by_content ()
{
	string path_to_protocol_store = configuration.option_meaning("Path_to_Fragment_base_DSSP_bridge")  + bridge_name_ + string ("/protocol/");

	for (int ii=0;ii<dssp_word_and_base_index_container_.size();ii++ )
	{
		string current_word = dssp_word_and_base_index_container_[ii].get_dssp_word();

		int size = current_word.size();
		for (int kk=0;kk<size;kk++)
			current_word[kk] = (current_word[kk] == '?' ) ? 'u' : current_word[kk];

		string output_file_name= path_to_protocol_store + current_word;

		ofstream out ( output_file_name.c_str());
		if ( ! out )	{	
			log_stream	 << "ERROR -  can't create dssp_words file" << output_file_name<< endl;
			cout		 << "ERROR -  can't create dssp_words file" << output_file_name<< endl;
			throw;	
		}
		vector < int > in_base_index_set = dssp_word_and_base_index_container_[ii].get_in_base_index_set();
		int size_in_base_index_set = in_base_index_set.size();
		for (int kk=0;kk<size_in_base_index_set;kk++)
		{
			out << in_base_index_set[kk] << endl;
		}
	
	}
}
void Fragment_base_DSSP_bridge::
sort_out_dssp_words_by_content_size()
{
	typedef map<string, vector <int> >   MAP_STRING_VECTOR_INT;
	MAP_STRING_VECTOR_INT::const_iterator theIterator;

	int counter =0;
	for ( theIterator = dssp_word_to_in_base_index_set_.begin();theIterator != dssp_word_to_in_base_index_set_.end();theIterator ++ ) 
	{
		string key			=	(*theIterator).first ;
		vector <int> value	=   (*theIterator).second ;

			Single_dssp_word_container curr_object(
				key,value);
			dssp_word_and_base_index_container_.push_back(curr_object);
	}

	sort(	dssp_word_and_base_index_container_.begin(),	dssp_word_and_base_index_container_.end() );


};
void Fragment_base_DSSP_bridge::
fill_up_primitive() 
{
	int total_fragment_number = fragment_base_->get_total_fragment_number(); 

	string current_pdb_ID_chain_ID = "***";
	DSSP_binary *current_dssp=0;
	string sequence_by_DSSP;		
	string extended_DSSP_sequence;

	int dssp_eight_class_number = dssp_eight_names_.size();
	vector <vector <int> > base_indexes_for_dssp_class; 
	base_indexes_for_dssp_class.resize(dssp_eight_class_number);

	int ready_chain_counter = 0;
	for (int ii=0; ii<total_fragment_number ;ii++ )
	{
			string	 pdb_ID_chain_ID;
			string	 fragment_sequence_by_base;
			int		 serial_number;
			string   pdb_resudue_number;

			fragment_base_->fill_up_record_items ( 
				ii,
				pdb_ID_chain_ID,
				fragment_sequence_by_base,
				serial_number,
				pdb_resudue_number);

			
			map<int,string> serial_index_to_bridge_partners;

			if (pdb_ID_chain_ID !=  current_pdb_ID_chain_ID )
			{
				ready_chain_counter ++;
				cout << pdb_ID_chain_ID << "  " << ii << "  " << ready_chain_counter << endl;

				if (  current_dssp)
					delete current_dssp;
				
				current_dssp = new DSSP_binary(pdb_ID_chain_ID,COMMON_USAGE) ;
				current_pdb_ID_chain_ID = pdb_ID_chain_ID;
				serial_index_to_bridge_partners =  current_dssp->get_serial_index_to_bridge_partners();
				sequence_by_DSSP			= current_dssp->get_sequence();
				extended_DSSP_sequence	= current_dssp->get_extended_DSSP_sequence();
			}

			//string sequence_by_DSSP			= current_dssp->get_sequence();
			//string extended_DSSP_sequence	= current_dssp->get_extended_DSSP_sequence();

			//current_dssp->get_serial_index_to_bridge_partners()

			string fragment_sequence_by_DSSP   =  sequence_by_DSSP.substr(serial_number,fragment_length_);
			fragment_sequence_by_DSSP = correct_fummy_DSSP_aa_seq (fragment_sequence_by_DSSP);


			string fragment_extended_DSSP_sequence = extended_DSSP_sequence.substr(serial_number,fragment_length_);
			fragment_extended_DSSP_sequence = correct_extended_DSSP_sequence (fragment_extended_DSSP_sequence);
			 

			assert (fragment_sequence_by_DSSP  == fragment_sequence_by_base );

			int index_for_add = collect_base_indexes_for_dssp_class_primitive(fragment_extended_DSSP_sequence);
			base_indexes_for_dssp_class[index_for_add].push_back(ii);
	
	}

	print_result_for_primitive_index (base_indexes_for_dssp_class); 

}
void Fragment_base_DSSP_bridge::
print_result_for_primitive_index ( vector <vector <int> > & base_indexes_for_dssp_class )
{

	string path_to_index_store = configuration.option_meaning("Path_to_Fragment_base_DSSP_bridge")  + bridge_name_ + string ("/");

	int index_size = base_indexes_for_dssp_class.size();
	for (int ii=0;ii<index_size;ii++)
	{
		char current_char_ID = ( dssp_eight_names_[ii] != '?' ) ? dssp_eight_names_[ii] : 'u' ;

		string path_to_current_out_file = 
			path_to_index_store + 
			current_char_ID + 
			string (".in_base_indexes");

		ofstream out ( path_to_current_out_file.c_str(),ios::binary );

		if ( ! out )	{	
			log_stream	 << "ERROR -  can't create in_base_indexes file" << path_to_current_out_file << endl;
			cout		 << "ERROR -  can't create in_base_indexes file" << path_to_current_out_file << endl;
			throw;	
		}
		int index_size_ii = base_indexes_for_dssp_class [ii].size();

		out.write ( (char* ) &index_size_ii, sizeof (int)  );
		for ( int kk=0; kk < index_size_ii ; kk++ )
			out.write ( (char* ) &base_indexes_for_dssp_class [ii][kk], sizeof (int)  );

		out.close();
	}

}

void Fragment_base_DSSP_bridge::
print_dssp_word_index_correspondence (const string & dssp_word )
{


	string path_to_store = configuration.option_meaning("Path_to_Fragment_base_DSSP_bridge") + bridge_name_  + string ("/protocol/") +  dssp_word ;
	ifstream in ( path_to_store .c_str());
	if ( ! in )	{	
		log_stream	 << "ERROR -  can't create in_base_indexes file" << path_to_store << endl;
		cout		 << "ERROR -  can't create in_base_indexes file" << path_to_store << endl;
		throw;	
	}

	string path_to_store_out = path_to_store + ".detailed_description" ;

	ofstream out ( path_to_store_out .c_str());
	if ( ! out )	{	
		log_stream	 << "ERROR -  can't create in_base_indexes file" << path_to_store_out << endl;
		cout		 << "ERROR -  can't create in_base_indexes file" << path_to_store_out<< endl;
		throw;	
	}


	int  current_index ;
	vector <int > base_indexes_for_dssp_words; 
	while (in >> current_index ) 
	{
		base_indexes_for_dssp_words.push_back(current_index );
	}
	

		string current_pdb_ID_chain_ID = "***";
	int ready_chain_counter = 0;
	DSSP_binary *current_dssp = 0;

	string sequence_by_DSSP	;
	string extended_DSSP_sequence;


	int size_bifdc =  base_indexes_for_dssp_words.size();
	for (int ii=0; ii <size_bifdc ;ii++ )
	{
			string	 pdb_ID_chain_ID;
			string	 fragment_sequence_by_base;
			int		 serial_number;
			string   pdb_resudue_number;

			fragment_base_->fill_up_record_items ( 
				base_indexes_for_dssp_words[ii],
				pdb_ID_chain_ID,
				fragment_sequence_by_base,
				serial_number,
				pdb_resudue_number);

			if (pdb_ID_chain_ID !=  current_pdb_ID_chain_ID )
			{
				ready_chain_counter ++;
				cout << pdb_ID_chain_ID << "  " << ii << "  " << ready_chain_counter << endl;
				out  << pdb_ID_chain_ID << "  " << ii << "  " << ready_chain_counter << endl;

				if (  current_dssp)
					delete current_dssp;
				
				current_dssp = new DSSP_binary(pdb_ID_chain_ID,COMMON_USAGE) ;
				current_pdb_ID_chain_ID = pdb_ID_chain_ID;
	//			serial_index_to_bridge_partners =  current_dssp->get_serial_index_to_bridge_partners();
				sequence_by_DSSP			= current_dssp->get_sequence();
				extended_DSSP_sequence	= current_dssp->get_extended_DSSP_sequence();
			}


			string fragment_sequence_by_DSSP   =  sequence_by_DSSP.substr(serial_number,fragment_length_);
			fragment_sequence_by_DSSP = correct_fummy_DSSP_aa_seq (fragment_sequence_by_DSSP);

			string fragment_extended_DSSP_sequence = extended_DSSP_sequence.substr(serial_number,fragment_length_);
			fragment_extended_DSSP_sequence = correct_extended_DSSP_sequence (fragment_extended_DSSP_sequence);

			out  << base_indexes_for_dssp_words[ii] << "\t" << serial_number << "\t" << pdb_resudue_number << "\t" 
				  << fragment_sequence_by_base << "\t" << fragment_sequence_by_DSSP << "\t"  <<
				  fragment_extended_DSSP_sequence << endl;

	}

}

void Fragment_base_DSSP_bridge::
collect_base_indexes_for_all_possible_dssp_word(
const string &fragment_extended_DSSP_sequence,
const int fragment_index_in_base)
{
	//map <string, vector <int> > dssp_word_to_in_base_index_set;
	vector <int> index_set; 
	index_set.resize(0);
	if ( dssp_word_to_in_base_index_set_.find(fragment_extended_DSSP_sequence) == dssp_word_to_in_base_index_set_.end()  ) 
	{
		index_set.push_back(fragment_index_in_base);
	}
	else 
	{
		index_set = dssp_word_to_in_base_index_set_[fragment_extended_DSSP_sequence];
		index_set.push_back(fragment_index_in_base);
	}
	dssp_word_to_in_base_index_set_[fragment_extended_DSSP_sequence] = index_set;
}

// dssp ��������� ������������ ������� ��������� ���������� ������. 
int Fragment_base_DSSP_bridge::
	collect_base_indexes_for_dssp_class_primitive(
		const string &fragment_extended_DSSP_sequence)
{
	int shift = fragment_length_/2;

	
// dssp_eight_names_ = "HGIEBSTC?";

	switch (fragment_extended_DSSP_sequence[shift]) 
	{
		case 'H':
			return 0;
		case 'G':
			return 1;
		case 'I':
			return 2;
		case 'E':
			return 3;
		case 'B':
			return 4;
		case 'S':
			return 5;
		case 'T':
			return 6;
		case 'c':
			return 7;
		case '?':
			return 8;
		default:
			cout		<< "Inadmissible symblol for dssp_eight_names_" << endl;
			return -1;
	}

}
vector <int > Fragment_base_DSSP_bridge::
get_base_indexes_for_dssp_class ( 
	const string & index_set_name) 
{
	string path_to_index_store = configuration.option_meaning("Path_to_Fragment_base_DSSP_bridge")  + bridge_name_ + string ("/");

	string path_to_in_file = 
		path_to_index_store + 
		index_set_name + 
		string (".in_base_indexes");

		ifstream in ( path_to_in_file .c_str(),ios::binary );

		if ( ! in )	{	
			log_stream	 << "ERROR -  can't create in_base_indexes file" << path_to_in_file << endl;
			cout		 << "ERROR -  can't create in_base_indexes file" << path_to_in_file << endl;
			throw;	
		}

		int index_set_size;
		in.read( (char* ) &index_set_size, sizeof (int) );	
		
		vector <int> base_indexes_for_dssp_class;
		base_indexes_for_dssp_class.resize(index_set_size);

		for (int ii=0;ii<index_set_size;ii++)
			in.read( (char* ) &base_indexes_for_dssp_class[ii], sizeof (int) );	

		return base_indexes_for_dssp_class;

}
void Fragment_base_DSSP_bridge::
init_bridge()
{



}


