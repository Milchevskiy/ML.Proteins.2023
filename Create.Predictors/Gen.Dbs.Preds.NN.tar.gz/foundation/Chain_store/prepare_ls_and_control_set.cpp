#pragma warning( disable : 4786 )

#include "../CommonFunc.h"
#include "../Censorship.h"

//#include "accepted_chain_data.h"

#include <fstream>

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;




void prepare_ls_and_control_set(
    const string &source_name,
    const int ls_control_rate,
    const int init_shift)
{

    ostringstream ost;
    ost << source_name<< "_" << ls_control_rate <<  "_" << init_shift;

    string out_file = ost.str() ;
    string out_file_learning_sample =  configuration.option_meaning("Path_to_Chain_store") + out_file + ".learning_sample";
    string out_file_control         =  configuration.option_meaning("Path_to_Chain_store") + out_file + ".control";

    string in_file_source = configuration.option_meaning("Path_to_Chain_store") + source_name;

    ifstream source_stream ( in_file_source.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << in_file_source<< endl;
  		cout		        << "ERROR -  can't find binary file" << in_file_source<< endl;
  		exit (1);
  	}


    ofstream learning_sample_stream ( out_file_learning_sample.c_str() );
    if ( ! learning_sample_stream )	{
      log_stream	   << "ERROR -  can't  file" << out_file_learning_sample<< endl;
      cout		      << "ERROR -  can't find file" << out_file_learning_sample<< endl;
      exit (1);
    }

    string text_file_name = configuration.option_meaning("Path_to_Chain_store") +		source_name;

	ofstream control_stream ( out_file_control.c_str() );
	if ( ! control_stream )	{
		log_stream	  << "ERROR -  can't find binary file" << out_file_control<< endl;
		cout		      << "ERROR -  can't find binary file" << out_file_control<< endl;
		exit (1);
	}

	string current_line;
	int local_counter = 0;
	int counter = 0;
	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;
    counter++;
    if ( (counter + init_shift)% ls_control_rate )
      learning_sample_stream << current_line << endl;
    else
      control_stream << current_line << endl;

	}






}
