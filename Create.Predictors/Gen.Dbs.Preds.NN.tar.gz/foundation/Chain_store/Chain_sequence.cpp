#pragma warning( disable : 4786 )

#include "Chain_sequence.h"

#include "PDB_util.h"
#include "tri_to_one_and_vice_versa_aa_translation.h"

#include "../Censorship.h"

#include <iostream>
#include <cctype>
#include <sstream>

extern Censorship configuration;
extern ofstream log_stream;


Chain_sequence::Chain_sequence (
    const string &full_path_to_pdb_file,
    char  chain_ID)
{


	ifstream source_stream ( full_path_to_pdb_file.c_str() );
	if ( ! source_stream )
	{
		cout		<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		log_stream	<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		return;
	}

    string current_line;
	getline(source_stream,current_line,'\n' );
	string rude_pdb_ID = current_line.substr(59,current_line.size()-58);

	string pdb_ID;
	istringstream ist ( rude_pdb_ID  );
	ist >> pdb_ID;

    chain_ID = toupper(chain_ID);

	pdb_chain_ID_ = pdb_ID + chain_ID;


	vector <string> seqres_record_pull = get_SEQRES_lines	( source_stream, chain_ID );

	tri_letter_sequence_ = 	get_chain_sequence_by_SEQRES		( seqres_record_pull );
}




Chain_sequence::Chain_sequence ( const string & pdb_chain_ID ) :
  pdb_chain_ID_	( pdb_chain_ID )
{
    int ttt=  pdb_chain_ID.size() ;
	if ( pdb_chain_ID.size() != 5 )
	{
		cout		<<	pdb_chain_ID  << ": strange pdb_chain_ID " << endl;
		log_stream	<<	pdb_chain_ID  << ": strange pdb_chain_ID " << endl;
		return;
	}

	//char	chain_ID =  toupper ( pdb_chain_ID[4] );  // convert to upper letter case
	char	chain_ID =   pdb_chain_ID[4];
	string	pdb_ID   =  pdb_chain_ID.substr(0,4);

    if (chain_ID == '_')
		chain_ID = ' ';

/// In case if all files collected in single directory
  	///string full_path_to_pdb_file =
///		configuration.option_meaning("Path_to_PDB_store") + string ("pdb")	+
///		pdb_ID + string (".ent");

/// file storing like original new protein bank style
    string full_path_to_pdb_store  =
        configuration.option_meaning("Path_to_PDB_store") ;

    string local_pdbbank_path = solve_the_rebus_to_find_file_by_pdbid (pdb_ID);

    string full_path_to_pdb_file = full_path_to_pdb_store + local_pdbbank_path;



	ifstream source_stream ( full_path_to_pdb_file.c_str() );
	if ( ! source_stream )
	{
		cout		<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		log_stream	<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
		return;
	}

	vector <string> seqres_record_pull = get_SEQRES_lines	( source_stream, chain_ID );

	tri_letter_sequence_ = 	get_chain_sequence_by_SEQRES		( seqres_record_pull );
}


string Chain_sequence::
get_one_letter_sequence () const
{
	return tri_to_one_letter_sequence ( tri_letter_sequence_ ) ;
}

