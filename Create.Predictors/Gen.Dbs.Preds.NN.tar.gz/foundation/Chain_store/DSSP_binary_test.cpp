
#pragma warning( disable : 4786 )

#include "DSSP_binary_test.h"
#include "DSSP_binary.h"

#include "../Fragment_base/Chain_binary.h"

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>

#include "tri_to_one_and_vice_versa_aa_translation.h"

#include "../Fragment_base/accepted_chain_data.h"



#include "../../../PB_RMSD/foundation/PB_RMSD.h"
#include "../../../PB_RMSD/foundation/pb16_to_index.h"


#include <bits/stdc++.h>

// Comparator function to sort pairs
// according to second value
bool cmp(pair<string, int>& a,
         pair<string, int>& b)
{
    return a.second > b.second;
}
/*
void sort(map<string, int>& M)
{

    // Declare vector of pairs
    vector<pair<string, int> > A;

    // Copy key-value pair from Map
    // to vector of pairs
    for (auto& it : M) {
        A.push_back(it);
    }

    // Sort using comparator function
    sort(A.begin(), A.end(), cmp);

    // Print the sorted value
    for (auto& it : A) {

        cout << it.first << ' '
             << it.second << endl;
    }
}
*/

// Function to sort the map according
// to value in a (key-value) pairs

//#include "../Fragment_base/Chain_binary_test.h"
void handle_occurence_DSSP(const string &RMSD_set, map <string,int> &occurence_SW,const int SW_length);






using namespace std;

extern ofstream log_stream;

DSSP_binary_test::~DSSP_binary_test()
{
	cout << "DSSP_binary_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;

}



void DSSP_binary_test::find_good_bin_dssp_list()
{

	vector < string >	accepted_chain_ID_list;
	vector < int >      accepted_chain_lenth;
	string				path_to_accepted_chain_list_file;

//	const string in_file_source =  "/home/milch/projects/Didona/Store/Chain_store/Culled_30";
	const string in_file_source =  "/home/milch/projects/Didona/Store/Chain_store/__Culled_30";


/*	string binary_file_name ("accepted_chain_list.bin");

	fill_up_accepted_chain_data (
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name );
*/



//	accepted_chain_ID_list.push_back("3DELB");

    ifstream source_stream ( in_file_source.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't open file" << in_file_source<< endl;
  		cout		        << "ERROR -  can't open binary file" << in_file_source<< endl;
  		exit (1);
  	}


  	const string good_bin_dssp_list="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/binary/good_bin_dssp_list";
    ofstream out ( good_bin_dssp_list.c_str() );
  	if ( ! out )	{
  		log_stream	        << "ERROR -  can't create file" << good_bin_dssp_list<< endl;
  		cout		        << "ERROR -  can't create file" << good_bin_dssp_list<< endl;
  		exit (1);
  	}



  	string current_line;


	int counter = 0;
	vector <string> wrong_pdb_list;
	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;


		accepted_chain_ID_list.push_back(cu_chain_ID);
        counter++;

    }




	for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
	{
        cout << ii << " " << accepted_chain_ID_list[ii] << endl;

		DSSP_binary dsb_com(accepted_chain_ID_list[ii],COMMON_USAGE) ;

		string extended_DSSP_sequence = dsb_com.get_extended_DSSP_sequence();

		if (extended_DSSP_sequence.size() == 0 )
            continue;

		int question_mark_number =0;

		for (int kk=0;kk<extended_DSSP_sequence.size();kk++)
		{
            if (extended_DSSP_sequence[kk]=='?')
                question_mark_number++;
		}

		if ( ( (double ) question_mark_number) / extended_DSSP_sequence.size() > 0.9 )
            continue;
        else
            out << accepted_chain_ID_list[ii] <<endl;


	}
}

void DSSP_binary_test::check_some_chain()
{
		DSSP_binary curr_dssp ("1F52A",COMMON_USAGE) ;

		string sequence					= curr_dssp.get_sequence();
		string extended_DSSP_sequence	= curr_dssp.get_extended_DSSP_sequence();
		string tri_letter_DSSP_sequence	= curr_dssp.get_tri_letter_DSSP_sequence();
		cout << sequence					<< endl;
		cout << extended_DSSP_sequence		<< endl;
		cout << tri_letter_DSSP_sequence	<< endl;

}


void DSSP_binary_test::fill_up_test ()
{
//		DSSP_binary dsb_fil("2H5CA",FILL_UP) ;
//		DSSP_binary dsb_com("2H5CA",COMMON_USAGE) ;

		DSSP_binary dsb_com("1AVHB",COMMON_USAGE) ;

		dsb_com.print_protocol();

/*		string sequence = dsb_com.get_sequence();
		string extended_DSSP = dsb_com.get_extended_DSSP_sequence();

		ofstream out ( "D:/Didona/Test/fill_up_true_dssp_seq_and_seq_test");
		if ( ! out )
		{
			log_stream	<< "can't create " << endl;
			cout		 << "can't create " << endl;
			exit (1);
		}
*/
}

void DSSP_binary_test::fill_up_data ()
{

	vector < string >	accepted_chain_ID_list;
	vector < int >      accepted_chain_lenth;
	string				path_to_accepted_chain_list_file;

	//const string in_file_source =  "/home/milch/projects/Didona/Store/Chain_store/Culled_30";
//	const string in_file_source =  "/home/milch/projects/Didona/Store/Chain_store/CB513";

    //const string in_file_source ="/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/CB513.not_empty";

    const string in_file_source         ="/media/milch/Новый том/ML_calculation/CaspDeBrew";

    string path_to_results_store        ="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/quarantine/";

/*
	string binary_file_name ("accepted_chain_list.bin");

	fill_up_accepted_chain_data (
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name );


*/

//	accepted_chain_ID_list.push_back("3DELB");

    ifstream source_stream ( in_file_source.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't open file" << in_file_source<< endl;
  		cout		        << "ERROR -  can't open binary file" << in_file_source<< endl;
  		exit (1);
  	}


  	string current_line;


	int counter = 0;
	vector <string> wrong_pdb_list;
	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;


		accepted_chain_ID_list.push_back(cu_chain_ID);
        counter++;

    }


// //   accepted_chain_ID_list.push_back("1BRSE");
     ///accepted_chain_ID_list.push_back("1YRNA");

	for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
	{
        cout << ii << " " << accepted_chain_ID_list[ii] << endl;

		DSSP_binary dsb_fil(accepted_chain_ID_list[ii],FILL_UP) ;
		DSSP_binary dsb_com(accepted_chain_ID_list[ii],COMMON_USAGE) ;

		dsb_com.print_protocol();


        Chain_binary *chain = new Chain_binary(accepted_chain_ID_list[ii]);

		string sequence = chain->get_sequence();
		string sequence_by_DSSP         = dsb_com.get_sequence();
		string  extended_DSSP_sequence  = dsb_com.get_extended_DSSP_sequence();



		string path_to_results_file =         path_to_results_store  + accepted_chain_ID_list[ii] + string(".dssp_brief");

		ofstream out ( path_to_results_file.c_str() );
		if ( ! out )
		{
			log_stream	<< "can't create "  << path_to_results_file << endl;
			cout		 << "can't create " << path_to_results_file << endl;
			exit (1);
		}

		out <<  sequence                << endl;
		out <<  sequence_by_DSSP        << endl;
		out <<  extended_DSSP_sequence  << endl;

	}


}
void get_dssp_string_pull(string &path_to_DSSP_source, char target_chain_ID,vector <string> & dssp_string_pull);
void  fill_up_dssp_maps(
    vector <string> & dssp_string_pull,
    map <string,char> & d_residue_number_to_aa,
    map <string,char> &d_residue_number_to_dssp);

void DSSP_binary_test::dummy_dssp_getting_out()
{

   const string in_file_source ="/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/CB513.not_empty";


    ifstream source_stream ( in_file_source.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't open file" << in_file_source<< endl;
  		cout		        << "ERROR -  can't open binary file" << in_file_source<< endl;
  		exit (1);
  	}
  	int counter = 0;

  	vector < string >	accepted_chain_ID_list;
  	string current_line;
	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;


		accepted_chain_ID_list.push_back(cu_chain_ID);
        counter++;

    }


  	const string path_to_dssp_store="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/";


	for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
	{
        cout << ii << " " << accepted_chain_ID_list[ii] << endl;

        string temp(accepted_chain_ID_list[ii]);
       	string	pdb_ID   =  temp.substr(0,4);
        char	target_chain_ID = temp[4];

  /*      Chain_binary *chain = new Chain_binary(accepted_chain_ID_list[ii]);
		string sequence = chain->get_sequence();
		vector <string> in_chain_residue_numbers = chain->get_in_chain_residue_number();
*/


        for (int kkk=0;kkk<pdb_ID.size();kkk++)
            pdb_ID[kkk] = tolower(pdb_ID[kkk]);

        string path_to_DSSP_source = path_to_dssp_store + pdb_ID + string(".dssp");
        log_stream << "before dssp_string_pull" << endl;
        vector <string> dssp_string_pull;
        get_dssp_string_pull(path_to_DSSP_source, target_chain_ID,dssp_string_pull);
        log_stream << "after dssp_string_pull" << endl;


        map <string,char> d_residue_number_to_aa;
        map <string,char> d_residue_number_to_dssp;


        log_stream << "before fill_up_dssp_maps" << endl;
        fill_up_dssp_maps(dssp_string_pull,d_residue_number_to_aa,d_residue_number_to_dssp);

       // int seq_len = sequence.size();
        int seq_len =1000;
        string dssp_sequence; dssp_sequence.resize(seq_len);
        string d_aa_sequence; d_aa_sequence.resize(seq_len);

        log_stream << "after fill_up_dssp_maps" << endl;

        for (int kkk=0;kkk<seq_len;kkk++)
        {
            dssp_sequence[kkk]='?';
            d_aa_sequence[kkk]='?';
        }

/*
        for (int kkk=0;kkk<in_chain_residue_numbers.size();kkk++)
        {
            string curr_residue_numbers = in_chain_residue_numbers[kkk];
            if ( d_residue_number_to_dssp.find(curr_residue_numbers) != d_residue_number_to_dssp.end()  )
            {
                dssp_sequence[kkk] = d_residue_number_to_dssp   [curr_residue_numbers];
                char d_aa = d_residue_number_to_aa              [curr_residue_numbers];
                if ( islower (d_aa))
                    d_aa= 'C';

               d_aa_sequence[kkk] =   d_aa  ;

               assert (d_aa==sequence[kkk]);

            }


        }

        string path_to_result = path_to_dssp_store + accepted_chain_ID_list[ii] + string(".rseq");
        ofstream out ( path_to_result.c_str() );
        if ( ! out )	{
            log_stream	        << "ERROR -  can't open file" << path_to_result<< endl;
            cout		        << "ERROR -  can't open binary file" << path_to_result<< endl;
            exit (1);
        }
*/
/*
        out << sequence << endl;
        out << d_aa_sequence << endl;
        out << dssp_sequence << endl;
*/

//    delete chain;
    }



}
void  fill_up_dssp_maps(
    vector <string> & dssp_string_pull,
    map <string,char> & d_residue_number_to_aa,
    map <string,char> &d_residue_number_to_dssp)
{
//    1    2 A L              0   0  168      0, 0.0     2,-0.1     0, 0.0     3,-0.0   0.000 360.0 360.0 360.0 114.5   -9.7  -13.3   53.4
//   16   20 A T  H  X S+     0   0   83     -4,-2.2     4,-1.9    -5,-0.2    -1,-0.2   0.937 110.6  41.6 -59.2 -52.8   37.1   -9.1   17.3
//    6    6 A I  E     +ab  39  69A   1     32,-3.5    34,-3.7    -2,-0.5     2,-0.3  -0.939  20.8 174.2-115.1 128.8   14.7   23.4   61.9
// 123456789 123456789 123456789 123456789

    for (int ii=0;ii<dssp_string_pull.size();ii++)
    {
        char aa     =dssp_string_pull[ii][13];
        char dssp   =dssp_string_pull[ii][16];

        string tmp   = dssp_string_pull[ii].substr(5,5);

        string d_residue_number;
		string key,meaning;
		{
            istringstream ist (tmp);
            ist >>d_residue_number;
		}

		if ( d_residue_number_to_aa.find(d_residue_number) == d_residue_number_to_aa.end()  )
        {
            d_residue_number_to_aa[d_residue_number] = aa  ;
        }
        else
        {
            cout << "ERROR! Multiple occurence" << d_residue_number << endl;
        }


   		if ( d_residue_number_to_dssp.find(d_residue_number) == d_residue_number_to_dssp.end()  )
        {
            d_residue_number_to_dssp[d_residue_number] = dssp  ;
        }
        else
        {
            cout << "ERROR! Multiple occurence" << d_residue_number << endl;
        }






    }
}


void get_dssp_string_pull(string &path_to_DSSP_source, char target_chain_ID,vector <string> & dssp_string_pull)
{

    vector <string> data_string_pull;

	ifstream dssp_stream  ( path_to_DSSP_source.c_str() );
	if ( ! dssp_stream )
	{
		cout		<<	path_to_DSSP_source  << " not found in local PDB bank" << endl;
		log_stream	<<	path_to_DSSP_source  << " not found in local PDB bank" << endl;
		exit(-1);
	}


	string current_line;
	for (int ii=0;ii<28;ii++)
	{
        getline( dssp_stream  , current_line, '\n' );
	}
// 123456789 123456789 123456789 123456789
//   10  266 A S  S    S+     0   0   31      2,-0.2     4,-0.1     8,-0.0     7,-0.1  -0.949 107.2  10.7-155.7 160.6   50.6   65.1    6.6
//   11  267 A G  S >  S+     0   0   57     -2,-0.3     3,-1.9     2,-0.1     2,-0.4  -0.219 115.9   7.0  64.7-149.6   49.4   64.5    3.1


	while( getline( dssp_stream  , current_line, '\n' ) )
	{
		if (current_line.size() < 3 )
			break;// это конец


		char curren_chain_ID = current_line[11];

		if ( target_chain_ID != curren_chain_ID )
			continue;
		else
            data_string_pull.push_back(current_line);
            log_stream	<<	current_line << endl;



	}
	 log_stream	<<	"get_dssp_string_pull END" << endl;
}





void DSSP_binary_test::fill_up_true_dssp_seq_and_seq_test ()
{
		DSSP_binary dsb_fil("2H5CA",COMMON_USAGE) ;

		ofstream out ( "D:/Didona/Test/fill_up_true_dssp_seq_and_seq_test");
		if ( ! out )
		{
			log_stream	<< "can't create " << endl;
			cout		 << "can't create " << endl;
			exit (1);
		}

		string sequence					= dsb_fil.get_sequence();
		string extended_DSSP_sequence	= dsb_fil.get_extended_DSSP_sequence();
		string tri_letter_DSSP_sequence	= dsb_fil.get_tri_letter_DSSP_sequence();

		for (int ii=0;ii<sequence.size();ii++)
		{
			out << sequence[ii]	<< '\t';
			out << extended_DSSP_sequence[ii]	<<  '\t';;
			out << tri_letter_DSSP_sequence[ii]	<< endl;
		}
}

void handle_occurence_DSSP(const string &RMSD_set, map <string,int> &occurence_SW,const int SW_length)
{
    int assignment_length = RMSD_set.size();
    for (int ii=0;ii<assignment_length-SW_length+1;ii++)
    {
        string cu_SW= RMSD_set.substr(ii,SW_length);
        if ( occurence_SW.find(cu_SW) == occurence_SW.end()  )
		{

				occurence_SW[cu_SW] = 1;
		}
		else
		{
				int curr_occurence = occurence_SW[cu_SW];
				occurence_SW[cu_SW] = curr_occurence+1;
		}

		int test = occurence_SW.size();

    }
}
