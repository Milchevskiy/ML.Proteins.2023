#ifndef FRAGMENT_BASE_DSSP_BRIDGE_TEST_H
#define FRAGMENT_BASE_DSSP_BRIDGE_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Fragment_base_DSSP_bridge_test: public Simple_test
{
public:
	~Fragment_base_DSSP_bridge_test();

    void run()
    {
		fill_up_test();
		//get_base_indexes_for_dssp_class_test();

		//fill_up_dssp_word_test();

		print_dssp_word_index_correspondence_test();
	}
	void fill_up_dssp_word_test();
	void fill_up_test();
	void get_base_indexes_for_dssp_class_test();
	void print_dssp_word_index_correspondence_test();
};

#endif
