#ifndef PEROTOPTATSJA_H
#define PEROTOPTATSJA_H

#include <vector>
#include <string>
#include <map>

using namespace std; 

class Perotoptatsja 
{

public:
	Perotoptatsja () {}

	Perotoptatsja (
		string & in_chain_residue_number,
		string & atom_name,
		string & residue_name,
		double & x,
		double & y,
		double & z) ;

	string get_residue_name					() const { return residue_name_;} 
	string get_atom_name					() const { return atom_name_;} 
	string get_in_chain_residue_number		() const { return in_chain_residue_number_;} 

	void fill_up_coord ( double *coord );

	double get_x() const { return x_;} 
	double get_y() const { return y_;} 
	double get_z() const { return z_;} 

private:	

	string in_chain_residue_number_;
	string atom_name_;
	string residue_name_;
	double coord_[3];
	double x_;
	double y_;
	double z_;

};



#endif