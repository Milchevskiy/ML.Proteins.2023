#include "../CommonFunc.h"

string qqq_test (string & ttt)
{
    return "AAAAAAAAAA";
}
