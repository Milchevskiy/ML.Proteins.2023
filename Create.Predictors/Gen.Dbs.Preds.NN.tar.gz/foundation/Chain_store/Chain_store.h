#ifndef CHAIN_STORE_H
#define CHAIN_STORE_H

#include <string>
#include <fstream>
#include <vector>
#include <map>

#include "Chain_store_run_mode.h"

class	Sheduler;

using namespace std;

class  Chain_store
{

public:
	Chain_store () {}  ;

	Chain_store ( const string & pdb_file_list ) ;

	Chain_store ( const string & pdb_chain_file_list,
			  const Chain_store_run_mode run_mode  ) ;

	Chain_store(vector < string >  & pdb_list);

	~Chain_store ();

private:
	Sheduler	*sheduler_;
	bool		is_empty_;

	void add_rejected_list (
	  ofstream &reject_stream,
	  const string & pdb_chain_ID,
	  const string & exlanation );


	void add_accepted_list (
	  ofstream &reject_stream,
	  const string & pdb_chain_ID,
	  const string & exlanation );

	int accepted_chain_number_;
	int rejected_chain_number_;
};


#endif
