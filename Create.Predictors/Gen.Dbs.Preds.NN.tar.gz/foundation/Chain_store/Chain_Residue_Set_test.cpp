#include "Chain_Residue_Set_test.h"
#include "../Fragment_base/Chain_binary.h"
#include "../CommonFunc.h"
#include "../Fragment_base/accepted_chain_data.h"
#include "../aminoacid_to_index.h"
#include "../Censorship.h"
#include <fstream>

#include "../Censorship.h"

#include "../CommonFunc.h"

#include "../Sheduler.h"

#include "PDB_util.h"

#include "Chain_Residue_Set.h"

extern ofstream log_stream;
extern Censorship configuration;

Chain_Residue_Set_test::~Chain_Residue_Set_test(){}

void Chain_Residue_Set_test::old_jopa()
{

	Sheduler *sheduler = new Sheduler(configuration.option_meaning("Path_to_Chain_store") + string("sheduler"));

	double Treshold_C_N_Distance = atof(sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str());
	double distance_epsilon = atof(sheduler->option_meaning("DISTANCE_EPSILON").c_str());
	double angle_epsilon = atof(sheduler->option_meaning("ANGLE_EPSILON").c_str());;

	//string current_pdb_id = string("4HB1A");
    string current_pdb_id = string("6EMKI");
		Chain_Residue_Set crs(
			current_pdb_id,
			Treshold_C_N_Distance,
			distance_epsilon,
			angle_epsilon);

		crs.print_protocol();

		crs.save_as_binary();


    delete sheduler;

}



void Chain_Residue_Set_test::debug_protocol_handling()
{

	Sheduler *sheduler = new Sheduler(configuration.option_meaning("Path_to_Chain_store") + string("sheduler"));

	double Treshold_C_N_Distance = atof(sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str());
	double distance_epsilon = atof(sheduler->option_meaning("DISTANCE_EPSILON").c_str());
	double angle_epsilon = atof(sheduler->option_meaning("ANGLE_EPSILON").c_str());;

	string current_pdb_id = string("2FULA");

		Chain_Residue_Set crs(
			current_pdb_id,
			Treshold_C_N_Distance,
			distance_epsilon,
			angle_epsilon);

		crs.print_protocol();

    delete sheduler;

}


