#include <cassert>

#include "../Censorship.h"
#include "PDB_util.h"
#include "../CommonFunc.h"


//extern Censorship configuration;

extern ofstream log_stream;

using namespace std;

string solve_the_rebus_to_find_file_by_pdbid (  string & pdb_ID)
{

   assert(pdb_ID.size() == 4 );
    if (pdb_ID.size() != 4 )
    {
        log_stream  <<  "PDB_ID Error.  in solve_the_rebus_to_find_file_by_pdbid. size = " << pdb_ID.size();
        exit (-1);
    }

    for ( int ii=0;ii<pdb_ID.size();ii++)
        pdb_ID [ii] = tolower(pdb_ID [ii]);


    string result = "/";
    result += pdb_ID[1];
    result += pdb_ID[2];
    result += "/pdb";
    result += pdb_ID;
    result += ".ent";

     return result;

}

