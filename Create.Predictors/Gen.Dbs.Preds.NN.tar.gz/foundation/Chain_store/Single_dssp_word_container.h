#ifndef SINGLE_DSSP_WORD_CONTAINER_H
#define SINGLE_DSSP_WORD_CONTAINER_H

#include <string>
#include <fstream>
#include <vector>
#include <map>

using namespace std;


class Single_dssp_word_container  
{

public:
	Single_dssp_word_container (
		string & dssp_word,
		vector <int> &in_base_index_set);

	string get_dssp_word () const { return dssp_word_; }
	
	vector <int> get_in_base_index_set() const { return in_base_index_set_; }

	double	size_in_base_index_set () const { return size_in_base_index_set_; } 

 	friend bool     operator >  (  const Single_dssp_word_container & v1,const Single_dssp_word_container & v2 ) 
	{ return ( v1.size_in_base_index_set() > v2.size_in_base_index_set() ) ; }
	friend bool     operator <  (  const Single_dssp_word_container & v1,const Single_dssp_word_container & v2 )   
	{ return ( v1.size_in_base_index_set() < v2.size_in_base_index_set() ) ; }
	friend bool     operator == (  const Single_dssp_word_container & v1,const Single_dssp_word_container & v2 )   
	{ return ( v1.size_in_base_index_set() == v2.size_in_base_index_set() ) ; }

private:
	int size_in_base_index_set_;  // ������ ��� ����, ����� ����������� �� ���� ����������

	string dssp_word_;
	vector <int> in_base_index_set_;

};


#endif