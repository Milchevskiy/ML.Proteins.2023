// gets all lines containing SEQRES in appropriate position 

#pragma warning( disable : 4786 )

#include "PDB_util.h"

#include <sstream>

vector <string> get_SEQRES_lines ( ifstream & source_stream )
{
	vector <string> seqres_record_pull;
	bool is_reached_yet = false;

	string current_line;
	while ( getline(source_stream,current_line,'\n' ) )
	{
		if ( is_seqres_line ( current_line ) ) 
		{
			if ( is_reached_yet == false )		is_reached_yet = true;
			seqres_record_pull.push_back(current_line);
		}
		else 
		{
			if ( is_reached_yet == true ) 	break;
			else 							continue;
		}
	}
	return seqres_record_pull;
}

vector <string> get_SEQRES_lines ( ifstream & source_stream, const char chain_ID )
{
	vector <string> seqres_record_pull;
	bool is_reached_yet = false;

	string current_line;
	while ( getline(source_stream,current_line,'\n' ) )
	{
		if ( is_seqres_line ( current_line,  chain_ID  ) )
		{
			if ( is_reached_yet == false )		is_reached_yet = true;
			seqres_record_pull.push_back(current_line);
		}
		else 
		{
			if ( is_reached_yet == true ) 	break;
			else 							continue;
		}
	}
	return seqres_record_pull;
}


vector <string>  get_chain_sequence_by_SEQRES ( const vector <string> & seqres_record_pull )
{
	vector < string > current_chain_sequence; 

	for ( int ii=0; ii< seqres_record_pull.size(); ii++ )
	{
		string essentially_space = seqres_record_pull[ii].substr(18,52);
		{
			istringstream ist( essentially_space );
			string current_residue_name;
			while ( ist >> current_residue_name ) 
				current_chain_sequence.push_back( current_residue_name );
		}
	}
	return current_chain_sequence;
}


vector < vector <string> >  get_sequence_by_SEQRES ( const vector <string> & seqres_record_pull )
{

	vector < vector <string> >  sequences_set;

	map < char, char > chain_ID_dummy_map; 
// analysing chain set in SEQRES record

	vector < string > current_chain_sequence; 

	for ( int ii=0; ii< seqres_record_pull.size(); ii++ )
	{
		string	chain_ID_string		= seqres_record_pull[ii].substr(11,1); 
		char	current_chain_ID	= chain_ID_string[0] ;

		if ( chain_ID_dummy_map.find( current_chain_ID ) !=  chain_ID_dummy_map.end()  )
		{
			chain_ID_dummy_map[current_chain_ID] = current_chain_ID;
			if ( current_chain_sequence.size() ) 
			{
				sequences_set.push_back (current_chain_sequence);
				sequences_set.resize(0);
			}
		}

		string essentially_space = seqres_record_pull[ii].substr(18,52);
		{
			istringstream ist( essentially_space );
			string current_residue_name;
			while ( ist >> current_residue_name ) 
				current_chain_sequence.push_back( current_residue_name );
		}
	}

	return sequences_set;
}