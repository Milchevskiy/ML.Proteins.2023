#include "Perotoptatsja.h"

Perotoptatsja::	Perotoptatsja (
		string & in_chain_residue_number,
		string & atom_name,
		string & residue_name,
		double & x,
		double & y,
		double & z):
 in_chain_residue_number_	( in_chain_residue_number ),
 atom_name_					( atom_name ),
 residue_name_				( residue_name ),
 x_ (x),
 y_ (y),
 z_ (z)
{
}

void Perotoptatsja::	
fill_up_coord ( double *coord )
{
	coord[0]=x_;
	coord[1]=y_;
	coord[2]=z_;
};


