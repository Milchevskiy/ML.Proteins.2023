// ���������� ����� �� � ������ Chain_binary �� �������� � ������������ ������� ���� coord_set
#include "../Censorship.h"

#include "../CommonFunc.h"
#include <iostream>
#include <fstream>

#include "../Geometry_util/Fragmrent_tranformation.h"
#include "../by_Qmol/EigenValues3D.h"
#include "../by_Qmol/kabsch_stolen.h"

#include "../tri_to_one_and_vice_versa_aa_translation.h"

void positioning_chain_by_clasters_set(
	double **claster_motif_coordinates,
	const int fragment_length,
	const int number_of_classes,
	double	*coord_set,
	const int number_of_residues,
	bool *  is_geometry_admissible_,
	bool *  is_there_coord_ ,
	vector < vector < double > >  & set_of_coordinate_in_clasters_system,
	const bool is_remove_first_CA, 
	const bool is_remove_last_N	)
{

	//string sequence = get_sequence();
	int current_number_of_fragments = number_of_residues - fragment_length + 1;

//	vector < vector < double > >  set_of_coordinate_in_clasters_system;
	set_of_coordinate_in_clasters_system.resize(current_number_of_fragments);
	for (int ii = 0; ii<current_number_of_fragments; ii++)
	{
		set_of_coordinate_in_clasters_system[ii].resize(number_of_classes);
		for (int ttt = 0; ttt<number_of_classes; ttt++)
			set_of_coordinate_in_clasters_system[ii][ttt] = -1;
	}

	double *cu_cord_set = new double[fragment_length * 9];
	double *w = new double[fragment_length * 9];
	for (int kk = 0; kk<(fragment_length * 9); kk++)
		w[kk] = 1;

	int kk;

	int atom_number_considered = 3 * fragment_length;

	int start_position_in_coord_array = 0;
	if ( is_remove_first_CA )
	{ 
		start_position_in_coord_array = 3;
		atom_number_considered -= 1;
	}
	if (is_remove_last_N)
	{
		atom_number_considered -= 1;
	}


	for (kk = 0; kk< current_number_of_fragments; kk++)
	{

		//extract_fragment(kk, fragment_length, cu_cord_set);
		memcpy(cu_cord_set, coord_set+9*kk, fragment_length * 9 * sizeof(double));

		// check that coorditates  presents 
		bool is_geom_flag = true;
		bool is_coord_flag = true;
	
		int right_stop = kk + fragment_length;
		for (int pp = kk; pp< right_stop; pp++)
		{
			is_geom_flag = is_geom_flag & is_geometry_admissible_[pp];
			is_coord_flag = is_coord_flag & is_there_coord_[pp];
		}
//		if (!is_geom_flag || !is_coord_flag)
		if (!is_coord_flag)  // ������ ���� ������, ����� ���������� ����(���� �����)
			continue;			// ����� ������ ���������� ���  �� ���� �� ����������


		for (int zz = 0; zz<number_of_classes; zz++)
		{
			bool error_flag = true;
			double distance = kabsch_rmsd_flexible_centroid(
				cu_cord_set						+ start_position_in_coord_array,
				claster_motif_coordinates[zz]	+ start_position_in_coord_array,
				w,
				atom_number_considered,
				error_flag);

			set_of_coordinate_in_clasters_system[kk][zz] = distance;
		}
	}
/*
	for (int tt = 0; tt < set_of_coordinate_in_clasters_system.size(); tt++)
	{
		cout << set_of_coordinate_in_clasters_system[tt][0] << "\t" << set_of_coordinate_in_clasters_system[tt][1] << endl;
	}
*/
	delete[] cu_cord_set;		delete[] w;

//	return set_of_coordinate_in_clasters_system;


}