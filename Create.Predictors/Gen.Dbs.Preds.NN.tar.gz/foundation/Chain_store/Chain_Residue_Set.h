#ifndef CHAIN_RESIDUE_SET_H
#define CHAIN_RESIDUE_SET_H

#include <vector>
#include <string>
#include <map>

using namespace std;

class Residue;

class Chain_Residue_Set
{
public:

/// For current server version only !!

    Chain_Residue_Set (
        const string &full_path_to_pdb_file,//PDB_chain_ID ,
        char  chain_ID,
        const double Treshold_C_N_Distance,
        const double distance_epsilon,
        const double angle_epsilon);


	Chain_Residue_Set (
		const string & pdb_chain_ID,
		const double Treshold_C_N_Distance,
		const double distance_epsilon,
		const double angle_epsilon);

	vector < Residue * > get_chain() const { return chain_ ;}

	vector < string >  get_tri_letter_sequence_by_seqres() const { return tri_letter_sequence_by_seqres_;} ;

	bool is_accord_seqres_atom	() const { return is_accord_seqres_atom_ ;}
	bool is_pdb_file			() const { return is_pdb_file_ ;}

	bool is_there_chain         () const { return is_there_chain_;}

	bool is_standard_aminoacisds() const { return is_standard_aminoacisds_;}


	bool is_present_CA_C_N_backbone () const { return is_present_CA_C_N_backbone_;}

	int get_residue_number_by_SERRES () const { tri_letter_sequence_by_seqres_; }
	int get_residue_number_by_coord  () const ;

	void print_protocol ();		// protocol for control fidelity
	void save_as_binary ();		// prepare binary file containig all chain all chain data

	int get_length ()				const { return chain_.size(); }
	int get_valid_residue_number ()	const ;

	string get_pdb_chain_ID () const { return pdb_chain_ID_; }

    vector <string > Error_message_set_for_protocol_;

private:
	string  pdb_chain_ID_ ;

	vector < Residue * > chain_;

	vector < string >  tri_letter_sequence_by_seqres_;

	bool is_accord_seqres_atom_;
	bool is_pdb_file_  ;
	bool is_there_chain_;
	bool is_standard_aminoacisds_;
	bool is_present_CA_C_N_backbone_;

//	void fill_up_chain ( vector <string> atom_record_pull );


	void fill_up_chain (
		vector <string> atom_record_pull,
		const double Treshold_C_N_Distance,
		const double distance_epsilon,
		const double angle_epsilon);

/// По-новому все
	void fill_up_chain_improved (
		vector <string> & atom_record_pull,
		const double Treshold_C_N_Distance,
		const double distance_epsilon,
		const double angle_epsilon);



	bool is_valid_CN_neighbour_distance (
		const Residue * current,
		const Residue * next,
		const double threshold_distance );

	bool compare_seq_set (
		const  vector < Residue * > & shablon,
		const vector < string >     & base,
		int *start_pos  );


  //  vector <string > Error_message_set_for_protocol_;

};

///That's how the world works! And there's nothing to be done about it!
/*
N-CA    1.453  ± 0.15
CA-C    1.53    ± 0.15
C-N     1.325  ± 0.15

C-N-CA 121.0 ± 0.15
N-CA-C 109.3 ± 0.15
CA-C-N 115.0 ± 0.15
*/


#endif
