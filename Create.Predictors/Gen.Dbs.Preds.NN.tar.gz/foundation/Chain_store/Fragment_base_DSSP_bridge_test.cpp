#pragma warning( disable : 4786 )

#include "Fragment_base_DSSP_bridge_test.h"
#include "Fragment_base_DSSP_bridge.h"

#include "../Fragment_base/Chain_binary.h"

#include "../CommonFunc.h"

#include "../Fragment_base/accepted_chain_data.h"

#include "../aminoacid_to_index.h" 

#include "../Censorship.h"

#include <fstream>
#include <string>

#include "../Fragment_base/Fragment_base_subtle.h" 
#include "DSSP_binary.h"

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;

Fragment_base_DSSP_bridge_test::
~Fragment_base_DSSP_bridge_test()
{
	cout << "Fragment_base_DSSP_bridge_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}
void Fragment_base_DSSP_bridge_test::
fill_up_dssp_word_test()
{
	Fragment_base_DSSP_bridge 	
		fr_o(string("Second"),FULL_UP_FRAGMENT_BASE_DSSP_BRIDGE) ;

	// � ������ "Second" � ����� config �������� ����� FILL_UP_MODE  DSSP_WORDS



}

void Fragment_base_DSSP_bridge_test::
fill_up_test()
{

	Fragment_base_DSSP_bridge 	
		fr_o(string("First"),FULL_UP_FRAGMENT_BASE_DSSP_BRIDGE) ;

}
void Fragment_base_DSSP_bridge_test::
get_base_indexes_for_dssp_class_test()
{

	Fragment_base_DSSP_bridge 	
		fr_o(string("First"),GENERAL_FRAGMENT_BASE_DSSP_BRIDGE_MODE) ;

	string path_to_store = configuration.option_meaning("Path_to_Fragment_base_DSSP_bridge") + string ("/First/protocol/S");
	ofstream out ( path_to_store .c_str());
	if ( ! out )	{	
		log_stream	 << "ERROR -  can't create in_base_indexes file" << path_to_store << endl;
		cout		 << "ERROR -  can't create in_base_indexes file" << path_to_store << endl;
		throw;	
	}


	Fragment_base_subtle * fragment_base =  fr_o.get_fragment_base();
	int fragment_length = fr_o.get_fragment_length() ;
	vector <int > base_indexes_for_dssp_class = fr_o.get_base_indexes_for_dssp_class ( "S") ;


	string current_pdb_ID_chain_ID = "***";
	int ready_chain_counter = 0;
	DSSP_binary *current_dssp = 0;

	string sequence_by_DSSP	;
	string extended_DSSP_sequence;


	int size_bifdc =  base_indexes_for_dssp_class.size();
	for (int ii=0; ii <size_bifdc ;ii++ )
	{
			string	 pdb_ID_chain_ID;
			string	 fragment_sequence_by_base;
			int		 serial_number;
			string   pdb_resudue_number;

			fragment_base->fill_up_record_items ( 
				base_indexes_for_dssp_class[ii],
				pdb_ID_chain_ID,
				fragment_sequence_by_base,
				serial_number,
				pdb_resudue_number);

			if (pdb_ID_chain_ID !=  current_pdb_ID_chain_ID )
			{
				ready_chain_counter ++;
				cout << pdb_ID_chain_ID << "  " << ii << "  " << ready_chain_counter << endl;
				out  << pdb_ID_chain_ID << "  " << ii << "  " << ready_chain_counter << endl;

				if (  current_dssp)
					delete current_dssp;
				
				current_dssp = new DSSP_binary(pdb_ID_chain_ID,COMMON_USAGE) ;
				current_pdb_ID_chain_ID = pdb_ID_chain_ID;
	//			serial_index_to_bridge_partners =  current_dssp->get_serial_index_to_bridge_partners();
				sequence_by_DSSP			= current_dssp->get_sequence();
				extended_DSSP_sequence	= current_dssp->get_extended_DSSP_sequence();
			}


			string fragment_sequence_by_DSSP   =  sequence_by_DSSP.substr(serial_number,fragment_length);
			fragment_sequence_by_DSSP = correct_fummy_DSSP_aa_seq (fragment_sequence_by_DSSP);

			string fragment_extended_DSSP_sequence = extended_DSSP_sequence.substr(serial_number,fragment_length);
			fragment_extended_DSSP_sequence = correct_extended_DSSP_sequence (fragment_extended_DSSP_sequence);

			out  << serial_number << "\t" << pdb_resudue_number << "\t" 
				  << fragment_sequence_by_base << "\t" << fragment_sequence_by_DSSP << "\t"  <<
				  fragment_extended_DSSP_sequence << endl;

	}



}

void Fragment_base_DSSP_bridge_test::
print_dssp_word_index_correspondence_test()
{
		Fragment_base_DSSP_bridge 	
		fr_o(string("Second"),GENERAL_FRAGMENT_BASE_DSSP_BRIDGE_MODE) ;

		fr_o.print_dssp_word_index_correspondence("-BB--");



}