#include "DSSP_single_point.h"

DSSP_single_point::	
DSSP_single_point (
	const char  one_letter_aa_name,
	const string & in_chain_residue_number) : 
		one_letter_aa_name_( one_letter_aa_name),
		in_chain_residue_number_(in_chain_residue_number),
		is_there_cysteine_bridge_(false)			
{
	extended_DSSP_name_ = '?';
}
