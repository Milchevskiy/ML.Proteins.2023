#ifndef RESIDUE_H
#define RESIDUE_H

#include <vector>
#include <string>
#include <map>

using namespace std;

class Residue
{
public:
	Residue (	const string in_chain_residue_number,
				const string & name_3,
				const double * chain_coordinates	);

	Residue (	const int serial_index,
				const string & name_3 );

	~Residue ();

	void full_up_coordinates ( const double * chain_coordinates	);

	double * get_coord					() const { return coord_ ;}

	void	set_in_chain_residue_number (  const string in_chain_residue_number) { in_chain_residue_number_ = in_chain_residue_number; }
	string	get_in_chain_residue_number () const { return in_chain_residue_number_; }
	string  get_residue_name			() const { return name_3_; }

	void set_serial_index (  const int serial_index  ) { serial_index_ = serial_index ; }
	int  get_serial_index () const { return serial_index_; }

	void set_is_there_coord (  bool is_there_coord ) { is_there_coord_ = is_there_coord; }
	bool get_is_there_coord () const { return is_there_coord_; }


	void set_is_geometry_admissible(  bool is_geometry_admissible ) { is_geometry_admissible_ = is_geometry_admissible; }
	bool get_is_geometry_admissible () const { return is_geometry_admissible_; }

	void set_point_to_continues_set ( const int point_to_continues_set) { point_to_continues_set_ = point_to_continues_set; }
	int  get_point_to_continues_set ( ) const { return point_to_continues_set_; }


private:
	int		serial_index_;
	string  chain_ID_;
	string  in_chain_residue_number_;
	string  name_3_;
	double  *coord_;
	bool	is_there_coord_;

	bool    is_geometry_admissible_;


	int     point_to_continues_set_;
};

void analyse_backbone_geometry (
	Residue *res_left,
	Residue *res_right,
	const double distance_epsilon,
	const double angle_epsilon	);

#endif

///That's how the world works! And there's nothing to be done about it!
/*
N-CA    1.453  ± 0.15
CA-C    1.53    ± 0.15
C-N     1.325  ± 0.15

C-N-CA 121.0 ± 0.15
N-CA-C 109.3 ± 0.15
CA-C-N 115.0 ± 0.15
*/

///That's how the world works! And there's nothing to be done about it!

#define N_CA    1.453
#define CA_C    1.53
#define C_N     1.325

#define C_N_CA 121.0
#define N_CA_С 109
#define CA_C_N 115.0

