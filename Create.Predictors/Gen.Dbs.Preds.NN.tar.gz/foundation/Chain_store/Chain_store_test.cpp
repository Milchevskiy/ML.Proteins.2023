#pragma warning( disable : 4786 )

#include "Chain_store_test.h"
#include "Chain_store.h"

#include "Chain_Residue_Set.h"


#include "../Fragment_base/Chain_binary.h"

#include "../CommonFunc.h"

#include "../Fragment_base/accepted_chain_data.h"

#include "../aminoacid_to_index.h"

#include "../Censorship.h"

#include <fstream>

#include "../ELM/save_as_fasta.h"

#include "PDB_util.h"

#include "../Geometry_util/Geometry_util.h"

#include "../Sheduler.h"

#include "../Main_model/handle_det_distance_set.h"

#include <cassert>

void prepare_ls_and_control_set(
    const string &source_name,
    const int ls_control_rate,
    const int init_shift);

string get_RESOLUTION_lines (
    ifstream & source_stream );

void assign_guality (
    const string & protocol_quality,
    map<string,double> & ql_map);


void connect_quality_to_pdb_ID_subset(
    map<string,double> & ql_map,
    const string subset_file);


void nonstastard_containing_analise(
     map<string,double> & ql_map,
    const string subset_file);


void check_Chain_binary_geometry(
    const string subset_file);

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;

Chain_store_test::
~Chain_store_test()
{
	cout << "Chain_store_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Chain_store_test::
dist_data_compare_test ()
{

	string external_PDB_chain_ID_list_file =	string("DeBre_LS.existed") ;

	string dist_data_compare_test = "../Test/dist_data_compare_test";

   ofstream out ( dist_data_compare_test.c_str() );
  	if ( ! out )	{
  		log_stream	        << "ERROR -  can't find binary file" << dist_data_compare_test<< endl;
  		cout		        << "ERROR -  can't find binary file" << dist_data_compare_test<< endl;
  		exit (1);
  	}


/*	Sheduler *sheduler = new Sheduler(configuration.option_meaning("Path_to_Chain_store") + string("sheduler"));

	double Treshold_C_N_Distance = atof(sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str());
	double distance_epsilon = atof(sheduler->option_meaning("DISTANCE_EPSILON").c_str());
	double angle_epsilon = atof(sheduler->option_meaning("ANGLE_EPSILON").c_str());;
*/
    vector < string >   accepted_chain_ID_list;

	fill_up_accepted_chain_data_text (
		accepted_chain_ID_list,
		external_PDB_chain_ID_list_file );
   //accepted_chain_ID_list.push_back("1A5IA");

   string good_model = "PB_3";
   string bad_model = "PB_3_june";

     string path_to_good_set =
        configuration.option_meaning("Path_to_Model_store") +
        good_model					+
        "/cross_sum/";

     string path_to_bad_set =
        configuration.option_meaning("Path_to_Model_store") +
        bad_model					+
        "/cross_sum/";



    for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
        {

            string good_name    = path_to_good_set   + accepted_chain_ID_list[ii] + string(".dist_data");
            string bad_name     = path_to_bad_set    + accepted_chain_ID_list[ii] + string(".dist_data");

            vector < vector < double > > good_set   =  read_det_distance_set (good_name);
            vector < vector < double > > bad_set    =  read_det_distance_set (bad_name);

            assert(good_set.size()==bad_set.size() );

            for (int kk=0; kk<good_set.size();kk++)
            {
                for (int zz=0; zz<good_set[kk].size();zz++)
                {
                    if (fabs( good_set[kk][zz] - bad_set[kk][zz] ) > 0.01 )
                    {
                        out << accepted_chain_ID_list[ii] << "\t" << ii << "\t" << kk <<  "\t" ;
                        PutVaDouble(good_set[kk][zz],out,10,3,'l'); out << "/";
                        PutVaDouble(bad_set[kk][zz],out,10,3,'l'); out << endl;

                    }

                }
            }







      }


}
void Chain_store_test:: check_geometry_for_subset()
{
 //       string bad      = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("bad");
        string good     = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("good");
   //     string not_vot  = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("not");

        check_Chain_binary_geometry(good);

}
void Chain_store_test:: clean_out_nonstastard_containing_chains()
{
        string bad      = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("bad");
        string good     = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("good");
        string not_vot  = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("not");


        string protocol_quality  = configuration.option_meaning("Path_to_Model_store") + string("PB_5_1/plain_results/") + string("protocol");
        map<string,double> ql_map;

       assign_guality (protocol_quality,ql_map);

       nonstastard_containing_analise(ql_map,bad);
      nonstastard_containing_analise(ql_map,good);
       nonstastard_containing_analise(ql_map,not_vot);



}

void Chain_store_test:: analyse_quality_for_subsets()
{
        string bad      = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("accepted_l10.bad_xray");
        string good     = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("accepted_l10.good_xray");
        string not_vot  = configuration.option_meaning("Path_to_Chain_store") + string("PB_5_1/") +   string("accepted_l10.not_xray");


        string protocol_quality  = configuration.option_meaning("Path_to_Model_store") + string("PB_5_1/plain_results/") + string("protocol");

        map<string,double> ql_map;

        assign_guality (protocol_quality,ql_map);

        connect_quality_to_pdb_ID_subset(ql_map,bad);
        connect_quality_to_pdb_ID_subset(ql_map,good);
        connect_quality_to_pdb_ID_subset(ql_map,not_vot);

}

void Chain_store_test::collect_xray_list()
{
    string source_name = "PB_5_1/accepted_l10";

    double threshold_value = 3;


    string protocol_name = "PB_5_1/xray_protocol";


    string in_file_source   = configuration.option_meaning("Path_to_Chain_store") + source_name;
    string in_file_protocol = configuration.option_meaning("Path_to_Chain_store") + protocol_name;


    string not_xay  = configuration.option_meaning("Path_to_Chain_store") + source_name + string(".not_xray");
    string bad_xay  = configuration.option_meaning("Path_to_Chain_store") + source_name + string(".bad_xray");
    string good_xay = configuration.option_meaning("Path_to_Chain_store") + source_name + string(".good_xray");





    ifstream source_stream ( in_file_source.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << in_file_source<< endl;
  		cout		        << "ERROR -  can't find binary file" << in_file_source<< endl;
  		exit (1);
  	}

    ofstream protocol_stream ( in_file_protocol.c_str() );
  	if ( ! protocol_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << in_file_protocol<< endl;
  		cout		        << "ERROR -  can't find binary file" << in_file_protocol<< endl;
  		exit (1);
  	}


  	 ofstream not_xay_stream ( not_xay.c_str() );
  	if ( ! not_xay_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" <<not_xay << endl;
  		cout		        << "ERROR -  can't find binary file" <<not_xay << endl;
  		exit (1);
  	}


	 ofstream bad_xay_stream ( bad_xay.c_str() );
  	if ( ! bad_xay_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << bad_xay<< endl;
  		cout		        << "ERROR -  can't find binary file" << bad_xay<< endl;
  		exit (1);
  	}

  		ofstream  good_xay_stream ( good_xay.c_str() );
  	if ( ! good_xay_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" <<good_xay << endl;
  		cout		        << "ERROR -  can't find binary file" <<good_xay << endl;
  		exit (1);
  	}



  	/// PATH TO PDB STORE
    string full_path_to_pdb_store  =        configuration.option_meaning("Path_to_PDB_store") ;

  	string current_line;
	int local_counter = 0;
	int counter = 0;
	vector <string> wrong_pdb_list;
	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;
        counter++;

        string pdb_ID = cu_chain_ID.substr(0,4);
      /// path to pdb

        string local_pdbbank_path = solve_the_rebus_to_find_file_by_pdbid (pdb_ID);
        string full_path_to_pdb_file = full_path_to_pdb_store + local_pdbbank_path;


        ifstream in ( full_path_to_pdb_file.c_str() );
        if ( ! in )
        {
            cout		<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
            log_stream	<<	full_path_to_pdb_file  << " not found in local PDB bank" << endl;
            wrong_pdb_list.push_back(pdb_ID);
            in.close();
            continue;
        }

        string resolution_line = get_RESOLUTION_lines(in);
        protocol_stream << resolution_line << endl;



       if( resolution_line.find("APPLICABLE") != string::npos  )
       {
            not_xay_stream << cu_chain_ID << "  \//" << resolution_line << endl;
            continue;
        }


        string ttt;
        double resolution_value;
        {
            istringstream ist (resolution_line);
            ist >> ttt ;
            ist >> ttt ;
            ist >> ttt ;

            if (ttt != "RESOLUTION.")
            {
                cout		    << "jOPA C RESOLUTION READING " << endl;
                log_stream	    <<	"jOPA C RESOLUTION READING " << endl;
                exit(-1);

            }
            ist >> resolution_value;
        }

        if (resolution_value <=threshold_value)
            good_xay_stream << cu_chain_ID << "  \//" << resolution_line << endl;
        else
            bad_xay_stream << cu_chain_ID << "  \//" << resolution_line << endl;


        in.close();

	}




}

void Chain_store_test::prepare_ls_and_control_set_test() /// отдельно от класса Сhain_store
{

    int ls_control_rate = 4;
    string source_name = "PB_culled/Culled_30";

/*
    prepare_ls_and_control_set(source_name,ls_control_rate,0);
    prepare_ls_and_control_set(source_name,ls_control_rate,1);
    prepare_ls_and_control_set(source_name,ls_control_rate,2);
    prepare_ls_and_control_set(source_name,ls_control_rate,3);


*/




}

void Chain_store_test::prepare_pdb_list_2020_style()
{
   string path_id_pull_pdb_list_90 =
        configuration.option_meaning("Path_to_Model_store") +
        string("Nonredundant_data") +
        string ("/") + string("id_pull_pdb_list_90.txt");


   string path_to_cluster_pdb_id =
        configuration.option_meaning("Path_to_Model_store") +
        string("Nonredundant_data") +
        string ("/") + string("bc-90.out");



   	ifstream  in_stream(path_to_cluster_pdb_id.c_str());
	if (!in_stream) {
		log_stream << "Can't find  file"    << path_to_cluster_pdb_id << endl;
		cout        << "Can't find file"    << path_to_cluster_pdb_id << endl;
		exit(1);
	}


    ofstream  out_stream(path_id_pull_pdb_list_90.c_str());
	if (!out_stream) {
		log_stream << "Can't find  file"    << path_id_pull_pdb_list_90 << endl;
		cout        << "Can't find file"    << path_id_pull_pdb_list_90 << endl;
		exit(1);
	}


    string current_line;
	while( getline( in_stream  , current_line, '\n' ) )
	{
		if (   current_line[0] == '/'  ||
			   current_line[0] == '#'  ||
			   current_line[0] == ' '  ||
			   current_line[0] == '\n' ||
			   current_line[0] == '\0')
			continue;

			string word;

			istringstream ist (current_line);
			ist >>  word;

			if (word.size()!=6)
                continue;

            string pdb_ID = word.substr(0,4) + word[5];

            out_stream << pdb_ID << endl;

   }

   out_stream.close();
   in_stream.close();




  	ifstream  in(path_id_pull_pdb_list_90.c_str());
	if (!in) {
		log_stream << "Can't find tune file" << path_id_pull_pdb_list_90 << endl;
		cout << "Can't find tune file" << path_id_pull_pdb_list_90 << endl;
		exit(1);
	}

	vector < string >   pdb_list;

	string current_word;
	while (in >> current_word)
		pdb_list.push_back(current_word);

	Chain_store ob(pdb_list);


}


void Chain_store_test::
creating_chain_binary_files_for_some_subset_test()
{
	//string path_to_external_PDB_chain_ID_list = "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/list";

    string path_to_shit_rogue =
        configuration.option_meaning("Path_to_Model_store") +
        string("De_Brewern_data") +
        string ("/");

    string path_to_external_PDB_chain_ID_list = path_to_shit_rogue + string("id_pull.txt");


	ifstream  in_stream(path_to_external_PDB_chain_ID_list.c_str());
	if (!in_stream) {
		log_stream << "Can't find tune file" << path_to_external_PDB_chain_ID_list << endl;
		cout << "Can't find tune file" << path_to_external_PDB_chain_ID_list << endl;
		exit(1);
	}

	vector < string >   pdb_list;

	string current_word;
	while (in_stream >> current_word)
		pdb_list.push_back(current_word);

	Chain_store ob(pdb_list);

}

void Chain_store_test::
constructor_test ()
{
	//string external_PDB_chain_ID_list_file =	string("not_exist_bin.txt") ;
	//string external_PDB_chain_ID_list_file =	string("DeBre_LS.existed") ;

    //string external_PDB_chain_ID_list_file =	string("CB513") ;

    string external_PDB_chain_ID_list_file =	string("all_for_dssp") ;

            string test = configuration.option_meaning("Path_to_Chain_store");

	Sheduler *sheduler = new Sheduler(configuration.option_meaning("Path_to_Chain_store") + string("sheduler"));

	double Treshold_C_N_Distance = atof(sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str());
	double distance_epsilon = atof(sheduler->option_meaning("DISTANCE_EPSILON").c_str());
	double angle_epsilon = atof(sheduler->option_meaning("ANGLE_EPSILON").c_str());;

    vector < string >   accepted_chain_ID_list;

	fill_up_accepted_chain_data_text (
		accepted_chain_ID_list,
		external_PDB_chain_ID_list_file );

///		convert to uppercase
   //accepted_chain_ID_list.push_back("1A5IA");

        for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
        {
            string current_pdb_id = accepted_chain_ID_list[ii];

            for (int kk=0; kk<current_pdb_id.size(); kk++)
                current_pdb_id[kk] = toupper(current_pdb_id[kk]);

                Chain_Residue_Set crs(
                    current_pdb_id,
                    Treshold_C_N_Distance,
                    distance_epsilon,
                    angle_epsilon);

                crs.print_protocol();
                crs.save_as_binary();
                cout << ii << " " << accepted_chain_ID_list[ii] << endl;
        }

     delete sheduler;

}
/*
void Chain_store_test:: prepare_PDB_full_path_preset_binary_files()
{

	//string external_PDB_chain_ID_list_file =	string("DeBre_LS.existed") ;

    string external_PDB_chain_ID_list_file =	string("CASP14_free_modeling") ;

	Sheduler *sheduler = new Sheduler(configuration.option_meaning("Path_to_Chain_store") + string("sheduler"));

	double Treshold_C_N_Distance = atof(sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str());
	double distance_epsilon = atof(sheduler->option_meaning("DISTANCE_EPSILON").c_str());
	double angle_epsilon = atof(sheduler->option_meaning("ANGLE_EPSILON").c_str());;

    vector < string >   accepted_chain_ID_list;

	fill_up_accepted_chain_data_text (
		accepted_chain_ID_list,
		external_PDB_chain_ID_list_file );

///		convert to uppercase
   //accepted_chain_ID_list.push_back("1A5IA");

        for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
        {
            string current_pdb_id = accepted_chain_ID_list[ii];
            char	chain_ID =  current_pdb_id[4];
            string	pdb_ID   =  current_pdb_id.substr(0,4);

            for (int kk=0; kk<current_pdb_id.size(); kk++)
                current_pdb_id[kk] = toupper(current_pdb_id[kk]);

                Chain_Residue_Set crs(
///                    current_pdb_id,
                    full_path_to_pdb_file
                    chain_ID,
                    Treshold_C_N_Distance,
                    distance_epsilon,
                    angle_epsilon);

                crs.print_protocol();
                crs.save_as_binary();
                cout << ii << " " << accepted_chain_ID_list[ii] << endl;
        }

     delete sheduler;


}
*/
void Chain_store_test::
revision_existing_database()
{
	string binary_file_name ("accepted_chain_list.bin");

	vector < string >  accepted_chain_ID_list;  //
	vector <int>       accepted_chain_lenth;

	fill_up_accepted_chain_data (
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name );


	string binary_file_name_revized =
		configuration.option_meaning("Path_to_Chain_store") +
		"accepted_chain_list.bin.revized";

	ofstream binary_stream_revizes ( binary_file_name_revized .c_str(),ios::binary );
//	ofstream binary_stream_revizes ( "aaaaa",ios::binary );


	if ( ! binary_stream_revizes )	{
		log_stream	 << "ERROR -  can't find binary file" << binary_file_name<< endl;
		cout		 << "ERROR -  can't find binary file" << binary_file_name<< endl;
		exit (1);
	}

	string protocol_of_revizion =
		configuration.option_meaning("Path_to_Chain_store") +
		"protocol_of_revizion";

	ofstream protocol_of_revizion_stream  ( protocol_of_revizion.c_str() );

	double threshold_value = 0.15;
	protocol_of_revizion_stream  << "***  threshold_value = " << threshold_value << endl;




	for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
	{
		int non_standard =0;
		Chain_binary cb( accepted_chain_ID_list[ii]);
		string sequence = cb.get_sequence();
		int seqlen = sequence.size();

		for (int kk=0;kk<sequence.size();kk++)
		{
			if ( sequence[kk] == 'X' )
				non_standard ++;
		}

		double defect = (double) non_standard / sequence.size();
		if (defect > threshold_value)
		{
			cout << accepted_chain_ID_list[ii] << "  length " << seqlen << " very non-standard: " << defect << endl;
			protocol_of_revizion_stream   << accepted_chain_ID_list[ii] << "  length " << seqlen << " very non-standard: " << defect << endl;

		}
		else
		{
			binary_stream_revizes.write( (char*) accepted_chain_ID_list[ii].c_str(), 5*sizeof (char) );
			binary_stream_revizes.write( (char*) &seqlen , sizeof (int) );
		}


	}
}




void Chain_store_test::
calc_total_pull_size()
{
	string binary_file_name ("accepted_chain_list.bin");

	vector < string >  accepted_chain_ID_list;  //
	vector <int>       accepted_chain_lenth;

	fill_up_accepted_chain_data (
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name );


	string binary_file_name_revized =
		configuration.option_meaning("Path_to_Chain_store") +
		"accepted_chain_list.bin.revized";

//	ofstream binary_stream_revizes ( binary_file_name_revized .c_str(),ios::binary );
//	ofstream binary_stream_revizes ( "aaaaa",ios::binary );


//	if ( ! binary_stream_revizes )	{
//		log_stream	 << "ERROR -  can't find binary file" << binary_file_name<< endl;
//		cout		 << "ERROR -  can't find binary file" << binary_file_name<< endl;
//		exit (1);
//	}

	string protocol_of_revizion =
		configuration.option_meaning("Path_to_Chain_store") +
		"total_pull_size";

	ofstream protocol_of_revizion_stream  ( protocol_of_revizion.c_str() );

	string chain_list_after_all_correction =
		configuration.option_meaning("Path_to_Chain_store") +
		"chain_list_after_all_correction";

	ofstream chain_list_after_all_correction_stream  ( chain_list_after_all_correction.c_str() );



	double threshold_value = 0.15;
//	protocol_of_revizion_stream  << "***  threshold_value = " << threshold_value << endl;


	int exist_coordinates_number = 0;
	int admissble_geometry_number = 0;
	int total_sequence_length = 0;


	for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
	{
		int non_standard =0;
		Chain_binary cb( accepted_chain_ID_list[ii]);
//		string sequence = cb.get_sequence();
//		int seqlen = sequence.size();

		int number_of_residues = cb.get_number_of_residues();
		bool *is_there_coord = cb.get_is_there_coord();
		bool *is_geometry_admissible = 	cb.get_is_geometry_admissible();


		for (int kk=0;kk<number_of_residues;kk++)
		{
			if (is_there_coord[kk])
				exist_coordinates_number ++;

			if (is_geometry_admissible[kk])
				admissble_geometry_number++;
		}

		total_sequence_length += number_of_residues;



		chain_list_after_all_correction_stream  << accepted_chain_ID_list[ii] << endl;



 //       binary_stream_revizes.write( (char* ) accepted_chain_ID_list [ii].c_str(), 5*sizeof (char) );
	//	binary_stream_revizes.write( (char* ) &accepted_chain_lenth[ii], sizeof (int) );

	}

	protocol_of_revizion_stream   << "Total number of protein chains:" << accepted_chain_ID_list.size()  << endl;
	protocol_of_revizion_stream   << "Total residue number:" << total_sequence_length  << endl;
	protocol_of_revizion_stream   << "The number of amino acids having the coordinates:" << exist_coordinates_number  << endl;
	protocol_of_revizion_stream   << "The number of amino acids having the admissible coordinates:" << admissble_geometry_number << endl;



}
#include "../ELM/simple_RE.h"
/*
void Chain_store_test::
prepare_elm_alternative_sequence_set()
{

	string binary_file_name("accepted_chain_list.bin");

	vector < string >  accepted_chain_ID_list;  //
	vector <int>       accepted_chain_lenth;

	fill_up_accepted_chain_data(
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name);

	string binary_file_name_revized =
		configuration.option_meaning("Path_to_Chain_store") +
		"accepted_chain_list.bin.revized";


	string path_to_alternative_sequence_storage =
		string("D:/Didona/Store/ELM/");

	simple_RE sre(path_to_alternative_sequence_storage + string("MOD_N-GLC_1/regular_expression") );

	string path_protocol =
		path_to_alternative_sequence_storage + string("MOD_N-GLC_1/protocol");

	ofstream p_stream(path_protocol.c_str());

	if (!p_stream) {
		cout		<< "ERROR -  can't create " << path_protocol << endl;
		log_stream	<< "ERROR -  can't create " << path_protocol << endl;
		throw "Protocol file ERROR";
	}


	for (int ii = 0; ii < accepted_chain_ID_list.size(); ii++)
	{
		int non_standard = 0;
		Chain_binary cb(accepted_chain_ID_list[ii]);

		string current_sequence = cb.get_sequence();

		vector <int> motiff_start_positions = sre.find_motifs_in_seq(current_sequence);

		if (motiff_start_positions.size() != 0)
		{
			p_stream << accepted_chain_ID_list[ii] << "\t";
			for (int kk = 0; kk < motiff_start_positions.size(); kk++)
				p_stream << motiff_start_positions[kk] << "\t";
			p_stream << endl;


			ostringstream ost;
			ost << ">Motif reg. expression start points: ";
			string header;
			for (int kk = 0; kk < motiff_start_positions.size(); kk++)
			{
				ost << motiff_start_positions[kk] << "\t";
			}
			header = ost.str();

			string Path_to_output_fasta_file =
				path_to_alternative_sequence_storage +
				string("MOD_N-GLC_1/control/") +
				accepted_chain_ID_list[ii]+ string(".fasta");

			save_as_fasta(
				Path_to_output_fasta_file,
				header,
				current_sequence);
		}
	}
}
*/


string get_RESOLUTION_lines ( ifstream & source_stream )
{
	vector <string> seqres_record_pull;
	bool is_reached_yet = false;

	string current_line;
	while ( getline(source_stream,current_line,'\n' ) )
	{

        int test1 = current_line.find("RESOLUTION");
        int test2 = current_line.find("REMARK   2");// == string::npos
        if ( current_line.find("RESOLUTION") != string::npos  && current_line.find("REMARK   2") != string::npos )
            return current_line;


	}
	return string("NOT FOUND RESOLUTION STRING");
}

void assign_guality (
    const string & protocol_quality,
    map<string,double> & ql_map)
{

    ifstream in ( protocol_quality.c_str() );
  	if ( ! in )	{
  		log_stream	        << "ERROR -  can't find binary file" << protocol_quality<< endl;
  		cout		        << "ERROR -  can't find binary file" << protocol_quality<< endl;
  		exit (1);
  	}


  	string current_line;
	while( getline( in , current_line, '\n' ) )
	{
       double quality;
       string chain_ID;
       istringstream ist (current_line);

       ist >> quality;
       ist >> chain_ID;

       ql_map[chain_ID]=quality;
	}
	in.close();



}

void connect_quality_to_pdb_ID_subset(
    map<string,double> & ql_map,
    const string subset_file)
{

    ifstream source_stream ( subset_file.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << subset_file<< endl;
  		cout		        << "ERROR -  can't find binary file" << subset_file<< endl;
  		exit (1);
  	}
    string subset_file_result = subset_file + string ("quality");

    ofstream out_stream ( subset_file_result.c_str() );
  	if ( ! out_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << subset_file<< endl;
  		cout		        << "ERROR -  can't find binary file" << subset_file<< endl;
  		exit (1);
  	}
    string current_line;
    int counter;
  	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string ttt;
		string resolution;
		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;
		ist >>ttt;
		ist >>ttt;
		ist >>ttt;
		ist >>resolution;

        counter++;


        double quality;
        if ( ql_map.find(cu_chain_ID) != ql_map.end()  )
            quality =   ql_map[cu_chain_ID];
        else
             quality = -1;


        out_stream << cu_chain_ID << "\t" << quality << "\t" << resolution << endl;

    }


}
void nonstastard_containing_analise(
     map<string,double> & ql_map,
    const string subset_file)
{
   ifstream source_stream ( subset_file.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << subset_file<< endl;
  		cout		        << "ERROR -  can't find binary file" << subset_file<< endl;
  		exit (1);
  	}
    string subset_file_result = subset_file + string (".nonstandard_analyse");

    ofstream out_stream ( subset_file_result.c_str() );
  	if ( ! out_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << subset_file<< endl;
  		cout		        << "ERROR -  can't find binary file" << subset_file<< endl;
  		exit (1);
  	}
    string current_line;
    int counter;
  	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;

        counter++;

		int non_standard =0;
		Chain_binary cb( cu_chain_ID );
		string sequence = cb.get_sequence();
		int seqlen = sequence.size();

		for (int kk=0;kk<sequence.size();kk++)
		{
            char current_letter= sequence[kk];
			if ( sequence[kk] == 'X' )
				non_standard ++;
		}

        double defect = (double) non_standard / sequence.size();


        double quality;
        if ( ql_map.find(cu_chain_ID) != ql_map.end()  )
            quality =   ql_map[cu_chain_ID];
        else
             quality = -1;


        out_stream << cu_chain_ID << "\t" << non_standard << "\t" << sequence.size() <<"\t"  << defect <<"\t"  << quality <<"\t:" << sequence << endl;

    }


}



void check_Chain_binary_geometry(
    const string subset_file)
{
   ifstream source_stream ( subset_file.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << subset_file<< endl;
  		cout		        << "ERROR -  can't find binary file" << subset_file<< endl;
  		exit (1);
  	}
    string subset_file_result = subset_file + string (".geometry_protocol");

    ofstream out_stream ( subset_file_result.c_str() );
  	if ( ! out_stream )	{
  		log_stream	        << "ERROR -  can't find binary file" << subset_file<< endl;
  		cout		        << "ERROR -  can't find binary file" << subset_file<< endl;
  		exit (1);
  	}
    string current_line;
    int counter=0;
  	while( getline( source_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;

        counter++;

        {

                Chain_binary cb( cu_chain_ID );

                int     number_of_residues      =   cb.get_number_of_residues       ();
                bool    *is_there_coord         =   cb.get_is_there_coord		    () ;
                bool	*is_geometry_admissible =   cb.get_is_geometry_admissible   () ;
                double  *coord_set              =   cb.get_coord_set				() ;

                double atom_1[3],atom_2[3];
                atom_1[0]=1;


                int number_of_atoms = 3*number_of_residues;
                for (int ii=0;ii<number_of_atoms-1;ii++)
                {
                    memcpy(atom_1,coord_set+3*ii,   3*sizeof(double));
                    memcpy(atom_2,coord_set+3*(ii+1), 3*sizeof(double));

                    int cu_atom_1 = ii/3;
                    int cu_atom_2 = (ii+1)/3;

                    if ( is_there_coord[cu_atom_1] == true && is_there_coord[cu_atom_2]==true )
                    {
                        double dist = Geometry_util::distance(atom_1,atom_2);
                        if ( dist > 1.7 )
                        {
                                out_stream << cu_chain_ID << "\t" << "counter:" << counter<< "\t" <<  "residue number: "  << ii <<  "\t";
                                out_stream
                                << atom_1[0] << "\t"
                                << atom_1[1] << "\t"
                                << atom_1[2] << "\t|"


                                << atom_2[0] << "\t"
                                << atom_2[1] << "\t"
                                << atom_2[2] << "\t| distance:"
                                << dist << endl;

                        }

                    }
/*                    else
                    {

                        out_stream << cu_chain_ID << "\t" << "residue number: "  << ii/9 <<  "\t";
                        out_stream << "No one ore both coord. " << endl;
                    }
*/
                }
        }
    }
}
