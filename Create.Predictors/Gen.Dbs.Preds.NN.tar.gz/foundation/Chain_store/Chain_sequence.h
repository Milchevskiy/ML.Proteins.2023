#ifndef CHAIN_SEQUENCE_H
#define CHAIN_SEQUENCE_H

#include <string>
#include <vector>

using namespace std;

class Chain_sequence
{
public:
    Chain_sequence ( const string &full_path_to_pdb_file, char  chain_ID) ;

	Chain_sequence ( const string & pdb_chain_ID );

	string				get_one_letter_sequence () const;
	vector < string >	get_tri_letter_sequence () const { return tri_letter_sequence_; };
	int					get_sequence_size		() const { return tri_letter_sequence_.size(); }


	string				get_pdb_chain_ID		() const { return pdb_chain_ID_; }
private:
	string  pdb_chain_ID_ ;
	vector < string >  tri_letter_sequence_;
};


#endif
