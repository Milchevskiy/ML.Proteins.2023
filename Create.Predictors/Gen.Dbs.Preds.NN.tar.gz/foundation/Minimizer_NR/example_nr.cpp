#include "../code/nr3.h"
#include "../code/mins.h"
#include "../code/mins_ndim.h"

//
// Minimize the following function
//
// f(x,y) = (x-1)^2 + (y-2)^2 + 3
//
//
Doub func(VecDoub_I & x)
{
return (x[0]-1.0)*(x[0]-1.0) + (x[1]-2.0)*(x[1]-2.0) + 3.0;
}

int main()
{
Int n = 2; // Number of parameters in the function

Int i;

//
// In general, you might have a better idea for an initial guess, but
// here, I'll just use zero values for the parameters.
//
VecDoub pinit(n, 0.0); // Initial guess is (0, 0)
VecDoub pmin; // Vector to hold the result from Powell minimization

cout << scientific;
cout << "Initial guess: minimum value = " << setw(13) << func(pinit) << " at: ";
for (i = 0; i < pinit.size(); i++) {
cout << setw(13) << pinit[i] << " ";
}
cout << endl << endl;

//
// Feed the function to the constructor
//
Powell <Doub(VecDoub_I &)> powell(func);

// Perform the minimization
pmin = powell.minimize(pinit);

cout << "Number of Powell iterations = " << powell.iter << endl << endl;
cout << "After Powell, minimum value = ";
cout << setw(13) << powell.fret << " at: ";
for (i = 0; i < n; i++) {
cout << setw(13) << pmin[i] << " ";
}
cout << endl << endl;

//
// Of course I made up a function for which I know
// the exact answer.
//
cout << "Actual minimum is 3.0 at 1.0 2.0" << endl << endl;

return 0;
}