

#pragma warning( disable : 4786 )

#include "Minimizer_NR_test.h"
//#include "../Restore_cartesian/Restore_cartesian.h"

#include "../Censorship.h"

#include "../CommonFunc.h"

#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"

#include "../Cluster_set/Cluster_set.h"

#include "../by_Qmol/EigenValues3D.h"
#include "../by_Qmol/kabsch_stolen.h"

#include "../CommonFunc.h"


#include "../NewNiki/Model_adapter.h"
#include "../NewNiki/Min.h"
#include "../NewNiki/Defs.h"

#include "../Minimizer_simple/Minimizer_simple.h"

#include <fstream>
#include <iostream>
#include <cassert>

#include "code/nr3.h"
#include "code/mins.h"
#include "code/mins_ndim.h"

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

//ofstream output;


//
Doub func(VecDoub_I & x)
{
return (x[0]-1.0)*(x[0]-1.0) + (x[1]-2.0)*(x[1]-2.0) + 3.0;
}


Minimizer_NR_test::~Minimizer_NR_test()
{
	cout << "Minimizer_NR_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}
void Minimizer_NR_test:: alien_example () // Powell method used
{

Int n = 2; // Number of parameters in the function

Int i;

//
// In general, you might have a better idea for an initial guess, but
// here, I'll just use zero values for the parameters.
//
VecDoub pinit(n, 0.0); // Initial guess is (0, 0)
VecDoub pmin; // Vector to hold the result from Powell minimization

cout << scientific;
cout << "Initial guess: minimum value = " << setw(13) << func(pinit) << " at: ";
for (i = 0; i < pinit.size(); i++) {
cout << setw(13) << pinit[i] << " ";
}
cout << endl << endl;

//
// Feed the function to the constructor
//
Powell <Doub(VecDoub_I &)> powell(func);

//Powell(T &func, const Doub ftoll=3.0e-8)

// Perform the minimization
pmin = powell.minimize(pinit);

cout << "Number of Powell iterations = " << powell.iter << endl << endl;
cout << "After Powell, minimum value = ";
cout << setw(13) << powell.fret << " at: ";
for (i = 0; i < n; i++) {
cout << setw(13) << pmin[i] << " ";
}
cout << endl << endl;

//
// Of course I made up a function for which I know
// the exact answer.
//
cout << "Actual minimum is 3.0 at 1.0 2.0" << endl << endl;




}

   class Funcd {
   public:
   Funcd (int num_trst) {};
    Doub operator() (VecDoub_I &x)
    {
        //return x[0]*x[0]+x[1]*x[1];
        return(x[0]-1.0)*(x[0]-1.0) + (x[1]-2.0)*(x[1]-2.0) + 3.0;

    }
    void df(VecDoub_I &x, VecDoub_O &deriv)
    {
//        deriv[0]=2.0*x[0];
//        deriv[1]=2.0*x[1];

        deriv[0]=2.0*(x[0]-1);
        deriv[1]=2.0*(x[1]-2);

    }


    };





void Minimizer_NR_test:: Frprmn_alien_example ()

{


Int n = 2; // Number of parameters in the function

Int i;


    VecDoub p(n, 0.0);  //p[0]

    Funcd funcd(1);

//     <Doub(VecDoub_I &)>
   // Frprmn<MyFunc & > frprmn(funcd);

   ////home/milch/projects/Didona/foundation/Minimizer_NR/Minimizer_NR_test.cpp|134|error: no matching function for call to ‘Frprmn<double(const NRvector<double>&)>::Frprmn(Minimizer_NR_test::Frprmn_alien_example()::MyFunc&)’|

    ///Frprmn<Doub(VecDoub_I &)> frprmn(funcd);

    //Frprmn <(VecDoub_I &)> frprmn(funcd);

    Frprmn<Funcd> frprmn(funcd);


    p=frprmn.minimize(p);



    cout << "Number of Frprmn iterations = " << frprmn.iter << endl << endl;
    cout << "After Frprmn, minimum value = ";
    cout << setw(13) << frprmn.fret << " at: ";
    for (i = 0; i < n; i++) {
    cout << setw(13) << p[i] << " ";
    }
    cout << endl << endl;




}


/*

    init_approximation[0]   =0;
    init_approximation[1]   =0;
    init_approximation[2]   =0;
    init_approximation[3]   =0;
    init_approximation[4]   =0;
    init_approximation[5]   =0;
    init_approximation[6]   =0;
    init_approximation[7]   =0;
    init_approximation[8]   =0;
    init_approximation[9]   =0;
//**********
/// FIX  ПАРАМЕТРЫ менять вероято. eps & dihotomia_eps может один из них лишний
//    double alpha = 0.01;
//    double eps = 0.0000001;
//    double dihotomia_eps = 0.00001;
//    int max_iter_number = 100000;
//
//    int      iter_number;
//    double   final_norma;

    misi.steepest_descent_handwork (  // ни фига не констант альфа.
        alpha,
        eps,
        dihotomia_eps,
        max_iter_number,
        init_approximation,
        final_approximaion,
        iter_number,
        final_norma);


    delete rc_pointer;


    double Pi = Pythagorean_Number ();
    out << "Result angles phi psi " << endl;
    for (int ii=0; ii< final_approximaion.size(); ii++)
        PutVaDouble( (180/Pi)*final_approximaion [ii],out,12,2,'l');
     out << endl<< endl;




    vector <double>  trg_phi_set;   trg_phi_set.resize(fragment_length);
    vector <double>  trg_psi_set;	trg_psi_set.resize(fragment_length);

  //  vector <double>  trg_ome_set;	trg_ome_set.resize(fragment_length);

    trg_phi_set[0]   =  0.00  ;   trg_psi_set[0] =  108.24 ;
    trg_phi_set[1]   = -90.12 ;   trg_psi_set[1] =  119.54 ;
    trg_phi_set[2]   = -92.21 ;   trg_psi_set[2] =  -18.06 ;
    trg_phi_set[3]   = -128.93;   trg_psi_set[3] =  147.04 ;
    trg_phi_set[4]   = -99.90 ;   trg_psi_set[4] =  0.00   ;


    out << "Target angles phi psi " << endl;
    for (int ii=0; ii< final_approximaion.size()/2; ii++)
    {
        PutVaDouble(trg_phi_set[ii],out,12,2,'l');
        PutVaDouble(trg_psi_set[ii],out,12,2,'l');
    }

    out << endl<< endl;








Int n = 2; // Number of parameters in the function

Int i;


    VecDoub p(n, 100000);  //p[0]

    rc_pointer->My_func_RC funcd;

//     <Doub(VecDoub_I &)>
   // Frprmn<MyFunc & > frprmn(funcd);

   ////home/milch/projects/Didona/foundation/Minimizer_NR/Minimizer_NR_test.cpp|134|error: no matching function for call to ‘Frprmn<double(const NRvector<double>&)>::Frprmn(Minimizer_NR_test::Frprmn_alien_example()::MyFunc&)’|

    ///Frprmn<Doub(VecDoub_I &)> frprmn(funcd);

    //Frprmn <(VecDoub_I &)> frprmn(funcd);

    Frprmn<My_func_RC> frprmn(funcd);


    p=frprmn.minimize(p);



    cout << "Number of Frprmn iterations = " << frprmn.iter << endl << endl;
    cout << "After Frprmn, minimum value = ";
    cout << setw(13) << frprmn.fret << " at: ";
    for (i = 0; i < n; i++) {
    cout << setw(13) << p[i] << " ";
    }
    cout << endl << endl;



}



*/
