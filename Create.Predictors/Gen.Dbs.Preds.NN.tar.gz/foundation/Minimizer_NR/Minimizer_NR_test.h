#ifndef MINIMIZER_NR_TEST_H
#define MINIMIZER_NR_TEST_H


#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif


class Minimizer_NR_test: public Simple_test
{
    public:
        Minimizer_NR_test() {}
        ~Minimizer_NR_test();

    void run()
    {
        alien_example ();
        Frprmn_alien_example () ;
//        Frprmn_reasl_data ();
	}
	void  alien_example ();
	void Frprmn_alien_example () ;
	void Frprmn_reasl_data ();

};

#endif // MINIMIZER_NR_H

