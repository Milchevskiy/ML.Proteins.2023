#ifndef MINIMIZER_NR_H
#define MINIMIZER_NR_H


class Minimizer_NR
{
    public:
        Minimizer_NR() {}
        virtual ~Minimizer_NR() {}

    protected:

    private:
};

#endif // MINIMIZER_NR_H



