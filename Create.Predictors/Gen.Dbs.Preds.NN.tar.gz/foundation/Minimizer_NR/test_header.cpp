
#include <fstream>
#include <iostream>
#include <cassert>

#include "code/nr3.h"
#include "code/mins.h"
#include "code/mins_ndim.h"


//#include "code/nr3.h"
//#include "code/mins.h"
//#include "code/mins_ndim.h"

using namespace std;

void test_head()
{
}
