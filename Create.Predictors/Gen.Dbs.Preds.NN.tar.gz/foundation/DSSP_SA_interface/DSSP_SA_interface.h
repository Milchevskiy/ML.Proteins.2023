#ifndef DSSP_SA_INTERFACE_H
#define DSSP_SA_INTERFACE_H

#include <vector>
#include <string>
#include <map>

using namespace std;


enum DSSP_SA_interface_operating_modes
{
	COMMON_USAGE_DSSP_SA_INTERFACE,
	FILL_UP_DSSP_SA_INTERFACE,
};


class DSSP_SA_interface
{
    public:
///     DSSP_SA_interface();
        DSSP_SA_interface(const string good_bin_dssp_list, DSSP_SA_interface_operating_modes  run_mode);

        virtual ~DSSP_SA_interface();

    protected:

    private:
        void init ();
        void fill_up();

        string good_bin_dssp_list_;

};


struct Detailed_decription_for_namesake
{
    string  name_;
    int     counter_;

    vector <string>     aa_sequence_fragment_pull_;
    vector <string>     dssp_sequence_fragment_pull_;
    vector <string>     pb_sequence_fragment_pull_;

    vector <int>        position_in_chain_;
    vector <string>     chain_ID_;
};


void make_map_for_appropriate_word(
    const string &key_symbol_sequence,
    map <string,Detailed_decription_for_namesake> &current_pull,
    const int length,
   	const string &aa_sequence,
    const string &dssp_sequence,
    const string &pb_sequence,
    const string current_chain_ID);


#endif // DSSP_SA_INTERFACE_H

