#ifndef DSSP_SA_INTERFACE_TEST_H_INCLUDED
#define DSSP_SA_INTERFACE_TEST_H_INCLUDED
#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  DSSP_SA_interface_test : public Simple_test
{
public:
	~DSSP_SA_interface_test ();

    void run()
    {
       /// create_binary_DSSP_pull();
		fill_up_test ();
	}
	void create_binary_DSSP_pull();
	void fill_up_test ();
	};


#endif // DSSP_SA_INTERFACE_TEST_H_INCLUDED
