#include "DSSP_SA_interface.h"

#include "../Fragment_base/Chain_binary.h"

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>

#include "../Chain_store/tri_to_one_and_vice_versa_aa_translation.h"
#include "../Chain_store/DSSP_binary.h"



#include "../Fragment_base/accepted_chain_data.h"



#include "../../../PB_RMSD/foundation/PB_RMSD.h"
#include "../../../PB_RMSD/foundation/pb16_to_index.h"

#include "../Main_model/handle_det_distance_set.h"



#include <bits/stdc++.h>


#include <fstream>
#include <iostream>


extern ofstream log_stream;
//extern Censorship configuration;

bool cmp_(pair<string, Detailed_decription_for_namesake>& a,
         pair<string, Detailed_decription_for_namesake>& b)
{
    return a.second.counter_ > b.second.counter_;
}




DSSP_SA_interface::DSSP_SA_interface(const string good_bin_dssp_list, DSSP_SA_interface_operating_modes  run_mode):
    good_bin_dssp_list_(good_bin_dssp_list)
{
    	switch ( run_mode  )
	{
		case COMMON_USAGE_DSSP_SA_INTERFACE:

			init();

			break;
		case FILL_UP_DSSP_SA_INTERFACE:

			fill_up	();
			break;
		default :
			log_stream	<< "Inadmissible run mode for DSSP_SA_interface class" << endl;
			cout		<< "Inadmissible run mode for DSSP_SA_interface class" << endl;
			exit (-1);
	}

    //ctor
}

DSSP_SA_interface::~DSSP_SA_interface()
{
    //dtor
}


void DSSP_SA_interface::fill_up()
{

    int fragment_length;
    int number_of_classes;

    string path_to_PB_data= "/home/milch/projects/PB_RMSD/PB/cartesian_coordinates.txt";

    double **claster_motif_coordinates = fill_up_PB_parameters (
        path_to_PB_data,
        fragment_length,
        number_of_classes );


    //string path_to_PDB_ID_set_store = "/media/milch/Новый\ том/ML_calculation/CaspDeBrew";


    ifstream  source_stream ( good_bin_dssp_list_.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't open file" << good_bin_dssp_list_<< endl;
  		cout		        << "ERROR -  can't open file" << good_bin_dssp_list_<< endl;
  		exit (1);
  	}



    int counter = 0;
    string current_line;
    vector < string >	accepted_chain_ID_list;

	///vector <string> wrong_pdb_list;  с этим ранее разобрались
	while( getline( source_stream , current_line, '\n' ) )
	{
		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;

		accepted_chain_ID_list.push_back(cu_chain_ID);
        counter++;

    }


///     map <string,int> occurence_DSSP;

    map <string,Detailed_decription_for_namesake> aa_sequence_map;
    map <string,Detailed_decription_for_namesake> dssp_sequence_map;
    map <string,Detailed_decription_for_namesake> pb_sequence_map;

    map <string,Detailed_decription_for_namesake> pb_sequence_map_predicted;




    const string path_to_dist_data_store = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_3adv/cross_sum/";

    const string path_to_adapted_learning_sample = "/media/milch/Новый\ том/ML_calculation/SEQ_DSSP_PB.data/";

    const string path_to_dssp_store             = "/home/milch/projects/Didona/Store/Chain_store/DSSP_store/";



    for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
///for (int ii=0;ii<1000;ii++)
    {
        cout <<  ii<< " " << accepted_chain_ID_list [ii] << endl;
/*
        DSSP_binary dsb_com(accepted_chain_ID_list[ii],COMMON_USAGE) ;
     	string aa_sequence            = dsb_com.get_sequence();
		string dssp_sequence	= dsb_com.get_extended_DSSP_sequence();
		string tri_letter_DSSP_sequence	= dsb_com.get_tri_letter_DSSP_sequence();
*/

        string path_to_breif_dssp = path_to_dssp_store + accepted_chain_ID_list [ii] + ".dssp_brief";

        ifstream  brief_stream ( path_to_breif_dssp.c_str() );
        if ( ! brief_stream )	{
            log_stream	        << "ERROR -  can't open file" << path_to_breif_dssp<< endl;
            cout		        << "ERROR -  can't open file" << path_to_breif_dssp<< endl;
            exit (1);
        }

        string dssp_sequence;
        string sequence_seqres;
        string sequence_atom_record;

        brief_stream >> sequence_seqres >> sequence_atom_record >> dssp_sequence;
        string aa_sequence (sequence_atom_record);

        brief_stream.close();







        string current_chain_ID = accepted_chain_ID_list[ii];
		Chain_binary *chain = new Chain_binary(accepted_chain_ID_list[ii]);
		string sequence = chain->get_sequence();


		/// Handle RMSD

        vector < vector < double > >   set_of_coordinate_in_clasters_system;
        chain->	positioning_chain_by_clasters_set(
            claster_motif_coordinates,
            fragment_length,
            number_of_classes,
            set_of_coordinate_in_clasters_system);

        vector <int> PB_index_set = get_PB_index_set (set_of_coordinate_in_clasters_system) ;
        string pb_sequence;
        pb_sequence += '-';
        pb_sequence += '-';

        int assignment_length = set_of_coordinate_in_clasters_system.size();
        int coord_size = set_of_coordinate_in_clasters_system[0].size();
        for (int ii=0;ii<assignment_length;ii++)
        {
            char letter_RMSD = index_to_16pb(PB_index_set[ii]);
            pb_sequence += letter_RMSD;
        }
        pb_sequence += '-';
        pb_sequence += '-';

        string path_to_observed     = path_to_dist_data_store + accepted_chain_ID_list[ii] + string (".dist_data");
        string path_to_predicted    = path_to_dist_data_store + accepted_chain_ID_list[ii] + string (".dist_data_predicted");

        vector < vector < double > >    observed        =        read_det_distance_set (path_to_observed);
//        vector < vector < double > >    observed;  observed.resize(0);
        for (int kk=0;kk<observed.size();kk++)
            observed[kk].resize(coord_size);


        vector <int> PB_index_set_test = get_PB_index_set (observed) ;

       int observed_record_size =  observed[0].size();

        string pb_sequence_observed;
        pb_sequence_observed += '-';
        pb_sequence_observed += '-';


        int assignment_length_test = observed.size();
        assert(assignment_length_test == assignment_length);
        for (int ii=0;ii<assignment_length_test;ii++)
        {
            char letter_RMSD = index_to_16pb(PB_index_set_test[ii]);
            pb_sequence_observed += letter_RMSD;
        }
        pb_sequence_observed += '-';
        pb_sequence_observed += '-';


        vector < vector < double > >   predicted        =        read_det_distance_set (path_to_predicted);
/****/    //  vector < vector < double > >   predicted ; predicted .resize(0);


       for (int kk=0;kk<predicted.size();kk++)
            predicted[kk].resize(coord_size);


       vector <int> PB_index_set_predicted = get_PB_index_set (predicted) ;

        int predicted_record_size = predicted[0].size();

    //    log_stream << "predicted_record_size: "<< predicted_record_size << endl;

  //      for (int kk=0; kk<PB_index_set_predicted.size(); kk++)
    //              log_stream << PB_index_set_predicted [kk]  << " " ;
     //    log_stream << endl;



        string pb_sequence_predicted;
        pb_sequence_predicted += '-';
        pb_sequence_predicted += '-';


        int assignment_length_predicted = predicted.size();
        assert(assignment_length_predicted == assignment_length);
        for (int ii=0;ii<assignment_length_predicted;ii++)
        {
            char letter_RMSD = index_to_16pb(PB_index_set_predicted[ii]);
            pb_sequence_predicted += letter_RMSD;
        }
        pb_sequence_predicted += '-';
        pb_sequence_predicted += '-';


        {


            const string current_learning_sample_file=path_to_adapted_learning_sample+ accepted_chain_ID_list[ii]+string(".data");
            ofstream  ls_stream ( current_learning_sample_file.c_str() );
            if ( ! ls_stream )	{
                log_stream	        << "ERROR -  can't open file" << current_learning_sample_file<< endl;
                cout		        << "ERROR -  can't open file" << current_learning_sample_file<< endl;
                exit (1);
            }

            ls_stream << aa_sequence << endl;
            ls_stream << dssp_sequence << endl;
            ls_stream << pb_sequence_predicted << endl;
            ls_stream << pb_sequence_observed << endl;

            ls_stream.close();


        }




/*

    make_map_for_appropriate_word(
        aa_sequence,
        aa_sequence_map,
        fragment_length,
       	aa_sequence,
        dssp_sequence,
        pb_sequence,
        current_chain_ID);

    make_map_for_appropriate_word(
        dssp_sequence,
        dssp_sequence_map,
        fragment_length,
       	aa_sequence,
        dssp_sequence,
        pb_sequence,
        current_chain_ID);


     make_map_for_appropriate_word(
        pb_sequence,
        pb_sequence_map,
        fragment_length,
       	aa_sequence,
        dssp_sequence,
        pb_sequence,
        current_chain_ID);





/// for predicted
     make_map_for_appropriate_word(
        pb_sequence_predicted,
        pb_sequence_map_predicted,
        fragment_length,
       	aa_sequence,
        dssp_sequence,
        pb_sequence,
        current_chain_ID);




		pb_sequence.resize(0);
		pb_sequence_observed.resize(0);
		pb_sequence_predicted.resize(0);


		PB_index_set.resize(0);
		PB_index_set_test.resize(0);
		PB_index_set_predicted.resize(0);
*/
		delete chain;

        log_stream << ii<< "\t" << accepted_chain_ID_list[ii] << endl;
    }

/*
/// DSSP key

 	const string Detailed_description_DSSP="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/analyse/Detailed_description_DSSP";
    ofstream  DSSP_stream ( Detailed_description_DSSP.c_str() );
  	if ( ! DSSP_stream )	{
  		log_stream	        << "ERROR -  can't open file" << Detailed_description_DSSP<< endl;
  		cout		        << "ERROR -  can't open file" << Detailed_description_DSSP<< endl;
  		exit (1);
  	}

 	const string Detailed_description_DSSP_PPII_only="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/analyse/Detailed_description_DSSP.PPII_only";
    ofstream  DSSP_stream_PPII_only ( Detailed_description_DSSP_PPII_only.c_str() );
  	if ( ! DSSP_stream_PPII_only )	{
  		log_stream	        << "ERROR -  can't open file" << Detailed_description_DSSP_PPII_only<< endl;
  		cout		        << "ERROR -  can't open file" << Detailed_description_DSSP_PPII_only<< endl;
  		exit (1);
  	}


    vector<pair<string, Detailed_decription_for_namesake> > dssp_sequence_array;

    // Copy key-value pair from Map
    // to vector of pairs
    for (auto& it : dssp_sequence_map ){
        dssp_sequence_array.push_back(it);
    }

    // Sort using comparator function
    sort(dssp_sequence_array.begin(), dssp_sequence_array.end(), cmp_);


     for (auto& it : dssp_sequence_array) {
          DSSP_stream << it.first << ' '  << it.second.counter_ << ':'<< endl;
          for (int kk=0;kk<it.second.counter_;kk++)
          {
            DSSP_stream << "\t" << it.second.dssp_sequence_fragment_pull_[kk]
                        << "\t" << it.second.pb_sequence_fragment_pull_[kk]
                        << "\t" << it.second.aa_sequence_fragment_pull_[kk]
                        << "\t" << it.second.chain_ID_[kk]
                        << "\t" << it.second.position_in_chain_[kk] << endl;
          }
    }

     for (auto& it : dssp_sequence_array) {

          string word =  it.first;
          if (word[2] != 'P')
            continue;

          DSSP_stream_PPII_only << it.first << ' '  << it.second.counter_ << ':'<< endl;
          for (int kk=0;kk<it.second.counter_;kk++)
          {
            DSSP_stream_PPII_only << "\t" << it.second.dssp_sequence_fragment_pull_[kk]
                        << "\t" << it.second.pb_sequence_fragment_pull_[kk]
                        << "\t" << it.second.aa_sequence_fragment_pull_[kk]
                        << "\t" << it.second.chain_ID_[kk]
                        << "\t" << it.second.position_in_chain_[kk] << endl;
          }
    }


/// PB key
  	const string Detailed_description_PB="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/analyse/Detailed_description_PB";
    ofstream  PB_stream ( Detailed_description_PB.c_str() );
  	if ( ! PB_stream )	{
  		log_stream	        << "ERROR -  can't open file" << Detailed_description_PB<< endl;
  		cout		        << "ERROR -  can't open file" << Detailed_description_PB<< endl;
  		exit (1);
  	}


    vector<pair<string, Detailed_decription_for_namesake> > pb_sequence_array;

    // Copy key-value pair from Map
    // to vector of pairs
    for (auto& it : pb_sequence_map ){
        pb_sequence_array.push_back(it);
    }

    // Sort using comparator function
    sort(pb_sequence_array.begin(), pb_sequence_array.end(), cmp_);


     for (auto& it : pb_sequence_array) {
          PB_stream << it.first << ' '  << it.second.counter_ << ':'<< endl;
          for (int kk=0;kk<it.second.counter_;kk++)
          {
            PB_stream   << "\t" << it.second.pb_sequence_fragment_pull_[kk]
                        << "\t" << it.second.dssp_sequence_fragment_pull_[kk]
                        << "\t" << it.second.aa_sequence_fragment_pull_[kk]
                        << "\t" << it.second.chain_ID_[kk]
                        << "\t" << it.second.position_in_chain_[kk] << endl;
          }
    }


/// PB key predicted
  	const string Detailed_description_PB_predicted="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/analyse/Detailed_description_PB_predicted";
    ofstream  PB_stream_predicted ( Detailed_description_PB_predicted.c_str() );
  	if ( ! PB_stream_predicted )	{
  		log_stream	        << "ERROR -  can't open file" << Detailed_description_PB_predicted<< endl;
  		cout		        << "ERROR -  can't open file" << Detailed_description_PB_predicted<< endl;
  		exit (1);
  	}

  	PB_stream_predicted << " predicted size_map " << pb_sequence_map_predicted.size() << endl;


    vector<pair<string, Detailed_decription_for_namesake> > pb_sequence_array_predicted;

    // Copy key-value pair from Map
    // to vector of pairs


    for (auto& it : pb_sequence_map_predicted ){
        pb_sequence_array_predicted.push_back(it);
    }

    PB_stream_predicted << " pb_sequence_array_predicted size " << pb_sequence_array_predicted.size() << endl;

    // Sort using comparator function
    sort(pb_sequence_array_predicted.begin(), pb_sequence_array_predicted.end(), cmp_);


     for (auto& it : pb_sequence_array_predicted) {
          PB_stream_predicted << it.first << ' '  << it.second.counter_ << ':'<< endl;
          for (int kk=0;kk<it.second.counter_;kk++)
          {
            PB_stream_predicted   << "\t" << it.second.pb_sequence_fragment_pull_[kk]
                        << "\t" << it.second.dssp_sequence_fragment_pull_[kk]
                        << "\t" << it.second.aa_sequence_fragment_pull_[kk]
                        << "\t" << it.second.chain_ID_[kk]
                        << "\t" << it.second.position_in_chain_[kk] << endl;
          }
    }




    /// AA key
  	const string Detailed_description_AA="/home/milch/projects/Didona/Store/Chain_store/DSSP_store/analyse/Detailed_description_AA";
    ofstream  AA_stream ( Detailed_description_AA.c_str() );
  	if ( ! AA_stream )	{
  		log_stream	        << "ERROR -  can't open file" << Detailed_description_AA<< endl;
  		cout		        << "ERROR -  can't open file" << Detailed_description_AA<< endl;
  		exit (1);
  	}


    vector<pair<string, Detailed_decription_for_namesake> > aa_sequence_array;

    // Copy key-value pair from Map
    // to vector of pairs

    for (auto& it : aa_sequence_map ){
        aa_sequence_array.push_back(it);
    }

    // Sort using comparator function
    sort(aa_sequence_array.begin(), aa_sequence_array.end(), cmp_);

    int qqq= aa_sequence_array.size();


    log_stream << "aa_sequence_map.size() " << aa_sequence_map.size();

    log_stream << "aa_sequence_array.size() " << aa_sequence_array.size();


     for (auto& it : aa_sequence_array) {
          AA_stream << it.first << ' '  << it.second.counter_ << ':'<< endl;
          for (int kk=0;kk<it.second.counter_;kk++)
          {
            AA_stream   << "\t" << it.second.aa_sequence_fragment_pull_[kk]
                        << "\t" << it.second.pb_sequence_fragment_pull_[kk]
                        << "\t" << it.second.dssp_sequence_fragment_pull_[kk]
                        << "\t" << it.second.chain_ID_[kk]
                        << "\t" << it.second.position_in_chain_[kk] << endl;
          }
    }
    */
}


///
void make_map_for_appropriate_word(
    const string &key_symbol_sequence,
    map <string,Detailed_decription_for_namesake> &current_pull,
    const int length,
   	const string &aa_sequence,
    const string &dssp_sequence,
    const string &pb_sequence,
    const string current_chain_ID)
{
    int assignment_length = key_symbol_sequence.size();
    for (int ii=0;ii<assignment_length - length+1;ii++)
    {
        string key_symbol_fragment= key_symbol_sequence.substr(ii,length);


        string     aa_sequence_fragment     = aa_sequence   .substr(ii,length);;
        string     dssp_sequence_fragment   = dssp_sequence .substr(ii,length);
        string     pb_sequence_fragment     = pb_sequence   .substr(ii,length);



    vector <string>     aa_sequence_fragment_pull_;
    vector <string>     dssp_sequence_fragment_pull_;
    vector <string>     pb_sequence_fragment_pull_;



        if ( current_pull.find(key_symbol_fragment) == current_pull.end()  )
		{
                Detailed_decription_for_namesake current_object;
                current_object.name_ = key_symbol_fragment;

                current_object.counter_=1;


                current_object.aa_sequence_fragment_pull_.push_back(aa_sequence_fragment);
                current_object.dssp_sequence_fragment_pull_.push_back(dssp_sequence_fragment);
                current_object.pb_sequence_fragment_pull_.push_back(pb_sequence_fragment);
                current_object.chain_ID_.push_back(current_chain_ID);
                current_object.position_in_chain_.push_back(ii);

                current_pull[key_symbol_fragment] = current_object;

		}
		else
		{
				Detailed_decription_for_namesake current_object = current_pull[key_symbol_fragment];

				current_object.counter_++;


                current_object.aa_sequence_fragment_pull_.push_back(aa_sequence_fragment);
                current_object.dssp_sequence_fragment_pull_.push_back(dssp_sequence_fragment);
                current_object.pb_sequence_fragment_pull_.push_back(pb_sequence_fragment);
                current_object.chain_ID_.push_back(current_chain_ID);
                current_object.position_in_chain_.push_back(ii);

                current_pull[key_symbol_fragment] = current_object;
		}

		//int test = occurence_SW.size();

    }
}


void DSSP_SA_interface::init()
{


}
