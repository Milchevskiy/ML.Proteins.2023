
#pragma warning( disable : 4786 )

#include "DSSP_SA_interface_test.h"
#include "DSSP_SA_interface.h"


#include "../Fragment_base/Chain_binary.h"

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>



#include "../Fragment_base/accepted_chain_data.h"



#include "../../../PB_RMSD/foundation/PB_RMSD.h"
#include "../../../PB_RMSD/foundation/pb16_to_index.h"

#include "../Chain_store/DSSP_binary.h"



#include <bits/stdc++.h>




using namespace std;

extern ofstream log_stream;

DSSP_SA_interface_test::~DSSP_SA_interface_test()
{
	cout << "DSSP_SA_interface_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;

}

void DSSP_SA_interface_test::create_binary_DSSP_pull()
{

    //const string good_bin_dssp_list="/home/milch/projects/Didona/Store/Chain_store/Culled_30";

    const string good_bin_dssp_list="/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/Culled_30.not_empty";


    ifstream  source_stream ( good_bin_dssp_list.c_str() );
  	if ( ! source_stream )	{
  		log_stream	        << "ERROR -  can't open file" << good_bin_dssp_list<< endl;
  		cout		        << "ERROR -  can't open file" << good_bin_dssp_list<< endl;
  		exit (1);
  	}


    int counter = 0;
    string current_line;
    vector < string >	accepted_chain_ID_list;

	///vector <string> wrong_pdb_list;  с этим ранее разобрались
	while( getline( source_stream , current_line, '\n' ) )
	{
		string cu_chain_ID;
		istringstream ist (current_line);
		ist >> cu_chain_ID;

		accepted_chain_ID_list.push_back(cu_chain_ID);
        counter++;

    }

    for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
    {
        cout <<  ii<< " " << accepted_chain_ID_list [ii] << endl;
        DSSP_binary dsb_com(accepted_chain_ID_list[ii],FILL_UP) ;
    }



}
void DSSP_SA_interface_test::fill_up_test()
{

   //	const string good_bin_dssp_list="/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/CB513.not_empty";

   ///const string good_bin_dssp_list="/home/milch/projects/Didona/Store/Chain_store/CB513";


    const string good_bin_dssp_list="/media/milch/Новый\ том/ML_calculation/CaspDeBrew";


    DSSP_SA_interface ob(good_bin_dssp_list,FILL_UP_DSSP_SA_INTERFACE);

}
