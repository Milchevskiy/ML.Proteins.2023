#include "Pair_string_double.h"

Pair_string_double::
Pair_string_double( const string index, const double value ) :
 index_ (index),
 value_ (value) 
{
}
