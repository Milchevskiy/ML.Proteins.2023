#include "CommonFunc.h"
#include <fstream>
#include <sstream>
#include <string>


extern ofstream log_stream;

void	get_angles_from_tune_file (
		vector <vector <double > >  & Phi_set,
		vector <vector <double > >  & Psi_set,
		vector <vector <double > >  & Omega_set,
		vector <string>				& conformation_name,
		const string				& data_filename)
{
//standard_alpha_helix_pull
//-60 	-45 	180 	-60 	-45 	180 	-60 	-45 	180 	-60 	-45 	180 	-60 	-45 	180
//standard_antiparallel_betta

	ifstream  in( data_filename.c_str() );
	if ( ! in )	{
		log_stream	 << "ERROR -  can't find binary file in get_angles_from_tune_file()" << data_filename<< endl;
		cout		 << "ERROR -  can't find binary file шт get_angles_from_tune_file() " << data_filename<< endl;

		exit (1);
	}

	int length;

	string current_line;
	getline( in  , current_line, '\n' );
	{
		string word;

		istringstream ist (current_line);
		ist >> word >> length;
	}


		/*  DUMMY CHECK*/ getline( in  , current_line, '\n' );
	int counter = 0;
	while( getline( in  , current_line, '\n' ) )
	{
		if (current_line[0]!='/' && current_line[0]!='#' )
			counter ++;
	}

	conformation_name.resize(counter);
	Phi_set.resize(counter);
	Psi_set.resize(counter);
	Omega_set.resize(counter);

	in.seekg(0,ios::beg);

	int position = in.tellg();

	in.close();


	ifstream  in1( data_filename.c_str() );
	if ( ! in1 )	{
		log_stream	 << "ERROR -  can't find binary file get_angles_from_tune_file() line 61 " << data_filename<< endl;
		cout		 << "ERROR -  can't find binary file get_angles_from_tune_file()  line 61" << data_filename<< endl;
		exit (1);
	}



	counter = 0;
	getline( in1  , current_line, '\n' );
//c	getline( in1  , current_line, '\n' );

	while( getline( in1  , current_line, '\n' ) )
	{
		conformation_name[counter]=current_line;
		getline( in1, current_line, '\n' );

		int local_counter =0;
		double current_Phi,current_Psi,current_omega;
		{
			istringstream ist (current_line);
			while( ist >> current_Phi >> current_Psi >> current_omega )
			{
				Phi_set		[counter].push_back(current_Phi );
				Psi_set		[counter].push_back(current_Psi );
				Omega_set	[counter].push_back(current_omega);
				local_counter ++;
			}
		}
		local_counter =0;
		counter++;
	}
}

