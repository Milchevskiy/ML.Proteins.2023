#pragma warning( disable : 4786 )

#include "../Statistical_utilits/statistic_general_purpose.h"

#include "../CommonFunc.h"
#include "Matrix_utilits.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <cmath>
 
using namespace std;

extern ofstream		log_stream;

// !!! MATRIX - ������������ ������������ ������������ �������� !!!

vector < vector  < double > >  InverseMatrix ( 
	vector < vector  < double > > & matrix,
	vector <int>  & sweep_flag,	
	const double tolerance)
{
	double	VERY_small_positive_value = epsilon_float();

	int matrix_size = matrix .size();
	vector <double> d;			d.			resize( matrix_size );
	vector <double> x;			x.			resize( matrix_size );
								sweep_flag.	resize( matrix_size );

	for (int ii=0; ii < matrix_size; ii++ )
		d[ii] =  matrix[ii][ii];

	vector <double> one_dimensional_marix = pull_out_upper_triagle ( matrix  );


	for (ii=0; ii < matrix_size; ii++ )
	{
		if (  one_dimensional_marix  [ one_dimensional_matrix_index(  ii,  ii, matrix_size) ] / d[ii] < tolerance )
		{
			sweep_flag[ii] = 0;
			continue;
		}
		else 
		{
			sweep_flag[ii] = 1;
			sweep_operator(matrix_size,ii,-1,one_dimensional_marix,x); 
		}
	}

	vector < vector  < double > >  inv_matrix; 	inv_matrix.resize (matrix_size);
	for ( ii=0; ii < matrix_size; ii++) 
		inv_matrix[ii].resize (matrix_size);

	for (  ii=0; ii< matrix_size; ii++ )
	{
		for ( int kk=0; kk< matrix_size; kk++ )
		{
			int ii_index = one_dimensional_matrix_index(  ii,  ii, matrix_size) ;
			int kk_index = one_dimensional_matrix_index(  kk,  kk, matrix_size) ;
			if ( one_dimensional_marix [ ii_index  ] >  VERY_small_positive_value || 
				 one_dimensional_marix [ kk_index  ] >  VERY_small_positive_value ) 
			{
				inv_matrix [ii][kk] = 0;
				inv_matrix [kk][ii] = 0;
			}
			else 
			{
				int c_index = one_dimensional_matrix_index(  ii,  kk, matrix_size) ;
				inv_matrix [ii][kk] =  - one_dimensional_marix [ c_index ];
				inv_matrix [kk][ii] =  - one_dimensional_marix [ c_index ];
			}
		}
	}

	return inv_matrix;	
}