#pragma warning( disable : 4786 )

#include "InverseMatrix_test.h"


#include <fstream>
#include <iostream>
#include <cassert>
#include <vector>

#include "../Statistical_utilits/statistic_general_purpose.h"

#include "Matrix_utilits.h"

using namespace std;

extern ofstream log_stream;

vector < vector  < double > >  InverseMatrix ( const vector < vector  < double > > & matrix );

InverseMatrix_test::~InverseMatrix_test()
{
	cout << "InverseMatrix_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}


void InverseMatrix_test::
first_test()
{
	vector  < double >  matrix;

	vector < double > x; x.resize(2);

	matrix.resize(3);
	

	matrix[0]=2;
	matrix[1]=-1;
	matrix[2]=2;
	

	sweep_operator(2,0,-1,matrix,x); 
	sweep_operator(2,1,-1,matrix,x); 

	//vector < vector  < double > > inv_matrix = InverseMatrix ( matrix );

	for (	int	ii=0;ii<3;ii++)
	{
		cout << 	matrix [ii]<< " ";
		cout << 	endl;
	}
}

void InverseMatrix_test::
matr_mlt_matr_test	()
{
	ifstream left_stream ("DIR_tests/left.matrix") ;
	if ( ! left_stream )	{	
		//log_stream << "Can't find get_core_residue_atom_array_test "<< endl;
		cout       << "Can't find file  " << "left.matrix"<< endl;
		exit (1);	
	}

	ifstream right_stream ("DIR_tests/right.matrix") ;
	if ( ! right_stream )	{	
		//log_stream << "Can't find get_core_residue_atom_array_test "<< endl;
		cout       << "Can't find file  " << "right.matrix"<< endl;
		exit (1);	
	}

	ofstream res_stream ("DIR_tests/result.matrix") ;
	if ( ! res_stream )	{	
		//log_stream << "Can't find get_core_residue_atom_array_test "<< endl;
		cout       << "Can't create file  " << "result.matrix"<< endl;
		exit (1);	
	}
	vector < vector  < double > >	left	= get_matrix_from_txt_file ( left_stream  ) ;
	vector < vector  < double > >	right	= get_matrix_from_txt_file ( right_stream ) ;

	vector < vector < double > >	result	= matr_mlt_matr ( left,right );

	print_rectangular_matrix ( 
		string ("left rectangular matrix"),res_stream ,left );
	
	print_rectangular_matrix ( 
		string ("right rectangular matrix"),res_stream ,right);

	print_rectangular_matrix ( 
		string ("result of multiplication two rectangular matrix"),res_stream ,result );
}

void InverseMatrix_test::
transpose_matr_mlt_matr_test	()
{
	ifstream left_stream ("DIR_tests/left.matrix") ;
	if ( ! left_stream )	{	
		//log_stream << "Can't find get_core_residue_atom_array_test "<< endl;
		cout       << "Can't find file  " << "left.matrix"<< endl;
		exit (1);	
	}

	ofstream res_stream ("DIR_tests/transpose_matr_mlt_matr_test.matrix") ;
	if ( ! res_stream )	{	
		//log_stream << "Can't find get_core_residue_atom_array_test "<< endl;
		cout       << "Can't create file  " << "result.matrix"<< endl;
		exit (1);	
	}

	vector < vector  < double > >	left	= get_matrix_from_txt_file ( left_stream  ) ;
	vector < vector < double > > result = transpose_matr_mlt_matr (	left,left );	

	print_rectangular_matrix ( 
		string ("initial  rectangular matrix"),res_stream ,left );

	print_rectangular_matrix ( 
		string ("transpose mult. by plain rectangular matrix"),res_stream ,result );

	vector < double > x; x.resize(10);

//  ������� ��� ������������ ������
	vector <double> one_dimensional_marix = pull_out_upper_triagle ( result );

	sweep_operator(2,0,-1,one_dimensional_marix,x); 
	sweep_operator(2,1,-1,one_dimensional_marix,x); 

	print_symmetrical_rectangular_matrix ( 
		string ("inverce rectangular matrix"),res_stream ,one_dimensional_marix );

}

void InverseMatrix_test::
oh_at_last_inverse_matrix       ()
{
	string path_to_for_inverse_matrix = string ( "DIR_tests/for_inverse.matrix" );

	ifstream in_stream ( path_to_for_inverse_matrix.c_str() ) ;
	if ( ! in_stream )	{	
		cout       << "Can't find file  " << "left.matrix"<< endl;
		exit (1);	
	}

	vector < vector  < double > >for_inverse_matrix	= get_matrix_from_txt_file ( in_stream ) ;
	vector < vector < double > > trm_to_m  = transpose_matr_mlt_matr (	for_inverse_matrix	,for_inverse_matrix	);	


	string path_to_trm_to_m = string ( "DIR_tests/trm_to_m.matrix" );
/*	print_rectangular_matrix ( 
		string ("transpose mult. by plain rectangular matrix"), 
		path_to_trm_to_m,
		trm_to_m,
		8,2);
*/

	 print_rectangular_matrix ( 
		string ("transpose mult. by plain rectangular matrix"), 
		path_to_trm_to_m, 
		trm_to_m , 8,3);
	


	vector <double> one_dimensional_marix = pull_out_upper_triagle ( trm_to_m );
	
	int matrix_size = trm_to_m.size();
	vector <double> ori_diagonal; ori_diagonal.resize( matrix_size );
	vector <double> x; x.resize( matrix_size );
	vector <int>  sweep_flag;  sweep_flag.resize( matrix_size );

	for (int ii=0; ii < matrix_size; ii++ )
		ori_diagonal[ii] =  trm_to_m[ii][ii];


//***************************** tolerance ***************************/
	double tolerance = 0.01;  

	for (ii=0; ii < matrix_size; ii++ )
	{
		if (  one_dimensional_marix  [ one_dimensional_matrix_index(  ii,  ii, matrix_size) ] / ori_diagonal[ii] < tolerance )
		{
			sweep_flag[ii] = 0;
			continue;
		}
		else 
		{
			sweep_flag[ii] = 1;
			sweep_operator(matrix_size,ii,-1,one_dimensional_marix,x); 
		}
	}

	print_symmetrical_rectangular_matrix ( 
		string ("inverce rectangular matrix"), string( "DIR_tests/inverse.matrix"),one_dimensional_marix, 8,3 );

}

void InverseMatrix_test::
true_InverseMatrix_test        ()
{

	string path_to_matrix = string ( "DIR_tests/sym_squarte.matrix" );
	ifstream in_stream ( path_to_matrix.c_str() ) ;
	if ( ! in_stream )	{	
		cout       << "Can't find file  " << path_to_matrix  << endl;
		exit (1);	
	}

	vector < vector  < double > > matrix= get_matrix_from_txt_file ( in_stream ) ;

	vector <int>   sweep_flag;
	double tolerance = 0.01;
	vector < vector  < double > > inv_matrix = 			InverseMatrix ( 
		matrix,
		sweep_flag,	
		tolerance);

	for (int ii=0;ii<inv_matrix.size();ii++)
		cout << sweep_flag[ii] << endl;


	 string path_to_inverse_matrix = string ("DIR_tests/inverse.matrix");
	 print_rectangular_matrix ( 
		string ("inverse matrix by plain symmetrical rectangular matrix"), 
		path_to_inverse_matrix, 
		inv_matrix , 8,3);


	 //vector < vector < double > >	unit_matrix	= matr_mlt_matr ( matrix,inv_matrix );

	 vector < vector < double > >	unit_matrix	= scecial_squarte_matr_mlt_matr ( matrix,inv_matrix, sweep_flag );


 	 string path_to_unit_matrix = string ("DIR_tests/unit.matrix");
	 print_rectangular_matrix ( 
		string ("inverse matrix by plain symmetrical rectangular matrix"), 
		path_to_unit_matrix , 
		unit_matrix , 8,3);


}
void InverseMatrix_test::
real_calc_test					()
{

	vector < vector  < double > > X = get_matrix_from_txt_file (string("D:/Model_store/freq_x5_2/plain_results/X.matrix "));
	vector < vector  < double > > Y = get_matrix_from_txt_file (string("D:/Model_store/freq_x5_2/plain_results/Y.matrix "));

	vector < vector  < double > > YtY =  transpose_matr_mlt_matr ( Y,Y);
	vector < vector  < double > > XtY =  transpose_matr_mlt_matr ( X,Y);


	vector <int>   sweep_flag;
	double tolerance = 0.001;
	vector < vector  < double > > inv_YtY = 			InverseMatrix ( 
		YtY,
		sweep_flag,	
		tolerance);


	vector < vector  < double > > R  = scecial_squarte_matr_mlt_matr ( XtY ,inv_YtY, sweep_flag );



	string path_to_inv_YtY   = string ("DIR_tests/inv_YtY .matrix");
	 print_rectangular_matrix ( 
		string ("inv_YtY.matrix"), 
		path_to_inv_YtY , 
		inv_YtY, 20,5);


	string path_to_YtY  = string ("DIR_tests/YtY.matrix");
	 print_rectangular_matrix ( 
		string ("YtY.matrix"), 
		path_to_YtY , 
		YtY, 20,5);

	string path_to_XtY  = string ("DIR_tests/XtY.matrix");
	 print_rectangular_matrix ( 
		string ("XtY.matrix"), 
		path_to_XtY , 
		XtY, 20,5);



	string path_to_R_matrix  = string ("DIR_tests/R.matrix");
	 print_rectangular_matrix ( 
		string ("R matrix"), 
		path_to_R_matrix  , 
		R, 20,5);


	vector < vector < double > > Ycorrected = matr_mlt_transpose_matr (	R , Y);


	vector < vector < double > > Ycorrected_transposed =  transpose_matrix (Ycorrected );
	
	string path_to_Ycorrected   = string ("DIR_tests/Ycorrected.matrix");
	 print_rectangular_matrix ( 
		string ("Ycorrected "), 
		path_to_Ycorrected  , 
		Ycorrected_transposed , 20,5);


}