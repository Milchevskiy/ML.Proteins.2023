#include "Matrix_utilits.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <cassert>

extern ofstream		log_stream;

using namespace std;


vector < vector < double > > matr_mlt_transpose_matr (
	vector < vector < double > > & left ,
	vector < vector < double > > & right )
{
	vector < vector < double > > transposed_right	= transpose_matrix ( right  );
	vector < vector < double > > result				= matr_mlt_matr ( left ,	transposed_right );

	return result;


}


