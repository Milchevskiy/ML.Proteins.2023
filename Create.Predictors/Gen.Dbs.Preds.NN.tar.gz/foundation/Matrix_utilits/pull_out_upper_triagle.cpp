#include "matrix_utilits.h"
#include <cassert>

vector <double> pull_out_upper_triagle ( vector < vector < double > > & matrix )
{
	int row_number = matrix .size();
	int col_number = matrix [0].size();

	assert ( row_number == col_number );

	vector < double > upper_triangle_matrix; 

	for ( int ii=0;ii<row_number;ii++)
	{
		for ( int kk=ii;kk<row_number;kk++)
			upper_triangle_matrix.push_back (matrix [ii][kk] );
	}
	return upper_triangle_matrix;
}