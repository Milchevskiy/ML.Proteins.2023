#include <sstream>
#include <fstream>
#include <iostream>
#include <vector>

using namespace std;

extern ofstream		log_stream;

vector < vector  < double > > get_matrix_from_txt_file ( ifstream & in_stream )
{
	vector < vector < double > > matrix;

	string current_line;
	while ( getline(in_stream,current_line,'\n' ) )
	{
		if (   current_line[0] == '/'  || 
		       current_line[0] == '#'  || 
		       current_line[0] == ' '  || 
		       current_line[0] == '\n' || 
		       current_line[0] == '\0'  )
		  continue;

		istringstream ist( current_line );

		vector < double > current_vector ;
		double d_value ;
		while ( ist >> d_value )
			current_vector.push_back(d_value ) ;

		matrix.push_back( current_vector );

		current_vector .resize(0);
	}

//	*** check_matrix_size compartibility *** 
	int number_of_columns = matrix[0].size();

	for (int ii=0;ii<matrix.size();ii++)
	{
		if ( matrix[ii].size() != number_of_columns ) 
		{
			cout		<< " get_matrix_from_txt_file () ERROR: check column number " << endl;
			log_stream	<< " get_matrix_from_txt_file () ERROR: check column number " << endl;
			exit (1);
		}
	}

	return matrix;
}

vector < vector  < double > > get_matrix_from_txt_file ( const string & source_file_name)
{

	ifstream in_stream ( source_file_name.c_str() ) ;
	if ( ! in_stream )	{	
		cout       << "Can't find file  " << source_file_name<< endl;
		exit (1);	
	}

	return get_matrix_from_txt_file ( in_stream  );

}