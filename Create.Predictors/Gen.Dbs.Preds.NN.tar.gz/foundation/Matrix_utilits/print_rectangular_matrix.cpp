#pragma warning( disable : 4786 )

#include "Matrix_utilits.h"
#include "../CommonFunc.h"

#include <fstream>

using namespace std;

void print_rectangular_matrix ( 
	string & header, 
	ofstream & res_stream, 
	const vector < vector <double > > & matrix )
{
	int number_of_rows		= matrix.size();
	int number_of_columns	= matrix[0].size();

	res_stream << header << endl;
	for (int ii=0 ; ii < number_of_rows; ii++ )
	{
		for (int kk=0; kk<number_of_columns; kk++	)
			PutVaDouble ( matrix [ii][kk],res_stream, 25, 5, 'l' ); res_stream << "  ";
		res_stream << endl;
	}

}


void print_rectangular_matrix ( 
	string & header, 
	 string & res_file_name, 
	 vector < vector <double > > & matrix,
	int field_size, 
	int after_decimal_point)
{

	ofstream res_stream (res_file_name.c_str() ) ;
	if ( ! res_stream )	{	
		cout       << "Can't create file  " << res_file_name << endl;
		exit (1);	
	}
	int number_of_rows		= matrix.size();
	int number_of_columns	= matrix[0].size();

	res_stream << header << endl;
	for (int ii=0 ; ii < number_of_rows; ii++ )
	{
		for (int kk=0; kk<number_of_columns; kk++	)
		PutVaDouble ( matrix [ii][kk],res_stream, field_size, after_decimal_point, 'l' ); res_stream << "  ";
	//	PutVaDouble ( matrix [ii][kk],res_stream, 8, 3, 'l' ); res_stream << "  ";

		res_stream << endl;
	}

}