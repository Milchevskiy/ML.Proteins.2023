#ifndef INVERSEMATRIX_TEST_H
#define INVERSEMATRIX_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  InverseMatrix_test: public Simple_test
{
public:
	~InverseMatrix_test();

    void run()
    {
//		first_test						();
//		matr_mlt_matr_test				();
//		transpose_matr_mlt_matr_test	();
//		oh_at_last_inverse_matrix       ();
//		true_InverseMatrix_test         ();
		real_calc_test					();

	}
	void first_test						();
	void matr_mlt_matr_test				();
	void transpose_matr_mlt_matr_test	();
	void oh_at_last_inverse_matrix      ();
	void true_InverseMatrix_test        ();
	void real_calc_test					();
};

#endif
