#include "Matrix_utilits.h"
#include <cassert>

vector < vector < double > >	scecial_squarte_matr_mlt_matr ( 
	vector < vector < double > >	& matrix,
	vector < vector < double > >	& inv_matrix, 
	vector < int > & sweep_flag )
{
	int size = inv_matrix.size();
	assert (matrix.size()		== size );
	assert (sweep_flag.size()	== size );

	vector < vector < double > >	unit_matrix	= matr_mlt_matr ( matrix,inv_matrix );


	for (int ii=0;ii<size;ii++)
	{
		if ( ! sweep_flag[ii] )
		{
			for (int kk=0;kk<size;kk++)
			{
				unit_matrix [ii][kk] = 0;
				unit_matrix [kk][ii] = 0;
			}
		}
	}

	return unit_matrix;
}