#ifndef MATRIX_UTILITS_H
#define MATRIX_UTILITS_H

#include <vector>

using namespace std;

	vector <double> get_row ( const int index, vector < vector < double > > & left );
	vector <double> get_col ( const int index, vector < vector < double > > & right);

	double scalar_mult ( const vector <double> & cu_row, const vector <double> & cu_col);

	vector < vector < double > > matr_mlt_matr ( 
		vector < vector < double > > & left ,
		vector < vector < double > > & right );

	vector < vector  < double > > get_matrix_from_txt_file ( ifstream & in_stream );
	vector < vector  < double > > get_matrix_from_txt_file ( const string & source_file_name);

	void print_rectangular_matrix ( 
		string & header, 
		ofstream & res_stream, 
		const vector < vector <double > > & matrix );
	void print_rectangular_matrix ( 
		string & header, 
		 string & res_file_name, 
		 vector < vector <double > > & matrix,
		 int, int);

	void print_symmetrical_rectangular_matrix (
			string & header, 
		ofstream & res_stream, 
		const  vector <double >  & matrix );
	void print_symmetrical_rectangular_matrix  (
		string & header, 
		const string & res_file_name, 
		const  vector <double >  & matrix,
		int field_size, 
		int after_decimal_point);


	vector < vector < double > > transpose_matr_mlt_matr (
		vector < vector < double > > & left ,
		vector < vector < double > > & right );


	vector < vector < double > > matr_mlt_transpose_matr (
		vector < vector < double > > & left ,
		vector < vector < double > > & right );


	vector < vector < double > > transpose_matrix ( const vector < vector < double > > & matrix );

	vector <double> pull_out_upper_triagle ( vector < vector < double > > & matrix );

	vector < vector  < double > >  InverseMatrix ( 
		vector < vector  < double > > & matrix,
		vector <int>  & sweep_flag,	
		const double tolerance);

	vector < vector < double > >	scecial_squarte_matr_mlt_matr ( 
		vector < vector < double > >	& matrix,
		vector < vector < double > >	& inv_matrix, 
		vector < int > & sweep_flag );



#endif