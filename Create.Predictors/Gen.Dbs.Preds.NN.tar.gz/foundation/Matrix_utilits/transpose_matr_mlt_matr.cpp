#include "Matrix_utilits.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <cassert>

extern ofstream		log_stream;

using namespace std;

vector < vector < double > > transpose_matr_mlt_matr (
	vector < vector < double > > & left ,
	vector < vector < double > > & right )
{
	assert ( left.size() == right.size() );

	vector < vector < double > > transposed_left	= transpose_matrix ( left );
	vector < vector < double > > result				= matr_mlt_matr ( transposed_left ,	right );

	return result;
}

