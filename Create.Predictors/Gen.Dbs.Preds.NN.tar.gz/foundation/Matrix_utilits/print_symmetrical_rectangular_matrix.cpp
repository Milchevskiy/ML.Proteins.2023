#pragma warning( disable : 4786 )

#include "Matrix_utilits.h"
#include "../CommonFunc.h"

#include "../Statistical_utilits/Statistic_general_purpose.h"

#include <fstream>

using namespace std;

void print_symmetrical_rectangular_matrix  (
		string & header, 
		ofstream & res_stream, 
		const  vector <double >  & matrix )
{

	res_stream << header << endl;

	int one_dim_size = matrix .size();

	int size = (int) (-1 + sqrt (1+8*one_dim_size ) )/2;

	for ( int ii=0; ii < size; ii++)
	{
		for ( int kk=0; kk < size; kk++)
		{
			int index = ( kk >= ii ) ? one_dimensional_matrix_index (ii,kk,size ) : one_dimensional_matrix_index (kk,ii,size ) ;
			PutVaDouble (matrix[index],res_stream,8,2,'l');  res_stream << " ";
		}
		res_stream << endl;
	}
}

void print_symmetrical_rectangular_matrix  (
		string & header, 
		const string & res_file_name, 
		const  vector <double >  & matrix,
		int field_size, 
		int after_decimal_point)
{

	ofstream res_stream (res_file_name.c_str() ) ;
	if ( ! res_stream )	{	
		cout       << "Can't create file  " << res_file_name << endl;
		exit (1);	
	}

	res_stream << header << endl;

	int one_dim_size = matrix .size();

	int size = (int) (-1 + sqrt (1+8*one_dim_size ) )/2;

	for ( int ii=0; ii < size; ii++)
	{
		for ( int kk=0; kk < size; kk++)
		{
			int index = ( kk >= ii ) ? one_dimensional_matrix_index (ii,kk,size ) : one_dimensional_matrix_index (kk,ii,size ) ;
			PutVaDouble (matrix[index],res_stream, field_size, after_decimal_point,'l');  res_stream << " ";
		}
		res_stream << endl;
	}
}
