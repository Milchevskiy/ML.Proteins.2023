#include "../Statistical_utilits/statistic_general_purpose.h"

#include "Matrix_utilits.h"

#include <cassert>
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>

extern ofstream		log_stream;

using namespace std;

vector < vector < double > > matr_mlt_matr (
	vector < vector < double > > & left ,
	vector < vector < double > > & right )
{
	int l_row_number = left.size();
	int l_col_number = left[0].size();

	int r_row_number = right.size();
	int r_col_number = right [0].size();

	assert ( l_col_number == r_row_number );

	vector < vector < double > > result;
	result.resize ( l_row_number );
	for (int ii=0;ii<l_row_number;ii++)
		result[ii].resize(r_col_number);
    int ii;
	for (ii=0;ii<l_row_number;ii++)
	{
		vector <double> cu_row = get_row (ii,left);
		for ( int jj=0;jj< r_col_number; jj++ )
		{
			vector <double> cu_col = get_col (jj,right);
			result[ii][jj] = scalar_mult (cu_row,cu_col);
		}
	}

	return result;
}


vector <double> get_row (
	const int index,
	vector < vector < double > > & matrix)
{
	int col_number = matrix[0].size();
	vector <double> row; row.resize (col_number);

	for (int ii=0; ii < col_number; ii++)
		row[ii] = matrix[index][ii];

	return row;
}

vector <double> get_col (
	const int index,
	vector < vector < double > > & matrix)
{
	int row_number = matrix.size();
	vector <double> col; col.resize (row_number);
	for (int ii=0; ii < row_number ; ii++)
		col[ii] = matrix[ii][index];

	return col;
}



double scalar_mult (
	const vector <double> & cu_row,
	const vector <double> & cu_col)
{
	assert (cu_row.size() == cu_col.size() ) ;
	
	int size = cu_row.size();

	double sum =0;
	for (int ii=0;ii<size ;ii++)
		sum += cu_row[ii]*cu_col[ii];

	return sum;
}
