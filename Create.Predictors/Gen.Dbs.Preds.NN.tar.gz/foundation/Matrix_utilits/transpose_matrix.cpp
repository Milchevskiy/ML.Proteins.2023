#include "Matrix_utilits.h"

vector < vector < double > > transpose_matrix ( const vector < vector < double > > & matrix )
{
	int row_number = matrix .size();
	int col_number = matrix [0].size();

	vector < vector < double > >  transpozed_matrix; 
	transpozed_matrix.resize (col_number);
	for (int ii=0;ii<col_number;ii++)
		transpozed_matrix[ii].resize (row_number);

	for ( int ii=0;ii<row_number;ii++)
	{
		for ( int kk=0;kk<col_number;kk++)
			transpozed_matrix[kk][ii] = matrix [ii][kk];
	}

	return transpozed_matrix;
}