#pragma warning(disable : 4786)

#include "HelixParameters_test.h"
#include "HelixParameters.h"

#include "../CommonFunc.h"
#include "../Censorship.h"

#include <fstream>
#include <string>

#include "../make_claster_motif_by_dihedral_set.h"
#include "../Fragment_base/accepted_chain_data.h"

#include "../CowardVariables/Distance_to_claster_variables.h"

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;

HelixParameters_test::
~HelixParameters_test()
{
    cout << "HelixParameters_test PASSED: " << "  failed: " << get_failed() << "	passed: " << get_passed() << endl;
}

void HelixParameters_test::simple_variables_creation_test()

{
    string path_PPII_assignment_store       = "../Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/";
    string path_PPII_assignment_store_list	= "../Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/list";
    ifstream  in_stream(path_PPII_assignment_store_list.c_str());
    if (!in_stream)
    {
        log_stream << "Can't find tune file" << path_PPII_assignment_store_list << endl;
        cout << "Can't find tune file" << path_PPII_assignment_store_list << endl;
        exit(1);
    }


    vector < string >   pdb_list;

    string current_word;
    while (in_stream >> current_word)
        pdb_list.push_back(current_word);



    string path_to_da_data_file = "../Store/new_SS_assignment/_da_data.txt";
    ofstream da_stream(path_to_da_data_file.c_str());
    if (!da_stream)
    {
        log_stream << "can't create " << path_to_da_data_file << endl;
        cout << "can't create " << path_to_da_data_file << endl;
        exit(1);
    }

    string path_to_da_data_indexes = "../Store/new_SS_assignment/_da_data.indexes";
    ofstream da_indexes(path_to_da_data_indexes.c_str());
    if (!da_indexes)
    {
        log_stream << "can't create " << path_to_da_data_indexes << endl;
        cout << "can't create " << path_to_da_data_indexes << endl;
        exit(1);
    }

/// Setting parameters here
    int helix_length = 2;
///************************

    int number_of_classes;
    int fragment_length_by_dihedral_store;

    string  path_to_dihedral_store = "../Store/Cluster_set/Manulally_1/positioning_chain_by_clasters_set_PPII_test.txt";

    double **claster_motif_coordinates = make_claster_motif_by_dihedral_set(
            path_to_dihedral_store,
            number_of_classes,
            fragment_length_by_dihedral_store);

    cout << claster_motif_coordinates[0][0] << " " << claster_motif_coordinates[0][1] << claster_motif_coordinates[0][2] << endl;
    cout << claster_motif_coordinates[0][3] << " " << claster_motif_coordinates[0][4] << claster_motif_coordinates[0][5] << endl;

    string model_name = string("new_generation_model_2");
    Distance_to_claster_variables *dicl_creator = new	 Distance_to_claster_variables(model_name);

    int global_index = 0;
    for (unsigned ii = 0; ii < pdb_list.size(); ii++)
    {
        string protocol_file_name = "../Store/new_SS_assignment/protocol/" + pdb_list[ii] + ".protocol";
        single_variable_creation(
            global_index,
            pdb_list[ii],
            protocol_file_name,
            helix_length,
            //path_to_dihedral_store,
            path_PPII_assignment_store,
            claster_motif_coordinates,
            number_of_classes,
            da_stream,
            da_indexes,
            dicl_creator);
    }

    delete dicl_creator;
    for (int kk = 0; kk<number_of_classes; kk++)
        delete[] claster_motif_coordinates[kk];
    delete[] claster_motif_coordinates;

}
void HelixParameters_test::simple_test()
{
    int number_of_classes=0;
    int fragment_length=0;

    string  path_to_dihedral_store = "../Store/Cluster_set/Manulally_1/angles.txt";

    double **claster_motif_coordinates = make_claster_motif_by_dihedral_set(
            path_to_dihedral_store,
            number_of_classes,
            fragment_length	);

    /*
    	void Traditional_Helix_Parameters_calc
    	(int StartIndexNu,  //- index in cooordinate storage
    		int WinLen,			// number of assymetrical subunints
    		int MaStShift,		// length of assymetrical subunints i.e. shift in baxkbone atom mumber
    		double *m_cha_coord,  // main chain coordinates (N,CA,C ....)
    		double & MeanCOS,
    		double & MeanHH)
    */

    //int test = sizeof(claster_motif_coordinates[0][0]);

    int residue_index = 0;
    int residue_window = 3;
    int residue_shift = 1;


    for (int ii = 0; ii < number_of_classes; ii++)
    {
        double  MeanCOS, MeanHH, dispCos, dispHH, MeanAngle, dispAngle;

        Traditional_Helix_Parameters_calc(
            residue_index,
            residue_window,
            residue_shift,
            fragment_length,
            claster_motif_coordinates[ii],
            MeanCOS,
            dispCos,
            MeanAngle,
            dispAngle,
            MeanHH,
            dispHH);

        cout << MeanCOS		<< " (" << dispCos		<< " )" << "\t" ;
        cout << MeanAngle	<< " (" << dispAngle	<< " )" << "\t";
        cout << MeanHH		<< " (" << dispHH		<< " )" << endl;

    }

    for (int ii = 0; ii < number_of_classes; ii++)
        delete[] claster_motif_coordinates[ii];
    delete [] claster_motif_coordinates;

}

#include "../Fragment_base/Chain_binary.h"

void HelixParameters_test::handle_single_chain()
{
    int fragment_length = 2;

    //Chain_binary cb("2VB1A");
    //Chain_binary cb("2VAKA");
    //Chain_binary cb("1C26A");
    //Chain_binary cb("1RJUV");
    //Chain_binary cb("1A62A");
    Chain_binary cb("16VPA");
//	Chain_binary cb("1BKVA");


    string sequence = cb.get_sequence();

    vector <string> residue_names			= cb.get_residue_names();
    vector <string> in_chain_residue_number = cb.get_in_chain_residue_number();
    bool*			is_there_coord			= cb.get_is_there_coord();
    bool*			is_geometry_admissible	= cb.get_is_geometry_admissible();

    int				number_of_residues		= cb.get_number_of_residues();

    vector < double >  set_of_rise_per_residue;
    vector < double >  disp_set_of_rise_per_residue;
    vector < double >  set_cos_rotation_angle;
    vector < double >  disp_disp_of_cos_rotation_angles;
    vector < double >  set_of_rotation_angle_degrees;
    vector < double >  disp_set_of_rotation_angle_degrees;

    cb.positioning_chain_by_helical_parameters(
        fragment_length,
        set_of_rise_per_residue,
        disp_set_of_rise_per_residue,
        set_cos_rotation_angle,
        disp_disp_of_cos_rotation_angles,
        set_of_rotation_angle_degrees,
        disp_set_of_rotation_angle_degrees);


    int shift = fragment_length / 2;
    for (int ii = 0; ii < set_of_rise_per_residue.size(); ii++)
    {
        cout << sequence[ii+shift];

        PutVaDouble(set_of_rise_per_residue[ii],			cout, 8, 3, 'r');
        PutVaDouble(disp_set_of_rise_per_residue[ii], cout, 8, 3, 'r');
        cout << '\t';
//		PutVaDouble(set_cos_rotation_angle[ii],				cout, 8, 3, 'r');
//		PutVaDouble(disp_disp_of_cos_rotation_angles[ii],	cout, 8, 3, 'r'); cout << '\t';
        PutVaDouble(set_of_rotation_angle_degrees[ii],		cout, 8, 3, 'r');
        PutVaDouble(disp_set_of_rotation_angle_degrees[ii], cout, 8, 3, 'r');
        cout << endl;

    }

}

void HelixParameters_test::
helix_pameters_protocol_test()
{

    int helix_length = 2;

    /*
    	vector <string> accepted_chain_ID_list;
    	vector <int >	accepted_chain_lenth;

    	string binary_file_name("accepted_chain_list.bin");

    	fill_up_accepted_chain_data(
    		accepted_chain_ID_list,
    		accepted_chain_lenth,
    		binary_file_name);
    */

    string path_PPII_assignment_store = "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/";

    string path_PPII_assignment_store_list=  "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/list";

    ifstream  in_stream(path_PPII_assignment_store_list.c_str());
    if (!in_stream)
    {
        log_stream << "Can't find tune file"	<< path_PPII_assignment_store_list << endl;
        cout << "Can't find tune file"			<< path_PPII_assignment_store_list << endl;
        exit(1);
    }

    vector < string >   pdb_list;

    string current_word;
    while (in_stream >> current_word)
        pdb_list.push_back(current_word);




    string path_to_dihedral_store	= "D:/Didona/Store/new_SS_assignment/left_helix_angles_3.txt";

    string path_to_da_data_file = "D:/Didona/Store/new_SS_assignment/da_data.txt";
    ofstream da_stream(path_to_da_data_file.c_str());
    if (!da_stream)
    {
        log_stream << "can't create " << path_to_da_data_file << endl;
        cout << "can't create " << path_to_da_data_file << endl;
        exit(1);
    }

    string path_to_da_data_indexes = "D:/Didona/Store/new_SS_assignment/da_data.indexes";
    ofstream da_indexes(path_to_da_data_indexes.c_str());
    if (!da_indexes)
    {
        log_stream << "can't create " << path_to_da_data_indexes << endl;
        cout << "can't create " << path_to_da_data_indexes << endl;
        exit(1);
    }


    string model_name = string("new_generation_model_2");

    Distance_to_claster_variables *dicl_creator = new	 Distance_to_claster_variables(model_name);

    for (unsigned ii = 0; ii < pdb_list.size(); ii++)
    {
        string protocol_file_name		= "D:/Didona/Store/new_SS_assignment/protocol/" + pdb_list[ii]+ ".protocol";

        helix_pameters_protocol(
            pdb_list[ii],
            protocol_file_name,
            helix_length,
            path_to_dihedral_store,
            path_PPII_assignment_store,
            da_stream,
            da_indexes,
            dicl_creator);
    }

    delete dicl_creator;
}
