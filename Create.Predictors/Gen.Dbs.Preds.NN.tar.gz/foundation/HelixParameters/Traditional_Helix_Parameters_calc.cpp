// ������������� - ��������, ������� ���� MaStShift  - ����� ������������� �������. ��� ���������� ���������� �����-������� ��� ����� ������� ��� �������� 3 (3 �����)

#include <cstdio>
#include <cstdlib>
#include <memory>
#include <cmath>
#include <cassert>

#include "../CommonFunc.h"
#include "../Statistical_utilits/calc_dispersion_and_average.h" 


#include "HelixParameters.h"

// ��� ���������� ���� �� � �������� header
/*void	LeastSquare2x2(double *TT, double *YY, int EquaNu, double *L1, double *M1);
int		index(int ii, int jj, int row);
void	VectMult_d(double Ax, double Ay, double Az, double Bx, double By, double Bz, double  *Rex, double  *Rey, double  *Rez);
double	GtCosVect(double Tx, double Ty, double Tz, double Px, double Py, double Pz);
*/

void Traditional_Helix_Parameters_calc(
	int residue_index,
	int residue_window,
	int residue_shift,
	int sequence_length,
	double *m_cha_coord,  // main chain coordinates (N,CA,C ....)
	double & MeanCOS,
	double & dispCos,
	double & MeanAngle,
	double & dispAngle,
	double & MeanHH,
	double & dispHH	)
{
	int StartIndexNu = residue_index * 3;  
	int WinLen = residue_window * 3;			// number of assymetrical subunints 
	int MaStShift = residue_shift*3;		// length of assymetrical subunints i.e. shift in baxkbone atom mumber
	
	assert((residue_index + residue_window + residue_shift) < sequence_length);

	double pi = Pythagorean_Number();

	double	TT[1000], YY[500];
	double 	a1x, a1y, a1z, a2x, a2y, a2z, L1, M1, N1;
	double 	Rex1, Rey1, Rez1, Rex2, Rey2, Rez2, dltX, dltY, dltZ, RR, CosNju;
	double 	CurrentHH, CurrentCOS, Test;
	int		ind1, ind2, ind4, ind5, ii, kk;
	double Check1, Check2;
	double Check3, Check4;

	vector <double> cos_aray, hh_aray, angle_array;
	cos_aray.resize(WinLen);	hh_aray.resize(WinLen);  angle_array.resize(WinLen);

	kk = 0;
	for (ii = StartIndexNu; ii < StartIndexNu + WinLen; ii++) {

//I had to redo the indexes, because now the coordinates are a continuous array
//		ind1 = MaStIndex[ii];
//		ind2 = MaStIndex[ii + 1];
//		ind4 = MaStIndex[ii + MaStShift];;
//		ind5 = MaStIndex[ii + MaStShift + 1];;
//I had to redo the indexes, because now the coordinates are a continuous array
		ind1 = 3*ii;
		ind2 = 3*(ii + 1);
		ind4 = 3 * (ii + MaStShift);
		ind5 = 3 * (ii + MaStShift + 1);;


// AddShift & SpecialShift:  This became irrelevant
//		ind1 += AddShift;
//		ind2 += AddShift;
//		ind4 += AddShift + SpecialShift;
//		ind5 += AddShift + SpecialShift;

// Array m_cha_coord  Strictly different from struct Mol
//		a1x = Mol[ind2].DeCo[0] - Mol[ind1].DeCo[0];
//		a1y = Mol[ind2].DeCo[1] - Mol[ind1].DeCo[1];
//		a1z = Mol[ind2].DeCo[2] - Mol[ind1].DeCo[2];

//		a2x = Mol[ind5].DeCo[0] - Mol[ind4].DeCo[0];
//		a2y = Mol[ind5].DeCo[1] - Mol[ind4].DeCo[1];
//		a2z = Mol[ind5].DeCo[2] - Mol[ind4].DeCo[2];


		a1x = m_cha_coord[ind2]		- m_cha_coord[ind1];
		a1y = m_cha_coord[ind2+1]	- m_cha_coord[ind1+1];
		a1z = m_cha_coord[ind2+2]	- m_cha_coord[ind1+2];;

		a2x = m_cha_coord[ind5]		- m_cha_coord[ind4];
		a2y = m_cha_coord[ind5+1]	- m_cha_coord[ind4+1];
		a2z = m_cha_coord[ind5+2]	- m_cha_coord[ind4+2];


		TT[2 * kk] = a1x - a2x;
		TT[2 * kk + 1] = a1y - a2y;
		YY[kk] = a2z - a1z;
		kk++;
	}
	LeastSquare2x2(TT, YY, WinLen, &L1, &M1);
	N1 = 1; // ��� ������������ ��� ������ 
			//for (ii=0; ii<WinLen; ii++ ) {
			//	printf("%5.3lf %5.3lf	%5.3lf\n ",TT[2*ii],TT[2*ii+1],YY[ii]);
			//	printf("Delta = %5.3lf  \n",TT[2*ii]*L1+TT[2*ii+1]*M1 - YY[ii] );
			//}
	MeanCOS = 0.0;	MeanHH = 0.0;
	//for (ii=0; ii<WinLen; ii++ ) {
	for (ii = StartIndexNu; ii < StartIndexNu + WinLen; ii++) 
	{

// like previous cycle
/*
		ind1 = MaStIndex[ii];
		ind2 = MaStIndex[ii + 1];
		ind4 = MaStIndex[ii + MaStShift];;
		ind5 = MaStIndex[ii + MaStShift + 1];;

		ind1 += AddShift;
		ind2 += AddShift;
		ind4 += AddShift + SpecialShift;
		ind5 += AddShift + SpecialShift;

		a1x = Mol[ind2].DeCo[0] - Mol[ind1].DeCo[0];
		a1y = Mol[ind2].DeCo[1] - Mol[ind1].DeCo[1];
		a1z = Mol[ind2].DeCo[2] - Mol[ind1].DeCo[2];

		a2x = Mol[ind5].DeCo[0] - Mol[ind4].DeCo[0];
		a2y = Mol[ind5].DeCo[1] - Mol[ind4].DeCo[1];
		a2z = Mol[ind5].DeCo[2] - Mol[ind4].DeCo[2];
*/

		ind1 = 3 * ii;
		ind2 = 3 * (ii + 1);
		ind4 = 3 * (ii + MaStShift);
		ind5 = 3 * (ii + MaStShift + 1);;


		// AddShift & SpecialShift:  This became irrelevant
		//		ind1 += AddShift;
		//		ind2 += AddShift;
		//		ind4 += AddShift + SpecialShift;
		//		ind5 += AddShift + SpecialShift;

		// Array m_cha_coord  Strictly different from struct Mol
		//		a1x = Mol[ind2].DeCo[0] - Mol[ind1].DeCo[0];
		//		a1y = Mol[ind2].DeCo[1] - Mol[ind1].DeCo[1];
		//		a1z = Mol[ind2].DeCo[2] - Mol[ind1].DeCo[2];

		//		a2x = Mol[ind5].DeCo[0] - Mol[ind4].DeCo[0];
		//		a2y = Mol[ind5].DeCo[1] - Mol[ind4].DeCo[1];
		//		a2z = Mol[ind5].DeCo[2] - Mol[ind4].DeCo[2];


		a1x = m_cha_coord[ind2] - m_cha_coord[ind1];
		a1y = m_cha_coord[ind2 + 1] - m_cha_coord[ind1 + 1];
		a1z = m_cha_coord[ind2 + 2] - m_cha_coord[ind1 + 2];;

		a2x = m_cha_coord[ind5] - m_cha_coord[ind4];
		a2y = m_cha_coord[ind5 + 1] - m_cha_coord[ind4 + 1];
		a2z = m_cha_coord[ind5 + 2] - m_cha_coord[ind4 + 2];



		/**/Check1 = GtCosVect(a1x, a1y, a1z, L1, M1, N1);
		/**/Check2 = GtCosVect(a2x, a2y, a2z, L1, M1, N1);



		/**/Check3 = a1x*a1x + a1y*a1y + a1z*a1z;
		/**/Check4 = a2x*a2x + a2y*a2y + a2z*a2z;


		VectMult_d(a1x, a1y, a1z, L1, M1, N1, &Rex1, &Rey1, &Rez1);
		VectMult_d(a2x, a2y, a2z, L1, M1, N1, &Rex2, &Rey2, &Rez2);

		CurrentCOS = GtCosVect(Rex1, Rey1, Rez1, Rex2, Rey2, Rez2);
		MeanCOS += CurrentCOS;
		cos_aray[ii]= CurrentCOS;	



		Test = acos(CurrentCOS);
		Test *= 180 / pi;  // ������ � �������� 	

		angle_array[ii] = Test;

		// Mol ������ ����
//		dltX = Mol[ind4].DeCo[0] - Mol[ind1].DeCo[0];
//		dltY = Mol[ind4].DeCo[1] - Mol[ind1].DeCo[1];
//		dltZ = Mol[ind4].DeCo[2] - Mol[ind1].DeCo[2];

		dltX = m_cha_coord[ind4]	- m_cha_coord[ind1];
		dltY = m_cha_coord[ind4+1]	- m_cha_coord[ind1+1];
		dltZ = m_cha_coord[ind4+2]	- m_cha_coord[ind1+2];

		RR = sqrt(dltX*dltX + dltY*dltY + dltZ*dltZ);
		CosNju = GtCosVect(dltX, dltY, dltZ, L1, M1, N1);

		CurrentHH = fabs(RR * CosNju);
		MeanHH += CurrentHH;
		hh_aray[ii] = CurrentHH;
	
	}

	MeanCOS /= WinLen;
	MeanHH /= WinLen;

	calc_dispersion_and_average(
		cos_aray,
		MeanCOS,
		dispCos);
	calc_dispersion_and_average(
		hh_aray,
		MeanHH,
		dispHH);
	calc_dispersion_and_average(
		angle_array,
		MeanAngle,
		dispAngle);
}

#define 	EPS 	0.0000000001															
double GtCosVect(double Tx, double Ty, double Tz, double Px, double Py, double Pz) {

	double Sum, Len1, Len2;

	Len1 = sqrt(Tx*Tx + Ty*Ty + Tz*Tz);
	Len2 = sqrt(Px*Px + Py*Py + Pz*Pz);

	if (fabs(Len1)*fabs(Len2)  <  EPS)  // some of vectors is too short 
		return -2;

	Sum = Tx*Px + Ty*Py + Tz*Pz;
	Sum /= (Len1*Len2);

	return Sum;
}
