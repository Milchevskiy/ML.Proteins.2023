#include "../CommonFunc.h"
#include <fstream>

extern ofstream log_stream;

void get_ppii_assignment
(const string & full_path_to_PPII_assignment,
	string & sequence_ppii,
	string & extended_ppii_DSSP_sequence)
{
	ifstream  in_stream(full_path_to_PPII_assignment.c_str());
	if (!in_stream) 
	{
		log_stream << "Can't find tune file" << full_path_to_PPII_assignment << endl;
		cout << "Can't find tune file" << full_path_to_PPII_assignment << endl;
		exit(1);
	}

	in_stream >> sequence_ppii >> extended_ppii_DSSP_sequence;
	

}

