// Vector multiplication of two vercots A & B; results writes in Rex
#include <cmath>

void VectMult_d( double Ax,double Ay,double Az,double Bx,double By,double Bz,\
		 double  *Rex,double  *Rey,double  *Rez) {

		 *Rex=Ay*Bz-Az*By;
		 *Rey=Az*Bx-Ax*Bz;
		 *Rez=Ax*By-Ay*Bx;
}
