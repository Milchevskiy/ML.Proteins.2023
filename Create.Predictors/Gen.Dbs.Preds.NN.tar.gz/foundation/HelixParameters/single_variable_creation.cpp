#include "HelixParameters.h"
#include "../CommonFunc.h"
#include "../Fragment_base/Chain_binary.h"
#include "../make_claster_motif_by_dihedral_set.h"
#include "../Chain_store/DSSP_binary.h"
#include "../Geometry_util/Geometry_util.h"
#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

#include "../CowardVariables/Distance_to_claster_variables.h"

#include <cassert>

#include <fstream>

#ifndef GET_NEAREST_CLASTER_INDEX_H
#define GET_NEAREST_CLASTER_INDEX_H

int get_nearest_claster_index(const vector <double> & distance_set);

#endif


extern ofstream log_stream;

void single_variable_creation(
	int		global_index,
	const	string & pdb_chain_ID,
	const	string & protocol_file_name,
	const	int helix_length,
	//string	& path_to_dihedral_store,
	string	& path_PPII_assignment_store,
	double **claster_motif_coordinates,
	int number_of_classes,
	ofstream & da_stream,
	ofstream & da_indexes,
	Distance_to_claster_variables *dicl_creator)
{
	double **current_claster_motif_coordinates;

	int MAX_FRAGMENT_LENGTH = 5;
	current_claster_motif_coordinates = new double*[number_of_classes];
	for (int ii = 0; ii < number_of_classes; ii++)
	{
		current_claster_motif_coordinates[ii] = new double[MAX_FRAGMENT_LENGTH * 9];
		memcpy(current_claster_motif_coordinates[ii], claster_motif_coordinates[ii], MAX_FRAGMENT_LENGTH * 9*sizeof(double));
	}




	string full_path_to_PPII_assignment = path_PPII_assignment_store + pdb_chain_ID;

	string sequence_ppii;
	string extended_ppii_DSSP_sequence;

	get_ppii_assignment
		(full_path_to_PPII_assignment,
			sequence_ppii,
			extended_ppii_DSSP_sequence);

	ofstream out(protocol_file_name.c_str());
	if (!out)
	{
		log_stream << "can't create " << endl;
		cout << "can't create " << endl;
		exit(1);
	}

	Chain_binary cb(pdb_chain_ID);
	bool is_there_binary_file_Chain_binary = cb.is_there_binary_file();

	if (!is_there_binary_file_Chain_binary)
	{
		out << "Chain_binary file not found" << endl;
		return;
	}


	DSSP_binary dssp_b(pdb_chain_ID, COMMON_USAGE);
	bool is_there_binary_file_DSSP = dssp_b.is_there_binary_file();
	if (!is_there_binary_file_Chain_binary)
	{
		out << "DSSP binary file not found" << endl;
		return;
	}

	string sequence = cb.get_sequence();
	string sequence_dssp = dssp_b.get_sequence();
	string extended_DSSP_sequence = dssp_b.get_extended_DSSP_sequence();

	bool is_coincide = true;
	int sequence_length = sequence.size();
	for (int ii = 0; ii < sequence_length; ii++)
	{
		sequence_ppii[ii] = toupper(sequence_ppii[ii]);
		if (sequence_ppii[ii] == 'X' || sequence[ii] == 'X')
			continue;

		if (sequence[ii] != sequence_ppii[ii])
		{
			is_coincide = false;
			break;
		}
	}

	if (!is_coincide)
	{
		out << "sequences don't coincide:" << endl;
		out << sequence << endl;;
		out << sequence_dssp << endl;;
		out << sequence_ppii << endl;;
		return;
	}
	else
	{
		out << sequence << endl;;
		out << sequence_dssp << endl;;
		out << sequence_ppii << endl;;
	}

	bool *is_geometry_admissible	= cb.get_is_geometry_admissible();
	bool *is_there_coord			= cb.get_is_there_coord();

	vector <string> residue_names	= cb.get_residue_names();
	int* serial_index				= cb.get_serial_index();



	dicl_creator->process_chain(&cb);

	int dist_var_size = dicl_creator->get_number_of_variables();

	vector < vector < double > > sophisticated_distance_variables = dicl_creator->get_sophisticated_distance_variables();
	vector <int >  nearest_index_set;
	get_nearest_index_set(
		dist_var_size / 2,
		sophisticated_distance_variables,
		nearest_index_set);


	int shift = dicl_creator->get_shift();

// ��� �������� �� ������������ �� ��������������� ��������



	double *coord_set = cb.get_coord_set();


	int fragment_length;


	fragment_length = 3;
	int shift_3 = 1;

//  UNCROPPED COORDINATES TEMPLATE
	bool is_remove_first_CA = false;
	bool is_remove_last_N = false;
	vector < vector < double > >   s_c_in_c_s_3;


	for (int ii = 0; ii < number_of_classes; ii++)
		memcpy(current_claster_motif_coordinates[ii], claster_motif_coordinates[ii], MAX_FRAGMENT_LENGTH * 9 * sizeof(double));


	positioning_chain_by_clasters_set(
		current_claster_motif_coordinates,
		fragment_length,
		number_of_classes,
		coord_set,
		sequence_length,
		is_geometry_admissible,
		is_there_coord,
		s_c_in_c_s_3,
		is_remove_first_CA,
		is_remove_last_N);


	// REMOVED FIRST CA ATOM FROM TEMPLATE
	is_remove_first_CA = true;
	is_remove_last_N = false;
	vector < vector < double > >   s_c_in_c_s_3_no_CA;

	for (int ii = 0; ii < number_of_classes; ii++)
		memcpy(current_claster_motif_coordinates[ii], claster_motif_coordinates[ii], MAX_FRAGMENT_LENGTH * 9 * sizeof(double));

	positioning_chain_by_clasters_set(
		current_claster_motif_coordinates,
		fragment_length,
		number_of_classes,
		coord_set,
		sequence_length,
		is_geometry_admissible,
		is_there_coord,
		s_c_in_c_s_3_no_CA,
		is_remove_first_CA,
		is_remove_last_N);


	// REMOVED FIRST CA ATOM & LAST 'N' ATOM FROM TEMPLATE
	is_remove_first_CA = true;
	is_remove_last_N = true;
	vector < vector < double > >   s_c_in_c_s_3_no_CA_no_N;

	for (int ii = 0; ii < number_of_classes; ii++)
		memcpy(current_claster_motif_coordinates[ii], claster_motif_coordinates[ii], MAX_FRAGMENT_LENGTH * 9 * sizeof(double));

	positioning_chain_by_clasters_set(
		current_claster_motif_coordinates,
		fragment_length,
		number_of_classes,
		coord_set,
		sequence_length,
		is_geometry_admissible,
		is_there_coord,
		s_c_in_c_s_3_no_CA_no_N,
		is_remove_first_CA,
		is_remove_last_N);

	for (int ii = 0; ii < sequence_length; ii++)
	{

		PutVa(residue_names[ii], out, 3, 0, 'l');
		out << '(' << sequence[ii] << ')' << ' ';
		out << sequence_dssp[ii] << ' ';
		out << extended_ppii_DSSP_sequence[ii] << ' ';


		if (is_there_coord[ii]) 	out << "C";
		else										out << "-";

		if (is_geometry_admissible[ii]) 	out << "G";
		else										out << "-";

		out << '\t';

		if (ii >= shift && ii < (sequence_length - shift))
		{
			PutVa(nearest_index_set[ii-shift], out, 3, 0, 'l');
		}
		else
		{
			PutVa("***", out, 3, 0, 'l');
		}
		out << '\t';

		for (int kk = 0; kk < number_of_classes; kk++)
		{
			if (ii >= shift_3 && ii < (sequence_length - shift_3))
			{
				PutVa(s_c_in_c_s_3[ii - shift_3][kk], out, 5, 3, 'l');
			}
			else
			{
				PutVa("***", out, 3, 0, 'l');
			}
			out << '\t';
		}
		out << '\t';
		out << '|';


		for (int kk = 0; kk < number_of_classes; kk++)
		{
			if (ii >= shift_3 && ii < (sequence_length - shift_3))
			{
				PutVa(s_c_in_c_s_3_no_CA[ii - shift_3][kk], out, 5, 3, 'l');
			}
			else
			{
				PutVa("***", out, 3, 0, 'l');
			}
			out << '\t';
		}
		out << '\t';
		out << '|';


		for (int kk = 0; kk < number_of_classes; kk++)
		{
			if (ii >= shift_3 && ii < (sequence_length - shift_3))
			{
				PutVa(s_c_in_c_s_3_no_CA_no_N[ii - shift_3][kk], out, 5, 3, 'l');
			}
			else
			{
				PutVa("***", out, 3, 0, 'l');
			}
			out << '\t';
		}
		out << '\t';
		out << "||";



		out << endl;
	}

	for (int ii = 0; ii < number_of_classes; ii++)
	{
		delete[] current_claster_motif_coordinates[ii];
	}
	delete[] current_claster_motif_coordinates;


//	delete[] coord_set;
}

void  get_nearest_index_set(
	const int number_of_clasters,
	vector < vector < double > > & det_distance_set,
	vector <int > & nearest_index_set)
{

	int distance_set_size = det_distance_set.size();
	nearest_index_set.resize(distance_set_size);

	for (int kk = 0; kk < distance_set_size; kk++)
	{

		for (int ttt = 0; ttt < number_of_clasters; ttt++)
			det_distance_set[kk][ttt] = -det_distance_set[kk][number_of_clasters + ttt];

		det_distance_set[kk].resize(number_of_clasters);

		int nearest_index;

		if (det_distance_set[kk][0] == -1.0)
			nearest_index = -1;
		else
			 nearest_index =	get_nearest_claster_index(det_distance_set[kk]);

		nearest_index_set[kk] = nearest_index;
	}
}
