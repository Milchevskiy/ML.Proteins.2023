#include "HelixParameters.h"
#include "../CommonFunc.h"

const double ideal_rise_per_residue = 3.1;
const double ideal_rotation_angle_degrees = 120;

const double ideal_rise_per_residue_ppi = 3.1;
const double ideal_rotation_angle_degrees_ppi = 120;

const double ideal_distance_to_ppi_origin = 0;


/*
const double rise_per_residue_DELTA = 1;
const double rotation_angle_degrees_DELTA = 30;
const double distance_to_ppi_origin_DELTA = 0.3;
*/
const double rise_per_residue_DELTA = 0.5;
const double rotation_angle_degrees_DELTA = 15;
const double distance_to_ppi_origin_DELTA = 0.15;

void make_dummy_ppii_var(
	const double rise_per_residue,
	const double rotation_angle_degrees,
	const double rise_per_residue_PPII,
	const double rotation_angle_degrees_PPII,
	const double distance_to_ppi_origin,
	vector <double> & var)
{


	double			delta_rise_per_residue = fabs(ideal_rise_per_residue - rise_per_residue);
		var[0] = exp(-delta_rise_per_residue / rise_per_residue_DELTA);

		double			 delta_rotation_angle_degrees = fabs(ideal_rotation_angle_degrees - rotation_angle_degrees);
		var[1] = exp(-delta_rotation_angle_degrees / rotation_angle_degrees_DELTA);

		double			delta_rise_per_residue_PPII = fabs(ideal_rise_per_residue - rise_per_residue_PPII);
		var[2] = exp(-delta_rise_per_residue_PPII / rise_per_residue_DELTA);


		double			delta_rotation_angle_degrees_PPII = fabs(ideal_rotation_angle_degrees - rotation_angle_degrees_PPII);
		var[3] = exp(-delta_rotation_angle_degrees_PPII / rotation_angle_degrees_DELTA);


		double			delta_distance_to_ppi_origin = fabs(ideal_distance_to_ppi_origin - distance_to_ppi_origin);
		var[4] = exp(-delta_distance_to_ppi_origin / distance_to_ppi_origin_DELTA);


	var[5] = var[2] * var[3] * var[4];

	var[6] = var[5] * var[0] * var[1];

}
