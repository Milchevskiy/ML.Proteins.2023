#include "HelixParameters.h"
#include "../CommonFunc.h"
#include "../Fragment_base/Chain_binary.h"
#include "../make_claster_motif_by_dihedral_set.h"
#include "../Chain_store/DSSP_binary.h"
#include "../Geometry_util/Geometry_util.h"
#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

#include "../CowardVariables/Distance_to_claster_variables.h"

#include <cassert>

extern ofstream log_stream;

void helix_pameters_protocol(
	const string & pdb_chain_ID,
	const string & protocol_file_name,
	const int helix_length,				// ���� ������ const int fragment_length
	string & path_to_dihedral_store,
	string & path_PPII_assignment_store,
	ofstream & da_stream,
	ofstream & da_indexes,
	Distance_to_claster_variables *dicl_creator)
{

	string full_path_to_PPII_assignment = path_PPII_assignment_store + pdb_chain_ID;

	string sequence_ppii;	
	string extended_ppii_DSSP_sequence;

	get_ppii_assignment	
		(full_path_to_PPII_assignment,
		sequence_ppii,
		extended_ppii_DSSP_sequence);


	ofstream out(protocol_file_name.c_str());
	if (!out)
	{
		log_stream << "can't create " << endl;
		cout << "can't create " << endl;
		exit(1);
	}


	Chain_binary cb(pdb_chain_ID);
	bool is_there_binary_file_Chain_binary = cb.is_there_binary_file();

	if (!is_there_binary_file_Chain_binary)
	{
		out << "Chain_binary file not found" << endl;
		return;
	}

		
	DSSP_binary dssp_b(pdb_chain_ID, COMMON_USAGE);
	bool is_there_binary_file_DSSP = dssp_b.is_there_binary_file();
	if (!is_there_binary_file_Chain_binary)
	{
		out << "DSSP binary file not found" << endl;
		return;
	}



	if ((!is_there_binary_file_Chain_binary) || (!is_there_binary_file_Chain_binary))
		return;

	dicl_creator->process_chain(&cb);

	int dist_var_size = dicl_creator->get_number_of_variables();
	
	vector < vector < double > > sophisticated_distance_variables = dicl_creator->get_sophisticated_distance_variables();

	vector < double >  set_of_rise_per_residue;
	vector < double >  disp_set_of_rise_per_residue;
	vector < double >  set_cos_rotation_angle;
	vector < double >  disp_disp_of_cos_rotation_angles;
	vector < double >  set_of_rotation_angle_degrees;
	vector < double >  disp_set_of_rotation_angle_degrees;

	cb.positioning_chain_by_helical_parameters(
		helix_length,
		set_of_rise_per_residue,
		disp_set_of_rise_per_residue,
		set_cos_rotation_angle,
		disp_disp_of_cos_rotation_angles,
		set_of_rotation_angle_degrees,
		disp_set_of_rotation_angle_degrees);

	vector < double >  set_of_rise_per_residue_PPII;
	vector < double >  disp_set_of_rise_per_residue_PPII;
	vector < double >  set_cos_rotation_angle_PPII;
	vector < double >  disp_disp_of_cos_rotation_angles_PPII;
	vector < double >  set_of_rotation_angle_degrees_PPII;
	vector < double >  disp_set_of_rotation_angle_degrees_PPII;

	cb.positioning_chain_by_helical_parameters_PPII(
		helix_length,
		set_of_rise_per_residue_PPII,
		disp_set_of_rise_per_residue_PPII,
		set_cos_rotation_angle_PPII,
		disp_disp_of_cos_rotation_angles_PPII,
		set_of_rotation_angle_degrees_PPII,
		disp_set_of_rotation_angle_degrees_PPII);


	
	int fragment_length_by_dihedral_store;

	int number_of_classes;
	double **claster_motif_coordinates = make_claster_motif_by_dihedral_set(
		path_to_dihedral_store,
		number_of_classes,
		fragment_length_by_dihedral_store);


	int fragment_length = helix_length;
	vector < vector < double > >  set_of_coordinate_in_clasters_system;
	cb.positioning_chain_by_clasters_set(
		claster_motif_coordinates,
		fragment_length,
		number_of_classes,
		set_of_coordinate_in_clasters_system);

	assert(fragment_length_by_dihedral_store > fragment_length);

//allocate memory for clustres smotifs started from CA ftoms

	double **claster_motif_coordinates_PPII = new double*[number_of_classes];
	for (int ii = 0; ii < number_of_classes; ii++)
		claster_motif_coordinates_PPII[ii] = new double[fragment_length_by_dihedral_store * 9];

// ��� ��������  ����������� ���������, �������� 3 �� �����
	for (int ii = 0; ii < number_of_classes; ii++)
		memcpy(claster_motif_coordinates_PPII[ii], claster_motif_coordinates[ii], fragment_length_by_dihedral_store * 9*sizeof(double));

	vector < vector < double > >  set_of_coordinate_in_clasters_system_PPII;
	cb.positioning_chain_by_clasters_set_PPII(
		claster_motif_coordinates_PPII,
		fragment_length,
		number_of_classes,
		set_of_coordinate_in_clasters_system_PPII);


	for (int ii = 0; ii < number_of_classes; ii++)
		delete[] claster_motif_coordinates[ii];
	delete[] claster_motif_coordinates;

	for (int ii = 0; ii < number_of_classes; ii++)
		delete[] claster_motif_coordinates_PPII[ii];
	delete[] claster_motif_coordinates_PPII;


	//DSSP_binary dssp_b(pdb_chain_ID, COMMON_USAGE);
	
	

	double *cu_cord_set = new double[fragment_length * 9];

	string sequence					= cb.get_sequence();
	string sequence_dssp			= dssp_b.get_sequence();
	string extended_DSSP_sequence	= dssp_b.get_extended_DSSP_sequence();
	int shift = fragment_length / 2;

	out << "tested helix length: " << helix_length << endl;

	//chech_sequence_coincides
	bool is_coincide = true;
	for (int ii = 0; ii < set_of_coordinate_in_clasters_system.size(); ii++)
	{
		if (sequence[ii + shift] != sequence_dssp[ii + shift])
		{
			is_coincide = false;
			break;
		}

		if (sequence[ii + shift] != toupper(sequence_ppii[ii + shift]) )
		{
			is_coincide = false;
			break;
		}

	}
	
	if (!is_coincide)
	{
		out << "sequences don't coincide:" << endl;
		out << sequence << endl;;
		out << sequence_dssp << endl;;
		out << sequence_ppii << endl;;
		return;
	}

	//for (int ii = 0; ii < set_of_coordinate_in_clasters_system.size(); ii++)
	 for (int ii = 1; ii < set_of_coordinate_in_clasters_system.size()-3; ii++)
	{
		out << sequence					[ii + shift] ;
		out << sequence_dssp			[ii + shift] ;
		out << sequence_ppii			[ii + shift] << ' ';
		out << extended_DSSP_sequence	[ii + shift] ;
		out << extended_ppii_DSSP_sequence[ii + shift];

		out << '\t';
		PutVaDouble(set_of_rise_per_residue				[ii], out, 8, 3, 'l');
		PutVaDouble(disp_set_of_rise_per_residue		[ii], out, 8, 3, 'l');
		PutVaDouble(set_of_rotation_angle_degrees		[ii], out, 8, 3, 'l');
		PutVaDouble(disp_set_of_rotation_angle_degrees	[ii], out, 8, 3, 'l');
		out << '\t';


		out << '\t';
		PutVaDouble(set_of_rise_per_residue_PPII[ii], out, 8, 3, 'l');
		PutVaDouble(disp_set_of_rise_per_residue_PPII[ii], out, 8, 3, 'l');
		PutVaDouble(set_of_rotation_angle_degrees_PPII[ii], out, 8, 3, 'l');
		PutVaDouble(disp_set_of_rotation_angle_degrees_PPII[ii], out, 8, 3, 'l');
		out << '\t';


		for (int kk = 0; kk < number_of_classes; kk++)
		{
			PutVaDouble(set_of_coordinate_in_clasters_system[ii][kk], out, 8, 5, 'l');
		}

		out << '\t';
		for (int kk = 0; kk < number_of_classes; kk++)
		{
			PutVaDouble(set_of_coordinate_in_clasters_system_PPII[ii][kk], out, 8, 5, 'l');
		}
	



		cb.extract_fragment(ii, fragment_length, cu_cord_set);
		vector < double > torsion_angles;
		fill_up_fragment_torsion_angles(
			cu_cord_set,
			fragment_length,
			torsion_angles,
			'd');


		out << '\t';
		out << '\t';
		for (int kk = 0; kk < torsion_angles.size();kk++)
			PutVaDouble(torsion_angles[kk], out, 8, 1, 'l');



	//	int dist_var_size = sophisticated_distance_variables.size();

		for (int jjj = 0; jjj < dist_var_size; jjj++)
			PutVaDouble(sophisticated_distance_variables[ii-1][jjj], out, 8, 5, 'l');


		out << endl;

		if (extended_ppii_DSSP_sequence[ii + shift] == '_')
			continue;

		if (set_of_rise_per_residue[ii] == -1 || set_of_rise_per_residue_PPII[ii] == -1)
			continue;

		if (extended_ppii_DSSP_sequence[ii + shift] == 'P')
			da_stream << 1 << '\t';
		else 
			da_stream << 0 << '\t';

/*FIX*/	vector <double> dummy_var; 
		dummy_var.resize(7);

		double distance_to_ppi_origin = set_of_coordinate_in_clasters_system[ii][0];
		make_dummy_ppii_var(
			set_of_rise_per_residue[ii],
			set_of_rotation_angle_degrees[ii],
			set_of_rise_per_residue_PPII[ii],
			set_of_rotation_angle_degrees_PPII[ii],
			distance_to_ppi_origin,
			dummy_var);

		for (int jjj = 0; jjj < 7;jjj++)
			PutVaDouble(dummy_var[jjj], da_stream, 8, 5, 'l');

		//dist_var_size = sophisticated_distance_variables.size();
		for (int jjj = 0; jjj < dist_var_size; jjj++)
			PutVaDouble(sophisticated_distance_variables[ii - 1][jjj], da_stream, 8, 5, 'l');


		da_stream << endl;
		cout << ii << endl;

	}
}
