#ifndef HELIXPARAMETERS_H
#define HELIXPARAMETERS_H

#include "../CowardVariables/Distance_to_claster_variables.h"

#include <string>
#include <vector>
using namespace std;


void single_variable_creation(
	int		global_index,
	const	string & pdb_chain_ID,
	const	string & protocol_file_name,
	const	int helix_length,
	//string	& path_to_dihedral_store,
	string	& path_PPII_assignment_store,
	ofstream & da_stream,
	ofstream & da_indexes);

void single_variable_creation(
	int		global_index,
	const	string & pdb_chain_ID,
	const	string & protocol_file_name,
	const	int helix_length,
	//string	& path_to_dihedral_store,
	string	& path_PPII_assignment_store,
	double **claster_motif_coordinates,
	int number_of_classes,
	ofstream & da_stream,
	ofstream & da_indexes,
	Distance_to_claster_variables *dicl_creator);


void  get_nearest_index_set(
	const int number_of_clasters,
	vector < vector < double > > & det_distance_set,
	vector <int > & nearest_index_set);

// Dummy calc. var. (temporary atempt)
void make_dummy_ppii_var(
	const double rise_per_residue,
	const double rotation_angle_degrees,
	const double rise_per_residue_PPII,
	const double rotation_angle_degrees_PPII,
	const double distance_to_ppi_origin,
	vector <double>& var);

void Traditional_Helix_Parameters_calc(
	int residue_index,
	int residue_window,
	int residue_shift,
	int sequence_length,
	double *m_cha_coord,  // main chain coordinates (N,CA,C ....)
	double & MeanCOS,
	double & dispCos,
	double & MeanAngle,
	double & dispAngle,
	double & MeanHH,
	double & dispHH);

void single_fragment_helix_parameters(
	double *cu_cord_set,
	const int fragment_length,
	double  & rise_per_residue,
	double  & disp_of_rise_per_residue,
	double  & cos_rotation_angle,
	double  & disp_of_cos_rotation_angle,
	double  & rotation_angle_degrees,
	double  & disp_of_rotation_angle_degrees);

void helix_pameters_protocol(
	const string & pdb_chain_ID,
	const string & protocol_file_name,
	const int helix_length,				// ���� ������ const int fragment_length
	string & path_to_dihedral_store,
	string & path_PPII_assignment_store,
	ofstream & da_stream,
	ofstream & da_indexes,
	Distance_to_claster_variables *dicl_creator);



void get_ppii_assignment(const string & full_path_to_PPII_assignment,
	string & sequence_ppii,
	string & extended_ppii_DSSP_sequence);


//fix ��������������� ������� - ���� �� ������������ �� ��� ���� �� ���� Geomety_util
void	LeastSquare2x2(double *TT, double *YY, int EquaNu, double *L1, double *M1);
int		index(int ii, int jj, int row);
void	VectMult_d(double Ax, double Ay, double Az, double Bx, double By, double Bz, double  *Rex, double  *Rey, double  *Rez);
double	GtCosVect(double Tx, double Ty, double Tz, double Px, double Py, double Pz);


#endif
