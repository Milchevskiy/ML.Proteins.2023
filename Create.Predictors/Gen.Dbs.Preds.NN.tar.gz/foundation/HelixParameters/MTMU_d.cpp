#include <cstdio>

int index(int ii,int jj,int row);

int mtmu_d(int row_1,int col_1,int row_2,int col_2,double*mtx_1,double*mtx_2, double *re_mtx) {

register int ii,jj,ll;
int Ind_1,Ind_2,Ind_3;


	if(col_1 != row_2) {
		printf("Error!!! Matrix size\n");
		return -1;
	}
// ���� �������� �������  ������� re_mtx
	for(ii=0;ii<row_1;ii++) {
		for(jj=0;jj<col_2;jj++) {
			for(ll=0;ll<col_1;ll++) {
				Ind_1= index(ii,jj,col_2);
				re_mtx[Ind_1] = 0.0f;
			}
		}
	}
	for(ii=0;ii<row_1;ii++) {
		for(jj=0;jj<col_2;jj++) {
			for(ll=0;ll<col_1;ll++) {
				Ind_1= index(ii,jj,col_2);
 				Ind_2= index(ii,ll,col_1);
				Ind_3= index(ll,jj,col_2);
				re_mtx[Ind_1] += mtx_1[Ind_2]*mtx_2[Ind_3];
			}
		}
	}
}

int index(int ii,int jj,int row) {

register int kk;

	kk= ii*row + jj;
	return kk;
}
