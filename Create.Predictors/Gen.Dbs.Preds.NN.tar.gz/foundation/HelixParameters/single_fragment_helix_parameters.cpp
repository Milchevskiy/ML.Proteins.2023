#include "../CommonFunc.h"
#include "HelixParameters.h"
#include "../Statistical_utilits/calc_dispersion_and_average.h" 

#include <cassert>


void single_fragment_helix_parameters(
	double *cu_cord_set,
	const int fragment_length,
	double  & rise_per_residue,
	double  & disp_of_rise_per_residue,
	double  & cos_rotation_angle,
	double  & disp_of_cos_rotation_angle,
	double  & rotation_angle_degrees,
	double  & disp_of_rotation_angle_degrees)
{
	
	//int StartIndexNu = residue_index * 3;
	int WinLen = fragment_length * 3;			
	int MaStShift = 3;		// length of assymetrical subunints i.e. shift in baxkbone atom mumber

	//assert((residue_index + residue_window + residue_shift) < sequence_length);

	double pi = Pythagorean_Number();

	double	TT[1000], YY[500];
	double 	a1x, a1y, a1z, a2x, a2y, a2z, L1, M1, N1;
	double 	Rex1, Rey1, Rez1, Rex2, Rey2, Rez2, dltX, dltY, dltZ, RR, CosNju;
	double 	CurrentHH, CurrentCOS, Test;
	int		ind1, ind2, ind4, ind5, ii, kk;
	double Check1, Check2;
	double Check3, Check4;


	int iteration_number = WinLen - MaStShift-1;

	vector <double> cos_aray, hh_aray, angle_array;
	cos_aray.resize(iteration_number);	hh_aray.resize(iteration_number);  angle_array.resize(iteration_number);

	kk = 0;

	for (ii = 0; ii <iteration_number; ii++) 
	{
		ind1 = 3 * ii;
		ind2 = 3 * (ii + 1);
		ind4 = 3 * (ii + MaStShift);
		ind5 = 3 * (ii + MaStShift + 1);;

		a1x = cu_cord_set[ind2]		- cu_cord_set[ind1];
		a1y = cu_cord_set[ind2 + 1] - cu_cord_set[ind1 + 1];
		a1z = cu_cord_set[ind2 + 2] - cu_cord_set[ind1 + 2];;

		a2x = cu_cord_set[ind5]		- cu_cord_set[ind4];
		a2y = cu_cord_set[ind5 + 1] - cu_cord_set[ind4 + 1];
		a2z = cu_cord_set[ind5 + 2] - cu_cord_set[ind4 + 2];

		TT[2 * kk] = a1x - a2x;
		TT[2 * kk + 1] = a1y - a2y;
		YY[kk] = a2z - a1z;
		kk++;
	}
	LeastSquare2x2(TT, YY, iteration_number, &L1, &M1);
	N1 = 1; // ��� ������������ ��� ������ 


	double MeanCOS = 0.0;	double MeanHH = 0.0;
	
	//for (ii = StartIndexNu; ii < StartIndexNu + WinLen; ii++)
	for (ii = 0; ii < iteration_number; ii++)
	{
		ind1 = 3 * ii;
		ind2 = 3 * (ii + 1);
		ind4 = 3 * (ii + MaStShift);
		ind5 = 3 * (ii + MaStShift + 1);;
		
		a1x = cu_cord_set[ind2]		- cu_cord_set[ind1];
		a1y = cu_cord_set[ind2 + 1] - cu_cord_set[ind1 + 1];
		a1z = cu_cord_set[ind2 + 2] - cu_cord_set[ind1 + 2];;

		a2x = cu_cord_set[ind5]		- cu_cord_set[ind4];
		a2y = cu_cord_set[ind5 + 1] - cu_cord_set[ind4 + 1];
		a2z = cu_cord_set[ind5 + 2] - cu_cord_set[ind4 + 2];

		/**/Check1 = GtCosVect(a1x, a1y, a1z, L1, M1, N1);
		/**/Check2 = GtCosVect(a2x, a2y, a2z, L1, M1, N1);

		/**/Check3 = a1x*a1x + a1y*a1y + a1z*a1z;
		/**/Check4 = a2x*a2x + a2y*a2y + a2z*a2z;

		VectMult_d(a1x, a1y, a1z, L1, M1, N1, &Rex1, &Rey1, &Rez1);
		VectMult_d(a2x, a2y, a2z, L1, M1, N1, &Rex2, &Rey2, &Rez2);

		CurrentCOS = GtCosVect(Rex1, Rey1, Rez1, Rex2, Rey2, Rez2);
		MeanCOS += CurrentCOS;
		cos_aray[ii] = CurrentCOS;

		Test = acos(CurrentCOS);
		Test *= 180 / pi;  // ������ � �������� 	

		angle_array[ii] = Test;

		dltX = cu_cord_set[ind4]		- cu_cord_set[ind1];
		dltY = cu_cord_set[ind4 + 1]	- cu_cord_set[ind1 + 1];
		dltZ = cu_cord_set[ind4 + 2]	- cu_cord_set[ind1 + 2];

		RR = sqrt(dltX*dltX + dltY*dltY + dltZ*dltZ);
		CosNju = GtCosVect(dltX, dltY, dltZ, L1, M1, N1);

		CurrentHH = fabs(RR * CosNju);
		MeanHH += CurrentHH;
		hh_aray[ii] = CurrentHH;

	}

	MeanCOS /= iteration_number;
	MeanHH /= iteration_number;

	calc_dispersion_and_average(
		cos_aray,
		cos_rotation_angle,
		disp_of_cos_rotation_angle);

	calc_dispersion_and_average(
		hh_aray,
		rise_per_residue,			//MeanHH,
		disp_of_rise_per_residue);	//dispHH);

	calc_dispersion_and_average(
		angle_array,
		rotation_angle_degrees,
		disp_of_rotation_angle_degrees);

}

