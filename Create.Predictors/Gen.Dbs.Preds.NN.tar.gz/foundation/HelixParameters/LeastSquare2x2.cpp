#include <cstdio>

	int		mtmu_d			(int row_1,int col_1,int row_2,int col_2,double*mtx_1,double*mtx_2, double *re_mtx) ;
	int		index			(int ii,int jj,int row) ;

void	LeastSquare2x2 (double *TT,double *YY,int EquaNu,\
							double *L1,double *M1) {


double TrTT[1000],TrTTxTT[4],InvTrTTxTT[4],TrTTxYY[2],Result[2]; 
  
  int ii,jj;
  int Ind_1,Ind_2;

  double DetTrTTxTT; 
  double Test;
// Transponir. matrix TT
	for(ii=0;ii<EquaNu;ii++) {
		for(jj=0;jj<2;jj++) { 
			Ind_1 =  index(ii,jj,2);
			Ind_2 =  index(jj,ii,EquaNu);
			TrTT [ Ind_2 ] = TT [ Ind_1  ];
		}
	}

	mtmu_d(2,EquaNu,EquaNu,2,TrTT ,TT ,TrTTxTT  ) ;
	
	DetTrTTxTT  = TrTTxTT  [0]*TrTTxTT  [3] - TrTTxTT  [1]*TrTTxTT  [2];
// Inverse Matrix for Res1
	InvTrTTxTT[0] =	 TrTTxTT  [3]/DetTrTTxTT   ;
	InvTrTTxTT[1] =	-TrTTxTT  [2]/DetTrTTxTT  ;
	InvTrTTxTT[2] =	-TrTTxTT  [1]/DetTrTTxTT  ;
	InvTrTTxTT[3] =	 TrTTxTT  [0]/DetTrTTxTT  ;

	mtmu_d(2,EquaNu,EquaNu,1,TrTT ,YY,TrTTxYY);
	mtmu_d(2,2,2,1,InvTrTTxTT,TrTTxYY,Result);

	*L1 = Result[0];
	*M1 = Result[1];

	Test = TrTTxTT[0]*  Result[0] + TrTTxTT[1]*  Result[1] -	TrTTxYY[0];
	Test = TrTTxTT[2]*  Result[0] + TrTTxTT[3]*  Result[1] -	TrTTxYY[1];;

}
