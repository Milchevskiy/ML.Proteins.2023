#ifndef HELIXPARAMETERS_TEST_H
#define HELIXPARAMETERS_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

HELIXPARAMETERS_TEST_H
class  HelixParameters_test : public Simple_test
{
public:
	~HelixParameters_test();

	void run()
	{
		simple_variables_creation_test();
		
		/*simple_test();
		helix_pameters_protocol_test();
		
		handle_single_chain();
		*/


	}
	void simple_test();

	void helix_pameters_protocol_test(); 
	void simple_variables_creation_test();
	void handle_single_chain();
};

#endif
#pragma once
