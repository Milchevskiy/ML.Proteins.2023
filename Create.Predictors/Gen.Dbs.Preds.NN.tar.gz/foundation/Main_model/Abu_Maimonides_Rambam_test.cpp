
#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "Abu_Maimonides_Rambam_test.h"
#include "Abu_Maimonides_Rambam.h"

#include "../Censorship.h"

#include <fstream>
#include <iostream>
#include <cassert>

#include "../Fragment_base/accepted_chain_data.h"


#include "../Matrix_utilits/Matrix_utilits.h"

#include "../Fragment_base/Chain_binary.h"
#include "../CommonFunc.h"

#include "../Chain_store/Chain_Residue_Set.h"

#include "../Pair_string_double.h"

#include "../Sheduler.h"
#include "../Statistical_utilits/charming_Reg_solution.h"

#include "../Main_model/handle_det_distance_set.h"
#include "../Main_model/handle_det_distance_set.h"

void  prepare_learning_and_control_set (
                int subset_number,
                int subset_ID,
                vector < string > PDB_chain_ID_list,
                string path_to_accepted_chain_list_file );

void handle_plain_result(
    string & result_files_set,
    map <string,double> &predictor_occurence);

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

#ifndef GET_NEAREST_CLASTER_INDEX_H
#define GET_NEAREST_CLASTER_INDEX_H

int get_nearest_claster_index( 	const vector <double> & distance_set );

#endif


void Abu_Maimonides_Rambam_test::
make_predictor_file_set_by_sequence_test ()
{

    Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    Chain_binary cb("1A1XA");

    string sequence = cb.get_sequence();
    int seq_len = sequence.size();

    string path_for_pytorch_data = "/media/milch/Новый том/ML_calculation/PB_16_test_new_approach_4/Results/add_analyse/";
    string predictor_file_name = "154LA.pr_dat";




    //154LA



    mr.make_predictor_file_set_by_sequence (
        sequence,
        path_for_pytorch_data,
        predictor_file_name);

}


void Abu_Maimonides_Rambam_test::
prepare_data_by_didona_PB_prediction_test (string & data_set_name)
{
  cout << "prepare_data_by_didona_PB_prediction_test ()" << endl;
	string model_name = string("test_new_approach_3adv");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
//	charming_Reg_solution  * current_crs = mr.init_together_model ();



    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_by_didona_PB_prediction_medium/IntermediateData//";
    string path_to_list_store = "/media/milch/Новый том/ML_calculation/";;
    string list_file_name = path_to_list_store + data_set_name;

    ifstream list_stream( list_file_name .c_str() ,ios::binary);
    if ( ! list_stream	)
    {
        log_stream << "list_file_name   can't create " << list_file_name<< endl;
        cout       << "list_file_name   can't create " << list_file_name<< endl;
        exit (1);
    }


    vector <string > PDB_chain_ID_list;
    string word;
    while (list_stream >> word )
        PDB_chain_ID_list.push_back(word);


    ///It is assumed that the binaries are already ready
    mr.prepare_data_by_didona_PB_prediction (path_to_raw_data,PDB_chain_ID_list,data_set_name );



    string sequence ;



}


void Abu_Maimonides_Rambam_test::
prepare_data_by_didona_PB_prediction_wide_test (string & data_set_name)
{

  cout << "prepare_data_by_didona_PB_prediction_test ()" << endl;
	string model_name = string("test_new_approach_3adv");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
//	charming_Reg_solution  * current_crs = mr.init_together_model ();



    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_by_didona_PB_prediction_medium/IntermediateData//";
    string path_to_list_store = "/media/milch/Новый том/ML_calculation/";;
    string list_file_name = path_to_list_store + data_set_name;

    ifstream list_stream( list_file_name .c_str() ,ios::binary);
    if ( ! list_stream	)
    {
        log_stream << "list_file_name   can't create " << list_file_name<< endl;
        cout       << "list_file_name   can't create " << list_file_name<< endl;
        exit (1);
    }


    vector <string > PDB_chain_ID_list;
    string word;
    while (list_stream >> word )
        PDB_chain_ID_list.push_back(word);


    ///It is assumed that the binaries are already ready
    mr.prepare_data_by_didona_PB_prediction_wide (path_to_raw_data,PDB_chain_ID_list,data_set_name );



    string sequence ;



}


void Abu_Maimonides_Rambam_test:: remove_correkated_predictors()
{
    string path_to_extra_list = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_7a/remove_list";

   	ifstream in_ex_l ( path_to_extra_list.c_str() ) ;
	if ( ! in_ex_l )	{
		cout       << "Can't find LIST file  " << path_to_extra_list<< endl;
		exit (1);
	}

    vector <int> list_index;
    int index;
    while (in_ex_l >> index )
        list_index.push_back(index);

    string path_to_coward = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_7a/CowardVariables.task";
   	ifstream in_pre ( path_to_coward.c_str() ) ;
	if ( ! in_pre )	{
		cout       << "Can't find LIST file  " << path_to_coward<< endl;
		exit (1);
	}

    vector <string> coward_list;
    string current_line;
    while (getline( in_pre , current_line, '\n' ) )
        coward_list.push_back(current_line);

    vector <int>    uniq_list_index;

    int coward_size= coward_list.size();
    uniq_list_index.resize(coward_size+100);

    int list_index_size = list_index.size();



    for (int ii=0;ii<list_index_size;ii++)
    {
        uniq_list_index[ list_index[ii] ] = 1;
    }

    string path_to_coward_result = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_7a/CowardVariables.task.after_remove";

   	ofstream res_coward ( path_to_coward_result ) ;
	if ( ! res_coward )	{
		cout       << "Can't create result file  " << endl;
		exit (1);
	}


    for (int ii=0;ii<coward_size;ii++)
    {
        if ( uniq_list_index[ii] == 1)
            continue;
        else
         res_coward << coward_list[ii] << endl;



    }

}

void Abu_Maimonides_Rambam_test:: handle_united_significant_predictors()
{
struct Predictor
{
    vector <double> Fisher_set;
    string predictor_body;
    bool   is_exist= false;

};

    string path_to_united_significant_file = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_3adv/plain_results/fin_500/ttt.srt";
    //string path_to_united_significant_file = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_3adv/plain_results/ttt.srt";
	ifstream in ( path_to_united_significant_file.c_str() ) ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << path_to_united_significant_file << endl;
		exit (1);
	}
    string path_to_result_file = "/home/milch/projects/Didona/Store/Model_store/test_new_approach_3adv/plain_results/fin_500/result_ttt.srt.csv";
	ofstream out ( path_to_result_file.c_str() ) ;
	if ( ! out )	{
		cout       << "Can't find LIST file  " << path_to_result_file << endl;
		exit (1);
	}


	vector <Predictor> predictor_set;
	predictor_set.resize(1000);


	string current_line;
	while( getline( in , current_line, '\n' ) )
	{

        istringstream ist (current_line);

//         0	   132.852      0      0.00752894      0.00065320 0 	 # c_FourierSmoothed	0	DUMB	WERD780101	1	8	1
        string dummy;
        int index;
        double Fisher_value;
        ist >>  dummy >> index >> Fisher_value;
        int start_pos = current_line.find("#");
        string predictor_body = current_line.substr(start_pos );

        predictor_set[index].Fisher_set.push_back(Fisher_value);
        predictor_set[index].predictor_body  = predictor_body ;
        predictor_set[index].is_exist=true;
	}


	int pointer = 0;
//	while (predictor_set[pointer].is_exist==true)
	for (int kk=0;kk<1000;kk++)
	{
        double sum =0;
        for (int ii=0;ii<predictor_set[pointer].Fisher_set.size();ii++)
        {
            double current_Fisher_value = predictor_set[pointer].Fisher_set[ii];
            sum +=predictor_set[pointer].Fisher_set[ii];
        }
        double Fisher_average= sum /predictor_set[pointer].Fisher_set.size();

        if (predictor_set[pointer].is_exist==true)
            out << "#\t" << pointer << "\t"<< predictor_set[pointer].Fisher_set.size() << "\t" << Fisher_average << "\t" << predictor_set[pointer].predictor_body  <<  endl;
        pointer++;
	}


}



void Abu_Maimonides_Rambam_test:: handle_ready_prediction_from_file()
{
    string path_to_store = string ("/home/milch/projects/Didona/Store/Model_store/3_culled_2/cross_sum/");
    string ext_pre = string (".dist_data_predicted");
    string ext_obs = string (".dist_data");

    string PDB_chain_ID = string ("1BKVA");


    string result_file_name = path_to_store + PDB_chain_ID + string ("check");

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}


    string path_to_pdv = path_to_store + PDB_chain_ID +ext_pre ;
    string path_to_odv = path_to_store + PDB_chain_ID +ext_obs ;

    vector < vector < double > >    pdv = read_det_distance_set (path_to_pdv);
    vector < vector < double > >    odv = read_det_distance_set (path_to_odv);



        int current_number_of_cases = odv.size();

    //    out<< sequence[0] << endl;
      //  out<< sequence[1] << endl;


        int number_of_clasters_ = pdv[0].size()/2;

        vector < double >  odv_left;  odv_left.   resize(number_of_clasters_);
        vector < double >  odv_right; odv_right.  resize(number_of_clasters_);

        vector < double >  pdv_left;  pdv_left.   resize(number_of_clasters_);
        vector < double >  pdv_right; pdv_right.  resize(number_of_clasters_);


        int true_coord_current_number = current_number_of_cases;
		for ( int ii = 0; ii< current_number_of_cases; ii++)
		{



            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                pdv_left    [jj]   = pdv[ii][jj];
                pdv_right   [jj]  = -pdv[ii][jj+number_of_clasters_];
            }

            int index_pdv_left  = get_nearest_claster_index(	pdv_left    );
            int index_pdv_right = get_nearest_claster_index(	pdv_right   );

//            out<< sequence[ii+shift_] << "\t";
            PutVa(index_pdv_left,out,5,0,'l');
            PutVa(index_pdv_right,out,5,0,'l');

			if (fabs(odv[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                true_coord_current_number --;
                PutVa("***",out,5,0,'l');
                PutVa("***",out,5,0,'l');
                out << endl;
     			continue;
            }
//vector < vector < double > >  odv_cp = odv;

            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                odv_left    [jj]   = odv[ii][jj];
                odv_right   [jj]  = -odv[ii][jj+number_of_clasters_];
            }

            int index_odv_left  = get_nearest_claster_index(	odv_left    );
            int index_odv_right = get_nearest_claster_index(	odv_right   );
            assert(index_odv_left==index_odv_right);

            PutVa(index_odv_left,out,5,0,'l');
            PutVa(index_odv_right,out,5,0,'l');
            out << endl;


/*
            left_quality_matrix [index_odv_left][index_pdv_left ] ++;
            if ( index_odv_left==index_pdv_left  )
                left_quality +=1;

*/
		}


}



void Abu_Maimonides_Rambam_test::
prepare_learning_and_control_set_test()
{

    vector <string > PDB_chain_ID_list;

	//string path_to_accepted_chain_list_file = "xray_3a_dev_03_few_nonstandard";


    string path_to_accepted_chain_list_file = "DeBre_LS_existed";

    fill_up_accepted_chain_data_text (
        PDB_chain_ID_list,
        path_to_accepted_chain_list_file);


     int subset_number = 5;

     for (int ii=0; ii<subset_number;ii++)
     {
         int subset_ID = ii;
         prepare_learning_and_control_set (
                subset_number,
                subset_ID,
                PDB_chain_ID_list,
                path_to_accepted_chain_list_file );
    }



}


void Abu_Maimonides_Rambam_test::
dist_data_predicted_file_test()
{

   	Abu_Maimonides_Rambam mr ( "PB_11", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//charming_Reg_solution  * current_crs = mr.init_together_model ();


    vector < vector < double > >    odv =mr. read_det_distance_set ("11ASA",".dist_data");
vector < vector < double > >    pdv =mr. read_det_distance_set ("11ASA",".dist_data_predicted_test");

    log_stream << "dist_data_predicted_file_test NOW" << endl;

    for (int ii=0;ii<31;ii++)
       log_stream <<   pdv[0][ii]<<"\t";
    log_stream << endl;

    int odv_size = odv.size();


}

void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files_next_layer ()
{
    string name =  string("PB_11");
    Abu_Maimonides_Rambam mr ( name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
    vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();
    ///log_stream << " vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list(); PASSED" << endl;


     string path_to_cross_sum_binary_file =
		configuration.option_meaning("Path_to_Model_store") +
		name					+
		"/cross_sum/"			+
		"together_next_layer"  +
		".cross_sum";


/// Пока так
	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/") + string("sheduler");
	Sheduler *sheduler_		= new Sheduler     (path_current) ;


	string path_to_regression_options_file_ =
		configuration.option_meaning("Path_to_Model_store") + 	name + string ("/") +
		sheduler_->option_meaning ("REGRESSION_OPTIONS_FILE_NEXT_LAYER");

	Sheduler *regression_options = new Sheduler	( path_to_regression_options_file_ );
//***********************************************************************

	charming_Reg_solution  * nela_crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options ) ;


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
        vector < vector < double > >    pdv     =        mr. read_det_distance_set (PDB_chain_ID_list[ii],".dist_data_predicted");
        vector < vector < double > >   pred_nela =       mr.make_next_layer_prediction (pdv,nela_crs);



        string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted_next_layer";


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
        }

        mr.write_distdata_for_regression(
			distdata_stream,
			pred_nela);

        cout << ii << " " <<  PDB_chain_ID_list[ii] <<   endl;
	}

	delete nela_crs;
	delete sheduler_;
	delete regression_options;
}

void Abu_Maimonides_Rambam_test::
make_next_layer_prediction_test()
{
    string name =  string("PB_11");
    Abu_Maimonides_Rambam mr ( name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();
    vector < vector < double > >    pdv =mr. read_det_distance_set ("11ASA",".dist_data_predicted");


       string path_to_cross_sum_binary_file =
		configuration.option_meaning("Path_to_Model_store") +
		name					+
		"/cross_sum/"			+
		"together_next_layer"  +
		".cross_sum";


/// Пока так
	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/") + string("sheduler");
	Sheduler *sheduler_		= new Sheduler     (path_current) ;


	string path_to_regression_options_file_ =
		configuration.option_meaning("Path_to_Model_store") + 	name + string ("/") +
		sheduler_->option_meaning ("REGRESSION_OPTIONS_FILE_NEXT_LAYER");

	Sheduler *regression_options = new Sheduler	( path_to_regression_options_file_ );
//***********************************************************************

	charming_Reg_solution  * nela_crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options ) ;


    vector < vector < double > >   pred_nela =
        mr.make_next_layer_prediction (pdv,nela_crs);

     log_stream<< "make_next_layer_prediction_test  :" << endl;
    for (int ii=0;ii<pred_nela[0].size();ii++)
    {
        PutVaDouble(pred_nela[5][ii],log_stream,10,5,'l'); log_stream<<'\t';
    }
    log_stream<< endl;
    for (int ii=0;ii<pred_nela[0].size();ii++)
    {
        PutVaDouble(pdv[5][ii],log_stream,10,5,'l'); log_stream<<'\t';
    }
    log_stream<< endl;


}
void Abu_Maimonides_Rambam_test::
check_charming_Reg_solution_test()
{

    string name("PB_11");
    Abu_Maimonides_Rambam mr(name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
    mr.make_cross_sum_binary_files_next_layer();


    string path_to_cross_sum_binary_file =
		configuration.option_meaning("Path_to_Model_store") +
		name					+
		"/cross_sum/"			+
		"together"  +
		".cross_sum";


/// Пока так
	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/") + string("sheduler");
	Sheduler *sheduler_		= new Sheduler     (path_current) ;


	string path_to_regression_options_file_ =
		configuration.option_meaning("Path_to_Model_store") + 	name + string ("/") +
		sheduler_->option_meaning ("REGRESSION_OPTIONS_FILE");

	Sheduler *regression_options = new Sheduler	( path_to_regression_options_file_ );
//***********************************************************************

	charming_Reg_solution  * current_crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options ) ;

    delete current_crs;
    delete regression_options;
}


void Abu_Maimonides_Rambam_test::
next_layer_prepare_cross_sum_test()
{

    string name("PB_11");
//    Abu_Maimonides_Rambam mr(name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
  //  mr.make_cross_sum_binary_files_next_layer();


    string path_to_cross_sum_binary_file =
		configuration.option_meaning("Path_to_Model_store") +
		name					+
		"/cross_sum/"			+
		"together_next_layer"  +
		".cross_sum";


/// Пока так
	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/") + string("sheduler");
	Sheduler *sheduler_		= new Sheduler     (path_current) ;


	string path_to_regression_options_file_ =
		configuration.option_meaning("Path_to_Model_store") + 	name + string ("/") +
		sheduler_->option_meaning ("REGRESSION_OPTIONS_FILE_NEXT_LAYER");

	Sheduler *regression_options = new Sheduler	( path_to_regression_options_file_ );
//***********************************************************************

	charming_Reg_solution  * current_crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options ) ;


	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name + string ("/") +
		sheduler_->option_meaning ("CLUSTER_FUNCTION_TASK_FILE");


	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name + string ("/") +
		sheduler_->option_meaning ("COWARD_VARIABLES_TASK_FILE_NEXT_LAYER");


    vector <string> predictor_task_files;
	predictor_task_files.push_back(	path_to_cowardvariables_task_file );


	string result_file_name_base =
		configuration.option_meaning("Path_to_Model_store") +
		name + 		string ("/plain_results/next_layer") ;


	current_crs->show_plain_results (
		predictor_task_files ,
		path_to_claster_function_task_file,
		result_file_name_base);




    delete current_crs;
    delete regression_options;

}

void Abu_Maimonides_Rambam_test::
///предолагается, что уже есть файлы *.dist_data_predicted & .dist_data
quality_assesment_for_prediction_set_test()
{
    string name("3_culled_2");
    Abu_Maimonides_Rambam mr(name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
//    mr.quality_assesment_for_prediction_set(".dist_data_predicted_next_layer");
    mr.quality_assesment_for_prediction_set(".dist_data_predicted");


  //  mr.CONTROL_quality_assesment_for_prediction_set(".dist_data_predicted");



}

void Abu_Maimonides_Rambam_test::
///предолагается, что уже есть файлы *.dist_data_predicted & .dist_data
confusion_matrix_left_and_right_test()
{
    string name("PB_9");
    Abu_Maimonides_Rambam mr(name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
//    mr.quality_assesment_for_prediction_set(".dist_data_predicted_next_layer");
    vector <string>  chain_ID_list_ls;
    vector <string>  chain_ID_list_CONTROL;


    fill_up_accepted_chain_data_text (
        chain_ID_list_ls,
        "DeBre_LS_existed_5_0.ls");



    fill_up_accepted_chain_data_text (
        chain_ID_list_CONTROL,
        "DeBre_LS_existed_5_0.control");

    string result_LS = "LS";

    mr.confusion_matrix_left_and_right(
        chain_ID_list_ls,
        result_LS);


    string result_CONTROL = "CONTROL";

    mr.confusion_matrix_left_and_right(
        chain_ID_list_CONTROL,
        result_CONTROL);

}

/*
void Abu_Maimonides_Rambam::
confusion_matrix_left_and_right(
    vector <string> & chain_ID_list,
    string & result_name)
*/


void Abu_Maimonides_Rambam_test::
prepare_das_data_test()
{

    string name("PB_3_june_0");
    Abu_Maimonides_Rambam mr(name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
    mr.prepare_das_data();

}
void Abu_Maimonides_Rambam_test::
reduce_predictor_set_test()
{


	string name("PB_9");
	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/plain_results/") ;

	vector <string> result_files_set;

    result_files_set.push_back("together_0.plain_result");
    result_files_set.push_back("together_10.plain_result");
    result_files_set.push_back("together_11.plain_result");
    result_files_set.push_back("together_12.plain_result");
    result_files_set.push_back("together_13.plain_result");
    result_files_set.push_back("together_14.plain_result");
    result_files_set.push_back("together_15.plain_result");
    result_files_set.push_back("together_16.plain_result");
    result_files_set.push_back("together_17.plain_result");
    result_files_set.push_back("together_18.plain_result");
    result_files_set.push_back("together_19.plain_result");
    result_files_set.push_back("together_1.plain_result");
    result_files_set.push_back("together_20.plain_result");
    result_files_set.push_back("together_21.plain_result");
    result_files_set.push_back("together_22.plain_result");
    result_files_set.push_back("together_23.plain_result");
    result_files_set.push_back("together_24.plain_result");
    result_files_set.push_back("together_25.plain_result");
    result_files_set.push_back("together_26.plain_result");
    result_files_set.push_back("together_27.plain_result");
    result_files_set.push_back("together_28.plain_result");
    result_files_set.push_back("together_29.plain_result");
    result_files_set.push_back("together_2.plain_result");
    result_files_set.push_back("together_30.plain_result");
    result_files_set.push_back("together_31.plain_result");
    result_files_set.push_back("together_3.plain_result");
    result_files_set.push_back("together_4.plain_result");
    result_files_set.push_back("together_5.plain_result");
    result_files_set.push_back("together_6.plain_result");
    result_files_set.push_back("together_7.plain_result");
    result_files_set.push_back("together_8.plain_result");
    result_files_set.push_back("together_9.plain_result");


    map <string,double> predictor_occurence;
    for (int ii=0;ii<result_files_set.size();ii++)
    {
        string fina = path_current + string (result_files_set[ii]);
        handle_plain_result(fina,predictor_occurence);
    }

    string outfile = path_current + name + string("reduced_Coward.txt");

    ofstream out(outfile.c_str());
	if(!out)
	{
		log_stream	<< outfile << "can't find "  << endl;
		cout		 << outfile << "can't find " << endl;
		exit(1);
	}


	vector < Pair_string_double > words_occurence_number;

	typedef map < string, double > MAP_STRING_DOUBLE;
	MAP_STRING_DOUBLE::const_iterator theIterator;

	int counter =0;
	for ( theIterator = predictor_occurence.begin();theIterator != predictor_occurence.end();theIterator ++ )
	{
		string key		=	(*theIterator).first ;
		double value	=   (*theIterator).second ;

		Pair_string_double current_pair (key,value);

		words_occurence_number.push_back ( Pair_string_double (key,value));
	}

	sort(	words_occurence_number.begin(),	words_occurence_number.end() );

	for (int ii=words_occurence_number.size()-1;ii>=0;ii--)
	{
        PutVaDouble(words_occurence_number[ii].value(),out,5,0,'l');
        PutVa(words_occurence_number[ii].index(),out,100,3,'l');
        out << endl;
    }
}
void handle_plain_result(
    string & fina,
    map <string,double> &predictor_occurence)
{

	ifstream in(fina.c_str());
	if(!in)
	{
		log_stream	<< fina << "can't find "  << endl;
		cout		 << fina << "can't find " << endl;
		exit(1);
	}


    string current_line;
	while( getline( in  , current_line, '\n' ) )
	{
		if (current_line.size() == 0)
			continue;
		if (   current_line[0] == '/'  ||
			   current_line[0] == '\n' ||
			   current_line[0] == '\0')
			continue;




        std::size_t pos = current_line.find("#");
        if(pos ==std::string::npos)
            continue;
        string word = current_line.substr(pos+1);


        if ( predictor_occurence.find(word) ==predictor_occurence.end() )
            predictor_occurence[word]=1.0;
        else
        {
            int buff = predictor_occurence[word];
            predictor_occurence[word] = buff+1.0;
        }
    }



/*
    typedef std::function<bool(std::pair<std::string, int>, std::pair<std::string, int>)> Comparator;

	// Defining a lambda function to compare two pairs. It will compare two pairs using second field
	Comparator compFunctor =
			[](std::pair<std::string, int> elem1 ,std::pair<std::string, int> elem2)
			{
				return elem1.second < elem2.second;
			};

	// Declaring a set that will store the pairs using above comparision logic
	std::set<std::pair<std::string, int>, Comparator> setOfWords(
			mapOfWordCount.begin(), mapOfWordCount.end(), compFunctor);

	// Iterate over a set using range base for loop
	// It will display the items in sorted order of values
	for (std::pair<std::string, int> element : setOfWords)
		std::cout << element.first << " :: " << element.second << std::endl;
  */

}
void Abu_Maimonides_Rambam_test::
check_cluster_property_test()
{
    Abu_Maimonides_Rambam mr ( "PB_2", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
    Distance_to_claster_variables *ob = mr.get_Distance_to_claster_variables();
   // ob->
}
void Abu_Maimonides_Rambam_test::
PB_observed_assignment_test()
{
    Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string PDB_chain_ID = "153LA";

    vector < vector < double > > det_distance_set =
		mr.read_det_distance_set(PDB_chain_ID,".dist_data");

    string PB_sequence = mr.PB_setting_by_det_distance_set(
                            det_distance_set);

   string out_file_name = "../Test/PB_observed_assignment";

   ofstream out(out_file_name.c_str());
    if (!out)
    {
        cout << "out file problem" << endl;
        exit(-1);
    }

    out << PDB_chain_ID << endl;
    out << "  " << PB_sequence << endl;
}

void Abu_Maimonides_Rambam_test::
prediction_by_sequence_test()
{

	Abu_Maimonides_Rambam mr("new_generation_model_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
		charming_Reg_solution  * current_crs = mr.init_together_model();



	string source_file = "D://I_Galkin//outallcalc";
	ifstream in(source_file.c_str());
	if(!in)
	{
		log_stream	<< source_file << "can't find "  << endl;
		cout		 << source_file << "can't find " << endl;
		exit(1);
	}

//	double current_quality;
	string current_line, num, sequence;


	int number_of_clasters = mr.get_number_of_clasters();



	while (in >> num >> sequence)
	{
		for (int ii = 0; ii < sequence.size(); ii++)
			for (int ii = 0; ii < sequence.size(); ii++)
			sequence[ii] = toupper(sequence[ii]);

		string out_file_name = new_extension_file_name(source_file, num);


		ofstream out(out_file_name.c_str());
		if (!out)
		{
			cout << "out file problem" << endl;
			exit(-1);
		}



		vector < vector < double > > predicted_det_distance_set =
			mr.make_prediction_by_sequence(
				sequence,
				current_crs);




		for (int tt = 0; tt<30; tt++)
			PutVa(tt, out, 10, 5, 'l');
		out << endl;

		for (int kk = 0; kk<predicted_det_distance_set.size(); kk++)
		{
			for (int ttt = 0; ttt<number_of_clasters; ttt++)
				predicted_det_distance_set[kk][ttt] = -predicted_det_distance_set[kk][number_of_clasters + ttt];

			predicted_det_distance_set[kk].resize(30);

			int predicted_nearest_index =
				get_nearest_claster_index(predicted_det_distance_set[kk]);

			PutVa(predicted_nearest_index, out, 4, 2, 'l');

			for (int tt = 0; tt<predicted_det_distance_set[0].size(); tt++)
			{
				PutVaDouble(-predicted_det_distance_set[kk][tt], out, 10, 5, 'l');
				out << " ";
			}
			out << endl;

		}
		out.close();
	}
}
void Abu_Maimonides_Rambam_test::
intack_test_for_prediction_by_sequence()
{
	Abu_Maimonides_Rambam mr("new_generation_model_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
		charming_Reg_solution  * current_crs = mr.init_together_model();

	//>gi|5524211|gb|AAD44166.1| cytochrome b [Elephas maximus maximus]

	int number_of_clasters = mr.get_number_of_clasters();

   string sequence = "LCLYTHIGRNIYYGSYLYSETWNTGIMLLLITMATAFMGYVLPWGQMSFWGATVITNLFSAIPYIGTNLVEWIWGGFSVDKATLNRFFAFHFILPFTMVALAGVHLTFLHETGSNNPLGLTSDSDKIPFHPYYTIKDFLGLLILILLLLLLALLSPDMLGDPDNHMPADPLNTPLHIKPEWYFLFAYAILRSVPNKLGGVLALFLSIVILGLMPFLHTSKHRSMMLRPLSQALFWTLTMDLLTLTWIGSQPVEYPYTIIGQMASILYFSIILAFLPIAGXIENY";


	vector < vector < double > > predicted_det_distance_set =
        mr.make_prediction_by_sequence(
            sequence,
            current_crs);

    string out_file_name = "../Test/intack_test_for_prediction_by_sequence_test.txt";

        ofstream out(out_file_name.c_str());
        if (!out)
        {
            cout << "out file problem" << endl;
            exit(-1);
        }

		for (int kk = 0; kk<predicted_det_distance_set.size(); kk++)
		{
			for (int ttt = 0; ttt<number_of_clasters; ttt++)
				predicted_det_distance_set[kk][ttt] = -predicted_det_distance_set[kk][number_of_clasters + ttt];

			predicted_det_distance_set[kk].resize(30);

			int predicted_nearest_index =
				get_nearest_claster_index(predicted_det_distance_set[kk]);

			PutVa(predicted_nearest_index, out, 4, 2, 'l');

			for (int tt = 0; tt<predicted_det_distance_set[0].size(); tt++)
			{
				PutVaDouble(-predicted_det_distance_set[kk][tt], out, 10, 5, 'l');
				out << " ";
			}
			out << endl;

		}
}


void Abu_Maimonides_Rambam_test::remove_large_chain()
{
	int THRESHOLD = 150;
	string binary_file_name("accepted_chain_list.bin");

	vector < string >   accepted_chain_ID_list;
	vector < int >      accepted_chain_lenth;

	fill_up_accepted_chain_data(
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name);

	string path_to_filtered_accepted_chain_list = "filtered_accepted_chain_list.bin";

	string result_binary_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		path_to_filtered_accepted_chain_list;

	ofstream binary_stream(result_binary_file_name.c_str(), ios::binary);

	if (!binary_stream) {
		log_stream << "ERROR -  can't find binary file" << binary_file_name << endl;
		cout << "ERROR -  can't find binary file" << binary_file_name << endl;
		exit(1);
	}

	int size = accepted_chain_ID_list.size();
	int true_counter = 0;
	for (int ii = 0; ii < size; ii++)
	{
		Chain_binary cb(accepted_chain_ID_list[ii]);
		int number_of_residues = cb.get_number_of_residues();

		if (number_of_residues < THRESHOLD)
		{
			binary_stream.write((char*)accepted_chain_ID_list[ii].c_str(), 5);
			binary_stream.write((char*)&number_of_residues, sizeof(int));
			true_counter++;
		}
		else
			continue;
	}
	cout << true_counter;
}

void Abu_Maimonides_Rambam_test::analyse_ready_prediction_set()
{
	string path_to_dir = string ("D:/Didona/Store/Model_store/second_model_advanced/plain_results/");
	string path_to_list = path_to_dir + string ("ready_list");

	ifstream in ( path_to_list.c_str()) ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << endl;
		exit (1);
	}

	string path_to_protocol = path_to_list = path_to_dir + string ("protocol_cmp_pred");
	ofstream out ( path_to_protocol.c_str()) ;
	if ( ! out )	{
		cout       << "Can't create protocol file  " << endl;
		exit (1);
	}

	string current_line;
	string word;

	vector <string> PDB_chain_ID_list;

	while( in >> word )
		PDB_chain_ID_list.push_back(word);

	int total_valid_length = 0;
	int total_length = 0;
	double total_quality =0;
	double total_vaild_length_m_quaity =0;



	for (unsigned ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
		string path_to_current_file = path_to_dir + PDB_chain_ID_list[ii];
		ifstream in_cur ( path_to_current_file.c_str() ) ;



		int current_valid_length;
		int current_length;
		double current_quality;

		while( getline( in_cur  , current_line, '\n' ) )
		{
			string key_word = current_line.substr(0,7);
			if (key_word != string ("Length:") )
				continue;
			else
			{
				{
				istringstream ist (current_line);
				ist >> word >> current_valid_length >> word >> current_length;
				}
				getline( in_cur  , current_line, '\n' );
				{
				istringstream ist (current_line);
				ist  >> word >> current_quality;
				}


				total_quality		+= current_quality;

				total_valid_length	+= current_valid_length;
				total_length		+= current_length;
				total_vaild_length_m_quaity += current_valid_length*current_quality;

				out  << current_quality << "\t" << PDB_chain_ID_list[ii] << ": " << current_valid_length << "\t" << current_length << "\t" << endl;
				cout << PDB_chain_ID_list[ii] << endl;

				break;
			}
		}

	//		handle_single__compare_prediction_INV (path_to_current_file);

	}

		out << "______________________________" << endl;

		out << "total_valid_length:"	<< "\t" << total_valid_length	<< "\t" << endl;
		out << "total_length:"			<< "\t" << total_length	<< endl;
		out << "total_quality:"		<< "\t" << total_quality<< endl;
		out << "accurate quality:" << "\t" << total_vaild_length_m_quaity/total_valid_length << endl;
		out << "rude quality:" << "\t" << total_quality/PDB_chain_ID_list.size()<< endl;
}

void Abu_Maimonides_Rambam_test::
prepare_obesrved_binary_files ()
{
	//string model_name = string("3_culled_2");
	string model_name = string("test_new_approach");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;


///	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();




	 	vector <string > PDB_chain_ID_list;

        //string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/PB_culled/Culled_30_4_0.control";
       // string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/PB_culled/Culled_30_4_0.learning_sample";
        //string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CB513";
        ///PB_culled/Culled_30_4_0.learning_sample

        string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CASP14_free_modeling";

        ifstream list_stream( list_file_name .c_str() ,ios::binary);
		if ( ! list_stream	)
		{
			log_stream << "list_file_name   can't create " << list_file_name<< endl;
			cout       << "list_file_name   can't create " << list_file_name<< endl;
			exit (1);
		}

		string word;
		while (list_stream >> word )
            PDB_chain_ID_list.push_back(word);




	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{


		mr.prepare_single_dist_data (PDB_chain_ID_list[ii]) ;
			cout << ii << " " <<  PDB_chain_ID_list[ii] << endl;
	}

//	delete current_crs;

}

void Abu_Maimonides_Rambam_test::
prepare_obesrved_binary_files_control()
 {
 	string model_name = string("PB_9_culled_for_PPII");
 //	string chain_list_file = "/home/milch/projects/Didona/Store/Chain_store/PB_culled/Culled_30_4_1.control";


	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    ///vector <string>  PDB_chain_ID_list;
//    fill_up_accepted_chain_data_text (
//        PDB_chain_ID_list,
//        chain_list_file);

    vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

   	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.prepare_single_dist_data (PDB_chain_ID_list[ii]) ;
			cout << ii << " " <<  PDB_chain_ID_list[ii] << endl;
	}

}

void Abu_Maimonides_Rambam_test::
CONTROL_prepare_obesrved_binary_files ()
{
	string model_name = string("DataCreate");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

//	charming_Reg_solution  * current_crs = mr.init_together_model ();

//	vector <string > PDB_chain_ID_list = mr.CONTROL_get_accepted_chain_ID_list();


	 	vector <string > PDB_chain_ID_list;

        string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CB513";

        ifstream list_stream( list_file_name .c_str() ,ios::binary);
		if ( ! list_stream	)
		{
			log_stream << "list_file_name   can't create " << list_file_name<< endl;
			cout       << "list_file_name   can't create " << list_file_name<< endl;
			exit (1);
		}

		string word;
		while (list_stream >> word )
            PDB_chain_ID_list.push_back(word);

	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.prepare_single_dist_data (PDB_chain_ID_list[ii]) ;
			cout << ii << " " <<  PDB_chain_ID_list[ii] << endl;
	}

//	delete current_crs;

}

void Abu_Maimonides_Rambam_test::
check_predicted_binary_file_read_write ()
{
  cout << "check_predicted_binary_file_read_write ()" << endl;
	string model_name = string("PB_11");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();

	string PDB_chain_ID = "9PAIB";

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID +
			".dist_data_predicted";

      //      log_stream << " string current_distance_file_name = PASSED" << endl;

			Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID );
			string sequence = chain->get_sequence();
			delete chain;
       //     log_stream << " Chain_binary * chain PASSED" << endl;
			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
				sequence,
				current_crs	);


		/// log_stream << " vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence ( PASSED" << endl;
// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}
	/*	log_stream << "BEFORE write bin file" << endl;
            for (int zzz = 0;  zzz<16;zzz++)
             log_stream <<    predicted_det_distance_set[0][zzz] << " ";
             log_stream << endl;
            for (int zzz = 16;  zzz<32;zzz++)
             log_stream <<    predicted_det_distance_set[0][zzz] << " ";
                log_stream << endl;
                */


		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);
		distdata_stream.close();

		vector <vector <double> > predicted_det_distance_set_from_file =  mr.read_det_distance_set(PDB_chain_ID,".dist_data_predicted");


	 string out_file_name = "../Test/check_predicted_binary_file_read_write";

	ofstream out(out_file_name.c_str());
    if (!out)
    {
        cout << "out file problem" << endl;
        exit(-1);
    }

    for (int ii=0;ii<predicted_det_distance_set.size();ii++)
    {
        for (int jj=0;jj<32;jj++)
        {
            PutVaDouble (predicted_det_distance_set[ii][jj],out,8,4,'l');   out << " / "  ;
            PutVaDouble (predicted_det_distance_set_from_file[ii][jj],out,8,4,'l');
        }

        out << endl;
    }





//*******************************************************************************

}


void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files (string & short_name)
{
    cout << "prepare_predicted_binary_files ()" << endl;
	string model_name = string("test_new_approach_3adv");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();

    vector <string > PDB_chain_ID_list;

    string path_to_list_store = "/home/milch/projects/Didona/Store/Chain_store/";
    string list_file_name = path_to_list_store + short_name;

    ifstream list_stream( list_file_name .c_str() ,ios::binary);
    if ( ! list_stream	)
    {
        log_stream << "list_file_name   can't create " << list_file_name<< endl;
        cout       << "list_file_name   can't create " << list_file_name<< endl;
        exit (1);
    }

    string word;
    while (list_stream >> word )
        PDB_chain_ID_list.push_back(word);

    string sequence ;

    for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted";

			Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID_list[ii] );
			string sequence = chain->get_sequence();
			delete chain;

			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
				sequence,
				current_crs	);

// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			exit (1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();

//*******************************************************************************
        cout << ii << " " <<  PDB_chain_ID_list[ii] <<   endl;

	}
	delete current_crs;
}


void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files ()
{

    cout << "prepare_predicted_binary_files ()" << endl;
	//string model_name = string("3_culled_2");
	string model_name = string("test_new_approach_3adv");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();



	 	vector <string > PDB_chain_ID_list;

        string list_file_name = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/CB513.not_empty";

        ifstream list_stream( list_file_name .c_str() ,ios::binary);
		if ( ! list_stream	)
		{
			log_stream << "list_file_name   can't create " << list_file_name<< endl;
			cout       << "list_file_name   can't create " << list_file_name<< endl;
			exit (1);
		}

		string word;
		while (list_stream >> word )
            PDB_chain_ID_list.push_back(word);



    string sequence ;///= "AAAPAPAPGGGGGGGGIIII";

    for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted";

  //          log_stream << " string current_distance_file_name = PASSED" << endl;
//            cout << "before mr.make_prediction_by_sequence " << endl;

			Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID_list[ii] );
			string sequence = chain->get_sequence();
			delete chain;

       //     log_stream << " Chain_binary * chain PASSED" << endl;
			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
				sequence,
				current_crs	);

	//		cout << "after mr.make_prediction_by_sequence " << endl;


// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();


/*
		string current_distance_file_name_test = current_distance_file_name + ".test.txt";
        ofstream distdata_stream_test( current_distance_file_name_test.c_str() );
		if ( ! distdata_stream_test )
		{
			log_stream << "make_cross_sum_binary_files TEST	(): ERROR -  can't create " << current_distance_file_name_test  << endl;
			cout       << "make_cross_sum_binary_files	TEST (): ERROR -  can't create " << current_distance_file_name_test  << endl;

			exit (1);
		}
		for (int kk=0;kk<predicted_det_distance_set.size();kk++)
        {

            for (int jj=0;jj<predicted_det_distance_set[0].size();jj++ )
            {


                PutVaDouble(predicted_det_distance_set[kk][jj],distdata_stream_test,10,3,'l') ;
                distdata_stream_test << " ";
            }
           distdata_stream_test << endl;

        }


**/
//*******************************************************************************
        cout << ii << " " <<  PDB_chain_ID_list[ii] <<   endl;

	}

	delete current_crs;
}


void Abu_Maimonides_Rambam_test::check_predicted_binary_files()
{


    cout << "check_predicted_binary_files ()" << endl;
	string model_name = string("PB_9_culled_for_AI");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)

	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted";


		//vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (				sequence,				current_crs	);
        vector <vector <double> > predicted_det_distance_set = read_det_distance_set (current_distance_file_name);


		string current_distance_file_name_test = current_distance_file_name + ".check.txt";
        ofstream distdata_stream_test( current_distance_file_name_test.c_str() );
		if ( ! distdata_stream_test )
		{
			log_stream << "make_cross_sum_binary_files TEST	(): ERROR -  can't create " << current_distance_file_name_test  << endl;
			cout       << "make_cross_sum_binary_files	TEST (): ERROR -  can't create " << current_distance_file_name_test  << endl;

			exit (1);
		}

		for (int kk=0;kk<predicted_det_distance_set.size();kk++)
        {

            for (int jj=0;jj<predicted_det_distance_set[0].size();jj++ )
            {


                PutVaDouble(predicted_det_distance_set[kk][jj],distdata_stream_test,10,3,'l') ;
                distdata_stream_test << " ";
            }
           distdata_stream_test << endl;

        }



//*******************************************************************************
        cout << ii << " " <<  PDB_chain_ID_list[ii] <<   endl;

	}



}

void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files_control()
{

 	string model_name = string("PB_9_culled_3");
 	string chain_list_file = "PB_culled/Culled_30_4_3.control";


//    string model_name = string("PB_9");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();


	vector <string > PDB_chain_ID_list;


///	string path_to_accepted_chain_list_file = " DeBre_LS_existed_5_1.control";

    fill_up_accepted_chain_data_text (
        PDB_chain_ID_list,
        chain_list_file);


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)

	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted";

      //      log_stream << " string current_distance_file_name = PASSED" << endl;

			Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID_list[ii] );
			string sequence = chain->get_sequence();
			delete chain;
       //     log_stream << " Chain_binary * chain PASSED" << endl;
			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
				sequence,
				current_crs	);


		/// log_stream << " vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence ( PASSED" << endl;
// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
//*******************************************************************************
        cout << ii << " " <<  PDB_chain_ID_list[ii] <<   endl;

	}

	delete current_crs;



}


void Abu_Maimonides_Rambam_test::
CONTROL_prepare_predicted_binary_files ()
{

	string model_name = string("DataCreate");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
 	charming_Reg_solution  * current_crs = mr.init_together_model ();

	//vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();
///    vector <string > PDB_chain_ID_list = mr.CONTROL_get_accepted_chain_ID_list();


    	vector <string > PDB_chain_ID_list;

        string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CB513";

        ifstream list_stream( list_file_name .c_str() ,ios::binary);
		if ( ! list_stream	)
		{
			log_stream << "list_file_name   can't create " << list_file_name<< endl;
			cout       << "list_file_name   can't create " << list_file_name<< endl;
			exit (1);
		}

		string word;
		while (list_stream >> word )
            PDB_chain_ID_list.push_back(word);


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted";

	/*
		ifstream t_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( t_stream)
		{
			log_stream << "already exist: " << current_distance_file_name  << endl;
			cout       << "already exist: " << current_distance_file_name  << endl;
			continue;
		}
		*/

			Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID_list[ii] );
			string sequence = chain->get_sequence();
			delete chain;

			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
				sequence,
				current_crs	);

// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
//*******************************************************************************



			cout << ii << " " <<  PDB_chain_ID_list[ii] << endl;
	}

	delete current_crs;
}

//Chain_Residue_Set crs ( pdb_chain_ID );
//crs.save_as_binary();



void Abu_Maimonides_Rambam_test::
prepare_observed_binary_files_for_external_sequnces()
{

	string path_to_shit_rogue =
			configuration.option_meaning("Path_to_Model_store") +
			string("De_Brewern_data") +
			string ("/");


//	string path_to_external_PDB_chain_ID_list = "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/";

//	string path_to_external_PDB_chain_ID_list = path_to_shit_rogue + "id_pull.txt";


	string external_PDB_chain_ID_list_file = path_to_shit_rogue + "id_pull.txt";
	vector <string > PDB_chain_ID_list;

	ifstream in_pdb_id(external_PDB_chain_ID_list_file.c_str());
	if (!in_pdb_id)
	{
		log_stream << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		cout << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		throw;
	}
	string current_word;
	while (in_pdb_id >> current_word)
		PDB_chain_ID_list.push_back(current_word);


//	Chain_store("large.txt");

/*	for (int ii = 0; ii < PDB_chain_ID_list.size(); ii++)
	{
		const string currentID = PDB_chain_ID_list[ii];
		Chain_Residue_Set crs(currentID);
		crs.save_as_binary();
	}
*/

	string model_name = string("PB_2");

	Abu_Maimonides_Rambam mr(model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);

	//	charming_Reg_solution  * current_crs = mr.init_together_model ();

//	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();




	for (int ii = 0; ii<PDB_chain_ID_list.size(); ii++)
	{
		mr.prepare_single_dist_data(PDB_chain_ID_list[ii]);
		cout << ii << " " << PDB_chain_ID_list[ii] << endl;
	}
}

void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files_for_external_sequnces()
{

	string model_name = string("new_generation_model_2");

	Abu_Maimonides_Rambam mr(model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);

	charming_Reg_solution  * current_crs = mr.init_together_model();

	//vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	string path_to_external_PDB_chain_ID_list = "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/";
	string external_PDB_chain_ID_list_file = path_to_external_PDB_chain_ID_list + string("list");
	vector <string > PDB_chain_ID_file_names;

	ifstream in_pdb_id(external_PDB_chain_ID_list_file.c_str());
	if (!in_pdb_id)
	{
		log_stream << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		cout << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		throw;
	}
	string current_word;
	while (in_pdb_id >> current_word)
		PDB_chain_ID_file_names.push_back(current_word);



	for (int ii = 0; ii<PDB_chain_ID_file_names.size(); ii++)
	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name +
			"/cross_sum/" +
			PDB_chain_ID_file_names[ii] +
			".dist_data_predicted";


//		Chain_binary * chain = new Chain_binary(PDB_chain_ID_list[ii]);
//		string sequence = chain->get_sequence();
//		delete chain;

		string seq_fina = path_to_external_PDB_chain_ID_list + PDB_chain_ID_file_names[ii];
		ifstream in_se(seq_fina.c_str() );
		if (!in_se)
		{
			log_stream << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
			cout << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
			throw;
		}
		string sequence;
		getline(in_se, sequence, '\n'); // the first string in tis file is sequence

		for (int kk = 0; kk < sequence.size(); kk++)
			sequence[kk] = toupper(sequence[kk]);

		vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence(
			sequence,
			current_crs);

		// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream(current_distance_file_name.c_str(), ios::binary);
		if (!distdata_stream)
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name << endl;
			cout << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name << endl;

			exit(1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
		//*******************************************************************************

		cout << ii << " " << PDB_chain_ID_file_names[ii] << endl;
	}

	delete current_crs;
}




double dummy_sum (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number);
double dummy_sum_2 (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number);


Abu_Maimonides_Rambam_test::~Abu_Maimonides_Rambam_test()
{
	cout << "Abu_Maimonides_Rambam_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}



void Abu_Maimonides_Rambam_test::prepare_united_su_avsumx_d_test (  )
{

	ifstream in ( "D:/Didona/Store/Model_store/_SETTED_BASIS_STRUCTURES/TriPeptides_next/cross_sum/ready_cross_sum_list") ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << endl;
		exit (1);
	}

	vector <string> PDB_chain_ID_list;
	string word;
	while( in >> word )
		PDB_chain_ID_list.push_back(word);

	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

//	mr.prepare_united_su_avsumx_d(PDB_chain_ID_list); Если нгеохота ждать
	mr.prepare_united_su_avsumx_d();
	mr.plain_solution ( "together" );

}

void Abu_Maimonides_Rambam_test::
prepare_data_for_AI_test()
{
    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
    //mr.prepare_data_for_AI("/raw_AI_data/");
    //string path_to_PDB_ID_list = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/test_30_by_Culled_30";
    string path_to_PDB_ID_list = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/Culled_30.not_empty";

    mr.prepare_data_for_AI("/AI_data_for_regression/",path_to_PDB_ID_list);

}
/*
void Abu_Maimonides_Rambam_test::
prepare_single_again_data_for_AI_test()
{
    Abu_Maimonides_Rambam mr("test_new_approach_1",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";
    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_new_app/IntermediateData/Based_on_Structure/";

    {
    string data_set_name        =   "validation_for_dssp";
    mr.prepare_single_again_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        =   "test_for_dssp";
    mr.prepare_single_again_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        =   "train_for_dssp";
    mr.prepare_single_again_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        =   "CB513";
    mr.prepare_single_again_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        =   "CaspDeBrew";
    mr.prepare_single_again_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }


}
*/


void Abu_Maimonides_Rambam_test::
prepare_triple_data_for_AI_test(string &data_set_name)
{
    Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";

    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_test_new_approach_4/IntermediateData/Based_on_Structure/";

    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );

   // string data_set_name        ="CB513";
    //string data_set_name        =   "CaspDeBrew";

    //string data_set_name        =   "all_for_dssp";
    //string path_to_PDB_ID_list  = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/all_for_dssp";
    //string path_to_raw_data     ="/media/milch/Новый том/stash/R1210.dat/";
/*
    {
    string data_set_name        ="CB513";
    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        ="CaspDeBrew";
    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }


    {
    string data_set_name        ="train_for_dssp";
    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        ="test_for_dssp";
    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

    {
    string data_set_name        ="validation_for_dssp";
    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }


    {
    string data_set_name        ="CaspDeBrew";
    mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
    }

*/


}


void Abu_Maimonides_Rambam_test::prepare_regression_data_for_significant_var_selection_test (string &data_set_name)
{

   // Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    Abu_Maimonides_Rambam mr("test_new_approach_3adv",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";

    //string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_test_new_approach_4/IntermediateData/Based_on_Structure/";
    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_test_new_approach_4/IntermediateData/DA_prepare_significant_set/";

    mr.prepare_regression_data_for_significant_var_selection(path_to_raw_data,path_to_PDB_ID_list,data_set_name );


}

void Abu_Maimonides_Rambam_test::prepare_DAS_selected_data_for_AI_test (string &data_set_name)

{

   // Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    Abu_Maimonides_Rambam mr("test_new_approach_3adv",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";

    //string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_test_new_approach_4/IntermediateData/Based_on_Structure/";
    //string path_to_raw_data     ="/media/milch/Новый\ том/ML_calculation/DAS_selected_predictors_model_PB16/";
    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/DAS_selected_predictors_model_PB16/483.data/";

    mr.prepare_DAS_selected_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );


}

void Abu_Maimonides_Rambam_test::
prepare_triple_data_for_AI_SS_8_for_classify_test()
{
    Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";
    //string path_to_raw_data     ="/media/milch/Новый\ том/ML_calculation/DSSP_8_initial_predictors/IntermediateData/";
    string path_to_raw_data     ="/media/milch/Новый\ том/ML_calculation/DSSP_8_test_for_classify_new_approach_4/IntermediateData/";
    string path_to_SS_data      ="/media/milch/Новый том/ML_calculation/SEQ_DSSP_PB.data/";

    //string data_set_name        =   "all_for_dssp";
    //string path_to_PDB_ID_list  = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/all_for_dssp";
    //string path_to_raw_data     ="/media/milch/Новый том/stash/R1210.dat/";

 //   mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
/*
    data_set_name        ="train_for_dssp";
    mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);

    data_set_name        ="test_for_dssp";
    mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);

    data_set_name        ="validation_for_dssp";
    mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);

*/

    {
      //  string data_set_name        ="CB513";
      string data_set_name        ="CaspDeBrew";
        mr.prepare_triple_data_for_AI_SS_8_for_classify(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }


    {
        string data_set_name        ="validation_for_dssp";
        mr.prepare_triple_data_for_AI_SS_8_for_classify(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }


    {
        string data_set_name        ="test_for_dssp";
        mr.prepare_triple_data_for_AI_SS_8_for_classify(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }

    {
        string data_set_name        ="train_for_dssp";
        mr.prepare_triple_data_for_AI_SS_8_for_classify(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }

//    {
//        string data_set_name        ="CaspDeBrew";
//        mr.prepare_triple_data_for_AI_SS_8_for_classify(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
//    }


}



void Abu_Maimonides_Rambam_test::
prepare_triple_data_for_AI_SS_8_test()
{
    Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";
    //string path_to_raw_data     ="/media/milch/Новый\ том/ML_calculation/DSSP_8_initial_predictors/IntermediateData/";
    string path_to_raw_data     ="/media/milch/Новый\ том/ML_calculation/DSSP_8_test_new_approach_4/IntermediateData/";
    string path_to_SS_data      ="/media/milch/Новый том/ML_calculation/SEQ_DSSP_PB.data/";

    //string data_set_name        =   "all_for_dssp";
    //string path_to_PDB_ID_list  = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/all_for_dssp";
    //string path_to_raw_data     ="/media/milch/Новый том/stash/R1210.dat/";

 //   mr.prepare_triple_data_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );
/*
    data_set_name        ="train_for_dssp";
    mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);

    data_set_name        ="test_for_dssp";
    mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);

    data_set_name        ="validation_for_dssp";
    mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);

*/

    {
      //  string data_set_name        ="CB513";
      string data_set_name        ="CaspDeBrew";
        mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }

/*
    {
        string data_set_name        ="validation_for_dssp";
        mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }


    {
        string data_set_name        ="test_for_dssp";
        mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }

    {
        string data_set_name        ="train_for_dssp";
        mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
    }
*/
//    {
//        string data_set_name        ="CaspDeBrew";
//        mr.prepare_triple_data_for_AI_SS_8(path_to_raw_data,path_to_PDB_ID_list,path_to_SS_data,data_set_name);
//    }


}

void Abu_Maimonides_Rambam_test:: /// на самом деле не triple_data а fivefold
prepare_triple_data_for_AI_by_sequence_test()
{
/*
    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";
    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16/IntermediateData/Based_on_Seguence/";
    string data_set_name        =   "all_for_dssp";
*/

    Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  ="/media/milch/Новый том/ML_calculation/";

    string path_to_raw_data     ="/media/milch/Новый том/ML_calculation/PB_16_test_new_approach_4/IntermediateData/Based_on_Seguence/";

    //string data_set_name        =   "validation_for_dssp";
  //  string data_set_name        =   "CaspDeBrew";

  string data_set_name        =   "Single_test";


    mr.prepare_triple_data_for_AI_by_sequence(path_to_raw_data,path_to_PDB_ID_list,data_set_name );

}

/*
void Abu_Maimonides_Rambam_test::
prepare_quinarii_data_for_AI_test()
{
    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_PDB_ID_list  = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/test_30_by_Culled_30.not_empty";
    string path_to_raw_data     ="/media/milch/Новый\ том/stash/by_R726_quinarii.dat/";
    string data_set_name        ="test";

    mr.prepare_quinarii_for_AI(path_to_raw_data,path_to_PDB_ID_list,data_set_name );



}
*/

void Abu_Maimonides_Rambam_test::
prepare_data_for_AI_for_prediction_by_sequences_set_test()
{
    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;


    string path_to_sequence_set_folder = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/AI_data_for_regression/");
    string path_to_result_folder       = string("/media/milch/Новый\ том/stash/Data_for_prediction_by_sequence/");
    string path_to_PDB_ID_list         = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/Culled_30.not_empty");


    mr.prepare_data_for_AI_for_prediction_by_sequences_set(
        path_to_sequence_set_folder,  //sequence- the first string in file [pdbID].protocol
        path_to_result_folder,
        path_to_PDB_ID_list);
}

void Abu_Maimonides_Rambam_test::
prepare_sophisticated_AI_data_set_based_on_first_stage_predicrion_by_fulle_sequence_test()
{
    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string path_to_first_stage_prediction_folder = string("/media/milch/Новый том/stash/Data_for_prediction_by_sequence/");

/*    string path_to_result_folder       = string("/media/milch/Новый\ том/stash/Data_for_prediction_by_sequence/test.dat/");
    string ready_data_name                                                                            =string("test");
    string path_to_PDB_ID_list         = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/test_30_by_Culled_30.not_empty");
*/
    string path_to_result_folder       = string("/media/milch/Новый\ том/stash/Data_for_prediction_by_sequence/validation.dat/");
    string ready_data_name                                                                            =string("validation");
    string path_to_PDB_ID_list         = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/validation_10_by_Culled_30.not_empty");

    mr.prepare_sophisticated_AI_data_set_based_on_first_stage_predicrion_by_fulle_sequence(
        path_to_first_stage_prediction_folder,  //sequence- the first string in file [pdbID].protocol
        path_to_result_folder,
        ready_data_name,
        path_to_PDB_ID_list);
}

/*
void Abu_Maimonides_Rambam_test::
prepare_data_R726_for_AI_for_prediction_by_sequences_set_test()
{
    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;


    string path_to_sequence_set_folder = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/AI_data_for_regression/");
    string path_to_result_folder       = string("/media/milch/Новый\ том/stash/Data_for_prediction_by_sequence/");
    string path_to_PDB_ID_list         = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/Culled_30.not_empty");


    mr.prepare_data_R726_for_AI_for_prediction_by_sequences_set(
        path_to_sequence_set_folder,  //sequence- the first string in file [pdbID].protocol
        path_to_result_folder,
        path_to_PDB_ID_list);
}
*/


///неудвчный вариант, хотя вроде правильно работает
void Abu_Maimonides_Rambam_test::
data_for_AI_prediction_by_sequence_test()
{

    Abu_Maimonides_Rambam mr("PB_9_culled_for_AI",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
    //string path_to_PDB_ID_list = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/test_30_by_Culled_30";
/* SINGLECASE
    /// sequence for chain 12ASA
    string sequence = "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSGAEKAVQVKVKALPDAQFEVVHSLAKWKRQTLGQHDFSAGEGLYTHMKALRPDEDRLSPLHSVYVDQWDWERVMGDGERQFSTLKSTVEAIWAGIKATEAAVSEEFGLAPFLPDQIHFVHSQELLSRYPDLDAKGRERAIAKDLGAVFLVGIGGKLSDGHRHDVRAPDYDDWSTPSELGHAGLNGDILVWNPVLEDAFELSSMGIRVDADTLKHQLALTGDEDRLELEWHQALLRGEMPQTIGGGIGQSRLTMLLLQLPHIGQVQAGVWPAAVRESVPSLL";

    vector < vector < double > >  sophisticated_variables = mr.data_for_AI_prediction_by_sequence(sequence);

    ofstream out("Test/data_for_AI_prediction_by_sequence_test");
    if (!out)
    {
        log_stream  <<  "ERROR -  can't create data_for_AI_prediction_by_sequence_test"<< endl;
        cout        <<  "ERROR -  can't create data_for_AI_prediction_by_sequence_test"<< endl;
        exit(1);
    }


    for (int ii=0; ii<sophisticated_variables.size();ii++)
    {
         for (int jj=0; jj<sophisticated_variables[0].size();jj++)
         {
            PutVaDouble(sophisticated_variables[ii][jj],out,10,3,'l');
         }
         out << endl;
    }
*/

   // string path_to_chaid_id_list = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/Culled_30.not_empty.not_empty");
    string path_to_chaid_id_list = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/validation");

/// [pfb_ID].protocol These files contain sequences and indexes of residues with known coordinates.
    string path_to_protocol_folder = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/AI_data_for_regression/");

///
    //string path_to_result_folder = string("/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/AI_data_consider_neighbors/");

    string path_to_result_folder = string("/media/milch/Новый\ том/stash/AI_data_consider_neighbors/");


	ifstream in ( path_to_chaid_id_list.c_str()) ;
	if ( ! in )	{
		cout       << "Can't find  file  " << path_to_chaid_id_list << endl;
		exit (1);
	}

	vector <string> PDB_chain_ID_list;
	string word;
	while( in >> word )
		PDB_chain_ID_list.push_back(word);


    string path_to_total_result = path_to_result_folder + string("validation_10_by_Culled_30") + string(".dat");
    ofstream result_total_stream ( path_to_total_result .c_str()) ;
    if ( ! result_total_stream  )	{
        cout       << "Can't find  file  " << path_to_total_result  << endl;
        exit (1);
    }


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
        cout << PDB_chain_ID_list[ii] << " " << ii << endl;
        string path_to_protocol = path_to_protocol_folder + PDB_chain_ID_list[ii]+ string(".protocol");
        ifstream protocol_stream ( path_to_protocol.c_str()) ;
        if ( ! protocol_stream  )	{
            cout       << "Can't find  file  " << path_to_protocol << endl;
            exit (1);
        }
/*
        string path_to_result = path_to_result_folder + PDB_chain_ID_list[ii] + string(".dat");
        ofstream result_stream ( path_to_result.c_str()) ;
        if ( ! result_stream  )	{
            cout       << "Can't find  file  " << path_to_result << endl;
            exit (1);
        }
*/


        vector <int> realy_cartesian_index;
        string current_line,sequence;
        getline( protocol_stream   , current_line, '\n' );
        istringstream ist (current_line);
        ist >> sequence;
        int tmp;
        while( protocol_stream >>  tmp)
            realy_cartesian_index.push_back(tmp);

        vector < vector < double > >  sophisticated_variables = mr.data_for_AI_prediction_by_sequence(sequence);

        vector < double > current_united_variables;
        int shift = 2;
        for (int kk=0;kk< realy_cartesian_index.size();kk++)
        {
//            if (realy_cartesian_index[kk]==0 || realy_cartesian_index[kk]== (sequence.size() - 5 ) )  /// 5 - это 2 + 2 крайних и 1 т.к. с 0 начало
  //              continue;


            int prev = realy_cartesian_index[kk] + shift-1;
            int curr = realy_cartesian_index[kk] + shift;
            int next = realy_cartesian_index[kk] + shift+1;
/*
                current_united_variables.insert(
                    current_united_variables.end(),
                    sophisticated_variables[ prev ].begin(),
                    sophisticated_variables[ prev ].end() );

                 current_united_variables.insert(
                    current_united_variables.end(),
                    sophisticated_variables[ curr ].begin(),
                    sophisticated_variables[ curr ].end() );


                 current_united_variables.insert(
                    current_united_variables.end(),
                    sophisticated_variables[ next ].begin(),
                    sophisticated_variables[ next ].end() );
*/

                for (int zz=0;zz<sophisticated_variables[prev].size();zz++)
                {
               		PutVaDouble (sophisticated_variables[prev][zz],result_total_stream,10,6,'l');
               		result_total_stream <<"\t";
                }
                for (int zz=0;zz<sophisticated_variables[curr].size();zz++)
                {
               		PutVaDouble (sophisticated_variables[curr][zz],result_total_stream,10,6,'l');
               		result_total_stream <<"\t";
                }
                for (int zz=0;zz<sophisticated_variables[next].size();zz++)
                {
               		PutVaDouble (sophisticated_variables[next][zz],result_total_stream,10,6,'l');
               		result_total_stream <<"\t";
                }

                result_total_stream << endl;

                ///sophisticated_variables.resize(0);


        }
        realy_cartesian_index.resize(0);
        protocol_stream.close();
       /// result_total_stream.close();
	}


}
void convert_raw_to_ready_single (const string &path_to_raw_file,const int shoulder);
void Abu_Maimonides_Rambam_test::prepare_data_for_AI_handle_raw_data_test()
{
    const string path_for_raw_data    = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/";
    //string chain_list_file          = "/home/milch/projects/Didona/Store/Chain_store/Culled_30";
    string chain_list_file          = "Culled_30";

    const int shoulder =1;

    vector <string> accepted_chain_ID_list;
   	fill_up_accepted_chain_data_text (
		accepted_chain_ID_list,
        chain_list_file );

    for (int kk = 0; kk < accepted_chain_ID_list.size(); kk++)
	{
        string current_chain_ID = accepted_chain_ID_list[kk];
        string path_to_raw_file = path_for_raw_data+ current_chain_ID+string(".raw_dat");
        convert_raw_to_ready_single (path_to_raw_file,shoulder);
        cout << kk<< " " << accepted_chain_ID_list[kk]<< endl;

    }

}

void Abu_Maimonides_Rambam_test::
prepare_train_test_validation_PDB_ID_list()
{
    const string path_for_raw_data    = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/";
    string chain_list_file          = "Culled_30";

    const int shoulder =1;

    vector <string> accepted_chain_ID_list;
        fill_up_accepted_chain_data_text (
        accepted_chain_ID_list,
        chain_list_file );

     string train_name      =     path_for_raw_data + string ("train_60_by_Culled_30");
     string test_name       =     path_for_raw_data + string ("test_30_by_Culled_30");
     string validation_name =     path_for_raw_data + string ("validation_10_by_Culled_30");

    ofstream train_stream(train_name.c_str());
    if (!train_stream)
    {
        log_stream  <<  "ERROR -  can't create " << train_name << endl;
        cout        <<  "ERROR -  can't create " << train_name << endl;
        exit(1);
    }


    ofstream test_stream(test_name.c_str());
    if (!test_stream)
    {
        log_stream  <<  "ERROR -  can't create " << test_name << endl;
        cout        <<  "ERROR -  can't create " << test_name << endl;
        exit(1);
    }


    ofstream validation_stream(validation_name.c_str());
    if (!validation_stream)
    {
        log_stream  <<  "ERROR -  can't create " << validation_name << endl;
        cout        <<  "ERROR -  can't create " << validation_name << endl;
        exit(1);
    }

  int b1=60, b2=90, b3=100;

  int random = rand() % 100;

  for (int kk = 0; kk < accepted_chain_ID_list.size(); kk++)
  {
    random = rand() % 100;
    if (random<=b1)
        train_stream << accepted_chain_ID_list[kk] << endl;
     else if (random>b1 && random<=b2)
        test_stream << accepted_chain_ID_list[kk] << endl;
     else
        validation_stream << accepted_chain_ID_list[kk] << endl;

  }
}

void Abu_Maimonides_Rambam_test::
collect_ready_data()
{
     string path_for_raw_data    = "/home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data/";
   //                                 /home/milch/projects/Didona/Store/Model_store/PB_9_culled_for_AI/raw_AI_data

  /*   string train_list        = path_for_raw_data + string("train_60_by_Culled_30");
     string test_list         = path_for_raw_data + string("test_30_by_Culled_30");
     string validation_list   = path_for_raw_data + string("validation_10_by_Culled_30");
*/

     string train_list        =  string("train_60_by_Culled_30");
     string test_list         =  string("test_30_by_Culled_30");
     string validation_list   =  string("validation_10_by_Culled_30");

     vector <string> accepted_chain_ID_list;
/***
 /// train block
     fill_up_accepted_chain_data_text (
        accepted_chain_ID_list,
        train_list );

    string train_file_name =    path_for_raw_data + string ("train.data");
   //  string train_file_name =     "train.data";

    ofstream train_stream(train_file_name.c_str());
 //  ofstream train_stream("XXX");
    if (!train_stream)

    {
        log_stream  <<  "ERROR -  can't create " << train_file_name << endl;
        cout        <<  "ERROR -  can't create " << train_file_name << endl;
        exit(1);
    }


     for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
     {
        string current_file_name = path_for_raw_data + accepted_chain_ID_list[ii] + string(".ready_data");
        ifstream in(current_file_name.c_str());
        if (!in)
        {
            log_stream  <<  "ERROR -  can't create " << current_file_name << endl;
            cout        <<  "ERROR -  can't create " << current_file_name << endl;
            exit(1);
        }

        string current_line;
        while( getline( in  , current_line, '\n' ) )
            train_stream << current_line << endl;

        in.close();

        cout << ii << " " << accepted_chain_ID_list[ii] << endl;

     }

/// test block
    accepted_chain_ID_list.resize(0);

  //  vector <string> accepted_chain_ID_list;
        fill_up_accepted_chain_data_text (
        accepted_chain_ID_list,
        test_list );

    string test_file_name =    path_for_raw_data + string ("test.data");

    ofstream test_stream(test_file_name.c_str());
    if (!test_stream)
    {
        log_stream  <<  "ERROR -  can't create " << test_file_name << endl;
        cout        <<  "ERROR -  can't create " << test_file_name << endl;
        exit(1);
    }


     for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
     {
        string current_file_name = path_for_raw_data + accepted_chain_ID_list[ii] + string(".ready_data");
        ifstream in(current_file_name.c_str());
        if (!in)
        {
            log_stream  <<  "ERROR -  can't create " << current_file_name << endl;
            cout        <<  "ERROR -  can't create " << current_file_name << endl;
            exit(1);
        }

        string current_line;
        while( getline( in  , current_line, '\n' ) )
            test_stream << current_line << endl;

        in.close();
        cout << ii << "test  " << accepted_chain_ID_list[ii] << endl;

     }

***/
/// validation block
    accepted_chain_ID_list.resize(0);

 //   vector <string> accepted_chain_ID_list;
        fill_up_accepted_chain_data_text (
        accepted_chain_ID_list,
        validation_list );


    string validation_file_name =    path_for_raw_data + string ("validation.data");

    ofstream validation_stream(validation_file_name.c_str());
    if (!validation_stream)
    {
        log_stream  <<  "ERROR -  can't create " << validation_file_name << endl;
        cout        <<  "ERROR -  can't create " << validation_file_name << endl;
        exit(1);
    }


     for (int ii=0;ii<accepted_chain_ID_list.size();ii++)
     {
        string current_file_name = path_for_raw_data + accepted_chain_ID_list[ii] + string(".ready_data");
        ifstream in(current_file_name.c_str());
        if (!in)
        {
            log_stream  <<  "ERROR -  can't create " << current_file_name << endl;
            cout        <<  "ERROR -  can't create " << current_file_name << endl;
            exit(1);
        }

        string current_line;
        while( getline( in  , current_line, '\n' ) )
            validation_stream << current_line << endl;

        in.close();

          cout << ii << "validation  " << accepted_chain_ID_list[ii] << endl;

     }

}
void Abu_Maimonides_Rambam_test::
dummy_insert_tab()
{
    string path_for_data        = "/home/milch/pytorch/tests/Multi_output_regression_large/";
 //   string data_file_name_bad   = path_for_data + "validation.d";
 //   string data_file_name_good  = path_for_data + "validation.data";

    string data_file_name_bad   = path_for_data + "test.d";
    string data_file_name_good  = path_for_data + "test.data";

        ifstream in(data_file_name_bad.c_str());
        if (!in)
        {
            log_stream  <<  "ERROR -  can't open " << data_file_name_bad << endl;
            cout        <<  "ERROR -  can't open " << data_file_name_bad << endl;
            exit(1);
        }

        ofstream out(data_file_name_good.c_str());
        if (!out)
        {
            log_stream  <<  "ERROR -  can't create " << data_file_name_good << endl;
            cout        <<  "ERROR -  can't create " << data_file_name_good << endl;
            exit(1);
        }

       	string current_line;
       	int counter = 0;
        while( getline( in  , current_line, '\n' ) )
        {
            double value;
      		istringstream ist (current_line);
      		int test=0;
      		while (ist >> value)
      		{
                if (test != 0 )
                    out << '\t';
         		PutVaDouble (value,out,10,6,'l');

         		test++;
            }
            out << endl;
            counter++;
            if(counter%1000==0)
                cout << counter << endl;

        }

}



void Abu_Maimonides_Rambam_test::
protocol_test()
{
   Abu_Maimonides_Rambam mr ( "PredictorSelectModel", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
   //Abu_Maimonides_Rambam mr ( "DebuggingPredictorParameters", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;


}

void Abu_Maimonides_Rambam_test::
plain_solution_test ()
{
   Abu_Maimonides_Rambam mr ( "PredictorSelectModel", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
   //Abu_Maimonides_Rambam mr ( "DebuggingPredictorParameters", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
    mr.plain_solution ( "together" );
}
void Abu_Maimonides_Rambam_test::
analyse_single_prediction_by_existing_model_exotic_dep_val_test()
{
	Abu_Maimonides_Rambam mr("PB_9_culled_for_AI", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);


	charming_Reg_solution  * current_crs = mr.init_together_model();

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	string protocol_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		string("PB_9_culled_for_AI") + string("/plain_results/") +
		string("protocol.exotic");

	ofstream out(protocol_file_name.c_str(), ios::binary);
	if (!out)
	{
		log_stream << "protocol_file_name   can't create " << protocol_file_name << endl;
		cout << "protocol_file_name   can't create " << protocol_file_name << endl;
		exit(1);
	}

	for (int ii = 0; ii<PDB_chain_ID_list.size(); ii++)
	{
		mr.analyse_single_prediction_by_existing_model_exotic_dep_val(
			PDB_chain_ID_list[ii],
			current_crs,
			out);

		cout << PDB_chain_ID_list[ii] << " " << ii << endl;
	}
}
void Abu_Maimonides_Rambam_test::
analyse_single_prediction_by_existing_model_test( string &short_name )
{
//	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//second_model_advanced
	//Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	string model_name = string("test_new_approach_3adv");
    Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	///vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	vector <string > PDB_chain_ID_list;

    ///string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CB513";

  //  string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/PB_culled/Culled_30_4_0.control";
  //  string short_name= "Culled_30_4_0.control";

  //  string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CB513";
  //  string short_name= "CB513";

    string path_to_list_store = "/home/milch/projects/Didona/Store/Chain_store/";
    string list_file_name = path_to_list_store + short_name;
//    string short_name= "Culled_30_4_0.learning_sample";


        ifstream list_stream( list_file_name .c_str() ,ios::binary);
		if ( ! list_stream	)
		{
			log_stream << "list_file_name   can't create " << list_file_name<< endl;
			cout       << "list_file_name   can't create " << list_file_name<< endl;
			exit (1);
		}

		string word;
		while (list_stream >> word )
            PDB_chain_ID_list.push_back(word);



		string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +short_name+
			 string ("protocol_inv") ;

		ofstream out( protocol_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}

		string protocol_file_name_1 =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +short_name+
			 string ("protocol_dir") ;

		ofstream out1( protocol_file_name_1 .c_str() ,ios::binary);
		if ( ! out1	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}


    double quality_sum_inv;
    int valid_coord_res_num_inv;
    int res_num_inv;


    double  SUM_quality_sum_inv =0.0;
    int     SUM_valid_coord_res_num_inv=0;
    int     SUM_res_num_inv=0;


    double quality_sum;
    int valid_coord_res_num;
    int res_num;

    double  SUM_quality_sum =0.0;
    int     SUM_valid_coord_res_num=0;
    int     SUM_res_num=0;



	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
 //   for (int ii=2000;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.analyse_single_prediction_by_existing_model_INV (
			PDB_chain_ID_list[ii],
			current_crs ,
			out,
            quality_sum_inv,
            valid_coord_res_num_inv,
            res_num_inv);

        SUM_quality_sum_inv         +=  quality_sum_inv;
        SUM_valid_coord_res_num_inv +=  valid_coord_res_num_inv;
        SUM_res_num_inv             +=  res_num_inv;


        mr.analyse_single_prediction_by_existing_model (
			PDB_chain_ID_list[ii],
			current_crs ,
			out1,
            quality_sum,
            valid_coord_res_num,
            res_num);

        SUM_quality_sum         +=  quality_sum;
        SUM_valid_coord_res_num +=  valid_coord_res_num;
        SUM_res_num             +=  res_num;

		cout << PDB_chain_ID_list[ii] <<  " " << ii << endl;
	}

	out << "********************************************" << endl;
	out << "Q16: " << SUM_quality_sum_inv / SUM_valid_coord_res_num_inv << "\t";
	out << "Total valid coord/ residue number: " << SUM_valid_coord_res_num_inv << " of " << SUM_res_num_inv<< endl;

	out1 << "********************************************" << endl;
	out1 << "Q16: " << SUM_quality_sum/ SUM_valid_coord_res_num << "\t";
	out1 << "Total valid coord/ residue number: " << SUM_valid_coord_res_num << " of " << SUM_res_num<< endl;





}
/*
void Abu_Maimonides_Rambam_test::
analyse_single_prediction_by_existing_model_test_control()
{

   string model_name = string("PB_9_culled_3");
   string  path_to_accepted_chain_list_file = "PB_culled/Culled_30_4_3.control";

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();


	vector <string > PDB_chain_ID_list;


    fill_up_accepted_chain_data_text (
        PDB_chain_ID_list,
        path_to_accepted_chain_list_file);
	//charming_Reg_solution  * current_crs = mr.init_together_model ();

//	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

		string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +
			 string ("CONTROL_protocol_inv") ;

		ofstream out( protocol_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}

		string protocol_file_name_1 =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +
			 string ("CONTROL_protocol_dir") ;

		ofstream out1( protocol_file_name_1 .c_str() ,ios::binary);
		if ( ! out1	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
 //   for (int ii=2000;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.analyse_single_prediction_by_existing_model_INV (
			PDB_chain_ID_list[ii],
			current_crs ,
			out);

        mr.analyse_single_prediction_by_existing_model (
			PDB_chain_ID_list[ii],
			current_crs ,
			out1);



			cout << PDB_chain_ID_list[ii] <<  " " << ii << endl;
	}




}
*/
/*
void Abu_Maimonides_Rambam_test::
CONTROL_analyse_single_prediction_by_existing_model_test()
{
//	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//second_model_advanced
	//Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	string model_name = string("PB_9");
    Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();



	//vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();
	///vector <string > PDB_chain_ID_list = mr.CONTROL_get_accepted_chain_ID_list();


	 	vector <string > PDB_chain_ID_list;

        string list_file_name = "/home/milch/projects/Didona/Store/Chain_store/CB513";

        ifstream list_stream( list_file_name .c_str() ,ios::binary);
		if ( ! list_stream	)
		{
			log_stream << "list_file_name   can't create " << list_file_name<< endl;
			cout       << "list_file_name   can't create " << list_file_name<< endl;
			exit (1);
		}

		string word;
		while (list_stream >> word )
            PDB_chain_ID_list.push_back(word);

		string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +
			 string ("protocol.CONTROL") ;

		ofstream out( protocol_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}




	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
 //   for (int ii=2000;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.analyse_single_prediction_by_existing_model_INV (
			PDB_chain_ID_list[ii],
			current_crs ,
			out);

			cout << PDB_chain_ID_list[ii] <<  " " << ii << endl;
	}

}
*/
/*
void Abu_Maimonides_Rambam_test::
CONTROL_DIRECT_analyse_single_prediction_by_existing_model_test()
{
//	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//second_model_advanced
	//Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	string model_name = string("PB_9");
    Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();



	//vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();
	vector <string > PDB_chain_ID_list = mr.CONTROL_get_accepted_chain_ID_list();

		string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +
			 string ("protocol_direct.CONTROL") ;

		ofstream out( protocol_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}




	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
 //   for (int ii=2000;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.analyse_single_prediction_by_existing_model (
			PDB_chain_ID_list[ii],
			current_crs ,
			out);

			cout << PDB_chain_ID_list[ii] <<  " " << ii << endl;
	}

}
*/
/*

void Abu_Maimonides_Rambam_test::
check_single_prediction_by_existing_model_test()
{
//	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//second_model_advanced
	//Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	string model_name = string("PB_11");
    Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

		string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +
			 string ("protocol") ;

		ofstream out( protocol_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}



        string PDB_chain_ID = "2YJ1B";

		mr.analyse_single_prediction_by_existing_model_INV (
			PDB_chain_ID,
			current_crs ,
			out);




}

*/

/*

void Abu_Maimonides_Rambam_test::
handle_mutual_distance_test()
{
	Abu_Maimonides_Rambam mr ( "Model_Fr4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();

	string PDB_chain_ID_1 = "119LA";
	string PDB_chain_ID_2 = "1ABAA";

	vector < vector < double > > predicted_det_distance_set_1  =
		mr.single_prediction_by_existing_model (PDB_chain_ID_1,current_crs );

	vector < vector < double > > det_distance_set_1  =
		mr.read_det_distance_set (PDB_chain_ID_1);

	vector < vector < double > > predicted_det_distance_set_2 =
		mr.single_prediction_by_existing_model (PDB_chain_ID_2,current_crs );

	vector < vector < double > > det_distance_set_2  =
		mr.read_det_distance_set (PDB_chain_ID_2);


	vector < vector < double > >  mutual_distance_set =
		two_chain_distance_set (
		PDB_chain_ID_1	,PDB_chain_ID_2,	5);

	ofstream out( "TEST/handle_mutual_distance_test" );

	if ( ! out)
	{
		cout		<<	" can't open test file " << endl;
		log_stream	<<	" can't open test file " << endl;
		exit (1);
	}

	for (int ii=0;ii<mutual_distance_set.size();ii++)
	{
		if (det_distance_set_1[ii][0]  ==-1 )
			continue;
		for (int jj=0;jj<mutual_distance_set[ii].size();jj++)
		{
			if (det_distance_set_2[jj][0]  ==-1 )
				continue;

			PutVaDouble (mutual_distance_set[ii][jj],out,10,3,'r');

			PutVaDouble (mutual_distance_set[ii][jj]*mutual_distance_set[ii][jj],out,10,3,'r');
			out << "\t";
			double s1 = dummy_sum (
				predicted_det_distance_set_1[ii],
				predicted_det_distance_set_2[jj],8);
			double s2 = dummy_sum_2(
				predicted_det_distance_set_1[ii],
				predicted_det_distance_set_2[jj],8);

			PutVaDouble (s1,out,10,3,'r');
			PutVaDouble (s2,out,10,3,'r');

			det_distance_set_1[ii].resize(8);
			det_distance_set_2[jj].resize(8);

			int nearest_index_1 = mr.get_nearest_claster_index( det_distance_set_1[ii]);
			int nearest_index_2 = mr.get_nearest_claster_index( det_distance_set_2[jj]);


			PutVa (nearest_index_1,out,10,3,'r');
			PutVa(nearest_index_2,out,10,3,'r');

			out << endl;
		}


	}



}

double dummy_sum (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number)
{
	double sum=0;
	for (int ii=0;ii<number;ii++)
		sum += fabs (set_1[ii] - set_2[ii]);

	return sum;
}
double dummy_sum_2 (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number)
{
	double sum=0;
	for (int ii=0;ii<number;ii++)
		sum += fabs (set_1[ii] - set_2[ii])*fabs (set_1[ii] - set_2[ii]);
	return sum;
}




void Abu_Maimonides_Rambam_test::make_prediction_by_external_PDB_test ()
{
	//Abu_Maimonides_Rambam mr ( "Model_Fr3", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	Abu_Maimonides_Rambam mr ( "Model_c30_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	mr.make_prediction_by_external_PDB("1C26A");

	mr.compare_ready_observation_prediction ("1C26A");


	delete current_crs ;
}


void Abu_Maimonides_Rambam_test::
correlation_pull_for_chain_by_together_model_test ()
{
	ifstream in ( "D:/Agony/Store/Model_store/Model_c30_2/cross_sum/list") ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << "left.matrix"<< endl;
		exit (1);
	}


	vector <string> PDB_chain_ID_list;
	string word;
	while( in >> word )
		PDB_chain_ID_list.push_back(word);

	Abu_Maimonides_Rambam mr ( "Model_c30_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.plain_solution("together");

	for (int ii=0; ii<PDB_chain_ID_list.size();ii++)
		mr.correlation_pull_for_chain_by_together_model(PDB_chain_ID_list[ii]);

}




void Abu_Maimonides_Rambam_test::
show_all_plain_solution_test ()

{
	Abu_Maimonides_Rambam mr ( "Model_Fr1", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.show_all_plain_solution ();
}

void Abu_Maimonides_Rambam_test::
show_all_solution_and_prediction_test()
{
	Abu_Maimonides_Rambam mr ( "StartModel", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.show_all_solution_and_prediction ();

	log_stream <<  " show_all_solution_and_prediction_test()" << endl;
}

void Abu_Maimonides_Rambam_test::
prepare_discriminant_data_test()
{
	Abu_Maimonides_Rambam mr ( "freq_x5_6_fast_4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.prepare_discriminant_data();
}

void Abu_Maimonides_Rambam_test::
prepare_correction_matrix_test()
{
	Abu_Maimonides_Rambam mr ( "freq_x5_6_fast_4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.prepare_correction_matrix();

}

void Abu_Maimonides_Rambam_test::
handle_correction_matrix_test()
{
	string path_to_martix_store = string ("D:/Model_store/freq_x5_6_fast_4/plain_results/");

	string path_to_martix_X  = path_to_martix_store + string ("X.matrix");
	string path_to_martix_Y  = path_to_martix_store + string ("Y.matrix");

	string path_to_martix_Yt_Y  = path_to_martix_store + string ("Yt_Y.matrix");


/home/milch/projects/Didona/Store/Model_store/test_new_approach_1/plain_results/FIN_100/./ttt.srt.csv
//	vector < vector  < double > >	martix_X = get_matrix_from_txt_file ( path_to_martix_X ) ;
	vector < vector  < double > >	martix_Y = get_matrix_from_txt_file ( in_stream ) ;

	vector < vector  < double > >	martix_Y_copy =  martix_Y;

	vector < vector < double > > martix_Yt_Y = transpose_matr_mlt_matr (martix_Y_copy,martix_Y );

	ofstream res_stream ( path_to_martix_Yt_Y.c_str() ) ;
	if ( ! res_stream )	{
		cout       << "Can't create file  " << path_to_martix_Yt_Y << endl;
		exit (1);
	}

	print_rectangular_matrix (
		string ("******** Matrix_Yt_Y **********"),res_stream ,martix_Yt_Y);
}
void Abu_Maimonides_Rambam_test::
make_predicted_distance_binary_files_test ()
{

	Abu_Maimonides_Rambam mr ( "StartModel", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.make_predicted_distance_binary_files();

}
void Abu_Maimonides_Rambam_test::
init_wu_blast_test ()
{
	Abu_Maimonides_Rambam mr ( "freq_x5_6_fast_4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.init_wu_blast ();

}
*/
