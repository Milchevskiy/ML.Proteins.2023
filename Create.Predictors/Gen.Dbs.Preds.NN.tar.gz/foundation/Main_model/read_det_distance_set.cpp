#include <vector>
#include <string>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <cstring>


using namespace std;

extern ofstream log_stream;

vector < vector < double > > read_det_distance_set (const string & current_distance_file_name)
{

	ifstream in( current_distance_file_name.c_str() ,ios::binary);
	if ( ! in )
	{
		log_stream << "read_det_distance_set	(): ERROR -  can't read " << current_distance_file_name  << endl;
		cout       << "read_det_distance_set	(): ERROR -  can't read " << current_distance_file_name  << endl;

		exit (1);
	}

	int number_of_cases ;
	int diva_number_of_variables ;

	in.read ( (char* ) & number_of_cases ,	sizeof (int)  );
	in.read ( (char* ) & diva_number_of_variables,	sizeof (int)  );
	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));

	vector < vector < double > > distance_set;
	distance_set.resize (number_of_cases) ;
	for (int jj=0; jj< number_of_cases ;jj++)
		distance_set[jj].resize (diva_number_of_variables );

        double 		tttt = distance_set[0][0];

	for (int ii=0; ii< diva_number_of_variables ;ii++)
	{
		in.read ( (char* )	t_arr,		number_of_cases * sizeof(double));
//		memset (				t_arr	,0,	number_of_cases * sizeof(double));
		for (int jj=0; jj< number_of_cases ;jj++)
			 distance_set [jj][ii] = t_arr [jj] ;
	}
	delete [] t_arr	;

	in.close();

	return distance_set;
}

vector < vector < double > > read_det_distance_set_DIR (const string & current_distance_file_name)
{

	vector < vector < double > > distance_set = read_det_distance_set (current_distance_file_name);

	int waited_cluster_number = distance_set [0].size()/2;

	int seq_len = distance_set.size();
	vector < vector < double > > distance_set_DIR; distance_set_DIR.resize(seq_len );

	for (unsigned ii=0; ii<seq_len ;ii++ )
	{
		distance_set_DIR[ii].resize(waited_cluster_number);
		for (unsigned kk=0;kk<waited_cluster_number;kk++)
		{
			distance_set_DIR[ii][kk] = distance_set[ii][kk];
		}

	}
	return distance_set_DIR;
}




vector < vector < double > > read_det_distance_set_SECOND_PART (const string & current_distance_file_name)
{

	vector < vector < double > > distance_set = read_det_distance_set (current_distance_file_name);

	int waited_cluster_number = distance_set [0].size()/2;

	int seq_len = distance_set.size();
	vector < vector < double > > distance_set_DIR; distance_set_DIR.resize(seq_len );

	for (unsigned ii=0; ii<seq_len ;ii++ )
	{
		distance_set_DIR[ii].resize(waited_cluster_number);
		for (unsigned kk=0;kk<waited_cluster_number;kk++)
		{
			distance_set_DIR[ii][kk] = - distance_set[ii][kk + waited_cluster_number];
		}

	}
	return distance_set_DIR;
}




vector < vector < double > > read_det_distance_set (
	const string & PDB_chain_ID ,
	const string & path_to_current_model_store,  // ��� located files
	const string & extension)
{
	/*
	string current_distcance_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		PDB_chain_ID +
		extension;

	*/

	string current_distcance_file_name =
		path_to_current_model_store	+
		"/cross_sum/"			+
		PDB_chain_ID +
		extension;


	ifstream in( current_distcance_file_name.c_str() ,ios::binary);
	if ( ! in )
	{
		log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distcance_file_name  << endl;
		cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distcance_file_name  << endl;

		exit (1);
	}

	int number_of_cases ;
	int diva_number_of_variables ;

	in.read ( (char* ) & number_of_cases ,	sizeof (int)  );
	in.read ( (char* ) & diva_number_of_variables,	sizeof (int)  );
	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));

	vector < vector < double > > distance_set;
	distance_set.resize (number_of_cases) ;
	for (int jj=0; jj< number_of_cases ;jj++)
		distance_set[jj].resize (diva_number_of_variables );

	for (int ii=0; ii< diva_number_of_variables ;ii++)
	{
		in.read ( (char* )	t_arr,		number_of_cases * sizeof(double));
		for (int jj=0; jj< number_of_cases ;jj++)
			 distance_set [jj][ii] = t_arr [jj] ;
	}
	delete [] t_arr	;

	in.close();

	return distance_set;
}
