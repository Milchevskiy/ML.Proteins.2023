#ifndef MORDEHAY_TEST_TEST
#define MORDEHAY_TEST_TEST

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Mordehay_test: public Simple_test
{
public:
	~Mordehay_test();

    void run() 
    { 
//** ultimate block 
//		test1 ();  // filling up tips
//		plain_solution_test();
//		analyse_prediction_learning_set_test(); 
//***
		structure_homology_search_test ();
//		find_error();
	}
	void test1 ();
	void plain_solution_test();
	void analyse_prediction_learning_set_test(); 
	void structure_homology_search_test ();
	void find_error();
};

#endif
