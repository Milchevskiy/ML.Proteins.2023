#include <string>
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

extern ofstream log_stream;

void fill_assignment_8 (
    const string & curr_seq_dssp_pb_file,
    string & sequence,
    string & sequence_by_dssp,
    string & dssp_short,
    vector <double> &assignment_8)
{
    ifstream  in( curr_seq_dssp_pb_file.c_str() );
    if (!in)
    {
        log_stream  <<  "ERROR -  can't open " << curr_seq_dssp_pb_file << endl;
        cout        <<  "ERROR -  can't open " << curr_seq_dssp_pb_file << endl;
        exit(1);
    }
/*
MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQAPILSRVGDGTQDNLSGAEKAVQVKVKALPDAQFEVVHSLAKWKRQTLGQHDFSAGEGLYTHMKALRPDEDRLSPLHSVYVDQWDWERVMGDGERQFSTLKSTVEAIWAGIKATEAAVSEEFGLAPFLPDQIHFVHSQELLSRYPDLDAKGRERAIAKDLGAVFLVGIGGKLSDGHRHDVRAPDYDDWSTPSELGHAGLNGDILVWNPVLEDAFELSSMGIRVDADTLKHQLALTGDEDRLELEWHQALLRGEMPQTIGGGIGQSRLTMLLLQLPHIGQVQAGVWPAAVRESVPSLL
???-HHHHHHHHHHHHHHHHHHHHHHH-EEE-0P0SEEETTSS-S--TTTT----EE--SSSTT--EEE-S--TTHHHHHHHHTT--TT-EEEEEEEEE-TT-S---SS--SEEEEEEEEEE--TT--SHHHHHHHHHHHHHHHHHHHHHHHHHS-0P0-S-SS-EEEEHHHHHHHSSSS-HHHHHHHHHHHHSEEEEE--SS--SSS--SS---TTTB--SSB0TTSSB-SEEEEEEEETTTTEEEEEEEEEEB--HHHHHHHHHHHT-TTGGGSHHHHHHHTT-S--EEEEEEEHHHHHHHHHT-S-GGGTS-----HHHHHH--S--
--BCMMMMMMMMMMMMMMMMMMMMMNOPACBFDCFBACMHIOKBGDEBHKLLBLADDDDBIGPIACCCBFBGPMMMMMMMMMMIPCEHIACDDEBCDDDFBLGBGPFKLAFBACDFBCDDDDDEJIGCGKLMMMMMMMMMMMMMMMMMMMMMMNOPADFBAEBACDDDEKLMMMMNMKIKMKOMMMMMMMMNOMLMDFBDBBACEKOPACBPPEEKMIAFBAAPFKOPAPGBACADCDDFHLMMMMMCBCCDECDDFKLMMMMMMMNOPGMMMLLGKMMMMMNOPBGEBACDEBDFKMMMMMMNOPFBGKMMMGBAAFFKMMMMIGPB--
--***LMMMMMMMMMMMMMMMMMMMNOPAEDEDDFBACEHIGPBGCEBGKAGCEDCDDFKNGKIACDEDFBGPKMMMMMMMMNOPDEJIACDDFBCDDDFBGGBGPFJIAFKACDFDDDDDDDEJLGBGKLMMMMMMMMMMMMMMMMMMMMMMNOPADFBAFBADDDEFKLMMMMNGKIGFKLMMMMMMMMNGPACDEBGBIACFJOPAEBPPEEKLIGFBBGCFKOPAPGBACEDDEDFKNOPAADFBGDDEBDDFKLMMMMMMMNOPGBLMMMGKLMMMMNOPBGEBADDDDDFKLMMMMMNOPABGKLMIGBACEFKLMMMIGBG--
*/
    in >> sequence_by_dssp;
    in >> dssp_short;

    in.close();

    if (sequence != sequence_by_dssp)
    {
        log_stream  <<  curr_seq_dssp_pb_file << ": sequence by dssp does not coincide to sequence by my PDB chain" << endl;
        cout        <<  curr_seq_dssp_pb_file << ": sequence by dssp does not coincide to sequence by my PDB chain" << endl;
    //    cout << "sequence " << sequence << endl;
     //   cout << "by dssp  " << sequence_by_dssp << endl;

        log_stream    << "sequence " << sequence << endl;
        log_stream    << "by dssp  " << sequence_by_dssp << endl;


       // exit (-1);
    }

    int length = sequence.size();
    assignment_8.resize(length);

    for (int i=0;i<dssp_short.size();i++)
    {
        if (dssp_short[i] =='-')
            assignment_8[i]=7.0;
        else if( dssp_short[i] =='?')
             assignment_8[i]=-1.0;
        else if( dssp_short[i]=='H')
            assignment_8[i] = 0.0;
        else if( dssp_short[i]=='G')
            assignment_8[i] = 1.0;
        else if( dssp_short[i]=='I')
            assignment_8[i] = 2.0;
        else if( dssp_short[i]=='T')
            assignment_8[i] = 3.0;
        else if( dssp_short[i]=='S')
            assignment_8[i] = 4.0;
        else if( dssp_short[i]=='E')
            assignment_8[i] = 5.0;
        else if( dssp_short[i]=='B')
            assignment_8[i] = 6.0;
        else
            assignment_8[i] = 7.0;
    }
}


void conv_to_vector (vector < double >  & assignment_8,  vector <  vector < double >  >  & assignment_vector_8)
{
    int length =assignment_8.size();
    assignment_vector_8.resize(length);

    for (int ii=0;ii<length;ii++)
    {
        assignment_vector_8[ii].resize(8);
        //fill(assignment_vector_8.begin(), assignment_vector_8.end(), 0);
        assignment_vector_8[ii].assign (8,0.0);
    }

    for (int k=0;k<length;k++)
    {
        int index = ( (int) assignment_8[k] );
        if (index==-1)
        {
            for (int jj=0;jj<8;jj++)
                assignment_vector_8[k][jj] = -1;
        }
        else
            assignment_vector_8[k][index] = 1;
    }

}
