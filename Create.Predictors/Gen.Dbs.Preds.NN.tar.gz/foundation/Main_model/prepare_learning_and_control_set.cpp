#include <iostream>
#include <cassert>

#include "../CommonFunc.h"


#include <fstream>


void  prepare_learning_and_control_set (
                int subset_number,
                int subset_ID,
                vector < string > PDB_chain_ID_list,
                string path_to_accepted_chain_list_file )
{



    ostringstream ost_ls;
    ost_ls << path_to_accepted_chain_list_file  <<  "_" << subset_number <<  "_" <<  subset_ID << ".ls";
    string ls_name = ost_ls.str() ;

    ostringstream ost_control;
    ost_control << path_to_accepted_chain_list_file  <<  "_" << subset_number <<  "_" <<  subset_ID << ".control";
    string control_name = ost_control.str() ;


  	ofstream ls_out ( ls_name.c_str()) ;
	if ( ! ls_out )	{
		cout       << "Can't create " << ls_name << endl;
		exit (1);
	}

	ofstream control_out ( control_name.c_str()) ;
	if ( ! control_out )	{
//		exit (1);
	}



	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
        int test = (ii%subset_number);
        cout << "test = " << test << " " << ii << endl;
        if (test == subset_ID)
	{
            control_out << PDB_chain_ID_list[ii] << endl;
	    cout << ii <<    "  " << "control " << endl;
	}
        else
            ls_out << PDB_chain_ID_list[ii] << endl;
	}


}
