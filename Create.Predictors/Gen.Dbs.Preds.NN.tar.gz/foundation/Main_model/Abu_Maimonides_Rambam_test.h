#ifndef ABU_MAIMONIDES_RAMBAM_TEST_H
#define ABU_MAIMONIDES_RAMBAM_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>
#include <iostream>
#include <vector>



using namespace std;

class  Abu_Maimonides_Rambam_test: public Simple_test
{
public:
	~Abu_Maimonides_Rambam_test();

	void run()
	{

        protocol_test();
        plain_solution_test ();

	}
	void check_predicted_binary_files();

    void handle_ready_prediction_from_file ();
	void prepare_learning_and_control_set_test();  ///  приготовит данные для learning sampe & control

	void prepare_predicted_binary_files_next_layer ();

    void make_next_layer_prediction_test();
    void check_charming_Reg_solution_test();
	void next_layer_prepare_cross_sum_test();

    void dist_data_predicted_file_test();
	void quality_assesment_for_prediction_set_test();

	void reduce_predictor_set_test();

	void compose_predctor_set_by_previous_plain_results ();

	void PB_observed_assignment_test();
	void check_cluster_property_test();
	void intack_test_for_prediction_by_sequence ();
	void remove_large_chain();
	void prepare_obesrved_binary_files ();
	void prepare_predicted_binary_files ();  //
	void analyse_ready_prediction_set();
	void prediction_by_sequence_test();
	void prepare_predicted_binary_files_for_external_sequnces();

	void handle_mutual_distance_test();

    void analyse_single_prediction_by_existing_model_test( string &short_name);

	void make_prediction_by_external_PDB_test ();

	void correlation_pull_for_chain_by_together_model_test ();
	void prepare_united_su_avsumx_d_test ();
	void plain_solution_test ();
	void protocol_test();

/// prepare data for AI
	void prepare_data_for_AI_test();
	void prepare_single_again_data_for_AI_test();

	void prepare_data_for_AI_handle_raw_data_test();
    void prepare_train_test_validation_PDB_ID_list();
    void collect_ready_data();
    void dummy_insert_tab();

    void data_for_AI_prediction_by_sequence_test();


	void show_all_plain_solution_test ();
	void show_all_solution_and_prediction_test();
	void prepare_discriminant_data_test();
	void prepare_correction_matrix_test();
	void handle_correction_matrix_test();
	void make_predicted_distance_binary_files_test ();
	void init_wu_blast_test ();
	void analyse_single_prediction_by_existing_model_exotic_dep_val_test();

	void prepare_observed_binary_files_for_external_sequnces();

	void check_single_prediction_by_existing_model_test();

    void CONTROL_prepare_obesrved_binary_files();
    void CONTROL_prepare_predicted_binary_files();
    void CONTROL_analyse_single_prediction_by_existing_model_test();
    void CONTROL_DIRECT_analyse_single_prediction_by_existing_model_test();


    void prepare_das_data_test();

    void check_predicted_binary_file_read_write ();

    void prepare_obesrved_binary_files_control();                  ;
    void prepare_predicted_binary_files_control();
    void analyse_single_prediction_by_existing_model_test_control();

    void confusion_matrix_left_and_right_test();


    void prepare_data_for_AI_for_prediction_by_sequences_set_test();
    void prepare_sophisticated_AI_data_set_based_on_first_stage_predicrion_by_fulle_sequence_test();



    void prepare_triple_data_for_AI_test(string &data_set_name);

    void prepare_regression_data_for_significant_var_selection_test (string &data_set_name);

    void prepare_triple_data_for_AI_SS_8_test();
    void prepare_triple_data_for_AI_SS_8_for_classify_test();

    void prepare_triple_data_for_AI_by_sequence_test();
    void show_only_together_protocol_test();

    void handle_united_significant_predictors();
    void  remove_correkated_predictors();

    void prepare_predicted_binary_files                     (string & short_name);
    void prepare_data_by_didona_PB_prediction_test          (string & short_name);
    void prepare_data_by_didona_PB_prediction_wide_test     (string & short_name);

    void prepare_DAS_selected_data_for_AI_test              (string & data_set_name);


    void make_predictor_file_set_by_sequence_test ();
 //   prepare_DAS_selected_data_for_AI


};

#endif
