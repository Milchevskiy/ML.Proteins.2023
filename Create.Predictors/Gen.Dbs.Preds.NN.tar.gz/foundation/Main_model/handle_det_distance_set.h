#ifndef HANDLE_DET_DISTANCE_SET_H
#define HANDLE_DET_DISTANCE_SET_H



#include <string>
#include <vector>

using namespace std;

vector < vector < double > > read_det_distance_set (const string & current_distance_file_name);

vector < vector < double > > read_det_distance_set_DIR (const string & current_distance_file_name);
vector < vector < double > > read_det_distance_set_INV (const string & current_distance_file_name);

vector < vector < double > > read_det_distance_set_SECOND_PART (const string & current_distance_file_name);

// ������� � �������� ������������
vector < vector < double > > read_det_distance_set (
	string & PDB_chain_ID ,
	string & path_to_current_model_store,  // ��� located files
	string & extension);




#endif
