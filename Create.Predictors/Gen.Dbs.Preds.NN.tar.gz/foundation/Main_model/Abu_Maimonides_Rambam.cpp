#pragma warning( disable : 4786 )
#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "Abu_Maimonides_Rambam.h"

#include "../Sheduler.h"
#include "../Fragment_base/Chain_binary.h"
#include "../CowardVariables/CowardVariables.h"
//#include "../CowardVariables/FrequencyVariables.h"
#include "../CowardVariables/Distance_to_claster_variables.h"
#include "../Censorship.h"
#include "../CommonFunc.h"
#include "../Statistical_utilits/Statistic_general_purpose.h"
#include "../Statistical_utilits/charming_Reg_solution.h"
#include "../Statistical_utilits/calculate_correlation_pull.h"
#include "single_prediction_for_any_known_regression_model.h"  // ???????????
#include "../Pair_int_double.h"

#include "../Fragment_base/accepted_chain_data.h"

#include "../Statistical_utilits/calc_dispersion_and_average.h"
#include "../Statistical_utilits/standardize_to_known_gauss.h"
/*
#include "standardize_first_to_second.h"

#include "get_probability_by_Z_value.h"
*/

#include "../Chain_store/Chain_Residue_Set.h"

#include <cassert>
#include <iostream>

//#define EPSILON_FLOAT  0.0001

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;


Abu_Maimonides_Rambam::Abu_Maimonides_Rambam():
	sheduler_(0),
	regression_options_    (0),
//	structure_assignment_(0),
//	structure_assignment_option_(),
	cowa_creator_(0),
	mss_(0),
	data_set_(0)
{

};

Abu_Maimonides_Rambam::~Abu_Maimonides_Rambam()
{
	if (sheduler_)				delete sheduler_;
	if (regression_options_)	delete regression_options_;
	if (cowa_creator_)			delete cowa_creator_;
	if (mss_)					delete mss_;
	if (data_set_)				delete [] data_set_;
}

Abu_Maimonides_Rambam::
	Abu_Maimonides_Rambam(
		const string & name,
		const Abu_Maimonides_Rambam_operating_modes run_mode  )
{
	init( name, run_mode  );
}



void Abu_Maimonides_Rambam::
	init(
		const string & name,
		const Abu_Maimonides_Rambam_operating_modes run_mode  )
{
	sheduler_			=0;
	regression_options_	=0;
	cowa_creator_		=0;
	//frva_creator_		=0;
	dicl_creator_		=0;
	mss_				=0;

	avsumx_	=0;
	su_		=0;

///        log_stream << "init() int Abu_Maimonides_Rambam " << endl;

	name_			= name;
	string path_current = configuration.option_meaning("Path_to_Model_store") + name_ + string("/") + string("sheduler");
	sheduler_		= new Sheduler     (path_current) ;


//************* INIT Distance_to_claster_variables *******************
	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("CLUSTER_FUNCTION_TASK_FILE");

	//	log_stream << "Before dicl_creator_ = new	 Distance_to_claster_variables ( 	name_) int Abu_Maimonides_Rambam " << endl;

	dicl_creator_ = new	 Distance_to_claster_variables ( 	name_);

    //    log_stream << "After dicl_creator_ = new	 Distance_to_claster_variables ( 	name_) int Abu_Maimonides_Rambam " << endl;

	number_of_clasters_ = dicl_creator_->number_of_clasters ();

	//int  fragment_length () const  { 	return fragment_length_ ; }

//************* INIT CowardVariables    **********************************
	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("COWARD_VARIABLES_TASK_FILE");
	cowa_creator_ = new CowardVariables     (path_to_cowardvariables_task_file) ;
//	cowa_creator_ = new CowardVariables     (path_to_cowardvariables_task_file) ;

    //    log_stream << "After cowa_creator_ = new CowardVariables     (path_to_cowardvariables_task_file) ;" << endl;
//***********************************************************************


//************* INIT Frequency_extrapolation   **********************************
	//string path_to_frequency_extrapolation_task_file =
	//	configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
	//	sheduler_->option_meaning ("FREQUENCY_EXTRAPOLATION_TASK_FILE");

	//frva_creator_ = new FrequencyVariables (path_to_frequency_extrapolation_task_file ) ;
//***********************************************************************

	//string binary_file_name ("accepted_chain_list.bin");

	string binary_file_name = sheduler_->option_meaning("CHAIN_LIST");
	if (binary_file_name == "UNKNOWN")
		binary_file_name = string ("accepted_chain_list");




/// Prohibit binary
//	fill_up_accepted_chain_data (
//		accepted_chain_ID_list_,
//		accepted_chain_lenth_,
//		binary_file_name );

     //   log_stream << "before cowa_creator_ = new CowardVariables     (path_to_cowardvariables_task_file) ;;" << endl;

	fill_up_accepted_chain_data_text (
		accepted_chain_ID_list_,
		binary_file_name );


 //   string CONTROL_binary_file_name = new_extension_file_name(binary_file_name,"control");
  //  string CONTROL_binary_file_name = binary_file_name;

  // 	fill_up_accepted_chain_data_text (
	//	CONTROL_accepted_chain_ID_list_,
	//	CONTROL_binary_file_name );


      //      log_stream << "after cowa_creator_ = new CowardVariables     (path_to_cowardvariables_task_file) ;;" << endl;
		// ************************* FIX ***** ONLY ONE TIME
//		accepted_chain_ID_list_.resize(1360);


//************* INIT regression_options_ **********************************
	string path_to_regression_options_file_ =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("REGRESSION_OPTIONS_FILE");

	regression_options_ = new Sheduler	( path_to_regression_options_file_ );
//***********************************************************************

//************* INIT LEARNING_THIN_OUT_SHIFT **********************************
	string learning_thin_out_shift_string =
		configuration.option_meaning("Path_to_Model_store") + name_ + string("/") +
		sheduler_->option_meaning("LEARNING_THIN_OUT_SHIFT");

	learning_thin_out_shift_ = atof(  learning_thin_out_shift_string.c_str() );
//***********************************************************************

	record_size_ =
		cowa_creator_->get_number_of_variables() +
		//frva_creator_->get_number_of_variables() +
		dicl_creator_ ->get_number_of_variables() ;


	data_set_ = new double[record_size_];


	upper_triange_matrix_size_ = record_size_ *(record_size_ +1)/2;
	avsumx_		= new double [record_size_ ]; 	memset (avsumx_	,0,record_size_   *sizeof(double));
	su_			= new double [upper_triange_matrix_size_  ]; 	memset (su_		,0,upper_triange_matrix_size_  *sizeof(double));

	shift_ = dicl_creator_->get_shift ();

	switch ( run_mode  )
	{
		case COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES:
			init_storage ();
			break;
		case FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES:
			make_cross_sum_binary_files();
			prepare_united_su_avsumx_d ();
			break;
		// creates cross sum matrix for whole learning sample. As opposed to previous option
		// does not savr binary files containig cross sum matrix for each chain and does not
		// save observed distance to cluster set. (former files *.dist_data )
		case fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES:
			fast_make_cross_sum_binary_together_files();
			//fast_prepare_united_su_avsumx_d();
			break;
		default :
			log_stream	<< "Inadmissible run mode for Maimonides_Rambam class" << endl;
			cout		<< "Inadmissible run mode for Maimonides_Rambam class" << endl;
			exit (-1);
	}
}
void Abu_Maimonides_Rambam::
prepare_das_data()  /// An input data file is created for discriminant analysis.
{
	string das_data_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/cross_sum/" +
		string("das_data") +
		".txt";

	//ofstream regdata_stream(das_data_file_name.c_str(), ios::binary);
	ofstream regdata_stream(das_data_file_name.c_str());
	if (!regdata_stream)
	{
		log_stream  <<  "das_data.txt: ERROR -  can't create " << das_data_file_name << endl;
		cout        <<  "das_data.txt: ERROR -  can't create " << das_data_file_name << endl;
		exit(1);
	}
    /// the first empty string for futher insertion of:  class number ; point number ; variables number
	regdata_stream << "                                                                                               " << endl;

	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	memset(avsumx_, 0, record_size_   *sizeof(double));
	memset(su_, 0, upper_triange_matrix_size_  *sizeof(double));

	int total_number_of_cases = 0;

	for (int kk = 0; kk < accepted_chain_ID_list_.size(); kk++)
	//for (int kk = 0; kk < 1000; kk++)
 	{
        string current_chain_ID = accepted_chain_ID_list_[kk];
		Chain_binary *chain = new Chain_binary(accepted_chain_ID_list_[kk]);
		string sequence = chain->get_sequence();

	//	cowa_creator_->process_chain(sequence);
	//	vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();



		vector < vector < double > >    predicted_distance_variables = read_det_distance_set (
                                                                                accepted_chain_ID_list_[kk],
                                                                                ".dist_data_predicted");
		vector < vector < double > >    observed_distance_variables = read_det_distance_set (
                                                                                accepted_chain_ID_list_[kk],
                                                                                ".dist_data");
        vector < vector < double > >    buff_for_index_search = read_det_distance_set ( accepted_chain_ID_list_[kk],".dist_data");




        ///int nearest_index =				get_nearest_claster_index(			det_distance_set[kk]);

        ///*********

/*

        if (kk==0)
        {
            int test1= sophisticated_distance_variables.size();
            int test2= predicted_distance_variables.size();
            int test3= observed_distance_variables.size();
            assert (test1==test2);
            assert (test1==test3);

            for (int zzz=0;zzz<test1;zzz++)
            {
                buff_for_index_search[zzz].resize(number_of_clasters_);

                int nearest_index = 	get_nearest_claster_index(		buff_for_index_search[zzz]);

                PutVa(nearest_index,log_stream,5,0,'l');



                PutVaDouble(sophisticated_distance_variables[zzz][16],log_stream,8,5,'l');
                PutVaDouble(observed_distance_variables[zzz][16],log_stream,8,5,'l');
                log_stream <<"aaaa\t";
                PutVaDouble(predicted_distance_variables[zzz][16],log_stream,8,5,'l');
                log_stream <<endl;
            }
        }

*/
        ///*********



		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;
		for ( int ii = 0; ii< current_number_of_cases; ii++)
		{
			if (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                double ttt = sophisticated_distance_variables[ii][0];
                true_coord_current_number --;
 				continue;
            }

            buff_for_index_search[ii].resize(number_of_clasters_);

            int nearest_index = 	get_nearest_claster_index(		buff_for_index_search[ii]);

            PutVa(nearest_index,regdata_stream,5,0,'l');

/*
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
	            PutVaDouble(sophisticated_variables[ii + shift][jj],regdata_stream,10,5,'l');
	            regdata_stream << "\t";
            }
*/
			//	data_set_[jj] = sophisticated_variables[ii + shift][jj];

			for (int jj = 0; jj< number_of_dicl_variables; jj++)
			{
				PutVaDouble( 10*predicted_distance_variables[ii][jj],regdata_stream,12,8,'l');
				regdata_stream << "\t";
            }

 			for (int jj = 0; jj< number_of_dicl_variables; jj++)
 			{
				PutVaDouble( 100*predicted_distance_variables[ii][jj]*
				            fabs(predicted_distance_variables[ii][jj]),regdata_stream,12,8,'l');
                regdata_stream << "\t";
            }

 			for (int jj = 0; jj< number_of_dicl_variables; jj++)
 			{
				PutVaDouble( 1000 * predicted_distance_variables[ii][jj]*
                                    predicted_distance_variables[ii][jj]*
                                    predicted_distance_variables[ii][jj],regdata_stream,12,8,'l');
                regdata_stream << "\t";
            }

			   // data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

			regdata_stream << endl;

			    /// predicted_distance add to variables set
            /// // из sophisticated_distance_variables get class number

	/*		int supplement_mode = 1;
			supplement_cross_sum_matrix(
				record_size_,
				data_set_,
				avsumx_,
				su_,
				supplement_mode);*/

		}
		delete chain;

        total_number_of_cases += true_coord_current_number;
		cout << kk << "\t" << accepted_chain_ID_list_[kk] << "\t" << total_number_of_cases << endl;
	}

	//int das_var_num = number_of_cowa_variables  + 3 * number_of_dicl_variables;
	int das_var_num =  3 * number_of_dicl_variables;


    regdata_stream.seekp(0,ios::beg);

    regdata_stream << number_of_clasters_ << " " << total_number_of_cases <<" " << das_var_num ;


/*	write_su_avsumx_d_for_regression(
		regdata_stream,
		total_number_of_cases);*/

}
void Abu_Maimonides_Rambam::
make_cross_sum_binary_files_next_layer()
{
    int number_of_cowa_variables = 6*number_of_clasters_;
    int number_of_dicl_variables = 2*number_of_clasters_;

    int record_size = number_of_cowa_variables + number_of_dicl_variables;
    int upper_triange_matrix_size_ = record_size *(record_size +1)/2;

   	double * data_set_ = new double[record_size];

    double *avsumx		= new double [record_size ]; 	memset (avsumx	,0,record_size   *sizeof(double));
	double *su			= new double [upper_triange_matrix_size_  ]; 	memset (su		,0,upper_triange_matrix_size_  *sizeof(double));

    int total_number_of_cases=0;

          string current_cross_data_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/cross_sum/" +
		string("together_next_layer") +
		".data";

	ofstream o_data(current_cross_data_name.c_str(), ios::binary);
	if (!o_data)
	{
		log_stream << "current_cross_data_name (): ERROR -  can't create " << current_cross_data_name << endl;
		cout << "current_cross_data_name (): ERROR -  can't create " << current_cross_data_name << endl;
		exit(1);
	}



	for (int kk = 0; kk < accepted_chain_ID_list_.size(); kk++)
	//for (int kk = 0; kk < 2; kk++)
 	{

        vector < vector < double > >    pdv = read_det_distance_set (accepted_chain_ID_list_[kk],".dist_data_predicted");
        vector < vector < double > >    odv = read_det_distance_set (accepted_chain_ID_list_[kk],".dist_data");

        int current_number_of_cases = odv.size();
        int true_coord_current_number = current_number_of_cases;

        int pdv_size = pdv.size();
        int odv_size = odv.size();

        assert( pdv_size == odv_size );


        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{
			if (fabs(odv[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                true_coord_current_number --;
 				continue;
            }

            int counter = 0;
			for (int jj = 0; jj< 2*number_of_clasters_; jj++)
			{
				data_set_[counter] = pdv[ii][jj];
				counter++;
            }

    		for (int jj = 0; jj< 2*number_of_clasters_; jj++)
			{
				data_set_[counter] = pdv[ii][jj]*fabs(pdv[ii][jj]);
				counter++;
            }

       		for (int jj = 0; jj< 2*number_of_clasters_; jj++)
			{
				data_set_[counter] = pdv[ii][jj]*pdv[ii][jj]*pdv[ii][jj];
                counter++;
            }

            for (int jj = 0; jj< 2*number_of_clasters_; jj++)
            {
                data_set_[counter] = odv[ii][jj];
                counter++;
            }

			int supplement_mode = 1;
			supplement_cross_sum_matrix(
				record_size,
				data_set_,
				avsumx,
				su,
				supplement_mode);

			 for (int zz=0;zz<counter;zz++)
			 {
                PutVaDouble(data_set_[zz],o_data,12,6,'l'); o_data << " ";
                if(zz%32==0)
                    o_data << endl;

              } o_data << endl<< endl;
        }





        total_number_of_cases += true_coord_current_number;
		cout << kk << "\t" << accepted_chain_ID_list_[kk] << endl;
 	}

    string current_cross_sum_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/cross_sum/" +
		string("together_next_layer") +
		".cross_sum";


	ofstream regdata_stream(current_cross_sum_file_name.c_str(), ios::binary);
	if (!regdata_stream)
	{
		log_stream << "prepare_united_su_avsumxd (): ERROR -  can't create " << current_cross_sum_file_name << endl;
		cout << "prepare_united_su_avsumxd (): ERROR -  can't create " << current_cross_sum_file_name << endl;
		exit(1);
	}

/*	write_su_avsumxd_for_regression(
		regdata_stream,
		total_number_of_cases);
		*/

		int number_of_dependent	   = number_of_dicl_variables;

		int number_of_predictor    = number_of_cowa_variables;

		 write_su_avsumx_d_for_regression_ (
            regdata_stream,
            number_of_predictor,
            number_of_dependent,
            total_number_of_cases,
            avsumx,
            su	 );



}


void Abu_Maimonides_Rambam::
confusion_matrix_left_and_right(
    vector <string> & chain_ID_list,
    string & result_name)
{


  	string confusion_matrix_fina =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/plain_results/" + result_name +
		string(".confusion_matrix") ;



	ofstream out(confusion_matrix_fina.c_str(), ios::binary);
	if (!out)
	{
		log_stream <<   "protocol_prediction_assesment: ERROR -  can't create " << confusion_matrix_fina << endl;
		cout <<         "protocol_prediction_assesment: ERROR -  can't create " << confusion_matrix_fina << endl;
		exit(1);
	}

//	Abu_Maimonides_Rambam mr ( "PB_9", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//charming_Reg_solution  * current_crs = init_together_model ();
	int total_number_of_cases = 0;
    double total_left_quality = 0;
    double total_right_quality= 0;

    vector < double >  odv_left;  odv_left.   resize(number_of_clasters_);
    vector < double >  odv_right; odv_right.  resize(number_of_clasters_);

    vector < double >  pdv_left;  pdv_left.   resize(number_of_clasters_);
    vector < double >  pdv_right; pdv_right.  resize(number_of_clasters_);


    vector < vector <int > > left_quality_matrix ;
    left_quality_matrix.resize (number_of_clasters_) ;
    int kk;
    for ( kk=0;kk<number_of_clasters_;kk++)
        left_quality_matrix[kk].resize(number_of_clasters_);

    vector < vector <int > > right_quality_matrix ;
    right_quality_matrix.resize (number_of_clasters_) ;

    for ( kk=0;kk<number_of_clasters_;kk++)
        right_quality_matrix[kk].resize(number_of_clasters_);


    for (int zzz=0;zzz<number_of_clasters_;zzz++)
    {
            std::fill(left_quality_matrix[zzz].begin(), left_quality_matrix[zzz].end(), 0);
            std::fill(right_quality_matrix[zzz].begin(), right_quality_matrix[zzz].end(), 0);
    }

    double left_quality = 0;
    double right_quality = 0;


    int global_true_coord_current_number = 0;
    int global_current_number_of_cases = 0;

	for (int kk = 0; kk < chain_ID_list.size(); kk++)
 	{



		vector < vector < double > >    odv = read_det_distance_set (chain_ID_list[kk],".dist_data");

        vector < vector < double > >    pdv = read_det_distance_set (chain_ID_list[kk],".dist_data_predicted");

        int current_number_of_cases = odv.size();

        int true_coord_current_number = current_number_of_cases;
       	for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                pdv_left    [jj]   = pdv[ii][jj];
                pdv_right   [jj]  = -pdv[ii][jj+number_of_clasters_];
            }

            int index_pdv_left  = get_nearest_claster_index(	pdv_left    );
            int index_pdv_right = get_nearest_claster_index(	pdv_right   );


			if (fabs(odv[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                true_coord_current_number --;
     			continue;
            }
//vector < vector < double > >  odv_cp = odv;

            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                odv_left    [jj]   = odv[ii][jj];
                odv_right   [jj]  = -odv[ii][jj+number_of_clasters_];
            }

            int index_odv_left  = get_nearest_claster_index(	odv_left    );
            int index_odv_right = get_nearest_claster_index(	odv_right   );
            assert(index_odv_left==index_odv_right);

            left_quality_matrix [index_odv_left][index_pdv_left ] ++;
            if ( index_odv_left==index_pdv_left  )
                left_quality +=1;

            right_quality_matrix [index_odv_right][index_pdv_right ] ++;
            if ( index_odv_right==index_pdv_right  )
                right_quality +=1;

        }

        global_true_coord_current_number += true_coord_current_number;
        global_current_number_of_cases   += current_number_of_cases;


        cout << kk<< "\t" << chain_ID_list[kk]<< endl;

    }

    if (global_true_coord_current_number)
    {
        left_quality /= global_true_coord_current_number;
        right_quality/= global_true_coord_current_number;
    }
    else
    {
        left_quality =0;
        right_quality=0;
    }


      out << "*****************************" << endl;
		out << "left Quality predition matrix" << endl;
		for ( int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVa( 	left_quality_matrix[kkk][jjj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << global_true_coord_current_number << " of " << global_current_number_of_cases<< endl;
		out << "left Quality: " << left_quality << endl;


		out << "*****************************" << endl;
		out << "right Quality predition matrix" << endl;
		for (int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVa( 	right_quality_matrix[kkk][jjj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << global_true_coord_current_number << " of " << global_current_number_of_cases<< endl;
		out << "Right Quality: " << right_quality << endl;

/// class occurence
      vector <double> class_occurence_right;    class_occurence_right.resize(number_of_clasters_); class_occurence_right.assign(number_of_clasters_,0);
      vector <double> class_occurence_left;     class_occurence_left.resize(number_of_clasters_);  class_occurence_left.assign(number_of_clasters_,0);


      for ( int kkk=0;kkk<number_of_clasters_;kkk++)
      {
        for (int jjj=0;jjj<number_of_clasters_;jjj++)
        {
            class_occurence_right[kkk]  += right_quality_matrix[kkk][jjj];
            class_occurence_left[kkk]   += left_quality_matrix[kkk][jjj];
        }
        assert (class_occurence_right[kkk]==class_occurence_left[kkk]);

      }


        out << "!!!! percentage " << endl;
		out << "left Quality predition matrix" << endl;
		for ( int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVaDouble( 	100*left_quality_matrix[kkk][jjj]/class_occurence_left[kkk],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << global_true_coord_current_number << " of " << global_current_number_of_cases<< endl;
		out << "left Quality: " << left_quality << endl;


		out << "*****************************" << endl;
		out << "right Quality predition matrix" << endl;
		for (int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVaDouble( 	100*right_quality_matrix[kkk][jjj]/class_occurence_right[kkk],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << global_true_coord_current_number << " of " << global_current_number_of_cases<< endl;
		out << "Right Quality: " << right_quality << endl;






}

void Abu_Maimonides_Rambam::
quality_assesment_for_prediction_set(const string &mode_extension)
{
/*
".dist_data_predicted_next_layer"
".dist_data_predicted"
*/
    if ( mode_extension != ".dist_data_predicted_next_layer" &&  mode_extension != ".dist_data_predicted" )
    {
            log_stream << "possible extension for predicted binary file: .dist_data_predicted_next_layer  or .dist_data_predicted NOT" << mode_extension<< endl;
			cout       << "possible extension for predicted binary file: .dist_data_predicted_next_layer  or .dist_data_predicted NOT" << mode_extension<< endl;
			exit (1);
    }

   	string protocol_prediction_assesment =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/plain_results/" +
		string("protocol_prediction_assesment") +
		mode_extension;



	ofstream protocol_out(protocol_prediction_assesment.c_str(), ios::binary);
	if (!protocol_out)
	{
		log_stream <<   "protocol_prediction_assesment: ERROR -  can't create " << protocol_prediction_assesment << endl;
		cout <<         "protocol_prediction_assesment: ERROR -  can't create " << protocol_prediction_assesment << endl;
		exit(1);
	}

//	Abu_Maimonides_Rambam mr ( "PB_9", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = init_together_model ();


	int total_number_of_cases = 0;
    double total_left_quality = 0;
    double total_right_quality= 0;

    vector < double >  odv_left;  odv_left.   resize(number_of_clasters_);
    vector < double >  odv_right; odv_right.  resize(number_of_clasters_);

    vector < double >  pdv_left;  pdv_left.   resize(number_of_clasters_);
    vector < double >  pdv_right; pdv_right.  resize(number_of_clasters_);


    vector < vector <int > > left_quality_matrix ;
    left_quality_matrix.resize (number_of_clasters_) ;
    int kk;
    for ( kk=0;kk<number_of_clasters_;kk++)
        left_quality_matrix[kk].resize(number_of_clasters_);

    vector < vector <int > > right_quality_matrix ;
    right_quality_matrix.resize (number_of_clasters_) ;

    for ( kk=0;kk<number_of_clasters_;kk++)
        right_quality_matrix[kk].resize(number_of_clasters_);


	for (int kk = 0; kk < accepted_chain_ID_list_.size(); kk++)
	//for (int kk = 0; kk < 1000; kk++)
 	{
        string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			accepted_chain_ID_list_[kk] + string (".") + mode_extension + string (".compare_prediction") ;

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}


		for (int zzz=0;zzz<number_of_clasters_;zzz++)
		{
				std::fill(left_quality_matrix[zzz].begin(), left_quality_matrix[zzz].end(), 0);
				std::fill(right_quality_matrix[zzz].begin(), right_quality_matrix[zzz].end(), 0);
        }

        double left_quality = 0;
        double right_quality = 0;


        string current_chain_ID = accepted_chain_ID_list_[kk];
		Chain_binary *chain = new Chain_binary(accepted_chain_ID_list_[kk]);
		string sequence = chain->get_sequence();


		vector < vector < double > >    odv = read_det_distance_set (accepted_chain_ID_list_[kk],".dist_data");



	//		vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
	//			sequence,
	//			current_crs	);
      //  vector < vector < double > >    pdv = read_det_distance_set (accepted_chain_ID_list_[kk],".dist_data_predicted");
        vector < vector < double > >    pdv = read_det_distance_set (accepted_chain_ID_list_[kk],mode_extension);
       // vector <vector <double> > pdv = make_prediction_by_sequence (sequence,current_crs	);
        int  nu_ca_test = pdv.size();


        int current_number_of_cases = odv.size();

        out<< sequence[0] << endl;
        out<< sequence[1] << endl;

        int true_coord_current_number = current_number_of_cases;
		for ( int ii = 0; ii< current_number_of_cases; ii++)
		{



            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                pdv_left    [jj]   = pdv[ii][jj];
                pdv_right   [jj]  = -pdv[ii][jj+number_of_clasters_];
            }

            int index_pdv_left  = get_nearest_claster_index(	pdv_left    );
            int index_pdv_right = get_nearest_claster_index(	pdv_right   );

            out<< sequence[ii+shift_] << "\t";
            PutVa(index_pdv_left,out,5,0,'l');
            PutVa(index_pdv_right,out,5,0,'l');

			if (fabs(odv[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                true_coord_current_number --;
                PutVa("***",out,5,0,'l');
                PutVa("***",out,5,0,'l');
                out << endl;
     			continue;
            }
//vector < vector < double > >  odv_cp = odv;

            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                odv_left    [jj]   = odv[ii][jj];
                odv_right   [jj]  = -odv[ii][jj+number_of_clasters_];
            }

            int index_odv_left  = get_nearest_claster_index(	odv_left    );
            int index_odv_right = get_nearest_claster_index(	odv_right   );
            assert(index_odv_left==index_odv_right);

            PutVa(index_odv_left,out,5,0,'l');
            PutVa(index_odv_right,out,5,0,'l');
            out << endl;



            left_quality_matrix [index_odv_left][index_pdv_left ] ++;
            if ( index_odv_left==index_pdv_left  )
                left_quality +=1;

            right_quality_matrix [index_odv_right][index_pdv_right ] ++;
            if ( index_odv_right==index_pdv_right  )
                right_quality +=1;

        }
       // total_number_of_cases += true_coord_current_number   ;

        total_left_quality += left_quality;
        total_right_quality+= right_quality;

        if (true_coord_current_number)
        {
            left_quality /= true_coord_current_number;
            right_quality/= true_coord_current_number;
        }
        else
        {
            left_quality =0;
            right_quality=0;
        }


        out << "*****************************" << endl;
		out << "left Quality predition matrix" << endl;
		for ( int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVa( 	left_quality_matrix[kkk][jjj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << true_coord_current_number << " of " << current_number_of_cases<< endl;
		out << "left Quality: " << left_quality << endl;


		out << "*****************************" << endl;
		out << "right Quality predition matrix" << endl;
		for (int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVa( 	right_quality_matrix[kkk][jjj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << true_coord_current_number << " of " << current_number_of_cases<< endl;
		out << "Right Quality: " << right_quality << endl;

        cout << kk<< "\t" << accepted_chain_ID_list_[kk] << endl;


        protocol_out << accepted_chain_ID_list_[kk] << "\t";
        PutVa( left_quality,protocol_out,8,6,'l');  protocol_out << "\t";
        PutVa( right_quality,protocol_out,8,6,'l'); protocol_out << "\t";
        protocol_out << "Length: " << true_coord_current_number << " of " << current_number_of_cases<< endl;

        total_number_of_cases += true_coord_current_number   ;

        total_left_quality += left_quality;
        total_right_quality +=  right_quality;



    }

    protocol_out << "direct model quality : " ;PutVa( total_left_quality/total_number_of_cases,protocol_out,8,6,'l') ;protocol_out << endl;
    protocol_out << "invers model quality : " ;PutVa( total_right_quality/total_number_of_cases,protocol_out,8,6,'l') ;protocol_out << endl;

}

////************* CONTROL

void Abu_Maimonides_Rambam::
CONTROL_quality_assesment_for_prediction_set(const string &mode_extension)
{
/*
".dist_data_predicted_next_layer"
".dist_data_predicted"
*/
    if ( mode_extension != ".dist_data_predicted_next_layer" &&  mode_extension != ".dist_data_predicted" )
    {
            log_stream << "possible extension for predicted binary file: .dist_data_predicted_next_layer  or .dist_data_predicted NOT" << mode_extension<< endl;
			cout       << "possible extension for predicted binary file: .dist_data_predicted_next_layer  or .dist_data_predicted NOT" << mode_extension<< endl;
			exit (1);
    }

   	string protocol_prediction_assesment =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/plain_results/" +
		string("protocol_prediction_assesment_CONTROL") +
		mode_extension;



	ofstream protocol_out(protocol_prediction_assesment.c_str(), ios::binary);
	if (!protocol_out)
	{
		log_stream <<   "protocol_prediction_assesment: ERROR -  can't create " << protocol_prediction_assesment << endl;
		cout <<         "protocol_prediction_assesment: ERROR -  can't create " << protocol_prediction_assesment << endl;
		exit(1);
	}

//	Abu_Maimonides_Rambam mr ( "PB_9", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = init_together_model ();



	//***************************

    string binary_file_name = sheduler_->option_meaning("CHAIN_LIST");
	if (binary_file_name == "UNKNOWN")
		binary_file_name = string ("accepted_chain_list");

	string 	binary_file_name_CONTROL = new_extension_file_name(binary_file_name,"control");


    vector <string> accepted_chain_ID_list_CONTROL;

	fill_up_accepted_chain_data_text (
		//accepted_chain_ID_list_,
		accepted_chain_ID_list_CONTROL,
		binary_file_name_CONTROL );



	int total_number_of_cases = 0;
    double total_left_quality = 0;
    double total_right_quality= 0;

    vector < double >  odv_left;  odv_left.   resize(number_of_clasters_);
    vector < double >  odv_right; odv_right.  resize(number_of_clasters_);

    vector < double >  pdv_left;  pdv_left.   resize(number_of_clasters_);
    vector < double >  pdv_right; pdv_right.  resize(number_of_clasters_);


    vector < vector <int > > left_quality_matrix ;
    left_quality_matrix.resize (number_of_clasters_) ;
    int kk;
    for ( kk=0;kk<number_of_clasters_;kk++)
        left_quality_matrix[kk].resize(number_of_clasters_);

    vector < vector <int > > right_quality_matrix ;
    right_quality_matrix.resize (number_of_clasters_) ;

    for ( kk=0;kk<number_of_clasters_;kk++)
        right_quality_matrix[kk].resize(number_of_clasters_);


	for (int kk = 0; kk < accepted_chain_ID_list_CONTROL.size(); kk++)
	//for (int kk = 0; kk < 1000; kk++)
 	{
        string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			accepted_chain_ID_list_CONTROL[kk] + string (".") + mode_extension + string (".compare_prediction") ;

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}


		for (int zzz=0;zzz<number_of_clasters_;zzz++)
		{
				std::fill(left_quality_matrix[zzz].begin(), left_quality_matrix[zzz].end(), 0);
				std::fill(right_quality_matrix[zzz].begin(), right_quality_matrix[zzz].end(), 0);
        }

        double left_quality = 0;
        double right_quality = 0;


        string current_chain_ID = accepted_chain_ID_list_CONTROL[kk];
		Chain_binary *chain = new Chain_binary(accepted_chain_ID_list_CONTROL[kk]);
		string sequence = chain->get_sequence();


		vector < vector < double > >    odv = read_det_distance_set (accepted_chain_ID_list_CONTROL[kk],".dist_data");



	//		vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
	//			sequence,
	//			current_crs	);
      //  vector < vector < double > >    pdv = read_det_distance_set (accepted_chain_ID_list_CONTROL[kk],".dist_data_predicted");
        vector < vector < double > >    pdv = read_det_distance_set (accepted_chain_ID_list_CONTROL[kk],mode_extension);
       // vector <vector <double> > pdv = make_prediction_by_sequence (sequence,current_crs	);
        int  nu_ca_test = pdv.size();


        int current_number_of_cases = odv.size();

        out<< sequence[0] << endl;
        out<< sequence[1] << endl;

        int true_coord_current_number = current_number_of_cases;
		for ( int ii = 0; ii< current_number_of_cases; ii++)
		{



            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                pdv_left    [jj]   = pdv[ii][jj];
                pdv_right   [jj]  = -pdv[ii][jj+number_of_clasters_];
            }

            int index_pdv_left  = get_nearest_claster_index(	pdv_left    );
            int index_pdv_right = get_nearest_claster_index(	pdv_right   );

            out<< sequence[ii+shift_] << "\t";
            PutVa(index_pdv_left,out,5,0,'l');
            PutVa(index_pdv_right,out,5,0,'l');

			if (fabs(odv[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                true_coord_current_number --;
                PutVa("***",out,5,0,'l');
                PutVa("***",out,5,0,'l');
                out << endl;
     			continue;
            }
//vector < vector < double > >  odv_cp = odv;

            for (int jj=0;jj<number_of_clasters_;jj++)
            {
                odv_left    [jj]   = odv[ii][jj];
                odv_right   [jj]  = -odv[ii][jj+number_of_clasters_];
            }

            int index_odv_left  = get_nearest_claster_index(	odv_left    );
            int index_odv_right = get_nearest_claster_index(	odv_right   );
            assert(index_odv_left==index_odv_right);

            PutVa(index_odv_left,out,5,0,'l');
            PutVa(index_odv_right,out,5,0,'l');
            out << endl;



            left_quality_matrix [index_odv_left][index_pdv_left ] ++;
            if ( index_odv_left==index_pdv_left  )
                left_quality +=1;

            right_quality_matrix [index_odv_right][index_pdv_right ] ++;
            if ( index_odv_right==index_pdv_right  )
                right_quality +=1;

        }
       // total_number_of_cases += true_coord_current_number   ;

        total_left_quality += left_quality;
        total_right_quality+= right_quality;

        if (true_coord_current_number)
        {
            left_quality /= true_coord_current_number;
            right_quality/= true_coord_current_number;
        }
        else
        {
            left_quality =0;
            right_quality=0;
        }


        out << "*****************************" << endl;
		out << "left Quality predition matrix" << endl;
		for ( int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVa( 	left_quality_matrix[kkk][jjj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << true_coord_current_number << " of " << current_number_of_cases<< endl;
		out << "left Quality: " << left_quality << endl;


		out << "*****************************" << endl;
		out << "right Quality predition matrix" << endl;
		for (int kkk=0;kkk<number_of_clasters_;kkk++)
		{
			for (int jjj=0;jjj<number_of_clasters_;jjj++)
				PutVa( 	right_quality_matrix[kkk][jjj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << true_coord_current_number << " of " << current_number_of_cases<< endl;
		out << "Right Quality: " << right_quality << endl;

        cout << kk<< "\t" << accepted_chain_ID_list_CONTROL[kk] << endl;


        protocol_out << accepted_chain_ID_list_CONTROL[kk] << "\t";
        PutVa( left_quality,protocol_out,8,6,'l');  protocol_out << "\t";
        PutVa( right_quality,protocol_out,8,6,'l'); protocol_out << "\t";
        protocol_out << "Length: " << true_coord_current_number << " of " << current_number_of_cases<< endl;

        total_number_of_cases += true_coord_current_number   ;

        total_left_quality += left_quality;
        total_right_quality +=  right_quality;



    }

    protocol_out << "direct model quality CONTROL : " ;PutVa( total_left_quality/total_number_of_cases,protocol_out,8,6,'l') ;protocol_out << endl;
    protocol_out << "invers model quality CONTROL: " ;PutVa( total_right_quality/total_number_of_cases,protocol_out,8,6,'l') ;protocol_out << endl;

}
void Abu_Maimonides_Rambam::
prepare_data_for_AI_for_prediction_by_sequences_set(
    const string &path_to_sequence_set_folder,  //sequence- the first string in file [pdbID].protocol
    const string &path_to_result_folder,
    const string &path_to_PDB_ID_list)
{

	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

    //string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   ifstream in_stream(path_to_PDB_ID_list.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    for (int kk = 0; kk < chain_ID_list.size(); kk++)
	{
        string current_chain_ID = chain_ID_list[kk];

        cout << current_chain_ID << "  " << kk << endl;

        string path_to_sequnce_store = path_to_sequence_set_folder + current_chain_ID+string(".protocol");
        ifstream in_seq(path_to_sequnce_store.c_str());
        if (!in_seq)
        {
            log_stream  <<  "ERROR -  can't open " << path_to_sequnce_store << endl;
            cout        <<  "ERROR -  can't open " << path_to_sequnce_store << endl;
            exit(1);
        }

        string current_line,sequence;
        getline( in_seq , current_line, '\n' );

        {
            istringstream ist (current_line);
            ist >> sequence;
		}

        int current_number_of_cases = sequence.size();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

        string path_for_result_file = path_to_result_folder + chain_ID_list[kk] + string("_by_seq.dat");
        ofstream res_stream(path_for_result_file.c_str());
        if (!res_stream)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_result_file << endl;
            cout        <<  "ERROR -  can't create " << path_for_result_file << endl;
            exit(1);
        }


        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{
            for (int jj=0;jj<number_of_cowa_variables-1;jj++)
            {
                PutVaDouble(sophisticated_variables[ii][jj],res_stream,10,6,'l'); res_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii][number_of_cowa_variables-1],res_stream,10,6,'l'); res_stream <<"\n";
        }
		res_stream.close();
		in_seq.close();

    }

}


void Abu_Maimonides_Rambam::
prepare_data_for_AI(const string &path_to_raw_data,const string &path_to_PDB_ID_list)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	memset(avsumx_, 0, record_size_   *sizeof(double));
	memset(su_, 0, upper_triange_matrix_size_  *sizeof(double));

	int total_number_of_cases = 0;


    string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   ifstream in_stream(path_to_PDB_ID_list.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_for_pytorch_data << endl;
        cout        <<  "ERROR -  can't open " << path_for_pytorch_data << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data    + path_to_PDB_ID_list + "X.dat";
    string path_for_Y =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data    + path_to_PDB_ID_list + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


    for (int kk = 0; kk < chain_ID_list.size(); kk++)
///    for (int kk = 0; kk < 400; kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

       /// bool is_PDB_ID_ASSIGNED_YET = false;

        string path_for_pytorch_file = path_for_pytorch_data + chain_ID_list[kk] + string(".dat");
        ofstream for_pytorch_stream(path_for_pytorch_file.c_str());
        if (!for_pytorch_stream)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file << endl;
            exit(1);
        }
/*
        string path_for_protocol_file = path_for_pytorch_data + chain_ID_list[kk] + string(".protocol");
        ofstream protocol_stream(path_for_protocol_file.c_str());
        if (!protocol_stream)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_protocol_file << endl;
            cout        <<  "ERROR -  can't create " << path_for_protocol_file << endl;
            exit(1);
        }
        protocol_stream << sequence << endl;
*/
        ///for_pytorch_stream  << number_of_cowa_variables << "\t" << number_of_dicl_variables << "\t" << current_number_of_cases << endl;

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

			for (int jj = 0; jj< number_of_cowa_variables; jj++)
				data_set_[jj] = sophisticated_variables[ii + shift][jj];

     		for (int jj = 0; jj< number_of_dicl_variables; jj++)
			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];
            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";
            //else                 protocol_stream << ii << endl;


          	for (int jj = 0; jj< number_of_cowa_variables; jj++)
				data_set_[jj] = sophisticated_variables[ii + shift][jj];

			for (int jj = 0; jj< number_of_dicl_variables; jj++)
			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

/*
            for (int kkk=0;kkk<number_of_cowa_variables+number_of_dicl_variables;kkk++)
            {
                PutVaDouble(data_set_[kkk],for_pytorch_stream,10,6,'l'); for_pytorch_stream <<"\t";
            }
            for_pytorch_stream << endl;
*/

        }

  //      for_pytorch_stream.close();

        cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

}

void Abu_Maimonides_Rambam::
prepare_sophisticated_AI_data_set_based_on_first_stage_predicrion_by_fulle_sequence(
    const string &path_to_first_stage_prediction_folder,
    const string &path_to_result_folder,
    const string &ready_data_name,
    const string &path_to_PDB_ID_list)
{
	int shift = dicl_creator_->get_shift();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();
	number_of_dicl_variables = number_of_dicl_variables/2;   /// !!!! не нужны обратные коорлинаты


	int total_number_of_cases = 0;

   ifstream in_stream(path_to_PDB_ID_list.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);



    string      global_result_X = path_to_result_folder + ready_data_name + string("X.dat");
    ofstream    global_X_stream(  global_result_X.c_str()  );
    if ( !global_X_stream )
    {
        log_stream  <<  "ERROR -  can't create " << global_result_X << endl;
        cout        <<  "ERROR -  can't create " << global_result_X << endl;
        exit(1);
    }
    string      global_result_Y = path_to_result_folder + ready_data_name + string("Y.dat");
    ofstream    global_Y_stream(  global_result_Y.c_str()  );
    if ( !global_Y_stream )
    {
        log_stream  <<  "ERROR -  can't create " << global_result_Y << endl;
        cout        <<  "ERROR -  can't create " << global_result_Y << endl;
        exit(1);
    }



    for (int kk = 0; kk < chain_ID_list.size(); kk++)
///    for (int kk = 0; kk < 400; kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

         /// Вместо cowa_creator_  данные из файла с перрвычными предсказаниями
		///cowa_creator_->process_chain(sequence);		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		vector < vector < double > > sophisticated_variables;
		sophisticated_variables.resize(0);

		string data_file_name = path_to_first_stage_prediction_folder + chain_ID_list[kk]  + "_pre.csv";
		ifstream data_stream(data_file_name.c_str());
        if (!data_stream)
        {
            log_stream  <<  "ERROR -  can't open " << data_file_name << endl;
            cout        <<  "ERROR -  can't open " << data_file_name << endl;
            exit(1);
        }

        string current_line;
        vector <double> buff;
        while( getline( data_stream  , current_line, '\n' ) )
        {
            istringstream ist (current_line);

            double temp;
            int counter=0;
            while (ist >> temp)
            {
                buff.push_back(temp);
                counter++;
            }
            if ( counter == 16 )
                sophisticated_variables.push_back(buff);
            buff.resize(0);
        }


		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

       /// bool is_PDB_ID_ASSIGNED_YET = false;

        string      local_result_X = path_to_result_folder + chain_ID_list[kk] + string("X.dat");
        ofstream    local_X_stream(  local_result_X.c_str()  );
        if ( !local_X_stream )
        {
            log_stream  <<  "ERROR -  can't create " << local_result_X << endl;
            cout        <<  "ERROR -  can't create " << local_result_X << endl;
            exit(1);
        }
        string      local_result_Y = path_to_result_folder + chain_ID_list[kk] + string("Y.dat");
        ofstream    local_Y_stream(  local_result_Y.c_str()  );
        if ( !local_Y_stream )
        {
            log_stream  <<  "ERROR -  can't create " << local_result_Y << endl;
            cout        <<  "ERROR -  can't create " << local_result_Y << endl;
            exit(1);
        }


        int     number_of_cowa_variables = sophisticated_variables[0].size();

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

 //    		for (int jj = 0; jj< number_of_dicl_variables; jj++)
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];
            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";

/// *************** GLOBAL X *********************************
          	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
//				data_set_[jj] = sophisticated_variables[ii + shift][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],global_X_stream,10,6,'l'); global_X_stream <<"\t";
            }

           	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
//				data_set_[jj] = sophisticated_variables[ii + shift -2 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],global_X_stream,10,6,'l'); global_X_stream <<"\t";
            }
           	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
//				data_set_[jj] = sophisticated_variables[ii + shift -1 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],global_X_stream,10,6,'l'); global_X_stream <<"\t";
            }
          	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
//				data_set_[jj] = sophisticated_variables[ii + shift +1 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],global_X_stream,10,6,'l'); global_X_stream <<"\t";
            }

          	for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
          	{
//				data_set_[jj] = sophisticated_variables[ii + shift +2 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],global_X_stream,10,6,'l'); global_X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift][number_of_cowa_variables-1],global_X_stream,10,6,'l'); global_X_stream <<"\n";
/// END *************** GLOBAL X *********************************

/// *************** Local X *********************************
          	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
//				data_set_[jj] = sophisticated_variables[ii + shift][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],local_X_stream,10,6,'l'); local_X_stream <<"\t";
            }

           	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
			//	data_set_[jj] = sophisticated_variables[ii + shift -2 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],local_X_stream,10,6,'l'); local_X_stream <<"\t";
            }
           	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
				//data_set_[jj] = sophisticated_variables[ii + shift -1 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],local_X_stream,10,6,'l'); local_X_stream <<"\t";
            }
          	for (int jj = 0; jj< number_of_cowa_variables; jj++)
          	{
				//data_set_[jj] = sophisticated_variables[ii + shift +1 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],local_X_stream,10,6,'l'); local_X_stream <<"\t";
            }

          	for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
          	{
				//data_set_[jj] = sophisticated_variables[ii + shift +2 ][jj];
				PutVaDouble(sophisticated_variables[ii + shift][jj],local_X_stream,10,6,'l'); local_X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift][number_of_cowa_variables-1],local_X_stream,10,6,'l'); local_X_stream <<"\n";
/// END *************** local X *********************************


/// ************ local & global Y stream ****************

			for (int jj = 0; jj< number_of_dicl_variables-1; jj++)
			{
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

   				PutVaDouble(sophisticated_distance_variables[ii][jj],global_Y_stream,   10,6,'l'); global_Y_stream  <<"\t";
   				PutVaDouble(sophisticated_distance_variables[ii][jj],local_Y_stream,    10,6,'l'); local_Y_stream   <<"\t";

            }
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],global_Y_stream,   10,6,'l'); global_Y_stream  <<"\n";
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],local_Y_stream,    10,6,'l'); local_Y_stream   <<"\n";

/// END ************ local & global Y stream ****************

        }


        cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }



}


/// Make large (triple) learning set. Data contain predictor's set for left current anf right neigbours
/// AND 5 !!!!!!!!
void Abu_Maimonides_Rambam::
prepare_triple_data_for_AI(
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &data_set_name)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


	int total_number_of_cases = 0;


   // string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   string path_for_pytorch_data = path_to_raw_data;
   string path_to_PDB_ID_list_file = path_to_PDB_ID_list + data_set_name;

   ifstream in_stream(path_to_PDB_ID_list_file.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


    for (int kk = 0; kk < chain_ID_list.size(); kk++)
///    for (int kk = 0; kk < 400; kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

       /// bool is_PDB_ID_ASSIGNED_YET = false;

        string path_for_pytorch_file_X = path_for_pytorch_data + chain_ID_list[kk] + string("X.dat");
        ofstream local_stream_X(path_for_pytorch_file_X.c_str());
        if (!local_stream_X)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            exit(1);
        }

        string path_for_pytorch_file_Y = path_for_pytorch_data + chain_ID_list[kk] + string("Y.dat");
        ofstream local_stream_Y(path_for_pytorch_file_Y.c_str());
        if (!local_stream_Y)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_Y << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_Y << endl;
            exit(1);
        }


        ///for_pytorch_stream  << number_of_cowa_variables << "\t" << number_of_dicl_variables << "\t" << current_number_of_cases << endl;

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";

/// Global file *X !!!
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1   ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";

/// Local file *X !!!

            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables-1 ; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],local_stream_X,10,6,'l'); local_stream_X <<"\n";


/// ************ local & global Y stream ****************

			for (int jj = 0; jj< number_of_dicl_variables-1; jj++)
			{
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

   				PutVaDouble(sophisticated_distance_variables[ii][jj],Y_stream,          10,6,'l'); Y_stream         <<"\t";
   				PutVaDouble(sophisticated_distance_variables[ii][jj],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\t";

            }
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],Y_stream,          10,6,'l'); Y_stream         <<"\n";
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\n";

/// END ************ local & global Y stream ****************


        }

         cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

}
void Abu_Maimonides_Rambam::prepare_NN_data_for_AI()
{

    string data_set_name = sheduler_->option_meaning("CHAIN_LIST");

	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


	int total_number_of_cases = 0;


   string path_current = configuration.option_meaning("Path_to_Model_store") + name_ + string("/") ;


   // string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;




    string path_for_X =  path_current + "NN_data/"+data_set_name + "X.dat";
    string path_for_Y =  path_current + "NN_data/"+data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


//    for (int kk = 0; kk < chain_ID_list.size(); kk++)

    accepted_chain_ID_list_;
    for (int kk = 0; kk < accepted_chain_ID_list_.size(); kk++)

	{
        string current_chain_ID = accepted_chain_ID_list_[kk];
		Chain_binary *chain = new Chain_binary(accepted_chain_ID_list_[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

       /// bool is_PDB_ID_ASSIGNED_YET = false;


        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";

/// Global file *X !!!
   			for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";


/// ************ local & global Y stream ****************

			for (int jj = 0; jj< number_of_dicl_variables-1; jj++)
			{
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

   				PutVaDouble(sophisticated_distance_variables[ii][jj],Y_stream,          10,6,'l'); Y_stream         <<"\t";

            }
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],Y_stream,          10,6,'l'); Y_stream         <<"\n";

/// END ************ local & global Y stream ****************


        }

         cout << kk <<  "\t" <<accepted_chain_ID_list_[kk] << endl;

    }



}



///A close analogue of the function prepare_triple_data_for_AI.
void Abu_Maimonides_Rambam::
prepare_DAS_selected_data_for_AI
(
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &data_set_name)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


	int total_number_of_cases = 0;


   // string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   string path_for_pytorch_data = path_to_raw_data;
   string path_to_PDB_ID_list_file = path_to_PDB_ID_list + data_set_name;

    ifstream in_stream(path_to_PDB_ID_list_file.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);

    string path_to_DAS_selected_predictor_indexes =  path_to_raw_data    + "DAS_selected_indexes";

    ifstream in_DAS_stream(path_to_DAS_selected_predictor_indexes.c_str());
    if (!in_DAS_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_DAS_selected_predictor_indexes << endl;
        cout        <<  "ERROR -  can't open " << path_to_DAS_selected_predictor_indexes << endl;
        exit(1);
    }

    vector <int> DAS_selected_predictor_indexes;
    int curent_num;
    while(in_DAS_stream >> curent_num)
        DAS_selected_predictor_indexes.push_back(curent_num);

    int nu_DAS_selected =  DAS_selected_predictor_indexes.size();


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


    for (int kk = 0; kk < chain_ID_list.size(); kk++)
///    for (int kk = 0; kk < 400; kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

       /// bool is_PDB_ID_ASSIGNED_YET = false;


        ///for_pytorch_stream  << number_of_cowa_variables << "\t" << number_of_dicl_variables << "\t" << current_number_of_cases << endl;

        vector<double> s_v_large;
        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";

/// Global file *X !!!
            ///vector1.insert(vector1.end (), vector2.begin(), vector2.end ());

            s_v_large.insert(s_v_large.end (), sophisticated_variables[ii + shift -2 ].begin(), sophisticated_variables[ii + shift -2 ].end ());
            s_v_large.insert(s_v_large.end (), sophisticated_variables[ii + shift -1 ].begin(), sophisticated_variables[ii + shift -1 ].end ());
            s_v_large.insert(s_v_large.end (), sophisticated_variables[ii + shift    ].begin(), sophisticated_variables[ii + shift    ].end ());
            s_v_large.insert(s_v_large.end (), sophisticated_variables[ii + shift +1 ].begin(), sophisticated_variables[ii + shift +1 ].end ());
            s_v_large.insert(s_v_large.end (), sophisticated_variables[ii + shift +2 ].begin(), sophisticated_variables[ii + shift +2 ].end ());

            for (int kk=0; kk <DAS_selected_predictor_indexes.size()-1 ;kk++)
            {
                PutVaDouble(s_v_large [ DAS_selected_predictor_indexes[kk] ] ,X_stream,10,6,'l');
                X_stream <<"\t";
            }
            PutVaDouble(s_v_large [ DAS_selected_predictor_indexes[  DAS_selected_predictor_indexes.size()-1 ] ] ,X_stream,10,6,'l');
            X_stream <<"\n";


/*
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],X_stream,10,6,'l');
                if (DAS_selected_predictor_indexes) X_stream <<"\t";
            }
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1   ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            //PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";
*/
            s_v_large.resize(0);



/// ************ local & global Y stream ****************

			for (int jj = 0; jj< number_of_dicl_variables-1; jj++)
			{
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

   				PutVaDouble(sophisticated_distance_variables[ii][jj],Y_stream,          10,6,'l'); Y_stream         <<"\t";
  // 				PutVaDouble(sophisticated_distance_variables[ii][jj],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\t";

            }
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],Y_stream,          10,6,'l'); Y_stream         <<"\n";
 //           PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\n";

/// END ************ local & global Y stream ****************


        }

         cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

}




//// Regtression for getting significant var. set for futher NN usage
void Abu_Maimonides_Rambam::
prepare_regression_data_for_significant_var_selection(
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &data_set_name)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


//	int total_number_of_cases = 0;


   // string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   string path_for_pytorch_data = path_to_raw_data;
   string path_to_PDB_ID_list_file = path_to_PDB_ID_list + data_set_name;

   ifstream in_stream(path_to_PDB_ID_list_file.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  path_to_raw_data    + data_set_name + "_DA.dat";
//    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    X_stream << number_of_dicl_variables  << "                          " << number_of_cowa_variables*5 << endl;

    int total_number_of_cases = 0;

    for (int kk = 0; kk < chain_ID_list.size(); kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		//get_nearest_claster_index

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

       /// bool is_PDB_ID_ASSIGNED_YET = false;


        vector <double>  dv_t;
        dv_t.resize(16);

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";

//            sophisticated_distance_variables[ii].resize(16);
            for (int zzz=0;zzz<16;zzz++)
                dv_t[zzz]=sophisticated_distance_variables[ii][zzz];

            int nearest_claster_index = get_nearest_claster_index(dv_t);
            total_number_of_cases++;

            PutVa(nearest_claster_index,X_stream,10,6,'l'); X_stream <<"\t";

/// Global file *X !!!

			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1   ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";




/// ************ local & global Y stream ****************

/*			for (int jj = 0; jj< number_of_dicl_variables-1; jj++)
			{
   				PutVaDouble(sophisticated_distance_variables[ii][jj],X_stream,          10,6,'l'); Y_stream         <<"\t";
            }
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],X_stream,          10,6,'l'); Y_stream         <<"\n";
*/
/// END ************ local & global Y stream ****************


        }

     //   total_number_of_cases += current_number_of_cases;

         cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

    X_stream.seekp(10,ios::beg);
    X_stream << total_number_of_cases;

}


/// for prepare_triple_data_for_AI_SS_8() only
void fill_assignment_8 (
    const string & curr_seq_dssp_pb_file,
    string & sequence,
    string & sequence_by_dssp,
    string & dssp_short,
    vector <double> &assignment_8);

void conv_to_vector (
    vector < double >  & assignment_8,
    vector <  vector < double >  >  & assignment_vector_8);

void Abu_Maimonides_Rambam::
prepare_triple_data_for_AI_SS_8_for_classify(
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &path_to_SS_data,
    const string &data_set_name)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


	int total_number_of_cases = 0;


   // string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   string path_for_pytorch_data = path_to_raw_data;
   string path_to_PDB_ID_list_file = path_to_PDB_ID_list + data_set_name;

   ifstream in_stream(path_to_PDB_ID_list_file.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  path_to_raw_data    + data_set_name + ".dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }



    for (int kk = 0; kk < chain_ID_list.size(); kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

        string curr_seq_dssp_pb_file = path_to_SS_data + current_chain_ID + ".data";
        string sequence_by_dssp, dssp_short;


        //sequence_by_dssp.size()
        int number_of_dssp_classes = 8;

        vector <double> assignment_8;
        fill_assignment_8 (curr_seq_dssp_pb_file,sequence,sequence_by_dssp,dssp_short,assignment_8);

    //    vector <  vector < double >  >  assignment_vector_8;

     //   conv_to_vector (assignment_8,assignment_vector_8);

       /// bool is_PDB_ID_ASSIGNED_YET = false;

        string path_for_pytorch_file_X = path_for_pytorch_data + chain_ID_list[kk] + string(".dat");
        ofstream local_stream_X(path_for_pytorch_file_X.c_str());
        if (!local_stream_X)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            exit(1);
        }

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{
            char ttt =   dssp_short[ii + shift];
            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";


             if (dssp_short[ii + shift] == '?')
             {
                cout << "Rude Error! in :" << endl;
                exit (-1);
                //continue;
             }

/// Global file *X !!!

            PutVa(  ( (int) assignment_8[ii + shift] ),X_stream,          3,0,'l'); X_stream         <<"\t";
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1   ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";

/// Local file *X !!!

            PutVa(  ( (int) assignment_8[ii + shift] ),local_stream_X,          3,0,'l'); local_stream_X         <<"\t";
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables-1 ; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],local_stream_X,10,6,'l'); local_stream_X <<"\n";

/*
			for (int jj = 0; jj< number_of_dssp_classes-1; jj++)
			{


   				PutVaDouble(assignment_vector_8[ii + shift][jj],Y_stream,          10,6,'l'); Y_stream         <<"\t";
   				PutVaDouble(assignment_vector_8[ii + shift][jj],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\t";
   			//	cout << assignment_vector_8[ii + shift][jj] << "\t";

            }
            PutVaDouble(assignment_vector_8[ii + shift][number_of_dssp_classes-1],Y_stream,          10,6,'l'); Y_stream         <<"\n";
            PutVaDouble(assignment_vector_8[ii + shift][number_of_dssp_classes-1],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\n";
*/
        }

         cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

}


void Abu_Maimonides_Rambam::
prepare_triple_data_for_AI_SS_8(
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &path_to_SS_data,
    const string &data_set_name)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


	int total_number_of_cases = 0;


   // string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ +  path_to_raw_data;

   string path_for_pytorch_data = path_to_raw_data;
   string path_to_PDB_ID_list_file = path_to_PDB_ID_list + data_set_name;

   ifstream in_stream(path_to_PDB_ID_list_file.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }



    for (int kk = 0; kk < chain_ID_list.size(); kk++)
///    for (int kk = 0; kk < 400; kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

        string curr_seq_dssp_pb_file = path_to_SS_data + current_chain_ID + ".data";
        string sequence_by_dssp, dssp_short;


        //sequence_by_dssp.size()
        int number_of_dssp_classes = 8;

        vector <double> assignment_8;
        fill_assignment_8 (curr_seq_dssp_pb_file,sequence,sequence_by_dssp,dssp_short,assignment_8);

        vector <  vector < double >  >  assignment_vector_8;

        conv_to_vector (assignment_8,assignment_vector_8);

       /// bool is_PDB_ID_ASSIGNED_YET = false;

        string path_for_pytorch_file_X = path_for_pytorch_data + chain_ID_list[kk] + string("X.dat");
        ofstream local_stream_X(path_for_pytorch_file_X.c_str());
        if (!local_stream_X)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            exit(1);
        }

        string path_for_pytorch_file_Y = path_for_pytorch_data + chain_ID_list[kk] + string("Y.dat");
        ofstream local_stream_Y(path_for_pytorch_file_Y.c_str());
        if (!local_stream_Y)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_Y << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_Y << endl;
            exit(1);
        }


        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{
            char ttt =   dssp_short[ii + shift];
            if ( (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(sophisticated_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue; ///for_pytorch_stream << "###  ";


             if (dssp_short[ii + shift] == '?')
             {
                cout << "Rude Error! in :" << endl;
                exit (-1);
                //continue;
             }

/// Global file *X !!!
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1   ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";

/// Local file *X !!!

            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables-1 ; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],local_stream_X,10,6,'l'); local_stream_X <<"\n";

/*
/// ************ local & global Y stream ****************

			for (int jj = 0; jj< number_of_dicl_variables-1; jj++)
			{
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

   				PutVaDouble(sophisticated_distance_variables[ii][jj],Y_stream,          10,6,'l'); Y_stream         <<"\t";
   				PutVaDouble(sophisticated_distance_variables[ii][jj],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\t";

            }
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],Y_stream,          10,6,'l'); Y_stream         <<"\n";
            PutVaDouble(sophisticated_distance_variables[ii][number_of_dicl_variables-1],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\n";

/// END ************ local & global Y stream ****************
*/

			for (int jj = 0; jj< number_of_dssp_classes-1; jj++)
			{
//			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

   				PutVaDouble(assignment_vector_8[ii + shift][jj],Y_stream,          10,6,'l'); Y_stream         <<"\t";
   				PutVaDouble(assignment_vector_8[ii + shift][jj],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\t";
   			//	cout << assignment_vector_8[ii + shift][jj] << "\t";

            }
            PutVaDouble(assignment_vector_8[ii + shift][number_of_dssp_classes-1],Y_stream,          10,6,'l'); Y_stream         <<"\n";
            PutVaDouble(assignment_vector_8[ii + shift][number_of_dssp_classes-1],local_stream_Y,    10,6,'l'); local_stream_Y   <<"\n";

        }

         cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

}


void Abu_Maimonides_Rambam::
prepare_triple_data_for_AI_by_sequence(
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &data_set_name)
{


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

 	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************

	int total_number_of_cases = 0;

   string path_for_pytorch_data = path_to_raw_data;

   string path_to_PDB_ID_list_file = path_to_PDB_ID_list + data_set_name;

   ifstream in_stream(path_to_PDB_ID_list_file.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        cout        <<  "ERROR -  can't open " << path_to_PDB_ID_list_file << endl;
        exit(1);
    }

    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }


    for (int kk = 0; kk < chain_ID_list.size(); kk++)
	{
        string current_chain_ID = chain_ID_list[kk];
		Chain_binary *chain = new Chain_binary(chain_ID_list[kk]);
		string sequence = chain->get_sequence();

               dicl_creator_->process_chain(chain);
        vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

        int current_number_of_cases = sophisticated_distance_variables.size();

		cowa_creator_->process_chain(sequence);
		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

	//	vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();




        string path_for_pytorch_file_X = path_for_pytorch_data + chain_ID_list[kk] + string("X.dat");
        ofstream local_stream_X(path_for_pytorch_file_X.c_str());
        if (!local_stream_X)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            exit(1);
        }

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

/*
/// Global file *X !!!
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1   ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< number_of_cowa_variables-1; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],X_stream,10,6,'l'); X_stream <<"\n";
*/
/// Local file *X !!!

            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables-1 ; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],local_stream_X,10,6,'l'); local_stream_X <<"\n";



        }

        cout << kk <<  "\t" <<chain_ID_list[kk] << endl;

    }

}


void Abu_Maimonides_Rambam::make_predictor_file_set_by_sequence (
    const string & sequence,
    const string & path_for_pytorch_data,
    const string & predictor_file_name)
{

        int shift = dicl_creator_->get_shift();

		cowa_creator_->process_chain(sequence);
		int number_of_cowa_variables = cowa_creator_->get_number_of_variables();

		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

        string path_for_pytorch_file_X = path_for_pytorch_data + predictor_file_name;
        ofstream local_stream_X(path_for_pytorch_file_X.c_str());
        if (!local_stream_X)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file_X << endl;
            exit(1);
        }

        int current_number_of_cases = sophisticated_variables.size()-4;  /// -4  !!!!!!!!!!!!!!

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

/// Local file *X !!!

            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift -1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift    ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            for (int jj = 0; jj< number_of_cowa_variables; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +1 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }

   			for (int jj = 0; jj< number_of_cowa_variables-1 ; jj++)
			{
                PutVaDouble(sophisticated_variables[ii + shift +2 ][jj],local_stream_X,10,6,'l'); local_stream_X <<"\t";
            }
            PutVaDouble(sophisticated_variables[ii + shift +2 ][number_of_cowa_variables-1],local_stream_X,10,6,'l'); local_stream_X <<"\n";



        }



}




/// triple data for prediction only
//void Abu_Maimonides_Rambam::
//prepare_data_R726_for_AI_for_prediction_by_sequences_set_test()
//{

//}

/*
void Abu_Maimonides_Rambam::
prepare_quinarii_for_AI
    const string &path_to_raw_data,
    const string &path_to_PDB_ID_list,
    const string &data_set_name)
{

    int shift = dicl_creator_->get_shift();

	#int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	#int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//***************************************************************
	number_of_dicl_variables = 16; ///********************************* надоело бадаться с обратными коорлдинатами !!
	//***************************************************************


	int total_number_of_cases = 0;

   string path_for_pytorch_data = path_to_raw_data;

   ifstream in_stream(path_to_PDB_ID_list.c_str());
    if (!in_stream)
    {
        log_stream  <<  "ERROR -  can't open " << path_for_pytorch_data << endl;
        cout        <<  "ERROR -  can't open " << path_for_pytorch_data << endl;
        exit(1);
    }
    vector <string> chain_ID_list;
    string curent_word;
    while(in_stream>> curent_word)
        chain_ID_list.push_back(curent_word);


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


}
*/

void Abu_Maimonides_Rambam::
fast_make_cross_sum_binary_together_files()
{
    string train_file_name = 			configuration.option_meaning("Path_to_Model_store") + name_+"/train.data";
    ofstream train_stream(train_file_name.c_str());
	if (!train_stream)
	{
		log_stream  <<  "ERROR -  can't create " << train_file_name << endl;
		cout        <<  "ERROR -  can't create " << train_file_name << endl;
		exit(1);
	}
    string validation_name = 			configuration.option_meaning("Path_to_Model_store") + name_+"/validation.data";
    ofstream validation_stream(validation_name.c_str());
	if (!validation_stream)
	{
		log_stream  <<  "ERROR -  can't create " << validation_name << endl;
		cout        <<  "ERROR -  can't create " << validation_name << endl;
		exit(1);
	}

    string test_name = 			configuration.option_meaning("Path_to_Model_store") + name_+"/test.data";
    ofstream test_stream(test_name.c_str());
	if (!test_stream)
	{
		log_stream  <<  "ERROR -  can't create " << test_name << endl;
		cout        <<  "ERROR -  can't create " << test_name << endl;
		exit(1);
	}

/// creating list files containing list of PDB_ID for learning, test and validatin sanples

    string test_list_name = 			configuration.option_meaning("Path_to_Model_store") + name_+"/test_list.txt";
    ofstream test_list_stream(test_list_name.c_str());
	if (!test_list_stream)
	{
		log_stream  <<  "ERROR -  can't create " << test_list_name << endl;
		cout        <<  "ERROR -  can't create " << test_list_name << endl;
		exit(1);
	}


    string train_list_name = 			configuration.option_meaning("Path_to_Model_store") + name_+"/train_list.txt";
    ofstream train_list_stream(train_list_name.c_str());
	if (!train_list_stream)
	{
		log_stream  <<  "ERROR -  can't create " << train_list_name << endl;
		cout        <<  "ERROR -  can't create " << train_list_name << endl;
		exit(1);
	}

    string validation_list_name = 			configuration.option_meaning("Path_to_Model_store") + name_+"/validation_list.txt";
    ofstream validation_list_stream(validation_list_name.c_str());
	if (!validation_list_stream)
	{
		log_stream  <<  "ERROR -  can't create " << validation_list_name << endl;
		cout        <<  "ERROR -  can't create " << validation_list_name << endl;
		exit(1);
	}



	string path_for_pytorch_data =  configuration.option_meaning("Path_to_Model_store") + name_ + string("/for_pytorch_data/") ;


	int shift = dicl_creator_->get_shift();

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	memset(avsumx_, 0, record_size_   *sizeof(double));
	memset(su_, 0, upper_triange_matrix_size_  *sizeof(double));

	int total_number_of_cases = 0;

/*
    pytorch_stream << number_of_cowa_variables << " " << number_of_dicl_variables << endl;

    for (int kkk=0;kkk<number_of_cowa_variables+number_of_dicl_variables;kkk++)
    {
        PutVa(kkk,pytorch_stream,10,3,'l'); pytorch_stream <<"\t";
    }
    pytorch_stream << endl;
*/
/*
    int fragment_length = dicl_creator_->fragment_length();
    double ** claster_motif_coordinates =  dicl_creator_->get_claster_motif_coordinates (); double ** claster_motif_coordinates =  dicl_creator_->get_claster_motif_coordinates ();
*/

	int separ_flag=0;
    for (int kk = 0; kk < accepted_chain_ID_list_.size(); kk++)
	{
        string current_chain_ID = accepted_chain_ID_list_[kk];
		Chain_binary *chain = new Chain_binary(accepted_chain_ID_list_[kk]);
		string sequence = chain->get_sequence();

/// ТУТ НАДО ВСТАВИТЬ УЧЕТ  ТЕКУЩЕЙ ЦЕПИ В Frequency_extrapolation
/*
       vector < vector < double > >   set_of_coordinate_in_clasters_system;
        chain->	positioning_chain_by_clasters_set(
            claster_motif_coordinates,
            fragment_length,
            number_of_clasters_,
            set_of_coordinate_in_clasters_system);
*/


		dicl_creator_->process_chain(chain);
		vector < vector < double > > const & sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();

		cowa_creator_->current_set_of_coordinate_in_clasters_system_=sophisticated_distance_variables;
		//cowa_creator_->process_chain(sequence,sophisticated_distance_variables);
		cowa_creator_->process_chain(sequence);

		vector < vector < double > > const & sophisticated_variables = cowa_creator_->get_sophisticated_variables();

		int current_number_of_cases = sophisticated_distance_variables.size();
        int true_coord_current_number = current_number_of_cases;

        bool is_PDB_ID_ASSIGNED_YET = false;
/*
        string path_for_pytorch_file = path_for_pytorch_data + accepted_chain_ID_list_[kk] + string(".data");
        ofstream for_pytorch_stream(path_for_pytorch_file.c_str());
        if (!for_pytorch_stream)
        {
            log_stream  <<  "ERROR -  can't create " << path_for_pytorch_file << endl;
            cout        <<  "ERROR -  can't create " << path_for_pytorch_file << endl;
            exit(1);
        }
*/
        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{
	//		cout << ii << endl;
			//if (fabs(set_of_coordinate_in_clasters_system[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
			if (fabs(sophisticated_distance_variables[ii][0] + 1) < EPSILON_FLOAT)  // åñëè ïåðâûé òóõëûé òî è âñå
            {
                true_coord_current_number --;
 				continue;
            }

			for (int jj = 0; jj< number_of_cowa_variables; jj++)
				data_set_[jj] = sophisticated_variables[ii + shift][jj];

			for (int jj = 0; jj< number_of_dicl_variables; jj++)
				//data_set_[number_of_cowa_variables + jj] = set_of_coordinate_in_clasters_system[ii][jj];
			    data_set_[number_of_cowa_variables + jj] = sophisticated_distance_variables[ii][jj];

/// DATA CReate ***********
//			    for (int kkk=0;kkk<number_of_cowa_variables+number_of_cowa_variables;kkk++)
//                    PutVaDouble(data_set_[kkk],log_stream,10,3,'l');
//                log_stream << endl;
/// DATA CReate end***********

/// DATA CReate for Pytorch ***********
/*
                for (int kkk=0;kkk<number_of_cowa_variables+number_of_dicl_variables;kkk++)
                {
                    PutVaDouble(data_set_[kkk],for_pytorch_stream,10,3,'l'); for_pytorch_stream <<"\t";
                }
                for_pytorch_stream << endl;


                if( separ_flag==0 || separ_flag==1 || separ_flag==2 || separ_flag==3 || separ_flag==4  || separ_flag ==5)
                {
                    for (int kkk=0;kkk<number_of_cowa_variables+number_of_dicl_variables;kkk++)
                    {
                        PutVaDouble(data_set_[kkk],train_stream,10,3,'l'); train_stream <<"\t";
                    }
                    train_stream << endl;

                    if ( is_PDB_ID_ASSIGNED_YET == false)
                    {
                        is_PDB_ID_ASSIGNED_YET = true;
                        train_list_stream << current_chain_ID << endl;
                    }

                }

                else if (separ_flag==6 ||separ_flag==7  )
                {
                   for (int kkk=0;kkk<number_of_cowa_variables+number_of_dicl_variables;kkk++)
                   {
                        PutVaDouble(data_set_[kkk],validation_stream,10,3,'l'); validation_stream <<"\t";
                    }
                    validation_stream << endl;

                    if ( is_PDB_ID_ASSIGNED_YET == false)
                    {
                        is_PDB_ID_ASSIGNED_YET = true;
                        validation_list_stream << current_chain_ID << endl;
                    }

                }
                else if (separ_flag==8 ||separ_flag==9  )
                {
                   for (int kkk=0;kkk<number_of_cowa_variables+number_of_dicl_variables;kkk++)
                   {
                        PutVaDouble(data_set_[kkk],test_stream,10,3,'l'); test_stream <<"\t";
                    }
                    test_stream << endl;
                }

               if ( is_PDB_ID_ASSIGNED_YET == false)
                {
                    is_PDB_ID_ASSIGNED_YET = true;
                    test_list_stream << current_chain_ID << endl;
                    log_stream   << current_chain_ID << "  for test sample" << endl;
                }




  //              pytorch_stream_y << endl;
  */
/// DATA CReate end***********


			int supplement_mode = 1;
			supplement_cross_sum_matrix(
				record_size_,
				data_set_,
				avsumx_,
				su_,
				supplement_mode);

		}
		delete chain;
		//total_number_of_cases += current_number_of_cases;
        total_number_of_cases += true_coord_current_number;
		cout << kk << "\t" << accepted_chain_ID_list_[kk] << endl;

/*
        separ_flag++;
        if (separ_flag==9)
            separ_flag=0;

        for_pytorch_stream.close();
*/
	}

	string current_cross_sum_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ +
		"/cross_sum/" +
		string("together") +
		".cross_sum";


	ofstream regdata_stream(current_cross_sum_file_name.c_str(), ios::binary);
	if (!regdata_stream)
	{
		log_stream << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name << endl;
		cout << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name << endl;
		exit(1);
	}

	write_su_avsumx_d_for_regression(
		regdata_stream,
		total_number_of_cases);

}


void Abu_Maimonides_Rambam::
data_for_AI_prediction_by_sequence(
    const string &sequence,
    const string &path_to_ready_data_file)
{

    ofstream out(path_to_ready_data_file.c_str());
    if (!out)
    {
        log_stream  <<  "ERROR -  can't create " << path_to_ready_data_file<< endl;
        cout        <<  "ERROR -  can't create " << path_to_ready_data_file<< endl;
        exit(1);
    }


    cowa_creator_->process_chain(sequence);
    vector < vector < double > > sophisticated_variables = cowa_creator_->get_sophisticated_variables();

    int number_of_cowa_variables=sophisticated_variables[0].size();
    int current_number_of_cases = sophisticated_variables.size();

    for ( int ii = 0; ii< current_number_of_cases; ii++)
    {
        for (int kkk=0;kkk<number_of_cowa_variables;kkk++)
        {
             PutVaDouble(data_set_[kkk],out,10,3,'l');
             out <<"\t";
        }
        out << endl;
    }
}

//vector < vector < double > >	const & get_sophisticated_variables() const { return sophisticated_variables_; }

vector < vector < double > > const & Abu_Maimonides_Rambam::
data_for_AI_prediction_by_sequence(
    const string &sequence   )
{

    cowa_creator_->process_chain(sequence);
    return ( cowa_creator_->get_sophisticated_variables() )  ;


}

void Abu_Maimonides_Rambam::
make_cross_sum_binary_files()
{



	int shift = dicl_creator_->get_shift ();

	vector < vector < double > >  global_set_of_coordinate_in_clasters_system;

	for (int ii =0; ii < accepted_chain_ID_list_.size(); ii++ )
	//for (int ii =11352; ii < accepted_chain_ID_list_.size(); ii++ )
	{
 	string current_cross_sum_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		accepted_chain_ID_list_ [ii] +
			".cross_sum";

		ifstream t_stream(current_cross_sum_file_name.c_str());
		if ( t_stream)
		{
			log_stream << "UZE BILO !!! make_cross_sum_binary_files	(): ERROR -  " << current_cross_sum_file_name   << endl;
			cout       << "UZE BILO !!! make_cross_sum_binary_files	(): ERROR -  " << current_cross_sum_file_name   << endl;
			t_stream.close();
			continue;
		}



		Chain_binary *chain = new Chain_binary ( accepted_chain_ID_list_[ii] );


		string sequence = chain->get_sequence();

// ************ prepare cowa_creator variables ******************
		//vector < vector < double > >	cowa_sophisticated_variables;
		cowa_creator_->process_chain(sequence);
		vector < vector < double > > sophisticated_variables = cowa_creator_->get_sophisticated_variables();



// ************ prepare dicl_creator variables ******************
		// Â ïðåäûäóùåé âåðñèè òóò áûëî set_of_coordinate_in_clasters_system íàâèñàíî, à íà ñàìîì äåëå áûëî âû÷èñëåíî
		// SOPHISTICATED_DISTANCE_VARIABLE
		// vector < vector < double > >  set_of_coordinate_in_clasters_system;

		dicl_creator_->process_chain(chain);
		vector < vector < double > > sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();
		/*,
			set_of_coordinate_in_clasters_system);*/
//****************************************************************
		beef_up_data (
			sophisticated_distance_variables,
			sophisticated_variables,
			shift,
			ADDITION_MODE);


		ofstream regdata_stream(current_cross_sum_file_name.c_str() ,ios::binary);
		if ( ! regdata_stream)
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			exit (1);
		}

		write_su_avsumx_d_for_regression (
			regdata_stream,
			sophisticated_distance_variables.size() ); // fix - âû÷åñòü ñëó÷àè ñ -1

		regdata_stream.close();

// FIX Íå âñåãäà íàäî
// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			accepted_chain_ID_list_ [ii] +
			".dist_data";

		ifstream check_distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if (check_distdata_stream)
		{
			cout << current_distance_file_name << "created early yet" << endl;
			check_distdata_stream.close();
		}


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			sophisticated_distance_variables);

		distdata_stream.close();

//*******************************************************************************

		cout << ii << "\t" << accepted_chain_ID_list_[ii] << endl;

		delete chain;

	}
}




void Abu_Maimonides_Rambam::
make_predicted_distance_binary_files()
{

// *************** init together *********************
	string path_to_cross_sum_binary_file_all_sufficient  =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together")      +
		".cross_sum";

	charming_Reg_solution  * together=
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_all_sufficient  ,
			regression_options_ ) ;

	vector <vector <int> > index_of_included_pool =
		together->get_index_of_included_pool();

	delete together;
// ************************************

	vector < vector < double > >  global_set_of_coordinate_in_clasters_system;

	for (int ii = 0; ii < accepted_chain_ID_list_.size(); ii++ )
	{

// ************ prepare dicl_creator PREDICTED variables ******************
		vector < vector < double > >  set_of_coordinate_in_clasters_system;


//*************************  prediction here  *****************************
	string path_to_cross_sum_binary_file_jack_nife  =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/_"			+
			accepted_chain_ID_list_[ii]  +
			".cross_sum";

	charming_Reg_solution  * jack_nife_model =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_jack_nife,
			regression_options_,
			index_of_included_pool) ;

	int shift = dicl_creator_->get_shift ();

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		accepted_chain_ID_list_[ii],
		jack_nife_model,
		shift);

	delete jack_nife_model;
//******************************************************************************

// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************
		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			accepted_chain_ID_list_ [ii] +
			".dist_data_predicted";

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
//*******************************************************************************

//************************* prepare global dist_data array ***********************
		global_set_of_coordinate_in_clasters_system.insert(
			global_set_of_coordinate_in_clasters_system.end(),
			predicted_det_distance_set.begin(),
			predicted_det_distance_set.end()  );

		cout << ii << "\t" << accepted_chain_ID_list_[ii] << endl;
	}

// ********************** WRITE GLOBAL  *.DIST_DATA FILE ************************
		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/together.dist_data_predicted";

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			global_set_of_coordinate_in_clasters_system);

		distdata_stream.close();
//*******************************************************************************

}



void Abu_Maimonides_Rambam::
beef_up_data (
	const vector < vector < double > >  & set_of_coordinate_in_clasters_system,
	const vector < vector < double > >	& sophisticated_variables,
	const int shift,
	const int supplement_mode )
{
	assert ( set_of_coordinate_in_clasters_system.size() == sophisticated_variables.size() - 2*shift );

	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
//	int number_of_frva_variables = frva_creator_->get_number_of_variables();

	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//double *data_set = new double [ record_size_];

	int task_size = set_of_coordinate_in_clasters_system.size();

	memset (avsumx_	,0,record_size_   *sizeof(double));
	memset (su_		,0,upper_triange_matrix_size_  *sizeof(double));

	for ( int ii=0; ii< task_size ; ii++)
	{
		if ( fabs(set_of_coordinate_in_clasters_system[ii][0]+ 1) < EPSILON_FLOAT )  // åñëè ïåðâûé òóõëûé òî è âñå
			continue;
		//for (int jj=0;	jj<		number_of_cowa_variables +  number_of_frva_variables;jj++ )
		for (int jj = 0; jj< number_of_cowa_variables ; jj++)
			data_set_[jj] = sophisticated_variables[ii+shift][jj];
		int jj;
		//for (jj=0;		jj<		number_of_dicl_variables;jj++ )
		for (jj = 0; jj< number_of_dicl_variables; jj++)
			data_set_[number_of_cowa_variables   + jj] = set_of_coordinate_in_clasters_system[ii][jj];

		supplement_cross_sum_matrix(
			record_size_,
			data_set_,
			avsumx_,
			su_,
			supplement_mode);

	}
	//delete [] data_set;
}

void Abu_Maimonides_Rambam::
write_su_avsumx_d_for_regression (
	ofstream & regdata_stream,
	const int number_of_cases )
{


	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
//	int number_of_frva_variables = frva_creator_->get_number_of_variables();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	//int number_of_cowa_and_frva =  number_of_cowa_variables + number_of_frva_variables ;
	int number_of_cowa_and_frva = number_of_cowa_variables  ;

	regdata_stream.write ( (char* ) & number_of_cowa_and_frva,sizeof (int)  );
	regdata_stream.write ( (char* ) & number_of_dicl_variables ,	sizeof (int)  );

	regdata_stream.write ( (char* ) & number_of_cases,	sizeof (int)  );
	regdata_stream.write ( (char* )  avsumx_,			record_size_ * sizeof (double)  );
	regdata_stream.write ( (char* )  su_,				upper_triange_matrix_size_			* sizeof (double)  );
}
/// AAAAAAAAAAAAAAAAAAAAAAAAAAAAAA



void Abu_Maimonides_Rambam::
write_distdata_for_regression (
   	ofstream & out,
	const vector < vector < double > >	& distance_set  )
{
	int number_of_cases =	distance_set.size();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	out.write ( (char* ) & number_of_cases ,	sizeof (int)  );
	out.write ( (char* ) & number_of_dicl_variables,	sizeof (int)  );

	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));

	for (int ii=0; ii< number_of_dicl_variables;ii++)
	{
		for (int jj=0; jj< number_of_cases ;jj++)
			t_arr [jj] = distance_set [jj][ii];
		out.write ( (char* )	t_arr,		number_of_cases * sizeof(double));
		memset (				t_arr	,0,	number_of_cases * sizeof(double));
	}
	delete [] t_arr	;
}

void Abu_Maimonides_Rambam::
compare_predicted_values ( vector <string> & accepted_chain_ID_list_ )
{


	for (int ii=0; ii<accepted_chain_ID_list_.size(); ii++ )
	{
		vector < vector < double > >  pre_dist_set = read_det_distance_set (
			accepted_chain_ID_list_ [ii], string(".dist_data_predicted") );

		vector < vector < double > >  obs_dist_set = read_det_distance_set (
			accepted_chain_ID_list_ [ii], string (".dist_data") );

		string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			accepted_chain_ID_list_[ii] + string (".compare_prediction") ;


		ofstream out( result_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}




		for (int kk=0;kk<pre_dist_set.size();kk++)
		{
			for (int tt=0;tt<pre_dist_set[0].size();tt++)
			{
				PutVaDouble (pre_dist_set[kk][tt],out,8,3,'l');
				PutVaDouble (obs_dist_set[kk][tt],out,8,3,'l');
				out << " ";
			}
			out << endl;

		}

		out.close ();

	}

}


void Abu_Maimonides_Rambam::
prepare_united_su_avsumx_d ()
{
	prepare_united_su_avsumx_d (accepted_chain_ID_list_);
}

void Abu_Maimonides_Rambam::
prepare_united_su_avsumx_d ( vector <string> & pdb_chain_list )
{
	double *current_avsumx	= new double [record_size_ ]; 			memset (current_avsumx	,	0,record_size_   *sizeof(double));
	double *current_su		= new double [upper_triange_matrix_size_  ]; 	memset (current_su	,		0,upper_triange_matrix_size_  *sizeof(double));

	memset (avsumx_	,0,record_size_			*sizeof(double));
	memset (su_		,0,upper_triange_matrix_size_	*sizeof(double));
	int total_number_of_cases = 0;
	int current_number_of_cases;

	int number_of_predictor;
	int number_of_dependent;

	int pdb_chain_list_size = pdb_chain_list.size();
	for (int ii = 0; ii < pdb_chain_list_size ; ii++ )
//	for (int ii = 0; ii < 11351 ; ii++ )
	{
		string current_cross_sum_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			pdb_chain_list[ii] +
			".cross_sum";

		ifstream regdata_stream(current_cross_sum_file_name.c_str() ,ios::binary);
		if ( ! regdata_stream)
		{
			log_stream << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			cout       << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			exit (1);
		}

		regdata_stream.read ( (char* ) & number_of_predictor,			sizeof (int)  );
		regdata_stream.read ( (char* ) & number_of_dependent,			sizeof (int)  );
		regdata_stream.read ( (char* ) & current_number_of_cases,		sizeof (int)  );


		regdata_stream.read ( (char* )  current_avsumx,			record_size_ * sizeof (double)  );
		regdata_stream.read ( (char* )  current_su,				upper_triange_matrix_size_			* sizeof (double)  );


		total_number_of_cases += current_number_of_cases;
		int kk;
		for (  kk=0;kk<record_size_;kk++)
			avsumx_[kk] += 	current_avsumx[kk];


		for ( kk=0;kk<upper_triange_matrix_size_;kk++)
			su_[kk] += 	current_su[kk];

		regdata_stream.close();

		cout << ii << " " << pdb_chain_list[ii] <<endl;

	}

	string current_cross_sum_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together")  +
		".cross_sum";


		ofstream regdata_stream(current_cross_sum_file_name.c_str() ,ios::binary);
		if ( ! regdata_stream)
		{
			log_stream << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			cout       << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			exit (1);
		}


		write_su_avsumx_d_for_regression (
			regdata_stream,
			total_number_of_cases );


	delete [] current_avsumx;	delete [] current_su ;
}

void Abu_Maimonides_Rambam::
prepare_for_jack_nife_su_avsumx_d ( )
{

	double *current_avsumx	= new double [record_size_ ]; 			memset (current_avsumx	,	0,record_size_   *sizeof(double));
	double *current_su		= new double [upper_triange_matrix_size_  ]; 	memset (current_su	,		0,upper_triange_matrix_size_  *sizeof(double));

	memset (avsumx_	,0,record_size_			*sizeof(double));
	memset (su_		,0,upper_triange_matrix_size_	*sizeof(double));
	int total_number_of_cases = 0;
	int current_number_of_cases;

	int number_of_predictor;
	int number_of_dependent;

	string together_cross_sum_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together") +
		".cross_sum";


	for (int ii = 0; ii < accepted_chain_ID_list_.size(); ii++ )
	{

		string current_cross_sum_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			accepted_chain_ID_list_[ii] +
			".cross_sum";


		string current_jack_nife_cross_sum_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/_"			+
			accepted_chain_ID_list_[ii] +
			".cross_sum";


		ifstream together_stream(together_cross_sum_file_name .c_str() ,ios::binary);
		if ( ! together_stream)
		{
			log_stream << "prepare_for_jack_nife_su_avsumx_d (): ERROR -  can't create " << together_cross_sum_file_name << endl;
			cout       << "prepare_for_jack_nife_su_avsumx_d (): ERROR -  can't create " << together_cross_sum_file_name << endl;
			exit (1);
		}

		ifstream regdata_stream(current_cross_sum_file_name.c_str() ,ios::binary);
		if ( ! regdata_stream)
		{
			log_stream << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			cout       << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			exit (1);
		}


		ofstream jnf_stream(current_jack_nife_cross_sum_file_name.c_str() ,ios::binary);
		if ( ! jnf_stream )
		{
			log_stream << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			cout       << "prepare_united_su_avsumx_d (): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			exit (1);
		}

		int number_of_predictor_together, number_of_dependent_together;
		together_stream.read ( (char* ) & number_of_predictor_together,	sizeof (int)  );
		together_stream.read ( (char* ) & number_of_dependent_together,	sizeof (int)  );
		together_stream.read ( (char* ) & total_number_of_cases,		sizeof (int)  );
		together_stream.read ( (char* )  avsumx_,			record_size_ * sizeof (double)  );
		together_stream.read ( (char* )  su_,				upper_triange_matrix_size_			* sizeof (double)  );


		regdata_stream.read ( (char* ) & number_of_predictor,	sizeof (int)  );
		regdata_stream.read ( (char* ) & number_of_dependent,	sizeof (int)  );
		regdata_stream.read ( (char* ) & current_number_of_cases,		sizeof (int)  );
		regdata_stream.read ( (char* )  current_avsumx,			record_size_ * sizeof (double)  );
		regdata_stream.read ( (char* )  current_su,				upper_triange_matrix_size_			* sizeof (double)  );

			assert ( number_of_predictor_together  == number_of_predictor );
			assert ( number_of_dependent_together  == number_of_dependent );

		total_number_of_cases -= current_number_of_cases;
		int kk;
		for (  kk=0;kk<record_size_;kk++)
			avsumx_[kk] -= 	current_avsumx[kk];

		for ( kk=0;kk<upper_triange_matrix_size_;kk++)
			su_[kk] -= 	current_su[kk];

		write_su_avsumx_d_for_regression (
			jnf_stream,
			total_number_of_cases );

		regdata_stream.		close();	jnf_stream.			close();		together_stream.	close();
	}
	delete [] current_avsumx;			delete [] current_su;
}
void Abu_Maimonides_Rambam::
plain_solution ( const string & PDB_chain_ID )
{

	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("COWARD_VARIABLES_TASK_FILE");

	string path_to_frequency_extrapolation_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("FREQUENCY_EXTRAPOLATION_TASK_FILE");



	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("CLUSTER_FUNCTION_TASK_FILE");


	string path_to_cross_sum_binary_file =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID  +
			".cross_sum";

	charming_Reg_solution  * crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options_ ) ;

	string result_file_name_base =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/") +
		PDB_chain_ID;

	vector <string> predictor_task_files;

	predictor_task_files.push_back(	path_to_cowardvariables_task_file );
	//predictor_task_files.push_back(	path_to_frequency_extrapolation_task_file );

	crs->show_plain_results (
		predictor_task_files ,
		path_to_claster_function_task_file,
		result_file_name_base);

	delete crs ;
}


void Abu_Maimonides_Rambam::
show_all_plain_solution ()
{
	for (int ii = 0; ii < accepted_chain_ID_list_.size(); ii++ )
		plain_solution ( accepted_chain_ID_list_ [ii] );
}



void Abu_Maimonides_Rambam::
show_all_solution_and_prediction ()
{
	init_global_averages_and_dispersion ();

	string path_to_cross_sum_binary_file_all_sufficient  =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together")+
		".cross_sum";

	charming_Reg_solution  * together=
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_all_sufficient  ,
			regression_options_ ) ;


	string result_file_name_base =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/") +
		"together";

	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("CLUSTER_FUNCTION_TASK_FILE");

	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("COWARD_VARIABLES_TASK_FILE");

	string path_to_frequency_extrapolation_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("FREQUENCY_EXTRAPOLATION_TASK_FILE");



	vector < string > predictor_task_files;
	predictor_task_files.push_back (path_to_cowardvariables_task_file ) ;
	predictor_task_files.push_back (path_to_frequency_extrapolation_task_file) ;


	together->show_plain_results (
		predictor_task_files,
		path_to_claster_function_task_file,
		result_file_name_base);

	string protocol_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/protocol.") +
		regression_options_->option_meaning("FISHER_INCLUDE") ;


	ofstream protocol_stream(protocol_file_name.c_str() );
	if ( ! protocol_stream )
	{
		log_stream << "show_all_solution_and_prediction ()(): ERROR -  can't create " << protocol_file_name<< endl;
		cout       << "show_all_solution_and_prediction ()(): ERROR -  can't create " << protocol_file_name<< endl;
		exit (1);
	}



	for (int ii = 0; ii < accepted_chain_ID_list_.size(); ii++ )
		solution_and_prediction(
		accepted_chain_ID_list_ [ii],
		together,
		protocol_stream);

}

void Abu_Maimonides_Rambam::
solution_and_prediction (
	const string & PDB_chain_ID,
	charming_Reg_solution  * together,
	ofstream & protocol_stream)
{

	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("CLUSTER_FUNCTION_TASK_FILE");

	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("COWARD_VARIABLES_TASK_FILE");



	string path_to_cross_sum_binary_file_all_sufficient  =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID  +
			".cross_sum";

	string path_to_cross_sum_binary_file_jack_nife  =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/_"			+
			PDB_chain_ID  +
			".cross_sum";

	charming_Reg_solution  * all_sufficient =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_all_sufficient  ,
			regression_options_ ) ;

	vector <vector <int> > index_of_included_pool =
		together->get_index_of_included_pool();

	charming_Reg_solution  * jack_nife_model =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_jack_nife,
			regression_options_,
			index_of_included_pool) ;

	vector < vector < double > >			 contact_variables;
	vector < vector < double > >			 det_contact_variables;
	vector < vector < double > >			 predicted_det_distance_set;

	vector <double> correlation_pull_all_sufficient =
		correlation_pull_for_chain (
			PDB_chain_ID,
			all_sufficient  );

	vector <double> correlation_pull_jack_nife =
		correlation_pull_for_chain (
			PDB_chain_ID,
			jack_nife_model );

	protocol_stream << PDB_chain_ID << ": " ;
	for ( int  kk=0; kk < correlation_pull_jack_nife.size(); kk++ )
	{
		PutVaDouble (correlation_pull_jack_nife[ kk ],protocol_stream, 10,3,'l' );
		protocol_stream<< " ";
	}
	protocol_stream<< endl;

	string result_file_name_base_all_sufficient =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/") +
		PDB_chain_ID;

	string result_file_name_base_jack_nife =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/_") +
		PDB_chain_ID;


	int number_of_clasters = dicl_creator_->number_of_clasters ();
	vector < int > base_claster_indexes;
	base_claster_indexes.resize(number_of_clasters ) ;
	int kk;
	for ( kk=0;kk<number_of_clasters ;kk++)
		base_claster_indexes[kk] = kk;

	analyse_predicted_assignment (
	  	PDB_chain_ID,
		jack_nife_model,
		base_claster_indexes);

	for ( kk=0;kk<number_of_clasters ;kk++)
		base_claster_indexes[kk] = number_of_clasters + kk;

	analyse_predicted_assignment_inv (
	  	PDB_chain_ID,
		jack_nife_model,
		base_claster_indexes);


	delete all_sufficient ;
	delete jack_nife_model;
}

vector <double> Abu_Maimonides_Rambam::
correlation_pull_for_chain (
	const string & PDB_chain_ID,
	charming_Reg_solution* current_crs )
{
	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int shift = dicl_creator_->get_shift ();

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		current_crs,
		shift);

	int task_size = det_distance_set[0].size();

	assert ( det_distance_set.size() == predicted_det_distance_set.size()) ;

	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);

	return correlation_pull ;
}
vector <double> Abu_Maimonides_Rambam::
correlation_pull_for_chain_by_together_model (
	const string & PDB_chain_ID )
{

		string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("COWARD_VARIABLES_TASK_FILE");

	string path_to_frequency_extrapolation_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("FREQUENCY_EXTRAPOLATION_TASK_FILE");


	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") +
		sheduler_->option_meaning ("CLUSTER_FUNCTION_TASK_FILE");


	string path_to_cross_sum_binary_file =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			"together"  +
			".cross_sum";

	charming_Reg_solution  * current_crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options_ ) ;

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int shift = dicl_creator_->get_shift ();

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		current_crs,
		shift);

	int task_size = det_distance_set[0].size();



	assert ( det_distance_set.size() == predicted_det_distance_set.size()) ;

	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);


	string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			PDB_chain_ID + string (".compare_prediction") ;

		ofstream out( result_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}

		int number_of_clasters = dicl_creator_->number_of_clasters ();

	vector < vector <int > > quality_matrix ;
	quality_matrix.resize (number_of_clasters) ;
	for (int kk=0;kk<number_of_clasters;kk++)
		quality_matrix[kk].resize(number_of_clasters);

	double quality = 0;

	vector <double> pred_dist_30; pred_dist_30.resize(number_of_clasters);
	vector <double> dist_30;	   dist_30.resize(number_of_clasters);

	int wrong_struct_number = 0;
	int kk;
		for ( kk=0;kk<predicted_det_distance_set.size();kk++)
		{

			for (int zz=0;zz<number_of_clasters;zz++)
			{
				pred_dist_30[zz] = predicted_det_distance_set[kk][zz];
				dist_30[zz] = det_distance_set[kk][zz];
			}
			int predicted_nearest_index =
				get_nearest_claster_index(			pred_dist_30);
			int nearest_index =
				get_nearest_claster_index(			dist_30);



			PutVa (predicted_nearest_index,out,4,2,'l');
			if (det_distance_set[kk][0] == -1 )
			{
				PutVa ("*",out,4,2,'l');
				wrong_struct_number ++ ;
			}
			else
			{
				PutVa (nearest_index ,out,4,2,'l');
				quality_matrix [nearest_index][predicted_nearest_index ] ++;

				if ( predicted_nearest_index == nearest_index )
					quality +=1;

			}


			for (int tt=0;tt<predicted_det_distance_set[0].size();tt++)
			{
				PutVaDouble (predicted_det_distance_set[kk][tt],out,8,3,'l');
				PutVaDouble (det_distance_set[kk][tt],out,8,3,'l');
				out << " ";
			}
			out << endl;

		}

		out << "Correlation pull" <<endl;

		for (int ii=0;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],out,8,3,'l');
//			out.close ();


		out << "*****************************";
		out << "Quality predition matrix" << endl;
		for ( kk=0;kk<number_of_clasters;kk++)
		{
			for (int jj=0;jj<number_of_clasters;jj++)
				PutVa( 	quality_matrix[kk][jj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;
		out << "Quality: " << quality/ ( det_distance_set.size() - wrong_struct_number ) << endl;


	return correlation_pull ;
}

void  Abu_Maimonides_Rambam::
init_global_averages_and_dispersion ()
{

	vector < vector < double > > global_distance_set  =
		read_det_distance_set ( "together");

	int task_size =  global_distance_set.size();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();


	global_averages_.resize(number_of_dicl_variables);
	global_disperse_.resize(number_of_dicl_variables);

	vector < vector < double > >   posrednik;

	posrednik.resize( number_of_dicl_variables );
	for (int ii = 0; ii < number_of_dicl_variables; ii++)
		posrednik[ii].resize(task_size);
	int ii;
	for ( ii=0;ii<task_size;ii++)
	{
		for (int kk=0;kk<number_of_dicl_variables;kk++)
			posrednik[kk][ii] = global_distance_set[ii][kk];
	}

	for ( ii=0;ii<number_of_dicl_variables;ii++)
	{
		calc_dispersion_and_average (
			posrednik[ii],
			global_averages_[ii],
			global_disperse_[ii]) ;
	}

}

/*
void  Abu_Maimonides_Rambam::
init_averages_and_dispersion (  const string & det_distance_file,
							   	vector < double >	& averages,
								vector < double >	& disperse )
{
	vector < vector < double > > distance_set =
		read_det_distance_set ( det_distance_file );

	int task_size =  distance_set.size();
	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	averages.resize(number_of_dicl_variables);
	disperse.resize(number_of_dicl_variables);

	vector < vector < double > >   posrednik;

	posrednik.resize( number_of_dicl_variables );
	for (int ii = 0; ii < number_of_dicl_variables; ii++)
		posrednik[ii].resize(task_size);
	int ii;
	for ( ii=0;ii<task_size;ii++)
	{
		for (int kk=0;kk<number_of_dicl_variables;kk++)
			posrednik[kk][ii] = distance_set[ii][kk];
	}


	for ( ii=0;ii<number_of_dicl_variables;ii++)
	{
		calc_dispersion_and_average (
			posrednik[ii],
			averages[ii],
			disperse[ii]) ;
	}
}

*/



void  Abu_Maimonides_Rambam::
analyse_predicted_assignment (
	  	const string & PDB_chain_ID,
	charming_Reg_solution* current_crs,
	const vector <int> & base_claster_indexes)
{

	init_global_averages_and_dispersion ();

	vector < vector < double > > det_distance_set  =
	read_det_distance_set (PDB_chain_ID);

	int shift = dicl_creator_->get_shift ();

	int number_of_clasters = dicl_creator_->number_of_clasters ();
	assert (base_claster_indexes.size() == number_of_clasters );

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		current_crs,
		shift);

	assert ( det_distance_set.size() == predicted_det_distance_set.size()) ;

	int task_size = det_distance_set[0].size();

	string result_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/") +
		PDB_chain_ID + string (".ass_pred");

	ofstream ass_pred_stream(result_file_name .c_str() );
	if ( ! ass_pred_stream)
	{
		log_stream << "analyse_predicted_assignment (): ERROR -  can't create " << result_file_name << endl;
		cout       << "analyse_predicted_assignment (): ERROR -  can't create " << result_file_name << endl;
		exit (1);
	}


	vector < vector <int > > quality_matrix ;
	quality_matrix.resize (number_of_clasters) ;
	for (int kk=0;kk<number_of_clasters;kk++)
		quality_matrix[kk].resize(number_of_clasters);

	double quality = 0;


	vector <double> d_claster;	d_claster.resize (number_of_clasters);
	vector <double> predicted_d_claster;	predicted_d_claster.resize (number_of_clasters);

//***************** calc. average and dispersion for distance set vector ********
	vector < vector < double > > standardized_predicted_det_distance_set  =
		standaze_distance_set ( predicted_det_distance_set);

	int wrong_struct_number = 0;
	for (int ii=0;ii< det_distance_set.size(); ii++ )
	{
		for (int kk=0;kk<number_of_clasters;kk++)
		{
			d_claster[kk] =  det_distance_set[ii][base_claster_indexes[kk]];
			predicted_d_claster[kk] =  standardized_predicted_det_distance_set[ii][base_claster_indexes[kk]];
		}


		int predicted_nearest_index =
			get_nearest_claster_index(			predicted_d_claster);
		int nearest_index =
			get_nearest_claster_index(			d_claster );

		if ( predicted_nearest_index == nearest_index )
			quality +=1;

		quality_matrix [nearest_index][predicted_nearest_index ] ++;

		PutVa ( nearest_index, ass_pred_stream, 4,2,'l');
		PutVa ( predicted_nearest_index , ass_pred_stream, 4,2,'l');

		int kk;
		for ( kk=0;kk<number_of_clasters;kk++)
		{
			PutVaDouble ( 	d_claster [kk],			ass_pred_stream, 8,3,'l');
			PutVaDouble ( 	predicted_d_claster[kk], ass_pred_stream, 8,3,'l');

			ass_pred_stream << "      ";
		}
		ass_pred_stream << endl;
	}

	ass_pred_stream << "*****************************";
	ass_pred_stream << "Quality predition matrix" << endl;
	for ( int kk=0;kk<number_of_clasters;kk++)
	{
		for (int jj=0;jj<number_of_clasters;jj++)
			PutVa( 	quality_matrix[kk][jj],	ass_pred_stream, 8,3,'l');
		ass_pred_stream << endl;
	}
	ass_pred_stream << "Length: " << det_distance_set.size()<< endl;
	ass_pred_stream << "Quality: " << quality/ ( det_distance_set.size() - wrong_struct_number )<< endl;
}

void  Abu_Maimonides_Rambam::
analyse_predicted_assignment_inv (
	  	const string & PDB_chain_ID,
	charming_Reg_solution* current_crs,
	const vector <int> & base_claster_indexes)
{
	vector < vector < double > > det_distance_set  =
	read_det_distance_set (PDB_chain_ID);

	int shift = dicl_creator_->get_shift ();

	int number_of_clasters = dicl_creator_->number_of_clasters ();
	assert (base_claster_indexes.size() == number_of_clasters );

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		current_crs,
		shift);

	assert ( det_distance_set.size() == predicted_det_distance_set.size()) ;

	int task_size = det_distance_set[0].size();

	string result_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/") +
		PDB_chain_ID + string (".ass_pred_inv");

	ofstream ass_pred_stream(result_file_name .c_str() );
	if ( ! ass_pred_stream)
	{
		log_stream << "analyse_predicted_assignment (): ERROR -  can't create " << result_file_name << endl;
		cout       << "analyse_predicted_assignment (): ERROR -  can't create " << result_file_name << endl;
		exit (1);
	}


	vector < vector <int > > quality_matrix ;
	quality_matrix.resize (number_of_clasters) ;
	for (int kk=0;kk<number_of_clasters;kk++)
		quality_matrix[kk].resize(number_of_clasters);

	double quality = 0;


	vector <double> d_claster;	d_claster.resize (number_of_clasters);
	vector <double> predicted_d_claster;	predicted_d_claster.resize (number_of_clasters);

//***************** calc. average and dispersion for distance set vector ********
	vector < vector < double > > standardized_predicted_det_distance_set  =
		standaze_distance_set ( predicted_det_distance_set);



	for (int ii=0;ii< det_distance_set.size(); ii++ )
	{

		for (int kk=0;kk<number_of_clasters;kk++)
		{
			d_claster[kk] =  - det_distance_set[ii][base_claster_indexes[kk]];
			//predicted_d_claster[kk] =  predicted_det_distance_set[ii][base_claster_indexes[kk]];
			predicted_d_claster[kk] =  - standardized_predicted_det_distance_set[ii][base_claster_indexes[kk]];
		}


		int predicted_nearest_index =
			get_nearest_claster_index(			predicted_d_claster);
		int nearest_index =
			get_nearest_claster_index(			d_claster );

		if ( predicted_nearest_index == nearest_index )
			quality +=1;

		quality_matrix [nearest_index][predicted_nearest_index ] ++;

		PutVa ( nearest_index, ass_pred_stream, 4,2,'l');
		PutVa ( predicted_nearest_index , ass_pred_stream, 4,2,'l');

		for ( int kk=0;kk<number_of_clasters;kk++)
		{
			PutVaDouble ( 	d_claster [kk],			ass_pred_stream, 8,3,'l');
			PutVaDouble ( 	predicted_d_claster[kk], ass_pred_stream, 8,3,'l');

			ass_pred_stream << "      ";
		}
		ass_pred_stream << endl;
	}

	ass_pred_stream << "*****************************";
	ass_pred_stream << "Quality predition matrix" << endl;
	ass_pred_stream << "Quality predition matrix" << endl;
	int kk;
	for ( kk=0;kk<number_of_clasters;kk++)
	{
		for (int jj=0;jj<number_of_clasters;jj++)
			PutVa( 	quality_matrix[kk][jj],	ass_pred_stream, 8,3,'l');
		ass_pred_stream << endl;
	}
	ass_pred_stream << "Length: " << det_distance_set.size()<< endl;
	ass_pred_stream << "Quality: " << quality/ det_distance_set.size() << endl;
}


int Abu_Maimonides_Rambam::
get_nearest_claster_index( 	const vector <double> & distance_set )
{
	vector < Pair_int_double > indexed_dist_store;  		indexed_dist_store.clear();

	for ( int kk=0;kk<distance_set.size(); kk++)
		indexed_dist_store.push_back( Pair_int_double (kk,distance_set[kk]) );

	sort (indexed_dist_store.begin(),indexed_dist_store.end() );
	int		nearest_index 	=	indexed_dist_store.front().index() ;

	return nearest_index ;

}



vector < vector < double > > Abu_Maimonides_Rambam::
read_det_distance_set (const string & PDB_chain_ID)
{
	string current_distance_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		PDB_chain_ID +
		".dist_data";

	ifstream in( current_distance_file_name.c_str() ,ios::binary);
	if ( ! in )
	{
		log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
		cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

		exit (1);
	}

	int number_of_cases ;
	int diva_number_of_variables ;

	in.read ( (char* ) & number_of_cases ,	sizeof (int)  );
	in.read ( (char* ) & diva_number_of_variables,	sizeof (int)  );
	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));

	vector < vector < double > > distance_set;
	distance_set.resize (number_of_cases) ;
	for (int jj=0; jj< number_of_cases ;jj++)
		distance_set[jj].resize (diva_number_of_variables );

	for (int ii=0; ii< diva_number_of_variables ;ii++)
	{
		in.read ( (char* )	t_arr,		number_of_cases * sizeof(double));
//		memset (				t_arr	,0,	number_of_cases * sizeof(double));
		for (int jj=0; jj< number_of_cases ;jj++)
			 distance_set [jj][ii] = t_arr [jj] ;
	}
	delete [] t_arr	;

	in.close();

	return distance_set;
}


vector < vector < double > > Abu_Maimonides_Rambam::
read_det_distance_set (const string & PDB_chain_ID , const string & extension)
{
	string current_distcance_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		PDB_chain_ID +
		extension;
		//".dist_data";


	ifstream in( current_distcance_file_name.c_str() ,ios::binary);
	if ( ! in )
	{
		log_stream << "read_det_distance_set() ERROR -  can't read " << current_distcance_file_name  << endl;
		cout       << "read_det_distance_set() ERROR -  can't read " << current_distcance_file_name  << endl;

		exit (1);
	}

	int number_of_cases ;
	int diva_number_of_variables ;

	in.read ( (char* ) & number_of_cases ,	sizeof (int)  );
	in.read ( (char* ) & diva_number_of_variables,	sizeof (int)  );
	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));

	vector < vector < double > > distance_set;
	distance_set.resize (number_of_cases) ;
	for (int jj=0; jj< number_of_cases ;jj++)
		distance_set[jj].resize (diva_number_of_variables );

	for (int ii=0; ii< diva_number_of_variables ;ii++)
	{
		in.read ( (char* )	t_arr,		number_of_cases * sizeof(double));
		for (int jj=0; jj< number_of_cases ;jj++)
			 distance_set [jj][ii] = t_arr [jj] ;
	}
	delete [] t_arr	;

	in.close();

	return distance_set;
}


void Abu_Maimonides_Rambam::
make_prediction_by_external_PDB (
	const string & PDB_chain_ID	)
{
		//	string check1= configuration.option_meaning("Path_to_Chain_store")  + string ("sheduler");

  	Sheduler *chain_store_sheduler		= new Sheduler     ( configuration.option_meaning("Path_to_Chain_store")  + string ("sheduler") ) ;

		string check2 = chain_store_sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str();
	double Treshold_C_N_Distance	=	atof( chain_store_sheduler->option_meaning("TRESHOLD_C_N_DISTANCE").c_str() );


	double distance_epsilon			=	atof( chain_store_sheduler->option_meaning("DISTANCE_EPSILON").c_str() );
	double angle_epsilon			=	atof( chain_store_sheduler->option_meaning("ANGLE_EPSILON").c_str() );;

	delete chain_store_sheduler;

// *** ñíà÷àëà ñäåëàåì
//		Chain_Residue_Set crs ( PDB_chain_ID );
//		crs.print_protocol();




		Chain_Residue_Set crs(
			PDB_chain_ID ,
			Treshold_C_N_Distance,
			distance_epsilon,
			angle_epsilon);


		if ( ! crs.is_pdb_file() )
		{
			cout << "PDB file or chain not found" << endl;
			exit (-1);
		}
		if ( ! crs.is_accord_seqres_atom() )
		{
			cout << "Sequence by SEQRES contradict given by ATOM pull" << endl;
			exit(-1);
		}
		else
			crs.save_as_binary();

// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************
		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID +
			".dist_data";

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}


		string predicted_current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID +
			".predicted_dist_data";

		ofstream predicted_distdata_stream( predicted_current_distance_file_name.c_str() ,ios::binary);
		if ( ! predicted_distdata_stream)
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}


	Chain_binary *chain = new Chain_binary ( PDB_chain_ID );
// ************ prepare dicl_creator variables ******************
	//	vector < vector < double > >  set_of_coordinate_in_clasters_system;

// LINUx time

/*		chain->positioning_chain_by_clasters_set (
			claster_motif_coordinates_,
			fragment_length_,
			number_of_classes_,
			set_of_coordinate_in_clasters_system_);
*/

		dicl_creator_->process_chain(chain);

		vector < vector < double > >  set_of_coordinate_in_clasters_system =
            dicl_creator_->get_sophisticated_distance_variables();

			//set_of_coordinate_in_clasters_system);
//****************************************************************

		write_distdata_for_regression (
			distdata_stream,
			set_of_coordinate_in_clasters_system);

		distdata_stream.close();
//*******************************************************************************



// *************** init together *********************
	string path_to_cross_sum_binary_file_all_sufficient  =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together")      +
		".cross_sum";

	charming_Reg_solution  * together=
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_all_sufficient  ,
			regression_options_ ) ;


		int shift = dicl_creator_->get_shift ();

		vector < vector < double > >  prediction   = make_prediction (
			PDB_chain_ID,
			together,
			shift);


			write_distdata_for_regression (
			predicted_distdata_stream,
			prediction);

			predicted_distdata_stream.close();

//		vector <double> correllation_pull =
//			correlation_pull_for_chain_by_together_model (
//				PDB_chain_ID );

		delete together;
		delete chain;

}
vector < vector < double > > Abu_Maimonides_Rambam::
	make_prediction_by_sequence (
	const string & sequence,
	charming_Reg_solution* current_crs	)
{


	int shift = dicl_creator_->get_shift ();

	int residue_number_in_chain	= 	sequence.length();
// ************ prepare cowa_creator variables ******************

//        cout << "before cowa_creator_->process_chain (	sequence );" << endl;
	vector < vector < double > > sophisticated_variables;
	cowa_creator_->process_chain (	sequence );
	sophisticated_variables = cowa_creator_->get_sophisticated_variables();
  //      cout << "after cowa_creator_->process_chain (	sequence );" << endl;


//***************************************************************


// ************ prepare frva_creator variables ******************
		//vector < vector < double > >	frva_sophisticated_variables;
		//frva_creator_->process_chain (
		//	sequence,
		//	frva_sophisticated_variables);
//***************************************************************





	double *  absolute_term_pool =
		current_crs ->get_absolute_term_pool			();
	double ** regression_coefficient_pool =
		current_crs ->get_regression_coefficient_pool	() ;

	vector < vector < double > > predicted_det_distance_set;
	int local_number_of_cases = sequence.size() - 2*shift;
	predicted_det_distance_set.resize( local_number_of_cases  ) ;

	int number_of_predictors = cowa_creator_->get_number_of_variables();
	//+frva_creator_->get_number_of_variables();


	int number_of_dependent  = dicl_creator_ ->get_number_of_variables() ;

	for (int ii=0;ii<local_number_of_cases;ii++)
		predicted_det_distance_set[ii].resize(number_of_dependent);

	///*********************
/*
        log_stream <<		" absolute_term_pool : ";
            for (int JJJ=0; JJJ<number_of_dependent;JJJ++)
                log_stream <<	absolute_term_pool[JJJ]	<< " ";

        log_stream <<	endl;

        log_stream <<		" regression_coefficient_pool : ";
            for (int JJJ=0; JJJ<number_of_dependent;JJJ++)
            {
                for (int ZZZ=0; ZZZ<number_of_predictors;ZZZ++)
                   log_stream <<  regression_coefficient_pool[JJJ][ZZZ] << " ";

                log_stream << endl;

            }
*/
    ///*********************************

	int ii;
	for (  ii=0;ii< local_number_of_cases ; ii++)
	{
		for (int jj=0; jj<number_of_dependent; jj++  )
		{
			double current_value =
				single_prediction_for_any_known_regression_model (
					sophisticated_variables[ii+shift],
					absolute_term_pool[jj],
					regression_coefficient_pool[jj],
					number_of_predictors );

			predicted_det_distance_set [ii][jj] =  current_value;
		}
	}
	return predicted_det_distance_set;


}


vector < vector < double > > Abu_Maimonides_Rambam::
make_prediction (
	const string & PDB_chain_ID,
	charming_Reg_solution* current_crs,
	const int shift)
{



	Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID );

	string sequence = chain ->get_sequence();

	int residue_number_in_chain	= 	sequence.length();
// ************ prepare cowa_creator variables ******************
	vector < vector < double > > sophisticated_variables;
	cowa_creator_->process_chain ( sequence );
	sophisticated_variables = cowa_creator_->get_sophisticated_variables();
//***************************************************************

// ************ prepare frva_creator variables ******************
		//vector < vector < double > >	frva_sophisticated_variables;
		//frva_creator_->process_chain (
		//	sequence,
		//	frva_sophisticated_variables);
//***************************************************************

	//	assert (cowa_sophisticated_variables.size() == frva_sophisticated_variables.size()) ;
		assert (sophisticated_variables.size() == sequence.size()) ;



	delete chain;


	double *  absolute_term_pool =
		current_crs ->get_absolute_term_pool			();
	double ** regression_coefficient_pool =
		current_crs ->get_regression_coefficient_pool	() ;

	vector < vector < double > > predicted_det_distance_set;
	int local_number_of_cases = sequence.size() - 2*shift;
	predicted_det_distance_set.resize( local_number_of_cases  ) ;

	int number_of_predictors = cowa_creator_->get_number_of_variables();
		//+								frva_creator_->get_number_of_variables();


	int number_of_dependent  = dicl_creator_ ->get_number_of_variables() ;

	for (int ii=0;ii<local_number_of_cases;ii++)
		predicted_det_distance_set[ii].resize(number_of_dependent);

	int ii;
	for (  ii=0;ii< local_number_of_cases ; ii++)
	{
		for (int jj=0; jj<number_of_dependent; jj++  )
		{
			double current_value =
				single_prediction_for_any_known_regression_model (
					sophisticated_variables[ii+shift],
					absolute_term_pool[jj],
					regression_coefficient_pool[jj],
					number_of_predictors );

			predicted_det_distance_set [ii][jj] =  current_value;
		}
	}
	return predicted_det_distance_set;
}

vector < vector < double > > Abu_Maimonides_Rambam::
standaze_distance_set_gentle (
		const vector < vector < double > > & predicted_det_distance_set,
		vector < double >	& averages,
		vector < double > 	& disperse)
{


	vector < vector < double > >  standardized_predicted_det_distance_set = predicted_det_distance_set;

	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();
	assert ( number_of_dicl_variables  == predicted_det_distance_set[0].size()  ) ;

	int task_size =  predicted_det_distance_set.size();

	vector < vector < double > >   posrednik;

	posrednik.resize( number_of_dicl_variables );
	for (int ii = 0; ii < number_of_dicl_variables; ii++)
		posrednik[ii].resize(task_size);
	int ii;
	for ( ii=0;ii<task_size;ii++)
	{
		for (int kk=0;kk<number_of_dicl_variables;kk++)
			posrednik[kk][ii] = predicted_det_distance_set[ii][kk];
	}

	for ( ii = 0; ii < number_of_dicl_variables; ii++)
	{
		standardize_to_known_gauss (
			posrednik[ii],
			averages[ii],
			disperse[ii]);
	}


	for ( ii=0;ii<task_size;ii++)
	{
		for (int kk=0;kk<number_of_dicl_variables;kk++)
			standardized_predicted_det_distance_set[ii][kk] = posrednik[kk][ii];
	}

	return standardized_predicted_det_distance_set;


}




vector < vector < double > > Abu_Maimonides_Rambam::
	standaze_distance_set (
		const vector < vector < double > > & predicted_det_distance_set)
{


	vector < vector < double > >  standardized_predicted_det_distance_set = predicted_det_distance_set;

	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();
	assert ( number_of_dicl_variables  == predicted_det_distance_set[0].size()  ) ;

	int task_size =  predicted_det_distance_set.size();

	vector < vector < double > >   posrednik;

	posrednik.resize( number_of_dicl_variables );
	for (int ii = 0; ii < number_of_dicl_variables; ii++)
		posrednik[ii].resize(task_size);
	int ii;
	for ( ii=0;ii<task_size;ii++)
	{
		for (int kk=0;kk<number_of_dicl_variables;kk++)
			posrednik[kk][ii] = predicted_det_distance_set[ii][kk];
	}

	for ( ii = 0; ii < number_of_dicl_variables; ii++)
	{
		standardize_to_known_gauss (
			posrednik[ii],
			global_averages_[ii],
			global_disperse_[ii]);
	}


	for ( ii=0;ii<task_size;ii++)
	{
		for (int kk=0;kk<number_of_dicl_variables;kk++)
			standardized_predicted_det_distance_set[ii][kk] = posrednik[kk][ii];
	}

	return standardized_predicted_det_distance_set;
}




void Abu_Maimonides_Rambam::
prepare_discriminant_data ()
{

	string path_to_cross_sum_binary_file_all_sufficient  =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together")+
		".cross_sum";

	charming_Reg_solution  * together=
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_all_sufficient  ,
			regression_options_ ) ;


	string da_data_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/da_data.") +
		regression_options_->option_meaning("FISHER_INCLUDE") ;

	ofstream da_stream(da_data_file_name .c_str() );
	if ( ! da_stream)
	{
		log_stream << "prepare_discriminant_data ()(): ERROR -  can't create " << da_data_file_name << endl;
		cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << da_data_file_name << endl;
		exit (1);
	}

	for (int ii = 0; ii < accepted_chain_ID_list_.size(); ii++ )
	{
		add_single_chain_discriminant_data (
			accepted_chain_ID_list_[ii],
			together,
			da_stream);

		cout << ii << "   " << accepted_chain_ID_list_[ii] << endl;
	}

	delete together;
	da_stream.close();
}

void Abu_Maimonides_Rambam::
add_single_chain_discriminant_data (
	const string PDB_chain_ID,
	charming_Reg_solution  * together,
	ofstream & da_stream)
{

	string path_to_cross_sum_binary_file_jack_nife  =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/_"			+
			PDB_chain_ID  +
			".cross_sum";

	vector <vector <int> > index_of_included_pool =
		together->get_index_of_included_pool();

	charming_Reg_solution  * jack_nife_model =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_jack_nife,
			regression_options_,
			index_of_included_pool) ;

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int shift = dicl_creator_->get_shift ();

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		jack_nife_model,
		shift);

	int number_of_clasters = dicl_creator_->number_of_clasters();

	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	vector <double> d_claster;	d_claster.resize (number_of_clasters);

	for (int ii=0;ii< det_distance_set.size(); ii++ )
	{
		for (int kk=0;kk<number_of_clasters;kk++)
		{
			d_claster[kk] =  det_distance_set[ii][kk]; // ïåðâûå êëàñòåðû - ïåðâûå ïåðåìåííûå
		}

		int nearest_index = 			get_nearest_claster_index(			d_claster );

		PutVa ( nearest_index, da_stream, 4,2,'l');
		int kk;
		for ( kk=0;kk<number_of_dicl_variables;kk++)
		{
			PutVaDouble ( 	predicted_det_distance_set[ii][kk], da_stream, 10,6,'l');
			da_stream << " ";
		}

		da_stream << endl;
	}
	delete jack_nife_model;
}

void Abu_Maimonides_Rambam::
prepare_correction_matrix ()
{
	string path_to_cross_sum_binary_file_all_sufficient  =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		string("together")+
		".cross_sum";

	charming_Reg_solution  * together=
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_all_sufficient,
			regression_options_ ) ;


	string X_matrix_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/X.matrix");

	string Y_matrix_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + 		string ("/plain_results/Y.matrix");

	ofstream X_stream(X_matrix_name.c_str() );
	if ( ! X_stream)
	{
		log_stream << "prepare_discriminant_data ()(): ERROR -  can't create " << X_matrix_name << endl;
		cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << X_matrix_name << endl;
		exit (1);
	}

	ofstream Y_stream(Y_matrix_name.c_str() );
	if ( ! Y_stream)
	{
		log_stream << "prepare_discriminant_data ()(): ERROR -  can't create " << Y_matrix_name << endl;
		cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << Y_matrix_name << endl;
		exit (1);
	}

	for (int ii = 0; ii < accepted_chain_ID_list_.size(); ii++ )
	{
		add_single_chain_to_XY_matrix (
			accepted_chain_ID_list_[ii],
			together,
			X_stream,
			Y_stream);

		cout << ii << "   " << accepted_chain_ID_list_[ii] << endl;
	}

	delete together;
	X_stream.close();
	Y_stream.close();
}

void Abu_Maimonides_Rambam::
add_single_chain_to_XY_matrix (
   	const string PDB_chain_ID,
	charming_Reg_solution  * together,
	ofstream & X_stream,
	ofstream & Y_stream	)
{

	string path_to_cross_sum_binary_file_jack_nife  =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/_"			+
		PDB_chain_ID  +
		".cross_sum";

	vector <vector <int> > index_of_included_pool =
		together->get_index_of_included_pool();

	charming_Reg_solution  * jack_nife_model =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file_jack_nife,
			regression_options_,
			index_of_included_pool) ;

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int shift = dicl_creator_->get_shift ();

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		jack_nife_model,
		shift);

	int number_of_clasters = dicl_creator_->number_of_clasters();

	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

	vector <double> d_claster;	d_claster.resize (number_of_clasters);

	for (int ii=0;ii< det_distance_set.size(); ii++ )
	{
		for ( int kk=0;kk<number_of_dicl_variables;kk++)
		{
			PutVaDouble ( 	det_distance_set[ii][kk], X_stream, 8,3,'l');
			X_stream<< "  ";
		}
		X_stream<< endl;
		int kk;
		for ( kk=0;kk<number_of_dicl_variables;kk++)
		{
			PutVaDouble ( 	predicted_det_distance_set[ii][kk], Y_stream, 8,3,'l');
			Y_stream << "  ";
		}
		Y_stream << endl;
	}
	delete jack_nife_model;
}
vector <vector <double> > Abu_Maimonides_Rambam::
convert_to_Z_value (
	const vector < vector < double > > & distance_set,
	const vector <double > & averages,
	const vector <double > & disperse )
{
	int row_number = distance_set.size() ;
	int col_number = distance_set[0].size();

	vector <vector < double > > sta_distance_set;
	sta_distance_set.resize(row_number );
	for (int ii=0;ii<row_number;ii++ )
		sta_distance_set[ii].resize(col_number);
	int ii;

	for (  ii=0;ii<row_number ;ii++)
	{
		for ( int kk=0;kk<col_number ;kk++)
			sta_distance_set[ii][kk] = ( distance_set[ii][kk] - averages [kk] ) / disperse[kk];
	}

	return sta_distance_set;
}
/*
vector < vector < int > > Abu_Maimonides_Rambam::
prepare_wu_blast_index (
	const vector < vector < double > > & sta_det_distance_set )
{

	vector < vector < int > > wu_blast_index ;
	int row_number = sta_det_distance_set.size() ;
	int col_number = sta_det_distance_set[0].size();

	wu_blast_index.resize( row_number ) ;
	for (int ii=0;ii<row_number ;ii++)
		wu_blast_index[ii].resize(col_number );

	int ii;
	for (ii=0;ii<row_number ;ii++)
	{
		for (int kk=0; kk<col_number; kk++)
		{
			double current_prob = get_probability_by_Z_value ( sta_det_distance_set [ii][kk]) ;
			current_prob *= 19;
			int current_index = (int ) current_prob ;
			wu_blast_index[ii][kk] = current_index ;
		}
	}

	return wu_blast_index;
}
*/
void Abu_Maimonides_Rambam::
put_wu_blasst_result (
	const string & result_name,
	const vector < vector <int> > & wu_blast_index  )
{
	ofstream out_stream(result_name.c_str() );
	if ( ! out_stream)
	{
		log_stream	<< " can't create " << result_name<< endl;
		cout		 << " can't create " << result_name<< endl;
		exit (1);
	}

	for (int ii=0;ii<wu_blast_index.size();ii++ )
	{
		for (int kk=0;kk<8;kk++ )
			PutVa (wu_blast_index[ii][kk], out_stream, 5, 2, 'l');
		out_stream << endl;
	}
}

/// after june 11

charming_Reg_solution  * Abu_Maimonides_Rambam::
init_together_model ()
{

	string path_to_cross_sum_binary_file =
		configuration.option_meaning("Path_to_Model_store") +
		name_					+
		"/cross_sum/"			+
		"together"  +
		".cross_sum";

	charming_Reg_solution  * current_crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options_ ) ;

	return current_crs;

// íå çàáûòü ïîäòåðåòü ïîòîì current_crs
}
vector < vector < double > > Abu_Maimonides_Rambam::
single_prediction_by_existing_model (
	const string &PDB_chain_ID,
	charming_Reg_solution  * current_crs )
{
	int shift = dicl_creator_->get_shift ();

	vector < vector < double > > predicted_det_distance_set  =
		make_prediction (
		PDB_chain_ID,
		current_crs,
		shift);

	return predicted_det_distance_set;
}

void Abu_Maimonides_Rambam::
analyse_single_prediction_by_existing_model (
    const string &PDB_chain_ID,
    charming_Reg_solution  * current_crs ,
    ofstream & protocol_stream,
    double &quality_sum,
    int &valid_coord_res_num,
    int &res_num)
{


	vector < vector < double > > predicted_det_distance_set  =
		single_prediction_by_existing_model (PDB_chain_ID,current_crs );

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int task_size = det_distance_set[0].size();
	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);



	string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			PDB_chain_ID + string (".compare_prediction") ;


		ofstream out( result_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}

		int number_of_clasters = dicl_creator_->number_of_clasters ();

		vector < vector <int > > quality_matrix ;
		quality_matrix.resize (number_of_clasters) ;
		for (int kk=0;kk<number_of_clasters;kk++)
			quality_matrix[kk].resize(number_of_clasters);

		double quality = 0;

		int wrong_struct_number = 0;
		int kk;
		for ( kk=0;kk<predicted_det_distance_set.size();kk++)
		{

			predicted_det_distance_set[kk].resize(number_of_clasters);
			det_distance_set[kk].resize(number_of_clasters);

			int predicted_nearest_index =
				get_nearest_claster_index(			predicted_det_distance_set[kk]);
			int nearest_index =
				get_nearest_claster_index(			det_distance_set[kk]);



			PutVa (predicted_nearest_index,out,4,2,'l');


			if (det_distance_set[kk][0] == -1 )
			{
				PutVa ("*",out,4,2,'l');
				wrong_struct_number ++ ;
			}
			else
			{
				PutVa (nearest_index ,out,4,2,'l');
				quality_matrix [nearest_index][predicted_nearest_index ] ++;

				if ( predicted_nearest_index == nearest_index )
					quality +=1;

			}


			for (int tt=0;tt<predicted_det_distance_set[0].size();tt++)
			{
				PutVaDouble (predicted_det_distance_set[kk][tt],out,8,3,'l');
				PutVaDouble (det_distance_set[kk][tt],out,8,3,'l');
				out << " ";

			//	PutVaDouble (predicted_det_distance_set[kk][tt],cout,8,3,'l');
			//	PutVaDouble (det_distance_set[kk][tt],cout,8,3,'l');
			//	out << " ";

			}
			out << endl;

		}

		out << "Correlation pull" <<endl;

		for (int ii=0;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],out,8,3,'l');
//			out.close ();


		out << "*****************************" << endl;
		out << "Quality predition matrix" << endl;
		for ( kk=0;kk<number_of_clasters;kk++)
		{
			for (int jj=0;jj<number_of_clasters;jj++)
				PutVa( 	quality_matrix[kk][jj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;
		out << "Quality: " << quality/ ( det_distance_set.size() - wrong_struct_number ) << endl;

// protocol


		PutVaDouble ( quality/ ( det_distance_set.size() - wrong_struct_number ),protocol_stream,8,3,'l');

		protocol_stream << PDB_chain_ID << " ";
		int ii;
		for ( ii=0;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],protocol_stream,8,3,'l');
		protocol_stream << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;


        quality_sum         = quality;
        valid_coord_res_num = det_distance_set.size() - wrong_struct_number;
        res_num             = det_distance_set.size();


		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID +
			".dist_data_predicted";


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			predicted_det_distance_set);



		out.close();
}


void Abu_Maimonides_Rambam::
compare_ready_observation_prediction (   // Ïîêà òîëüêî äëÿ îáðàòíûé âåëè÷èí ðàññîÿíèÿ
const string &PDB_chain_ID)
{
	string extension1= string(".predicted_dist_data");
	string extension2= string(".dist_data");
	vector < vector < double > > predicted_det_distance_set  =
		read_det_distance_set (PDB_chain_ID,extension1);

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID,extension2);


//***************

		int task_size = det_distance_set[0].size();
	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);



	string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			PDB_chain_ID + string (".compare_prediction_INV") ;

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}

		int number_of_clasters = dicl_creator_->number_of_clasters ();

		vector < vector <int > > quality_matrix ;
		quality_matrix.resize (number_of_clasters) ;
		int kk;
		for ( kk=0;kk<number_of_clasters;kk++)
			quality_matrix[kk].resize(number_of_clasters);

		double quality = 0;

		int wrong_struct_number = 0;

		for ( kk=0;kk<predicted_det_distance_set.size();kk++)
		{

			for (int ttt=0;ttt<number_of_clasters;ttt++)
			{
				predicted_det_distance_set	[kk][ttt] = - predicted_det_distance_set[kk][number_of_clasters+ttt];
				det_distance_set			[kk][ttt] = - det_distance_set			[kk][number_of_clasters+ttt];
			}

			predicted_det_distance_set[kk].resize(number_of_clasters);
			det_distance_set[kk].resize(number_of_clasters);

			int predicted_nearest_index =
				get_nearest_claster_index(			predicted_det_distance_set[kk]);
			int nearest_index =
				get_nearest_claster_index(			det_distance_set[kk]);



			PutVa (predicted_nearest_index,out,4,2,'l');
			if (det_distance_set[kk][0] == -1.0 )  // FIX STRONG ATTENSION
			{
				PutVa ("*",out,4,2,'l');
				wrong_struct_number ++ ;
			}
			else
			{
				PutVa (nearest_index ,out,4,2,'l');
				quality_matrix [nearest_index][predicted_nearest_index ] ++;

				if ( predicted_nearest_index == nearest_index )
					quality +=1;

			}


			for (int tt=0;tt<predicted_det_distance_set[0].size();tt++)
			{
				PutVaDouble (predicted_det_distance_set[kk][tt],out,8,3,'l');
				PutVaDouble (det_distance_set[kk][tt],out,8,3,'l');
				out << " ";

				PutVaDouble (predicted_det_distance_set[kk][tt],cout,8,3,'l');
				PutVaDouble (det_distance_set[kk][tt],cout,8,3,'l');
				cout << " ";

			}
			out << endl;
			cout << endl;

		}

		out << endl << "Correlation pull" <<endl;

		for (int ii=number_of_clasters;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],out,8,3,'l');
//			out.close ();


		out << "*****************************";
		out << "Quality predition matrix" << endl;
		for ( kk=0;kk<number_of_clasters;kk++)
		{
			for (int jj=0;jj<number_of_clasters;jj++)
				PutVa( 	quality_matrix[kk][jj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;
		out << "Quality: " << quality/ ( det_distance_set.size() - wrong_struct_number ) << endl;

// protocol


	//	PutVaDouble ( quality/ ( det_distance_set.size() - wrong_struct_number ),protocol_stream,8,3,'l');


}

void Abu_Maimonides_Rambam::
analyse_single_prediction_by_existing_model_exotic_dep_val(
	const string &PDB_chain_ID,
	charming_Reg_solution  * current_crs,
	ofstream & protocol_stream)
{
	vector < vector < double > > predicted_det_distance_set =
		single_prediction_by_existing_model(PDB_chain_ID, current_crs);

	vector < vector < double > > det_distance_set =
		read_det_distance_set(PDB_chain_ID);

	int task_size = det_distance_set[0].size();
	vector <double> correlation_pull = calculate_correlation_pull(
		predicted_det_distance_set,
		det_distance_set,
		task_size);

	string result_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		name_ + string("/plain_results/") +
		PDB_chain_ID + string(".exotic_dep_val");

	ofstream out(result_file_name.c_str());
	if (!out)
	{
		log_stream << "result_file_name   can't create " << result_file_name << endl;
		cout << "result_file_name   can't create " << result_file_name << endl;
		exit(1);
	}

	int number_of_clasters = dicl_creator_->number_of_clasters();
	int number_of_variables = dicl_creator_->get_number_of_variables();

	int first_exotic = 2 * number_of_clasters;
	int wrong_struct_number = 0;

	for (int kk = 0; kk < predicted_det_distance_set.size(); kk++)
	{


		for (int tt = first_exotic; tt < number_of_variables; tt++)
		{
			if (det_distance_set[kk][0] == -1.0)  // FIX STRONG ATTENSION
			{
				PutVa("*", out, 8, 3, 'l');
				wrong_struct_number++;
			}
			else
				PutVaDouble(det_distance_set[kk][tt], out, 8, 3, 'l');

			PutVaDouble(predicted_det_distance_set[kk][tt], out, 8, 3, 'l');

			out << endl;
		}
	}

	out << endl << "Correlation pull" << endl;

	for (int ii = first_exotic; ii<correlation_pull.size(); ii++)
		PutVaDouble(correlation_pull[ii], out, 8, 3, 'l');
	out << endl;

	out << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size() << endl;
}
/// ******************************
#include "../pb16_to_index.h"

void Abu_Maimonides_Rambam::
single_prediction_by_existing_model_INV_for_server (
	string &PDB_chain_ID,
	charming_Reg_solution  * current_crs ,
	ofstream & result_out)
{
	vector < vector < double > > predicted_det_distance_set  =
		single_prediction_by_existing_model (PDB_chain_ID,current_crs );

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int task_size = det_distance_set[0].size();
	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);

////    int number_of_clasters = ->number_of_clasters ();

   	int number_of_clasters = dicl_creator_->number_of_clasters();


    vector < vector <int > > quality_matrix ;
    quality_matrix.resize (number_of_clasters) ;
    int kk;
    for ( kk=0;kk<number_of_clasters;kk++)
        quality_matrix[kk].resize(number_of_clasters);

    double quality = 0;

    int wrong_struct_number = 0;


    vector <int> pni; pni.resize(  predicted_det_distance_set.size() );
    vector <int> oni; oni.resize(  predicted_det_distance_set.size() );

        vector <double>  nearest_distance;nearest_distance.resize(   predicted_det_distance_set.size() );

    for ( kk=0;kk<predicted_det_distance_set.size();kk++)
    {

        for (int ttt=0;ttt<number_of_clasters;ttt++)
        {
            predicted_det_distance_set	[kk][ttt] = - predicted_det_distance_set[kk][number_of_clasters+ttt];
            det_distance_set			[kk][ttt] = - det_distance_set			[kk][number_of_clasters+ttt];
        }

        predicted_det_distance_set[kk].resize(number_of_clasters);
        det_distance_set[kk].resize(number_of_clasters);

        int predicted_nearest_index =   get_nearest_claster_index(			predicted_det_distance_set[kk]);
        int nearest_index =            get_nearest_claster_index(			det_distance_set[kk]);


        pni[kk]=predicted_nearest_index;
        nearest_distance[kk]=predicted_det_distance_set[kk][ predicted_nearest_index  ];

        if (det_distance_set[kk][0] == -1.0 )  // FIX STRONG ATTENSION
        {
            oni[kk]=-1;  // structure not assigned
            wrong_struct_number ++ ;
        }
        else
        {
            oni[kk]=nearest_index;
            quality_matrix [nearest_index][predicted_nearest_index ] ++;
            if ( predicted_nearest_index == nearest_index )
                quality +=1;

        }

    }

    Chain_binary *chain = new Chain_binary(PDB_chain_ID);

    string sequence = chain->get_sequence();
    vector <string> chain_residue_number = chain->get_in_chain_residue_number();
    delete chain;


    string predicted_sequence;  predicted_sequence  .resize(    predicted_det_distance_set.size()   );
    string observed_sequence;   observed_sequence   .resize(    predicted_det_distance_set.size()   );

    for (int ii=0; ii<predicted_det_distance_set.size();ii++ )
    {
        predicted_sequence  [ii]    = get_letter_pb16 ( pni[ii] );
        observed_sequence   [ii]    = get_letter_pb16 ( oni[ii] );
    }

    int shift = dicl_creator_->get_shift ();


    result_out << "PDB ID: <b>" <<  PDB_chain_ID.substr(0,4) << "</b>\tchain ID :"
               << PDB_chain_ID[4] << "\t\t";

   result_out<< "Prediction Quality (Q16):<b> " << quality/ ( det_distance_set.size() - wrong_struct_number ) << "</b>\t"
              << "Amino acids having 3D : " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<<endl<<endl;



     for (int ii=0; ii<predicted_det_distance_set.size();ii++ )
     {///

      //  result_out << sequence[ii]  << "\t"<< observed_sequence[ii]<< "\t";
        if ( observed_sequence[ii] != predicted_sequence[ii])
            predicted_sequence[ii] = tolower( predicted_sequence[ii]);
    }


    result_out << "Predicted PB: "  << "--" << predicted_sequence << "--" <<endl;
    result_out << "Observed PB:  "  << "--" << observed_sequence  << "--" <<endl;
    result_out << "Sequence:     "  << sequence << endl<< endl;

    result_out << "<span style=\"color: red\">";
    result_out << "True predictions are represented by a <b>capital letter</b>, false by a small letter" << endl << endl;
    result_out << "</span>" << endl;


    result_out << "Detailed prediction: " << endl;
    result_out << "Sequence"  << "\t"<< "Observed PB" << "\t"<< "Predicted PB"<< "\t" << "Predicted RMSD to predicted PB" << endl;

    for (int ii=0; ii<predicted_det_distance_set.size();ii++ )
     {///

        result_out << sequence[ii+2]  << "\t"<< observed_sequence[ii]<< "\t" << predicted_sequence[ii] << "\t" ;

/*        if ( observed_sequence[ii] == predicted_sequence[ii])
            result_out <<  predicted_sequence[ii];
        else
          result_out <<  (char)  tolower( predicted_sequence[ii] );
*/
    //    if ( observed_sequence[ii] == '*')
    //        result_out <<'?';


        result_out  << "\t" << setw(8) << 1/( - nearest_distance[ii] ) - 1  << endl;
    }


    string PB_name = "ABCDEFGHIJKLMNOP";
    result_out << "Confusion matrix" << endl;
    result_out << "-" << '\t';
    for (int zz=0;zz<PB_name.size(); zz++ )
        result_out << PB_name[zz] << '\t';

    result_out << endl;

    for ( kk=0;kk<number_of_clasters;kk++)
    {
        result_out << PB_name[kk] << '\t';
        for (int jj=0;jj<number_of_clasters;jj++)
        {
            //PutVa( 	quality_matrix[kk][jj],	result_out, 8,3,'l');
           result_out <<  quality_matrix[kk][jj] << '\t';

        }
        result_out << endl;
    }
    result_out << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;
    result_out << "Quality: " << quality/ ( det_distance_set.size() - wrong_struct_number ) << endl;

// protocol


}



void Abu_Maimonides_Rambam::
analyse_single_prediction_by_existing_model_INV (
	const string &PDB_chain_ID,
	charming_Reg_solution  * current_crs ,
	ofstream & protocol_stream,
	double &quality_sum,
	int &valid_coord_res_num,
	int &res_num)
{
	vector < vector < double > > predicted_det_distance_set  =
		single_prediction_by_existing_model (PDB_chain_ID,current_crs );

	vector < vector < double > > det_distance_set  =
		read_det_distance_set (PDB_chain_ID);

	int task_size = det_distance_set[0].size();
	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);

	string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_ + 		string ("/plain_results/") +
			PDB_chain_ID + string (".compare_prediction_INV") ;

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}

		int number_of_clasters = dicl_creator_->number_of_clasters ();

		vector < vector <int > > quality_matrix ;
		quality_matrix.resize (number_of_clasters) ;
		int kk;
		for ( kk=0;kk<number_of_clasters;kk++)
			quality_matrix[kk].resize(number_of_clasters);

		double quality = 0;

		int wrong_struct_number = 0;

		for ( kk=0;kk<predicted_det_distance_set.size();kk++)
		{

			for (int ttt=0;ttt<number_of_clasters;ttt++)
			{
				predicted_det_distance_set	[kk][ttt] = - predicted_det_distance_set[kk][number_of_clasters+ttt];
				det_distance_set			[kk][ttt] = - det_distance_set			[kk][number_of_clasters+ttt];
			}

			predicted_det_distance_set[kk].resize(number_of_clasters);
			det_distance_set[kk].resize(number_of_clasters);

			int predicted_nearest_index =
				get_nearest_claster_index(			predicted_det_distance_set[kk]);
			int nearest_index =
				get_nearest_claster_index(			det_distance_set[kk]);



			PutVa (predicted_nearest_index,out,4,2,'l');
//			if (det_distance_set[kk][0] == -1 )  // FIX STRONG ATTENSION
			if (det_distance_set[kk][0] == -1.0 )  // FIX STRONG ATTENSION
			{
				PutVa ("*",out,4,2,'l');
				wrong_struct_number ++ ;
			}
			else
			{
				PutVa (nearest_index ,out,4,2,'l');
				quality_matrix [nearest_index][predicted_nearest_index ] ++;

				if ( predicted_nearest_index == nearest_index )
					quality +=1;

			}


			for (int tt=0;tt<predicted_det_distance_set[0].size();tt++)
			{
				PutVaDouble (predicted_det_distance_set[kk][tt],out,8,3,'l');
				PutVaDouble (det_distance_set[kk][tt],out,8,3,'l');
				out << " ";

//				PutVaDouble (predicted_det_distance_set[kk][tt],cout,8,3,'l');
	//			PutVaDouble (det_distance_set[kk][tt],cout,8,3,'l');
			//	cout << " ";

			}
			out << endl;
			//cout << endl;

		}

		out << endl << "Correlation pull" <<endl;

		for (int ii=number_of_clasters;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],out,8,3,'l');
//			out.close ();


		out << "*****************************";
		out << "Quality predition matrix" << endl;
		for ( kk=0;kk<number_of_clasters;kk++)
		{
			for (int jj=0;jj<number_of_clasters;jj++)
				PutVa( 	quality_matrix[kk][jj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;
		out << "Quality: " << quality/ ( det_distance_set.size() - wrong_struct_number ) << endl;

// protocol


		PutVaDouble ( quality/ ( det_distance_set.size() - wrong_struct_number ),protocol_stream,8,3,'l');

		protocol_stream << PDB_chain_ID << " ";
		for ( int ii=0;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],protocol_stream,8,3,'l');
		protocol_stream << "Length: " << det_distance_set.size() - wrong_struct_number << " of " << det_distance_set.size()<< endl;


        quality_sum         = quality;
        valid_coord_res_num = det_distance_set.size() - wrong_struct_number;
        res_num             = det_distance_set.size();



				string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID +
			".dist_data_predicted";


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			predicted_det_distance_set);
}

// ðàññòîÿíèå ìåæäó âñåìè valid ôðàãìåíòàìè äâóõ öåïåé



void Abu_Maimonides_Rambam::
prepare_single_dist_data (
	const string &PDB_chain_ID)
{


	Chain_binary *chain = new Chain_binary ( PDB_chain_ID );
// ************ prepare dicl_creator variables ******************

	dicl_creator_->process_chain(chain);
	vector < vector < double > > sophisticated_distance_variables = dicl_creator_->get_sophisticated_distance_variables();;

	delete chain;
//****************************************************************

			string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID +
			".dist_data";


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}


		write_distdata_for_regression (
			distdata_stream,
			sophisticated_distance_variables);

		distdata_stream.close();
}// òîëüêî äëÿ êîíòðîëÿ êà÷åñòâà ïðåäñêàçàíèÿ äëÿ ñåðâåðà

/// передумал
/*
string Abu_Maimonides_Rambam::
make_predicted_BP(
	const string &PDB_chain_ID,
	charming_Reg_solution  * current_crs ,
	ofstream & protocol_stream)
{
    string pb_name = "abcdefghigklmnop";
    vector < vector < double > > predicted_det_distance_set  =
		single_prediction_by_existing_model (PDB_chain_ID,current_crs );

    Cluster_set*	cls = dicl_creator_->get_Cluster_set();


    cls->get_host_dir();

   // int tttt= cls->fragment_length();

//    string  predicted_BP = cls ->PB_setting_by_det_distance_set(
//        predicted_det_distance_set,
//        pb_name);

//	string  predicted_BP = dicl_creator_->get_Cluster_set()->PB_setting_by_det_distance_set(
//        edicted_det_distance_set,
//        pb_name);

  //  return predicted_BP;
  return "";
}

*/

string Abu_Maimonides_Rambam::
PB_setting_by_det_distance_set(
	vector < vector < double > > &det_distance_set)
{
    return dicl_creator_->PB_setting_by_det_distance_set(det_distance_set);
}

vector < vector < double > >  Abu_Maimonides_Rambam::
make_next_layer_prediction (
    vector < vector < double > > &pdv,
    charming_Reg_solution* nela_crs	)
{
    vector < vector < double > >    pdv_exd     = prepare_predictors(pdv);  // кввадраты и кубы добавил
    vector < vector < double > >    pred_nela;


    int local_number_of_cases = pdv.size();
    pred_nela.resize(local_number_of_cases);

    int number_of_dependent = nela_crs->get_number_of_dependent();
    for (int kk=0;kk<local_number_of_cases;kk++)
        pred_nela[kk].resize(number_of_dependent);

	double *  absolute_term_pool =
		nela_crs ->get_absolute_term_pool			();
	double ** regression_coefficient_pool =
		nela_crs ->get_regression_coefficient_pool	() ;

    int number_of_predictors = pdv_exd[0].size();

	for ( int ii=0;ii< local_number_of_cases ; ii++)
	{
		for (int jj=0; jj<number_of_dependent; jj++  )
		{
			double current_value =
				single_prediction_for_any_known_regression_model (
					pdv_exd[ii],
					absolute_term_pool[jj],
					regression_coefficient_pool[jj],
					number_of_predictors );

			pred_nela [ii][jj] =  current_value;
		}
	}

    return pred_nela;

}
void Abu_Maimonides_Rambam::
prepare_data_by_didona_PB_prediction (
    string &path_to_raw_data,
    vector <string> &PDB_chain_ID_list,
    string &data_set_name)
{
    int direct_size         = 16;
    int direct_inverse_size = 32;


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


    for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
        cout << ii<< "\t"<< PDB_chain_ID_list[ii] << "\tfrom\t" << data_set_name << endl;

		vector < vector < double > >    predicted_distance_variables = read_det_distance_set (PDB_chain_ID_list[ii],".dist_data_predicted");
		vector < vector < double > >    observed_distance_variables = read_det_distance_set (PDB_chain_ID_list[ii], ".dist_data");



		int      current_number_of_cases = observed_distance_variables.size();
        assert ( current_number_of_cases ==predicted_distance_variables.size() );

        for ( int ii = 0; ii< current_number_of_cases; ii++)
		{

            if ( (fabs(observed_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(observed_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue;

/// Global file *X !!!
			for (int jj = 0; jj< direct_size-1; jj++)
			{
                PutVaDouble(predicted_distance_variables[ii][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(predicted_distance_variables[ii][direct_inverse_size-1],X_stream,10,6,'l'); X_stream <<"\n";

   			for (int jj = 0; jj< direct_size-1; jj++)
			{
                PutVaDouble(observed_distance_variables[ii][jj],Y_stream,10,6,'l'); Y_stream <<"\t";
            }
            PutVaDouble(observed_distance_variables[ii][direct_size-1],Y_stream,10,6,'l'); Y_stream <<"\n";


        }

	}

}

void Abu_Maimonides_Rambam::
prepare_data_by_didona_PB_prediction_wide (
    string &path_to_raw_data,
    vector <string> &PDB_chain_ID_list,
    string &data_set_name)
{
    int direct_size         = 16;
    int direct_inverse_size = 32;


    string path_for_X =  path_to_raw_data    + data_set_name + "X.dat";
    string path_for_Y =  path_to_raw_data    + data_set_name + "Y.dat";

    ofstream X_stream(path_for_X.c_str());
    if (!X_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_X << endl;
        cout        <<  "ERROR -  can't create " << path_for_X << endl;
        exit(1);
    }

    ofstream Y_stream(path_for_Y.c_str());
    if (!Y_stream)
    {
        log_stream  <<  "ERROR -  can't create " << path_for_Y << endl;
        cout        <<  "ERROR -  can't create " << path_for_Y << endl;
        exit(1);
    }


    for (int kk=0;kk<PDB_chain_ID_list.size();kk++)
	{
        cout << kk<< "\t"<< PDB_chain_ID_list[kk] << "\tfrom\t" << data_set_name << endl;

		vector < vector < double > >    predicted_distance_variables = read_det_distance_set (PDB_chain_ID_list[kk],".dist_data_predicted");
		vector < vector < double > >    observed_distance_variables = read_det_distance_set (PDB_chain_ID_list[kk], ".dist_data");



		int      current_number_of_cases = observed_distance_variables.size();
        assert ( current_number_of_cases ==predicted_distance_variables.size() );

        for ( int ii = 2 ; ii< current_number_of_cases-2; ii++)
		{

            if ( (fabs(observed_distance_variables[ii][0] + 1) < EPSILON_FLOAT) ||
                 (fabs(observed_distance_variables[ii][1] + 1) < EPSILON_FLOAT) )
                continue;

/// Global file *X !!!

			for (int jj = 0; jj< direct_size; jj++)
			{
                PutVaDouble(predicted_distance_variables[ii-2][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< direct_size; jj++)
			{
                PutVaDouble(predicted_distance_variables[ii-1][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< direct_size; jj++)
			{
                PutVaDouble(predicted_distance_variables[ii+1][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
   			for (int jj = 0; jj< direct_size; jj++)
			{
                PutVaDouble(predicted_distance_variables[ii+2][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
			for (int jj = 0; jj< direct_size-1; jj++)
			{
                PutVaDouble(predicted_distance_variables[ii][jj],X_stream,10,6,'l'); X_stream <<"\t";
            }
            PutVaDouble(predicted_distance_variables[ii][direct_inverse_size-1],X_stream,10,6,'l'); X_stream <<"\n";



   			for (int jj = 0; jj< direct_size-1; jj++)
			{
                PutVaDouble(observed_distance_variables[ii][jj],Y_stream,10,6,'l'); Y_stream <<"\t";
            }
            PutVaDouble(observed_distance_variables[ii][direct_size-1],Y_stream,10,6,'l'); Y_stream <<"\n";


        }

	}

}

/// через жзопу пока не сделал акуратный класс типа Cowardvar. Тут квадраты и кубы добавлены к оригинальному pdv
 vector < vector < double > >   Abu_Maimonides_Rambam::
 prepare_predictors(vector < vector < double > > & pdv)
 {
     vector < vector < double > > pdv_ext;

     int current_number_of_cases = pdv.size();

     pdv_ext.resize(current_number_of_cases);
     for (int kk=0;kk<current_number_of_cases;kk++)
        pdv_ext[kk].resize(6*number_of_clasters_);

     for ( int ii = 0; ii< current_number_of_cases; ii++)
	 {
	        int counter = 0;
			for (int jj = 0; jj< 2*number_of_clasters_; jj++)
			{
				pdv_ext[ii][counter] = pdv[ii][jj];
				counter++;
            }

    		for (int jj = 0; jj< 2*number_of_clasters_; jj++)
			{
				pdv_ext[ii][counter] = pdv[ii][jj]*fabs(pdv[ii][jj]);
				counter++;
            }

       		for (int jj = 0; jj< 2*number_of_clasters_; jj++)
			{
				pdv_ext[ii][counter] = pdv[ii][jj]*pdv[ii][jj]*pdv[ii][jj];
                counter++;
            }
     }

     return  pdv_ext;

 }


void write_su_avsumx_d_for_regression_ (
	ofstream & regdata_stream,
    const int number_of_predictor_,
    const int number_of_dependent_,
    const int number_of_cases,
    double *avsumx_,
    double *su_	 )
{
	regdata_stream.write ( (char* ) & number_of_predictor_,     sizeof (int)  );
	regdata_stream.write ( (char* ) & number_of_dependent_,	    sizeof (int)  );

	int record_size_ = number_of_predictor_ + number_of_dependent_;
	int global_upper_triange_matrix_size = record_size_*(record_size_+1)/2;

	regdata_stream.write ( (char* ) & number_of_cases,	                                    sizeof (int)  );
	regdata_stream.write ( (char* )  avsumx_,			record_size_ *                      sizeof (double)  );
	regdata_stream.write ( (char* )  su_,		        global_upper_triange_matrix_size*   sizeof (double)  );
}



