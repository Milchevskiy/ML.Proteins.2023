#pragma warning( disable : 4786 )

#include "Mordehay_test.h"

#include "Mordehay.h"

#include "../MutualDistances/MutualDistances.h"

#include "../Fragment_base/Chain_binary.h"

#include "../CommonFunc.h"

using namespace std;

extern ofstream log_stream;

Mordehay_test::
~Mordehay_test()
{
	cout << "Mordehay_test PASSED: " << "  failed: " << get_failed() <<  " passed: " << get_passed() << endl;
}


void Mordehay_test::test1 ()
{
//	MutualDistances  md1 (	string("len5_pair10"),			MUTUALDISTANCES_FILL_UP);
	Mordehay mrd ("Md1",FILL_UP_MODEL_MORDEHAY_OPERATING_MODES);
//	MutualDistances  md1 (	string("len7_pair10"),			MUTUALDISTANCES_FILL_UP);
//	Mordehay mrd ("FirstMordehay",FILL_UP_MODEL_MORDEHAY_OPERATING_MODES);

}

void Mordehay_test::plain_solution_test ()
{
	Mordehay mrd ("Md1",COMMON_USAGE_MORDEHAY_OPERATING_MODES);
	mrd.plain_solution("together");

}

void Mordehay_test::analyse_prediction_learning_set_test()
{
	Mordehay mrd ("Md1",COMMON_USAGE_MORDEHAY_OPERATING_MODES);

	mrd.prepare_predicted_dist_data_for_learning_set  ();
	mrd.analyse_prediction_learning_set();
}


void Mordehay_test::structure_homology_search_test ()
{

	Mordehay mrd ("Md1",COMMON_USAGE_MORDEHAY_OPERATING_MODES);


	Chain_binary cb( "1BB1A");
	string sequence = cb.get_sequence();


	vector < string > teplate_list_filename;
	teplate_list_filename.push_back("1BB1A");
	teplate_list_filename.push_back("1BBHA");


	int objective_num = 0 ; // ��� ���� ���������� �������� ����������

	mrd.structure_homology_search(
		sequence,
		teplate_list_filename,
		objective_num,
		-1);

	/*	vector < vector < double > >  distance_set =
		two_chain_distance_set (
			"1BB1A",
			"1BBHA",
			 7);
*/

}

void Mordehay_test::find_error()
{
	Mordehay mrd ("Md1",COMMON_USAGE_MORDEHAY_OPERATING_MODES);

	Chain_binary cb( "1BB1A");
	string sequence = cb.get_sequence();

	int objective_num = 0;

	vector <vector <double> > distance_matrix = mrd.single_structure_homology_search(
		sequence,
		"1BBHA",
		objective_num,
		-1);

		vector < vector < double > >  distance_set =
		two_chain_distance_set (
			"1BBHA",
			"1BB1A",
			 7);


		ofstream out("TEST//find_error");
		if ( ! out)	
		{	
			cout       << "TEST//find_error can't create "   << endl;
			exit (1);	
		}


		int counter = 0;
		vector <double> predicted;
		vector <double> observed;
		for (int ii=0;ii<distance_matrix.size();ii++)
		{
			for (int jj=0;jj<distance_matrix[ii].size();jj++)
			{
				
				double d2 = (1/(1+distance_set [ii][jj]))*1/(1+distance_set [ii][jj]);
				if (distance_set[ii][jj]!= -1)
				{
					predicted.	push_back(distance_matrix [ii][jj]);
					observed.	push_back(d2 );
				}
//				cout << distance_matrix [ii][jj] << " " << (1/(1+distance_set [ii][jj])) * (1/(1+distance_set [ii][jj])) << endl;
				out <<"(";
				PutVa(ii,out,5,1,'l'); out <<"//";
				PutVa(jj,out,5,1,'l'); 
				PutVaDouble(distance_matrix [ii][jj],out,8,3,'l'); 
				PutVaDouble(d2 ,out,8,3,'l'); 
				out <<")\t";


//				log_stream << distance_matrix [ii][jj] << " " << (1/(1+distance_set [ii][jj])) * (1/(1+distance_set [ii][jj])) << endl;


				counter ++;
			}
			out <<endl;
		}


		double  Corr =   calculate_correlation(
			predicted,
			observed);
		cout << Corr << endl;

}
/*
void Mordehay_test::
show_all_solution_and_prediction_test()
{
	
	Mordehay mrd ("FirstMordehay",COMMON_USAGE_MORDEHAY_OPERATING_MODES);
	mrd.show_all_solution_and_prediction ();


	vector < vector < double > > predicted_det_distance_set  = 	
		single_prediction_by_existing_model (PDB_chain_ID,current_crs );


	log_stream <<  " show_all_solution_and_prediction_test()" << endl;
}
*/