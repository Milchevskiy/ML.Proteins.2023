
#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "Abu_Maimonides_Rambam_test.h"
#include "Abu_Maimonides_Rambam.h"

#include "../Censorship.h"

#include <fstream>
#include <iostream>
#include <cassert>

#include "../Fragment_base/accepted_chain_data.h"

#include "../Matrix_utilits/Matrix_utilits.h"

#include "../Fragment_base/Chain_binary.h"
#include "../CommonFunc.h"



#include "../Chain_store/Chain_Residue_Set.h"

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

#ifndef GET_NEAREST_CLASTER_INDEX_H
#define GET_NEAREST_CLASTER_INDEX_H

int get_nearest_claster_index( 	const vector <double> & distance_set );

#endif
void Abu_Maimonides_Rambam_test::
check_cluster_property_test()
{
    Abu_Maimonides_Rambam mr ( "PB_2", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
    Distance_to_claster_variables *ob = mr.get_Distance_to_claster_variables();
   // ob->
}
void Abu_Maimonides_Rambam_test::
PB_observed_assignment_test()
{
    Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    string PDB_chain_ID = "153LA";

    vector < vector < double > > det_distance_set =
		mr.read_det_distance_set(PDB_chain_ID,".dist_data");

    string PB_sequence = mr.PB_setting_by_det_distance_set(
                            det_distance_set);

   string out_file_name = "../Test/PB_observed_assignment";

   ofstream out(out_file_name.c_str());
    if (!out)
    {
        cout << "out file problem" << endl;
        exit(-1);
    }

    out << PDB_chain_ID << endl;
    out << "  " << PB_sequence << endl;



}

void Abu_Maimonides_Rambam_test::
prediction_by_sequence_test()
{

	Abu_Maimonides_Rambam mr("new_generation_model_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
		charming_Reg_solution  * current_crs = mr.init_together_model();



	string source_file = "D://I_Galkin//outallcalc";
	ifstream in(source_file.c_str());
	if(!in)
	{
		log_stream	<< source_file << "can't find "  << endl;
		cout		 << source_file << "can't find " << endl;
		exit(1);
	}

//	double current_quality;
	string current_line, num, sequence;


	int number_of_clasters = mr.get_number_of_clasters();



	while (in >> num >> sequence)
	{
		for (int ii = 0; ii < sequence.size(); ii++)
			for (int ii = 0; ii < sequence.size(); ii++)
			sequence[ii] = toupper(sequence[ii]);

		string out_file_name = new_extension_file_name(source_file, num);


		ofstream out(out_file_name.c_str());
		if (!out)
		{
			cout << "out file problem" << endl;
			exit(-1);
		}



		vector < vector < double > > predicted_det_distance_set =
			mr.make_prediction_by_sequence(
				sequence,
				current_crs);




		for (int tt = 0; tt<30; tt++)
			PutVa(tt, out, 10, 5, 'l');
		out << endl;

		for (int kk = 0; kk<predicted_det_distance_set.size(); kk++)
		{
			for (int ttt = 0; ttt<number_of_clasters; ttt++)
				predicted_det_distance_set[kk][ttt] = -predicted_det_distance_set[kk][number_of_clasters + ttt];

			predicted_det_distance_set[kk].resize(30);

			int predicted_nearest_index =
				get_nearest_claster_index(predicted_det_distance_set[kk]);

			PutVa(predicted_nearest_index, out, 4, 2, 'l');

			for (int tt = 0; tt<predicted_det_distance_set[0].size(); tt++)
			{
				PutVaDouble(-predicted_det_distance_set[kk][tt], out, 10, 5, 'l');
				out << " ";
			}
			out << endl;

		}
		out.close();
	}
}
void Abu_Maimonides_Rambam_test::
intack_test_for_prediction_by_sequence()
{
	Abu_Maimonides_Rambam mr("new_generation_model_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
		charming_Reg_solution  * current_crs = mr.init_together_model();

	//>gi|5524211|gb|AAD44166.1| cytochrome b [Elephas maximus maximus]

	int number_of_clasters = mr.get_number_of_clasters();

   string sequence = "LCLYTHIGRNIYYGSYLYSETWNTGIMLLLITMATAFMGYVLPWGQMSFWGATVITNLFSAIPYIGTNLVEWIWGGFSVDKATLNRFFAFHFILPFTMVALAGVHLTFLHETGSNNPLGLTSDSDKIPFHPYYTIKDFLGLLILILLLLLLALLSPDMLGDPDNHMPADPLNTPLHIKPEWYFLFAYAILRSVPNKLGGVLALFLSIVILGLMPFLHTSKHRSMMLRPLSQALFWTLTMDLLTLTWIGSQPVEYPYTIIGQMASILYFSIILAFLPIAGXIENY";


	vector < vector < double > > predicted_det_distance_set =
        mr.make_prediction_by_sequence(
            sequence,
            current_crs);

    string out_file_name = "../Test/intack_test_for_prediction_by_sequence_test.txt";

        ofstream out(out_file_name.c_str());
        if (!out)
        {
            cout << "out file problem" << endl;
            exit(-1);
        }

		for (int kk = 0; kk<predicted_det_distance_set.size(); kk++)
		{
			for (int ttt = 0; ttt<number_of_clasters; ttt++)
				predicted_det_distance_set[kk][ttt] = -predicted_det_distance_set[kk][number_of_clasters + ttt];

			predicted_det_distance_set[kk].resize(30);

			int predicted_nearest_index =
				get_nearest_claster_index(predicted_det_distance_set[kk]);

			PutVa(predicted_nearest_index, out, 4, 2, 'l');

			for (int tt = 0; tt<predicted_det_distance_set[0].size(); tt++)
			{
				PutVaDouble(-predicted_det_distance_set[kk][tt], out, 10, 5, 'l');
				out << " ";
			}
			out << endl;

		}



}


void Abu_Maimonides_Rambam_test::remove_large_chain()
{
	int THRESHOLD = 150;
	string binary_file_name("accepted_chain_list.bin");

	vector < string >   accepted_chain_ID_list;
	vector < int >      accepted_chain_lenth;

	fill_up_accepted_chain_data(
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name);

	string path_to_filtered_accepted_chain_list = "filtered_accepted_chain_list.bin";

	string result_binary_file_name =
		configuration.option_meaning("Path_to_Chain_store") +
		path_to_filtered_accepted_chain_list;

	ofstream binary_stream(result_binary_file_name.c_str(), ios::binary);

	if (!binary_stream) {
		log_stream << "ERROR -  can't find binary file" << binary_file_name << endl;
		cout << "ERROR -  can't find binary file" << binary_file_name << endl;
		exit(1);
	}

	int size = accepted_chain_ID_list.size();
	int true_counter = 0;
	for (int ii = 0; ii < size; ii++)
	{
		Chain_binary cb(accepted_chain_ID_list[ii]);
		int number_of_residues = cb.get_number_of_residues();

		if (number_of_residues < THRESHOLD)
		{
			binary_stream.write((char*)accepted_chain_ID_list[ii].c_str(), 5);
			binary_stream.write((char*)&number_of_residues, sizeof(int));
			true_counter++;
		}
		else
			continue;
	}
	cout << true_counter;
}

void Abu_Maimonides_Rambam_test::analyse_ready_prediction_set()
{
	string path_to_dir = string ("D:/Didona/Store/Model_store/second_model_advanced/plain_results/");
	string path_to_list = path_to_dir + string ("ready_list");

	ifstream in ( path_to_list.c_str()) ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << endl;
		exit (1);
	}

	string path_to_protocol = path_to_list = path_to_dir + string ("protocol_cmp_pred");
	ofstream out ( path_to_protocol.c_str()) ;
	if ( ! out )	{
		cout       << "Can't create protocol file  " << endl;
		exit (1);
	}

	string current_line;
	string word;

	vector <string> PDB_chain_ID_list;

	while( in >> word )
		PDB_chain_ID_list.push_back(word);

	int total_valid_length = 0;
	int total_length = 0;
	double total_quality =0;
	double total_vaild_length_m_quaity =0;



	for (unsigned ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
		string path_to_current_file = path_to_dir + PDB_chain_ID_list[ii];
		ifstream in_cur ( path_to_current_file.c_str() ) ;



		int current_valid_length;
		int current_length;
		double current_quality;

		while( getline( in_cur  , current_line, '\n' ) )
		{
			string key_word = current_line.substr(0,7);
			if (key_word != string ("Length:") )
				continue;
			else
			{
				{
				istringstream ist (current_line);
				ist >> word >> current_valid_length >> word >> current_length;
				}
				getline( in_cur  , current_line, '\n' );
				{
				istringstream ist (current_line);
				ist  >> word >> current_quality;
				}


				total_quality		+= current_quality;

				total_valid_length	+= current_valid_length;
				total_length		+= current_length;
				total_vaild_length_m_quaity += current_valid_length*current_quality;

				out  << current_quality << "\t" << PDB_chain_ID_list[ii] << ": " << current_valid_length << "\t" << current_length << "\t" << endl;
				cout << PDB_chain_ID_list[ii] << endl;

				break;
			}
		}

	//		handle_single__compare_prediction_INV (path_to_current_file);

	}

		out << "______________________________" << endl;

		out << "total_valid_length:"	<< "\t" << total_valid_length	<< "\t" << endl;
		out << "total_length:"			<< "\t" << total_length	<< endl;
		out << "total_quality:"		<< "\t" << total_quality<< endl;
		out << "accurate quality:" << "\t" << total_vaild_length_m_quaity/total_valid_length << endl;
		out << "rude quality:" << "\t" << total_quality/PDB_chain_ID_list.size()<< endl;
}

void Abu_Maimonides_Rambam_test::
prepare_obesrved_binary_files ()
{
	string model_name = string("PB_2");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

//	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.prepare_single_dist_data (PDB_chain_ID_list[ii]) ;
			cout << ii << " " <<  PDB_chain_ID_list[ii] << endl;
	}

//	delete current_crs;

}

void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files ()
{

	string model_name = string("PB_2");

	Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name				+
			"/cross_sum/"			+
			PDB_chain_ID_list[ii] +
			".dist_data_predicted";

	/*
		ifstream t_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( t_stream)
		{
			log_stream << "already exist: " << current_distance_file_name  << endl;
			cout       << "already exist: " << current_distance_file_name  << endl;
			continue;
		}
		*/

			Chain_binary * chain = 	new Chain_binary ( PDB_chain_ID_list[ii] );
			string sequence = chain->get_sequence();
			delete chain;

			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
				sequence,
				current_crs	);

// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
//*******************************************************************************



			cout << ii << " " <<  PDB_chain_ID_list[ii] << endl;
	}

	delete current_crs;
}

//Chain_Residue_Set crs ( pdb_chain_ID );
//crs.save_as_binary();



void Abu_Maimonides_Rambam_test::
prepare_observed_binary_files_for_external_sequnces()
{


	string path_to_external_PDB_chain_ID_list = "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/";
	string external_PDB_chain_ID_list_file = path_to_external_PDB_chain_ID_list + string("list");
	vector <string > PDB_chain_ID_list;

	ifstream in_pdb_id(external_PDB_chain_ID_list_file.c_str());
	if (!in_pdb_id)
	{
		log_stream << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		cout << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		throw;
	}
	string current_word;
	while (in_pdb_id >> current_word)
		PDB_chain_ID_list.push_back(current_word);


//	Chain_store("large.txt");

/*	for (int ii = 0; ii < PDB_chain_ID_list.size(); ii++)
	{
		const string currentID = PDB_chain_ID_list[ii];
		Chain_Residue_Set crs(currentID);
		crs.save_as_binary();
	}
*/

	string model_name = string("new_generation_model_2");

	Abu_Maimonides_Rambam mr(model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);

	//	charming_Reg_solution  * current_crs = mr.init_together_model ();

//	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();




	for (int ii = 0; ii<PDB_chain_ID_list.size(); ii++)
	{
		mr.prepare_single_dist_data(PDB_chain_ID_list[ii]);
		cout << ii << " " << PDB_chain_ID_list[ii] << endl;
	}
}

void Abu_Maimonides_Rambam_test::
prepare_predicted_binary_files_for_external_sequnces()
{

	string model_name = string("new_generation_model_2");

	Abu_Maimonides_Rambam mr(model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);

	charming_Reg_solution  * current_crs = mr.init_together_model();

	//vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	string path_to_external_PDB_chain_ID_list = "D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/";
	string external_PDB_chain_ID_list_file = path_to_external_PDB_chain_ID_list + string("list");
	vector <string > PDB_chain_ID_file_names;

	ifstream in_pdb_id(external_PDB_chain_ID_list_file.c_str());
	if (!in_pdb_id)
	{
		log_stream << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		cout << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
		throw;
	}
	string current_word;
	while (in_pdb_id >> current_word)
		PDB_chain_ID_file_names.push_back(current_word);



	for (int ii = 0; ii<PDB_chain_ID_file_names.size(); ii++)
	{

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name +
			"/cross_sum/" +
			PDB_chain_ID_file_names[ii] +
			".dist_data_predicted";


//		Chain_binary * chain = new Chain_binary(PDB_chain_ID_list[ii]);
//		string sequence = chain->get_sequence();
//		delete chain;

		string seq_fina = path_to_external_PDB_chain_ID_list + PDB_chain_ID_file_names[ii];
		ifstream in_se(seq_fina.c_str() );
		if (!in_se)
		{
			log_stream << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
			cout << "ERROR -  can't open" << external_PDB_chain_ID_list_file << endl;
			throw;
		}
		string sequence;
		getline(in_se, sequence, '\n'); // the first string in tis file is sequence

		for (int kk = 0; kk < sequence.size(); kk++)
			sequence[kk] = toupper(sequence[kk]);

		vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence(
			sequence,
			current_crs);

		// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		ofstream distdata_stream(current_distance_file_name.c_str(), ios::binary);
		if (!distdata_stream)
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name << endl;
			cout << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name << endl;

			exit(1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
		//*******************************************************************************

		cout << ii << " " << PDB_chain_ID_file_names[ii] << endl;
	}

	delete current_crs;
}




double dummy_sum (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number);
double dummy_sum_2 (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number);


Abu_Maimonides_Rambam_test::~Abu_Maimonides_Rambam_test()
{
	cout << "Abu_Maimonides_Rambam_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}



void Abu_Maimonides_Rambam_test::prepare_united_su_avsumx_d_test (  )
{

	ifstream in ( "D:/Didona/Store/Model_store/_SETTED_BASIS_STRUCTURES/TriPeptides_next/cross_sum/ready_cross_sum_list") ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << endl;
		exit (1);
	}

	vector <string> PDB_chain_ID_list;
	string word;
	while( in >> word )
		PDB_chain_ID_list.push_back(word);

	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

//	mr.prepare_united_su_avsumx_d(PDB_chain_ID_list); Если нгеохота ждать
	mr.prepare_united_su_avsumx_d();
	mr.plain_solution ( "together" );

}

void Abu_Maimonides_Rambam_test::
protocol_test()
{

	//Abu_Maimonides_Rambam mr ( "new_generation_model_2", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	Abu_Maimonides_Rambam mr ( "PB_2", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	log_stream <<  " protocol_test() " << endl;
}

void Abu_Maimonides_Rambam_test::
plain_solution_test ()
{

//	Abu_Maimonides_Rambam mr ( "new_generation_model_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
//	mr.plain_solution ( "together" );

    Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.plain_solution ( "together" );

}
void Abu_Maimonides_Rambam_test::
analyse_single_prediction_by_existing_model_exotic_dep_val_test()
{
	Abu_Maimonides_Rambam mr("PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);


	charming_Reg_solution  * current_crs = mr.init_together_model();

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

	string protocol_file_name =
		configuration.option_meaning("Path_to_Model_store") +
		string("PB_2") + string("/plain_results/") +
		string("protocol.exotic");

	ofstream out(protocol_file_name.c_str(), ios::binary);
	if (!out)
	{
		log_stream << "protocol_file_name   can't create " << protocol_file_name << endl;
		cout << "protocol_file_name   can't create " << protocol_file_name << endl;
		exit(1);
	}

	for (int ii = 0; ii<PDB_chain_ID_list.size(); ii++)
	{
		mr.analyse_single_prediction_by_existing_model_exotic_dep_val(
			PDB_chain_ID_list[ii],
			current_crs,
			out);

		cout << PDB_chain_ID_list[ii] << " " << ii << endl;
	}
}
void Abu_Maimonides_Rambam_test::
analyse_single_prediction_by_existing_model_test()
{
//	Abu_Maimonides_Rambam mr ( "_SETTED_BASIS_STRUCTURES/TriPeptides_next", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	//second_model_advanced
	//Abu_Maimonides_Rambam mr ( "PB_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	string model_name = string("PB_2");
    Abu_Maimonides_Rambam mr ( model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector <string > PDB_chain_ID_list = mr.get_accepted_chain_ID_list();

		string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name + 		string ("/plain_results/") +
			 string ("protocol") ;

		ofstream out( protocol_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}




	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{
		mr.analyse_single_prediction_by_existing_model_INV (
			PDB_chain_ID_list[ii],
			current_crs ,
			out);

			cout << PDB_chain_ID_list[ii] <<  " " << ii << endl;
	}

}



/*

void Abu_Maimonides_Rambam_test::
handle_mutual_distance_test()
{
	Abu_Maimonides_Rambam mr ( "Model_Fr4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();

	string PDB_chain_ID_1 = "119LA";
	string PDB_chain_ID_2 = "1ABAA";

	vector < vector < double > > predicted_det_distance_set_1  =
		mr.single_prediction_by_existing_model (PDB_chain_ID_1,current_crs );

	vector < vector < double > > det_distance_set_1  =
		mr.read_det_distance_set (PDB_chain_ID_1);

	vector < vector < double > > predicted_det_distance_set_2 =
		mr.single_prediction_by_existing_model (PDB_chain_ID_2,current_crs );

	vector < vector < double > > det_distance_set_2  =
		mr.read_det_distance_set (PDB_chain_ID_2);


	vector < vector < double > >  mutual_distance_set =
		two_chain_distance_set (
		PDB_chain_ID_1	,PDB_chain_ID_2,	5);

	ofstream out( "TEST/handle_mutual_distance_test" );

	if ( ! out)
	{
		cout		<<	" can't open test file " << endl;
		log_stream	<<	" can't open test file " << endl;
		exit (1);
	}

	for (int ii=0;ii<mutual_distance_set.size();ii++)
	{
		if (det_distance_set_1[ii][0]  ==-1 )
			continue;
		for (int jj=0;jj<mutual_distance_set[ii].size();jj++)
		{
			if (det_distance_set_2[jj][0]  ==-1 )
				continue;

			PutVaDouble (mutual_distance_set[ii][jj],out,10,3,'r');

			PutVaDouble (mutual_distance_set[ii][jj]*mutual_distance_set[ii][jj],out,10,3,'r');
			out << "\t";
			double s1 = dummy_sum (
				predicted_det_distance_set_1[ii],
				predicted_det_distance_set_2[jj],8);
			double s2 = dummy_sum_2(
				predicted_det_distance_set_1[ii],
				predicted_det_distance_set_2[jj],8);

			PutVaDouble (s1,out,10,3,'r');
			PutVaDouble (s2,out,10,3,'r');

			det_distance_set_1[ii].resize(8);
			det_distance_set_2[jj].resize(8);

			int nearest_index_1 = mr.get_nearest_claster_index( det_distance_set_1[ii]);
			int nearest_index_2 = mr.get_nearest_claster_index( det_distance_set_2[jj]);


			PutVa (nearest_index_1,out,10,3,'r');
			PutVa(nearest_index_2,out,10,3,'r');

			out << endl;
		}


	}



}

double dummy_sum (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number)
{
	double sum=0;
	for (int ii=0;ii<number;ii++)
		sum += fabs (set_1[ii] - set_2[ii]);

	return sum;
}
double dummy_sum_2 (
	vector <double> &set_1,
	vector <double> &set_2,
	const int number)
{
	double sum=0;
	for (int ii=0;ii<number;ii++)
		sum += fabs (set_1[ii] - set_2[ii])*fabs (set_1[ii] - set_2[ii]);
	return sum;
}




void Abu_Maimonides_Rambam_test::make_prediction_by_external_PDB_test ()
{
	//Abu_Maimonides_Rambam mr ( "Model_Fr3", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	Abu_Maimonides_Rambam mr ( "Model_c30_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	mr.make_prediction_by_external_PDB("1C26A");

	mr.compare_ready_observation_prediction ("1C26A");


	delete current_crs ;
}


void Abu_Maimonides_Rambam_test::
correlation_pull_for_chain_by_together_model_test ()
{
	ifstream in ( "D:/Agony/Store/Model_store/Model_c30_2/cross_sum/list") ;
	if ( ! in )	{
		cout       << "Can't find LIST file  " << "left.matrix"<< endl;
		exit (1);
	}


	vector <string> PDB_chain_ID_list;
	string word;
	while( in >> word )
		PDB_chain_ID_list.push_back(word);

	Abu_Maimonides_Rambam mr ( "Model_c30_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.plain_solution("together");

	for (int ii=0; ii<PDB_chain_ID_list.size();ii++)
		mr.correlation_pull_for_chain_by_together_model(PDB_chain_ID_list[ii]);

}




void Abu_Maimonides_Rambam_test::
show_all_plain_solution_test ()

{
	Abu_Maimonides_Rambam mr ( "Model_Fr1", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.show_all_plain_solution ();
}

void Abu_Maimonides_Rambam_test::
show_all_solution_and_prediction_test()
{
	Abu_Maimonides_Rambam mr ( "StartModel", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.show_all_solution_and_prediction ();

	log_stream <<  " show_all_solution_and_prediction_test()" << endl;
}

void Abu_Maimonides_Rambam_test::
prepare_discriminant_data_test()
{
	Abu_Maimonides_Rambam mr ( "freq_x5_6_fast_4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.prepare_discriminant_data();
}

void Abu_Maimonides_Rambam_test::
prepare_correction_matrix_test()
{
	Abu_Maimonides_Rambam mr ( "freq_x5_6_fast_4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.prepare_correction_matrix();

}

void Abu_Maimonides_Rambam_test::
handle_correction_matrix_test()
{
	string path_to_martix_store = string ("D:/Model_store/freq_x5_6_fast_4/plain_results/");

	string path_to_martix_X  = path_to_martix_store + string ("X.matrix");
	string path_to_martix_Y  = path_to_martix_store + string ("Y.matrix");

	string path_to_martix_Yt_Y  = path_to_martix_store + string ("Yt_Y.matrix");


	ifstream in_stream ( path_to_martix_Y .c_str() ) ;
	if ( ! in_stream )	{
		cout       << "Can't create file  " << path_to_martix_Y << endl;
		exit (1);
	}

//	vector < vector  < double > >	martix_X = get_matrix_from_txt_file ( path_to_martix_X ) ;
	vector < vector  < double > >	martix_Y = get_matrix_from_txt_file ( in_stream ) ;

	vector < vector  < double > >	martix_Y_copy =  martix_Y;

	vector < vector < double > > martix_Yt_Y = transpose_matr_mlt_matr (martix_Y_copy,martix_Y );

	ofstream res_stream ( path_to_martix_Yt_Y.c_str() ) ;
	if ( ! res_stream )	{
		cout       << "Can't create file  " << path_to_martix_Yt_Y << endl;
		exit (1);
	}

	print_rectangular_matrix (
		string ("******** Matrix_Yt_Y **********"),res_stream ,martix_Yt_Y);
}
void Abu_Maimonides_Rambam_test::
make_predicted_distance_binary_files_test ()
{

	Abu_Maimonides_Rambam mr ( "StartModel", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.make_predicted_distance_binary_files();

}
void Abu_Maimonides_Rambam_test::
init_wu_blast_test ()
{
	Abu_Maimonides_Rambam mr ( "freq_x5_6_fast_4", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.init_wu_blast ();

}
*/
