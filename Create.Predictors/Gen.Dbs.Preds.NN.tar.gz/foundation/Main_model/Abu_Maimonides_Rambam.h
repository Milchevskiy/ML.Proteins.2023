#ifndef ABU_MAIMONIDES_RAMBAM_H
#define ABU_MAIMONIDES_RAMBAM_H

#include "Abu_Maimonides_Rambam_operating_modes.h"

#include <string>
#include <vector>
#include <fstream>

class Sheduler;
class CowardVariables ;
class FrequencyVariables;
class Distance_to_claster_variables;
//class Structure_assignment;
class Masticated_structure_store;
class charming_Reg_solution;

using namespace std;

class Abu_Maimonides_Rambam
{
public:
	Abu_Maimonides_Rambam	();
	~Abu_Maimonides_Rambam	(); // **** FIX **** FIX **** FIX **** FIX

	Abu_Maimonides_Rambam	(
		const string & name,
		const Abu_Maimonides_Rambam_operating_modes run_mode  ) ;

	void init	(
		const string & name,
		const Abu_Maimonides_Rambam_operating_modes run_mode  );


	vector < string > get_accepted_chain_ID_list () const  {return accepted_chain_ID_list_;}
    vector < string > CONTROL_get_accepted_chain_ID_list () const  {return CONTROL_accepted_chain_ID_list_;}



	void show_all_plain_solution ();

	void plain_solution ( const string & PDB_chain_ID );
	void prepare_for_jack_nife_su_avsumx_d ();


	void solution_and_prediction (
		const string & PDB_chain_ID,
		charming_Reg_solution  * together,
		ofstream & protocol_stream);

	void show_all_solution_and_prediction  ();

	void prepare_discriminant_data ();

	void prepare_correction_matrix ();

	void make_predicted_distance_binary_files();


	void  init_averages_and_dispersion (
		const string & det_distance_file,
		vector < double >	& averages,
		vector < double >	& disperse );

	void 	init_wu_blast ();

	void compare_predicted_values ( vector <string> & accepted_chain_ID_list_ ) ;

	void prepare_united_su_avsumx_d ( vector <string> & pdb_chain_list );
	vector <double> correlation_pull_for_chain_by_together_model (const string & PDB_chain_ID);

// ��������� ������ ��� ���� ����� ������ �� together.cross_sum
	void
		make_prediction_by_external_PDB (
		const string & PDB_chain_ID	);

//	void analyse_single_prediction_by_existing_model (
//		const string &PDB_chain_ID,
//		charming_Reg_solution  * current_crs,
//		ofstream & protocol_stream);

		void analyse_single_prediction_by_existing_model (
            const string &PDB_chain_ID,
            charming_Reg_solution  * current_crs ,
            ofstream & protocol_stream,
            double &quality_sum,
            int &valid_coord_res_num,
            int &res_num);


	void analyse_single_prediction_by_existing_model_INV (
		const string &PDB_chain_ID,
		charming_Reg_solution  * current_crs ,
		ofstream & protocol_stream);


		void analyse_single_prediction_by_existing_model_INV (
            const string &PDB_chain_ID,
            charming_Reg_solution  * current_crs ,
            ofstream & protocol_stream,
            double &quality_sum,
            int &valid_coord_res_num,
            int &res_num);


/// SERVER
	void single_prediction_by_existing_model_INV_for_server (
        string &PDB_chain_ID,
        charming_Reg_solution  * current_crs ,
        ofstream & result_out);

	void 	analyse_single_prediction_by_existing_model_exotic_dep_val(
			const string &PDB_chain_ID,
			charming_Reg_solution  * current_crs,
			ofstream & protocol_stream);


	charming_Reg_solution  * init_together_model ();

	vector < vector < double > > single_prediction_by_existing_model (
		const string &PDB_chain_ID,
		charming_Reg_solution  * current_crs );

	vector < vector < double > >
		read_det_distance_set (const string & PDB_chain_ID);

//	vector < vector < double > >
//		read_det_distance_set (	const string & PDB_chain_ID,string & extension);


	vector < vector < double > >
		read_det_distance_set (const string & PDB_chain_ID, const string & extension);


	int get_nearest_claster_index( 	const vector <double> & distance_set );


	vector < vector < double > > make_prediction_by_sequence (
		const string & sequence,
		charming_Reg_solution* current_crs		);

	int get_number_of_clasters () { return  number_of_clasters_ ; }

	void compare_ready_observation_prediction (const string & PDB_chain_ID);

	int get_shift () const {return  shift_; }

	void prepare_single_dist_data (const string &PDB_chain_ID); // ������ ��� �������� �������� ������������ ��� �������

	void write_distdata_for_regression (
   		ofstream & out,
		const vector < vector < double > >	& distance_set  );

	void prepare_united_su_avsumx_d ();

	Distance_to_claster_variables* get_Distance_to_claster_variables() const { return dicl_creator_; };

/// ���������
/*
	string make_predicted_BP(
        const string &PDB_chain_ID,
        charming_Reg_solution  * current_crs ,
        ofstream & protocol_stream);
*/

    string PB_setting_by_det_distance_set(vector < vector < double > > &det_distance_set);


	void prepare_das_data();  /// An input data file is created for discriminant analysis.

	//void prepare_data_for_AI();

	void quality_assesment_for_prediction_set(const string &mode_extension);
	void CONTROL_quality_assesment_for_prediction_set(const string &mode_extension);




    void make_cross_sum_binary_files_next_layer();

    vector < vector < double > >  make_next_layer_prediction (
                                    vector < vector < double > > &pdv,
                                    charming_Reg_solution* nela_crs	);

/// ����� ����� ���� �� ������ ��������� ����� ���� Cowardvar. ��� �������� � ���� ��������� � ������������� pdv
    vector < vector < double > >    prepare_predictors(vector < vector < double > > & pdv)  ;



    void   confusion_matrix_left_and_right(
        vector <string> & chain_ID_list,
        string & result_name);

    void prepare_data_for_AI(const string &path_to_raw_data,const string &path_to_PDB_ID_list);

    void prepare_single_again_data_for_AI(
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &data_set_name);

    void prepare_triple_data_for_AI(
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &data_set_name);

    void prepare_NN_data_for_AI();


    void prepare_DAS_selected_data_for_AI (
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &data_set_name);

    void prepare_regression_data_for_significant_var_selection(
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &data_set_name);


    void prepare_triple_data_for_AI_SS_8(
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &path_to_SS_data,
        const string &data_set_name);

    void prepare_triple_data_for_AI_SS_8_for_classify(
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &path_to_SS_data,
        const string &data_set_name);



    void prepare_triple_data_for_AI_by_sequence(
        const string &path_to_raw_data,
        const string &path_to_PDB_ID_list,
        const string &data_set_name);

//   void make_predictor_set_by_sequence (const string &sequence);

    void make_predictor_file_set_by_sequence (
        const string & sequence,
        const string & path_for_pytorch_data,
        const string & predictor_file_name);



    void prepare_data_for_AI_for_prediction_by_sequences_set( // ������� ������ ��� ������������ ����. ����. ��� ������ PDB_ID
        const string &path_to_sequence_set_folder,  //sequence- the first string in file [pdbID].protocol
        const string &path_to_result_folder,
        const string &path_to_PDB_ID_list);

///  ������� ���������� ��� ����������� ������������ ��������� ����� ���� /home/milch/pytorch/tests/MultiOutputRegression_final/Check.npy/Prediction_single_advanced.py
    void data_for_AI_prediction_by_sequence(
        const string &sequence,
        const string &path_to_ready_data_file);
/// ������������� ������� ���������� �������� ������ �����������
    vector < vector < double > > const &  data_for_AI_prediction_by_sequence(
            const string &sequence );


    void prepare_sophisticated_AI_data_set_based_on_first_stage_predicrion_by_fulle_sequence(
        const string &path_to_first_stage_prediction_folder,
        const string &path_to_result_folder,
        const string &ready_data_name,
        const string &path_to_PDB_ID_list);


    void prepare_data_by_didona_PB_prediction (
        string &path_to_raw_data,
        vector <string> &PDB_chain_ID_list,
        string &data_set_name);

    void prepare_data_by_didona_PB_prediction_wide (
        string &path_to_raw_data,
        vector <string> &PDB_chain_ID_list,
        string &data_set_name);



private:

	int number_of_clasters_ ;

	vector < string >  accepted_chain_ID_list_;  //
	vector <int>       accepted_chain_lenth_;


	vector < string >  CONTROL_accepted_chain_ID_list_;


	string			name_;

	Sheduler		*sheduler_;
	Sheduler		*regression_options_;

	CowardVariables					*cowa_creator_;
	FrequencyVariables				*frva_creator_;
	Distance_to_claster_variables	*dicl_creator_;
	Masticated_structure_store		*mss_;

//	vector < string >	PDB_chain_ID_list_;					// ��������� ������� ������

	int record_size_;
	int upper_triange_matrix_size_;
	double *avsumx_	;
	double *su_		;

	void init_storage () {}		/// ���� ��������

	void make_cross_sum_binary_files();
/// This function prepares preliminary data for further use in forming the input data for the neural network. For each protein chain, a separate file


    //void prepare_data_for_AI(const string &path_to_raw_data,const int distance_from_center);


	void fast_make_cross_sum_binary_together_files();


	void beef_up_data (
		const vector < vector < double > >  & set_of_coordinate_in_clasters_system,
		const vector < vector < double > >	& sophisticated_variables,
		const int shift,
		const int supplement_mode );

	void write_su_avsumx_d_for_regression (
		ofstream & regdata_stream,
		const int number_of_cases );

//	void write_distdata_for_regression (
//   		ofstream & out,
//		const vector < vector < double > >	& distance_set  );


	//	void prepare_united_su_avsumx_d ( vector <string> & pdb_chain_list );


	vector <double> correlation_pull_for_chain (
		const string & PDB_chain_ID,
		charming_Reg_solution* current_crs );

//	vector < vector < double > >
//		read_det_distance_set (const string & PDB_chain_ID);


//	void compare_predicted_values ( vector <string> & accepted_chain_ID_list_ ) ;

	vector < vector < double > > make_prediction (
		const string & PDB_chain_ID,
		charming_Reg_solution* current_crs,
		const int shift);

//ector < vector < double > > make_prediction_by_sequence (
//const string & sequence,
//charming_Reg_solution* current_crs		);


	void  analyse_predicted_assignment (
	  	const string & PDB_chain_ID,
		charming_Reg_solution* current_crs,
		const vector <int> & base_claster_indexes);

	void  analyse_predicted_assignment_inv (
	  	const string & PDB_chain_ID,
		charming_Reg_solution* current_crs,
		const vector <int> & base_claster_indexes);

	//int get_nearest_claster_index( 	const vector <double> & distance_set );

	vector < vector < double > > 	standaze_distance_set (
		const vector < vector < double > > & predicted_det_distance_set);


	vector < vector < double > > standaze_distance_set_gentle (
		const vector < vector < double > > & predicted_det_distance_set,
		vector < double >	& averages,
		vector < double > 	& disperse);


	vector < double >	global_averages_;
	vector < double >	global_disperse_;

	void  init_global_averages_and_dispersion ();

	void 	add_single_chain_discriminant_data (
		const string PDB_chain_ID,
		charming_Reg_solution  * together,
		ofstream & da_stream);

	void add_single_chain_to_XY_matrix (
   		const string PDB_chain_ID,
		charming_Reg_solution  * together,
		ofstream & X_stream,
		ofstream & Y_stream	);

	vector < vector < int > > prepare_wu_blast_index (
		const vector < vector < double > > & sta_det_distance_set  );

	void 	put_wu_blasst_result (
		const string & result_name,
		const vector < vector <int> > & wu_blast_index  );

	vector <vector <double> > convert_to_Z_value (
		const vector < vector < double > > & distance_set,
		const vector <double > & averages,
		const vector <double > & disperse );

//	charming_Reg_solution  * init_together_model ();



	int shift_;


	double *data_set_;

	double learning_thin_out_shift_;
};
///
void write_su_avsumx_d_for_regression_ (
	ofstream & regdata_stream,
    const int number_of_predictor_,
    const int number_of_dependent_,
    const int number_of_cases,
    double *avsumx_,
    double *su_	 );


#define EPSILON_FLOAT  0.0001

#endif
