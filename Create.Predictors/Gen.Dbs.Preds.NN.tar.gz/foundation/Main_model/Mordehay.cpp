#pragma warning( disable : 4786 )

#include "Mordehay.h"

#include "../MutualDistances/MutualDistances.h"

#include "Abu_Maimonides_Rambam.h"

//#include "handle_det_distance_set.h"

#include "../Sheduler.h"
#include "../CowardVariables/CowardVariables.h"
//#include "../CowardVariables/FrequencyVariables.h"
#include "../CowardVariables/Distance_to_claster_variables.h"
#include "../Censorship.h"
#include "../CommonFunc.h"
#include "../Statistical_utilits/Statistic_general_purpose.h"
#include "../Statistical_utilits/charming_Reg_solution.h"
#include "../Statistical_utilits/calculate_correlation_pull.h"
#include "../Statistical_utilits/single_prediction_for_any_known_regression_model.h"
#include "../Statistical_utilits/calculate_correlation_pull.h"
#include "../Pair_int_double.h"

#include "../NL_CowardVariables/NL_DistanceVariables.h"
#include "../NL_CowardVariables/NL_CowardVariables.h"

#include "handle_det_distance_set.h"

#include "../Cluster_set/Cluster_set.h"

//#include "../PDB_util/PDB_util.h"

#include "../Fragment_base/accepted_chain_data.h"

#include <cassert>
#include <iostream>
#include <sstream>

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;


Mordehay::~Mordehay()
{
	if (!sheduler_ )
		delete sheduler_;

	if (!nl_cowa_creator_ )
		delete nl_cowa_creator_ ;

	if (!nl_dist_creator_ )
		delete nl_dist_creator_ ;

	if (!crs_ )
		delete crs_ ;

}

Mordehay::Mordehay():
	sheduler_(0),
	regression_options_ (0),
	nl_cowa_creator_	(0),
	nl_dist_creator_	(0),
	mudis_				(0),
	crs_				(0)

{

};

Mordehay::Mordehay(
		const string & name,
		const Mordehay_operating_modes run_mode  )
{
	init( name, run_mode  );
}


void Mordehay::
	init(
		const string & name,
		const Mordehay_operating_modes run_mode  )
{
	sheduler_			=0;
	regression_options_	=0;
	nl_cowa_creator_		=0;
	//frva_creator_		=0;
	nl_dist_creator_	=0;
	//mss_				=0;
	mudis_				=0;


	avsumx_	=0;
	su_		=0;

	name_			= name;
	sheduler_		= new Sheduler     ( configuration.option_meaning("Path_to_Model_store_next_layer")  + name_ + string ("/") + string ("sheduler") ) ;


	string first_level_model_name =  sheduler_->option_meaning ("FIRST_LEVEL_MODEL");

	Sheduler *primary_model_sheduler		=
		new Sheduler     ( configuration.option_meaning("Path_to_Model_store")  + first_level_model_name + string ("/") + string ("sheduler") ) ;

//	primary_model_sheduler->option_meaning("CLUSTER_SET_NAME");

	string cluster_set_name_ =   primary_model_sheduler->option_meaning("CLUSTER_SET_NAME");
	Cluster_set  *cls = new Cluster_set  (	cluster_set_name_,COMMON_USAGE_CLUSTER_SET_MODE);

	first_layer_window_length_ = cls->fragment_length();
	cls->number_of_classes();


	delete cls;
	delete primary_model_sheduler;
//************* INIT MutualDistancesDatabase *******************
		string name_mutual_distance_base = sheduler_->option_meaning ("MUTUAL_DISTANCES_DATABASE");
		mudis_ = new MutualDistances (name_mutual_distance_base ,MUTUALDISTANCES_COMMON_USAGE);


//************* INIT Distance_to_claster_variables *******************
	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("NL_DISTANCE_FUNCTION_TASK_FILE");


	nl_dist_creator_ = new	 NL_DistanceVariables			 ( 	name_);

	//number_of_clasters_ = NL_DistanceVariables	->number_of_clasters ();

//***********************************************************************

//************* INIT CowardVariables    **********************************
	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("NL_COWARD_VARIABLES_TASK_FILE");

	nl_cowa_creator_ = new NL_CowardVariables     (path_to_cowardvariables_task_file) ;
//***********************************************************************

//************* INIT Frequency_extrapolation   **********************************
//	string path_to_frequency_extrapolation_task_file =
//	configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
//		sheduler_->option_meaning ("FREQUENCY_EXTRAPOLATION_TASK_FILE");

//	frva_creator_ = new FrequencyVariables (path_to_frequency_extrapolation_task_file ) ;
//***********************************************************************
	// NEWFIX ��� ���� ����� ������� �����


//***********************************************************************

//************* INIT regression_options_ **********************************
	string path_to_regression_options_file_ =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("REGRESSION_OPTIONS_FILE");

	regression_options_ = new Sheduler	( path_to_regression_options_file_ );
//***********************************************************************

	record_size_ =
		nl_cowa_creator_->get_number_of_variables() +
		nl_dist_creator_ ->get_number_of_variables() ;

			int du_te = nl_dist_creator_ ->get_number_of_variables() ;

	upper_triange_matrix_size_ = record_size_ *(record_size_ +1)/2;
	avsumx_		= new double [record_size_ ]; 	memset (avsumx_	,0,record_size_   *sizeof(double));
	su_			= new double [upper_triange_matrix_size_  ]; 	memset (su_		,0,upper_triange_matrix_size_  *sizeof(double));


	string binary_file_name ("accepted_chain_list.bin");

	fill_up_accepted_chain_data (
		accepted_chain_ID_list_,
		accepted_chain_lenth_,
		binary_file_name );

	length_ = mudis_->get_length ();

	switch ( run_mode  )
	{
		case COMMON_USAGE_MORDEHAY_OPERATING_MODES:
			init_storage ();
			break;
		case FILL_UP_MODEL_MORDEHAY_OPERATING_MODES:
			make_cross_sum_binary_files();
			prepare_united_su_avsumx_d ();
			break;
		default :
			log_stream	<< "Inadmissible run mode for Maimonides_Rambam class" << endl;
			cout		<< "Inadmissible run mode for Maimonides_Rambam class" << endl;
			exit (-1);
	}
}

void Mordehay::
init_storage ()
{
	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("NL_COWARD_VARIABLES_TASK_FILE");

	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("NL_DISTANCE_FUNCTION_TASK_FILE");


	string path_to_cross_sum_binary_file =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/together.cross_sum";

	crs_ = 	new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options_ ) ;

}

void Mordehay::
make_cross_sum_binary_files()
{
		int pre_index_current = -1;
		int obs_index_current = -1;


		prediction_variables_current_		= 0;
		observation_variables_current_	= 0;


		string first_level_model_name =  sheduler_->option_meaning ("FIRST_LEVEL_MODEL");

		Sheduler *primary_model_sheduler		=
			new Sheduler     ( configuration.option_meaning("Path_to_Model_store")  + first_level_model_name + string ("/") + string ("sheduler") ) ;

		int nure_in_mudis				= mudis_->get_number_of_records ();
//!!!		int len_of_fragment_in_mudis	= mudis_->get_length();

		string path_to_prediction_store = configuration.option_meaning("Path_to_Model_store")  + first_level_model_name +  "/cross_sum/";

		int pre_index,pre_start_pos,obs_index,obs_start_pos;
		double distance;


		int size_sofi_var_vector	= nl_cowa_creator_->get_number_of_variables();
		int size_distance_variables = nl_dist_creator_ ->get_number_of_variables();


		double *data_set = new double [ record_size_];

		vector < vector <double> > Whole_Pull_distance_variables;
		int number_of_cases = 0;
		for ( int ii=0; ii< nure_in_mudis; ii++ )
		{

			vector <double> sofi_var_vector;
			vector <double> distance_variables;
			sofi_var_vector.	resize(size_sofi_var_vector	);
			distance_variables.	resize(size_distance_variables);

			mudis_->get_single_record(ii,
				pre_index,pre_start_pos,
				obs_index,obs_start_pos,distance );

			if ( distance == -1 )
				continue;

//			vector < vector < double > >  prediction =
//				mudis_->get_fragment_prediction(
//					pre_index,pre_start_pos,
//					path_to_prediction_store);

				vector < vector < double > > prediction =
					get_fragment_prediction (
						pre_index,pre_start_pos,
						path_to_prediction_store,
						pre_index_current);
						//,						prediction_variables_current_) ;


				vector < vector < double > >   observation =
					get_fragment_observation(
						obs_index, obs_start_pos,
						path_to_prediction_store,
						obs_index_current);
						//,						observation_variables_current_) ;


			bool no_obs_flag = false;
			for (unsigned int ttt=0; ttt< observation.size(); ttt++ )			{
				if (observation[ttt][0] == -1 )					no_obs_flag = true;
			}
			if (no_obs_flag ) 				continue;

// � ��� ��� process_chain() �� ����
// � ��� ��� ���� ����� calc_values()

			nl_cowa_creator_->calc_values (
				prediction,
				observation,
				sofi_var_vector);

			nl_dist_creator_->calc_values (
				distance,
				distance_variables );

// �� �������� ���������� - ����� �� �����������
//			for (int tt = 0; tt < sofi_var_vector.size(); tt++)
	//			log_stream << sofi_var_vector[tt] << '\t';
//
//			for (int tt = 0; tt < distance_variables .size(); tt++)
//				log_stream << distance_variables [tt] << '\t';
//
//			log_stream << endl;
			int point = 0;
			for (unsigned int ttt=0;ttt<sofi_var_vector.size(); ttt++)
			{
				data_set[point] = sofi_var_vector[ttt]; point++;
			}
			for (unsigned int ttt=0;ttt<distance_variables .size(); ttt++)
			{
				data_set[point] = distance_variables[ttt]; point++;
			}

			supplement_cross_sum_matrix(
				record_size_,
				data_set,
				avsumx_,
				su_,
				ADDITION_MODE);

			number_of_cases ++;

			Whole_Pull_distance_variables.push_back(  distance_variables  );

			if ( ii%1000 == 0 )
				cout << ii << endl;

		}
		delete [] data_set;

	 	string current_cross_sum_file_name =
		configuration.option_meaning("Path_to_Model_store_next_layer") +
		name_					+
		"/cross_sum/together.cross_sum";

		ofstream regdata_stream(current_cross_sum_file_name.c_str() ,ios::binary);
		if ( ! regdata_stream)
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_cross_sum_file_name   << endl;
			exit (1);
		}

		write_su_avsumx_d_for_regression (
			regdata_stream,
			number_of_cases );

		regdata_stream.close();


// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/together.dist_data";


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			Whole_Pull_distance_variables);

		distdata_stream.close();

}


void Mordehay::
write_distdata_for_regression (
   	ofstream & out,
	const vector < vector < double > >	& distance_set  )
{
	int number_of_cases =	distance_set.size();
	int number_of_dicl_variables = nl_dist_creator_->get_number_of_variables();

	out.write ( (char* ) & number_of_cases ,	sizeof (int)  );
	out.write ( (char* ) & number_of_dicl_variables,	sizeof (int)  );

	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));

	for (int ii=0; ii< number_of_dicl_variables;ii++)
	{
		for (int jj=0; jj< number_of_cases ;jj++)
			t_arr [jj] = distance_set [jj][ii];
		out.write ( (char* )	t_arr,		number_of_cases * sizeof(double));
		memset (				t_arr	,0,	number_of_cases * sizeof(double));
	}
	delete [] t_arr	;
}


void Mordehay::
write_su_avsumx_d_for_regression (
	ofstream & regdata_stream,
	const int number_of_cases )
{

//	int number_of_variables = cowa_creator_->get_number_of_variables();
//	int number_of_clasters = structure_assignment_->number_of_clasters();

//	int number_of_cowa_variables = cowa_creator_->get_number_of_variables();
//	int number_of_frva_variables = frva_creator_->get_number_of_variables();
//	int number_of_dicl_variables = dicl_creator_->get_number_of_variables();

//	int number_of_cowa_and_frva =  number_of_cowa_variables + number_of_frva_variables ;


//	int nl_cowa_creator_->get_number_of_variables() +
//	int nl_dist_creator_ ->get_number_of_variables() ;



// ������� ������� ����������� �� ������ ������� �� Abu_Maimonides_Rambam::
// ������� ����� ���������� ������ ���������� ��� �������
	int number_of_cowa_and_frva		= nl_cowa_creator_->get_number_of_variables();
	int number_of_dicl_variables	= nl_dist_creator_ ->get_number_of_variables() ;




	//regdata_stream.write ( (char* ) & number_of_cowa_variables ,sizeof (int)  );
	regdata_stream.write ( (char* ) & number_of_cowa_and_frva,sizeof (int)  );
	regdata_stream.write ( (char* ) & number_of_dicl_variables ,	sizeof (int)  );

	regdata_stream.write ( (char* ) & number_of_cases,	sizeof (int)  );
	regdata_stream.write ( (char* )  avsumx_,			record_size_ * sizeof (double)  );
	regdata_stream.write ( (char* )  su_,				upper_triange_matrix_size_			* sizeof (double)  );
}

void Mordehay::
plain_solution ( const string & PDB_chain_ID )
{

	string path_to_cowardvariables_task_file =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("NL_COWARD_VARIABLES_TASK_FILE");




	string path_to_claster_function_task_file =
		configuration.option_meaning("Path_to_Model_store_next_layer") + 	name_ + string ("/") +
		sheduler_->option_meaning ("NL_DISTANCE_FUNCTION_TASK_FILE");
/*

	string path_to_cross_sum_binary_file =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/"			+
			PDB_chain_ID  +
			".cross_sum";

	charming_Reg_solution  * crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options_ ) ;
*/
	string result_file_name_base =
		configuration.option_meaning("Path_to_Model_store_next_layer") +
		name_ + 		string ("/plain_results/") +
		PDB_chain_ID;

	vector <string> predictor_task_files;

	predictor_task_files.push_back(	path_to_cowardvariables_task_file );
//	predictor_task_files.push_back(	path_to_frequency_extrapolation_task_file );

	crs_->show_plain_results (
		predictor_task_files ,
		path_to_claster_function_task_file,
		result_file_name_base);

	delete crs_ ;
}

// ���������� �������� ������� ������� ��� ������������
// ��� ��������� ����� ������� ������� ��������� ���� ��������
// �������� ���� ��� �������� ����������
// FIX ����� ���� ����� �������� -������� ������
//"for (int jj=0; jj<number_of_dependent; jj++  )" e,hfnnm
double Mordehay::	make_single_pair_prediction (
		vector < vector < double > >  & prediction,
		vector < vector < double > >  & observation,
		const int objective_num )
{

	vector < double >  distance_variables  =
		make_single_pair_prediction (
			prediction,
			observation );

	return distance_variables [objective_num];


}



vector < double >  Mordehay::
make_single_pair_prediction (
	vector < vector < double > >  & prediction,
	vector < vector < double > >  & observation
	/*charming_Reg_solution* current_crs*/)
{

	vector < double > 	sofi_var_vector;
	int size_sofi_var_vector	= nl_cowa_creator_->get_number_of_variables();
	sofi_var_vector.	resize(size_sofi_var_vector	);

	nl_cowa_creator_->calc_values (
		prediction,
		observation,
		sofi_var_vector);

//***************************************************************

	double *  absolute_term_pool = 				crs_->get_absolute_term_pool			();
	double ** regression_coefficient_pool = 	crs_->get_regression_coefficient_pool	() ;

	int number_of_predictors	=	nl_cowa_creator_->get_number_of_variables();
	int number_of_dependent		=	nl_dist_creator_->get_number_of_variables() ;

	vector < double >  predicted_det_distance_vector;
	predicted_det_distance_vector.resize(number_of_dependent);

	for (int jj=0; jj<number_of_dependent; jj++  )
	{
		double current_value =
			single_prediction_for_any_known_regression_model (
				sofi_var_vector,
				absolute_term_pool[jj],
				regression_coefficient_pool[jj],
				number_of_predictors );

		predicted_det_distance_vector[jj] =  current_value;
	}

	return predicted_det_distance_vector;
}

void Mordehay::
prepare_predicted_dist_data_for_learning_set  ()
{

	int pre_index_current = -1;
	int obs_index_current = -1;

	prediction_variables_current_		= 0;
	observation_variables_current_	= 0;


	string path_to_cross_sum_binary_file =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/together.cross_sum";


		charming_Reg_solution  * crs =
		new  charming_Reg_solution (
			path_to_cross_sum_binary_file,
			regression_options_ ) ;



		int nure_in_mudis				= mudis_->get_number_of_records ();
///!!		int len_of_fragment_in_mudis	= mudis_->get_length();

		string first_level_model_name =  sheduler_->option_meaning ("FIRST_LEVEL_MODEL");
		string path_to_prediction_store = configuration.option_meaning("Path_to_Model_store")  + first_level_model_name +  "/cross_sum/";

		int pre_index,pre_start_pos,obs_index,obs_start_pos;
		double distance;


		int size_sofi_var_vector	= nl_cowa_creator_->get_number_of_variables();
		int size_distance_variables = nl_dist_creator_ ->get_number_of_variables();


		double *data_set = new double [ record_size_];

		vector < vector <double> > Whole_Pull_distance_variables;
		int number_of_cases = 0;
		for ( int ii=0; ii< nure_in_mudis; ii++ )
		{

			vector <double> sofi_var_vector;
			vector <double> distance_variables;
			sofi_var_vector.	resize(size_sofi_var_vector	);
			distance_variables.	resize(size_distance_variables);

			mudis_->get_single_record(ii,
				pre_index,pre_start_pos,
				obs_index,obs_start_pos,distance );

			if ( distance == -1 )
				continue;
/*
			vector < vector < double > >  prediction =
				mudis_->get_fragment_prediction(
					pre_index,pre_start_pos,
					path_to_prediction_store);

			vector < vector < double > >  observation =
				mudis_->get_fragment_observation(
					obs_index,obs_start_pos,
					path_to_prediction_store);
*/
				vector < vector < double > > prediction =
					get_fragment_prediction (
						pre_index,pre_start_pos,
						path_to_prediction_store,
						pre_index_current);
						//,						prediction_variables_current_) ;


				vector < vector < double > >   observation =
					get_fragment_observation(
						obs_index, obs_start_pos,
						path_to_prediction_store,
						obs_index_current);
						//,						observation_variables_current_) ;



			bool no_obs_flag = false;
			for (unsigned int ttt=0; ttt< observation.size(); ttt++ )			{
				if (observation[ttt][0] == -1 )					no_obs_flag = true;
			}
			if (no_obs_flag ) 				continue;

// � ��� ��� process_chain() �� ����
// � ��� ��� ���� ����� calc_values()

			nl_cowa_creator_->calc_values (
				prediction,
				observation,
				sofi_var_vector);


			distance_variables  = make_single_pair_prediction (
				prediction,
				observation	);

//			nl_dist_creator_->calc_values (
//				distance,
//				distance_variables );

			int point = 0;
			for (unsigned int ttt=0;ttt<sofi_var_vector.size(); ttt++)
			{
				data_set[point] = sofi_var_vector[ttt]; point++;
			}
//			for (int ttt=0;ttt<distance_variables .size(); ttt++)
//			{
//				data_set[point] = distance_variables[ttt]; point++;
//			}

//			supplement_cross_sum_matrix(
//				record_size_,
//				data_set,
//				avsumx_,
//				su_,
//				ADDITION_MODE);

			number_of_cases ++;

			Whole_Pull_distance_variables.push_back(  distance_variables  );

			if ( ii%1000 == 0 )
				cout << ii << endl;

		}
		delete [] data_set;
		delete crs ;


		// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************

		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/together.predicted_dist_data";


		ofstream distdata_stream( current_distance_file_name.c_str() ,ios::binary);
		if ( ! distdata_stream )
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;
			cout       << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name  << endl;

			exit (1);
		}

		write_distdata_for_regression (
			distdata_stream,
			Whole_Pull_distance_variables);

		distdata_stream.close();


//		double *data_set = new double [ record_size_];


}

//#ifndef LOCAL_GET_PDB_LIST_H
//#define LOCAL_GET_PDB_LIST_H
// I plane to use it for motdehay class only
//vector <string> get_pdb_list (const string & teplate_list_filename);
//#endif

//�� ������ ��������� ����� �������� ���������
//� ����� � ������ ��
vector <vector <double> > Mordehay::single_structure_homology_search (
		const string &sequence,
		const string  pdb_ID,
		const int objective_num,
		double sort_sign)

{
		string first_level_model_name =  sheduler_->option_meaning ("FIRST_LEVEL_MODEL");
    Sheduler *primary_model_sheduler		=
			new Sheduler     ( configuration.option_meaning("Path_to_Model_store")  + first_level_model_name + string ("/") + string ("sheduler") ) ;


	Abu_Maimonides_Rambam mr ( first_level_model_name , COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	int number_of_clasters = mr.get_number_of_clasters();

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector < vector < double > > whole_prediction =
		mr.make_prediction_by_sequence (
			sequence,
			current_crs);

	delete current_crs ;
	delete primary_model_sheduler;

//	vector <string> pdb_ID_list = get_pdb_list (teplate_list_filename);


	int length = mudis_->get_length ();


// ��� ����������!! first_layer_window_length  �� ��������� � mudis_!!!
	int first_layer_window_length = mudis_->get_first_layer_window_length ();
	int current_fragment_record_len =   length - first_layer_window_length +1;


	vector <vector <double> > prediction;   // prediction.resize(current_fragment_record_len);
	vector <vector <double> > observation;	// observation.resize(current_fragment_record_len);

/*
	vector <vector <double> > prediction;    prediction.resize(current_fragment_record_len);
	vector <vector <double> > observation;	 observation.resize(current_fragment_record_len);
	for (int kk=0;kk<current_fragment_record_len;kk++)
	{
		prediction [kk].resize(2*number_of_clasters);
		observation[kk].resize(2*number_of_clasters);
	}
*/
	int size_distance_variables = nl_dist_creator_ ->get_number_of_variables();
	vector <double> distance_variables;
	distance_variables.	resize(size_distance_variables);


			vector < vector < double > >  whole_observed =
			mr.read_det_distance_set (
				pdb_ID,
				string (".dist_data") );

		int colomn_size =  whole_prediction.size()   - current_fragment_record_len+1;
		int row_size	= whole_observed.size()  -  current_fragment_record_len+1;
		vector < vector <double> > distance_matrix;
		distance_matrix.resize (row_size);
		for (int dd=0;dd<row_size;dd++)
			distance_matrix[dd].resize(colomn_size);



		for (int ii=0;ii<whole_observed.size()-current_fragment_record_len+1;ii++)
		{
			for (int kk=0;kk<current_fragment_record_len;kk++)
			{
				observation.push_back(whole_observed[ii+kk]);
			}

			for (int jj=0;jj<whole_prediction.size()-current_fragment_record_len+1;jj++)
			{
				for (int kk=0;kk<current_fragment_record_len;kk++)
				{
					prediction	.push_back(whole_prediction[jj+kk]);
				}

				double predicted_distance  = make_single_pair_prediction (
					prediction,
					observation,
					objective_num );

				distance_matrix[ii][jj]=predicted_distance;

				prediction.resize(0);


	//			log_stream	<< ii << " " << pdb_ID_list[ttt] << " " << jj <<  ": " << predicted_distance << endl;
	//			cout		<< ii << " " << pdb_ID_list[ttt] << " " << jj <<  ": " << predicted_distance << endl;
			}

			observation.resize(0);



		}


		return distance_matrix;


}



void Mordehay::structure_homology_search (
	const string &sequence,
	const vector <string> & pdb_ID_list,
	const int objective_num,
	double sort_sign)   // ����� ������ �������� ���������� �� ��� ���.
{

	string first_level_model_name =  sheduler_->option_meaning ("FIRST_LEVEL_MODEL");
    Sheduler *primary_model_sheduler		=
			new Sheduler     ( configuration.option_meaning("Path_to_Model_store")  + first_level_model_name + string ("/") + string ("sheduler") ) ;


	Abu_Maimonides_Rambam mr ( first_level_model_name , COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	int number_of_clasters = mr.get_number_of_clasters();

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector < vector < double > > whole_prediction =
		mr.make_prediction_by_sequence (
			sequence,
			current_crs);

	delete current_crs ;
	delete primary_model_sheduler;

//	vector <string> pdb_ID_list = get_pdb_list (teplate_list_filename);


	length_ = mudis_->get_length ();
//	int first_layer_window_length = mudis_->get_first_layer_window_length ();
	int current_fragment_record_len =   length_ - first_layer_window_length_ +1;


	vector <vector <double> > prediction;   // prediction.resize(current_fragment_record_len);
	vector <vector <double> > observation;	// observation.resize(current_fragment_record_len);

/*
	vector <vector <double> > prediction;    prediction.resize(current_fragment_record_len);
	vector <vector <double> > observation;	 observation.resize(current_fragment_record_len);
	for (int kk=0;kk<current_fragment_record_len;kk++)
	{
		prediction [kk].resize(2*number_of_clasters);
		observation[kk].resize(2*number_of_clasters);
	}
*/
	int size_distance_variables = nl_dist_creator_ ->get_number_of_variables();
	vector <double> distance_variables;
	distance_variables.	resize(size_distance_variables);

///!!	int len_of_fragment_in_mudis	= mudis_->get_length();  // ����� ��� ����� ���������
	for (int ttt=0; ttt< pdb_ID_list.size(); ttt++ )
	{
		vector < vector < double > >  whole_observed =
			mr.read_det_distance_set (
				pdb_ID_list[ttt],
				string (".dist_data") );

		int colomn_size =  whole_prediction.size()   - current_fragment_record_len+1;
		int row_size	= whole_observed.size()  -  current_fragment_record_len+1;
		vector < vector <double> > distance_matrix;
		distance_matrix.resize (row_size);
		for (int dd=0;dd<row_size;dd++)
			distance_matrix[dd].resize(colomn_size);


		string output_file_name = string("TEST//") +  pdb_ID_list[ttt] + string("homology_search");
		ofstream out(output_file_name.c_str() );
		if ( ! out)
		{
			log_stream	<< "ERROR -  can't create " << output_file_name << endl;
			cout		 << "ERROR -  can't create " << output_file_name << endl;
			exit (1);
		}

		for (int ii=0;ii<whole_observed.size()-current_fragment_record_len+1;ii++)
		{
			for (int kk=0;kk<current_fragment_record_len;kk++)
			{
				observation.push_back(whole_observed[ii+kk]);
			}

			for (int jj=0;jj<whole_prediction.size()-current_fragment_record_len+1;jj++)
			{
				for (int kk=0;kk<current_fragment_record_len;kk++)
				{
					prediction	.push_back(whole_prediction[jj+kk]);
				}

				double predicted_distance  = make_single_pair_prediction (
					prediction,
					observation,
					objective_num );

				distance_matrix[ii][jj]=predicted_distance;

				prediction.resize(0);


	//			log_stream	<< ii << " " << pdb_ID_list[ttt] << " " << jj <<  ": " << predicted_distance << endl;
	//			cout		<< ii << " " << pdb_ID_list[ttt] << " " << jj <<  ": " << predicted_distance << endl;
			}

			observation.resize(0);



		}

		for (int dd=0;dd<row_size;dd++)   // ����� ������ ������� � ������ ���� �� ������� ��������
		{
			for (int pp=0;pp<colomn_size;pp++)
			//	PutVaDouble(-1+ 1/distance_matrix[dd][pp],out,8,3,'l');
				PutVaDouble(distance_matrix[dd][pp],out,8,3,'l');

			out << endl;

		}



	}

}




void Mordehay::	analyse_prediction_learning_set ()
{

		string predicted_datafile =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/together.predicted_dist_data";

		string observed_datafile =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_					+
			"/cross_sum/together.dist_data";


	vector < vector < double > > predicted_det_distance_set  =
			read_det_distance_set (predicted_datafile);
	vector < vector < double > > det_distance_set  =
			read_det_distance_set (observed_datafile);


	int task_size = det_distance_set[0].size();
	vector <double> correlation_pull  = calculate_correlation_pull (
		predicted_det_distance_set,
		det_distance_set,
		task_size);


	string result_file_name =
			configuration.option_meaning("Path_to_Model_store_next_layer") +
			name_ + 		string ("/plain_results/") +
			string ("together.compare_prediction") ;


		ofstream out( result_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}

		for (unsigned  int kk=0;kk<predicted_det_distance_set.size();kk++)
		{

			for (unsigned int tt=0;tt<predicted_det_distance_set[0].size();tt++)
			{
				PutVaDouble (predicted_det_distance_set[kk][tt],out,8,3,'l');
				PutVaDouble (det_distance_set[kk][tt],out,8,3,'l');
				out << " ";
			}
			out << endl;
		}

		out << "Correlation pull" <<endl;

		for (unsigned int ii=0;ii<correlation_pull.size();ii++)
			PutVaDouble(correlation_pull[ii],out,8,3,'l');

}



vector < vector < double > > Mordehay::
get_fragment_prediction (
	const int pre_index,
	const int pre_start_pos,
	const string & path_to_prediction_store,
	int & pre_index_current)
	//,	char *prediction_variables_current_)
{

	vector < vector < double > > distance_set;

	if ( pre_index != pre_index_current )
	{
		pre_index_current = pre_index ;
		if (prediction_variables_current_)			delete [] prediction_variables_current_;
		string current_path  = path_to_prediction_store + accepted_chain_ID_list_[pre_index ] + ".dist_data_predicted";
 		prediction_variables_current_ = refresh_variables_current (current_path);
	}
	int		number_of_cases;
	int		diva_number_of_variables;

	memcpy (&number_of_cases,						prediction_variables_current_, sizeof(int));
	memcpy (&diva_number_of_variables,				prediction_variables_current_+ sizeof(int), sizeof(int));

	int current_fragment_record_len =   length_ - first_layer_window_length_ +1;

	distance_set.resize (current_fragment_record_len) ;

	for (int jj=0; jj< current_fragment_record_len ;jj++)
		distance_set[jj].resize (diva_number_of_variables );

	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));
	for (int ii=0; ii< diva_number_of_variables ;ii++)
	{
		memset (				t_arr	,0,	number_of_cases * sizeof(double));
		memcpy (t_arr,	prediction_variables_current_ + 2*sizeof(int) + ii*number_of_cases * sizeof(double), number_of_cases * sizeof(double));

		for (int jj=pre_start_pos; jj< pre_start_pos + length_ - first_layer_window_length_ +1 ;jj++)
				distance_set [jj-pre_start_pos][ii] = t_arr [jj] ;
	}

	delete [] t_arr;


// ����������� 30 ��� 60 ������� ��������� � ������ �� current_path
	return distance_set;
}

/// **********************************
vector < vector < double > > Mordehay::
get_fragment_observation(
	const int obs_index,
	const int obs_start_pos,
	const string & path_to_observation_store,
	int & obs_index_current)
	//,	char *observation_variables_current_)
{

	vector < vector < double > > distance_set;

	if ( obs_index != obs_index_current )
	{
		obs_index_current = obs_index ;

		if (observation_variables_current_)
			delete [] observation_variables_current_;

		string current_path  = path_to_observation_store + accepted_chain_ID_list_[obs_index ] + ".dist_data";
 		observation_variables_current_ = refresh_variables_current (current_path);
	}
	int		number_of_cases;
	int		diva_number_of_variables;

	memcpy (&number_of_cases,						observation_variables_current_, sizeof(int));
	memcpy (&diva_number_of_variables,				observation_variables_current_+ sizeof(int), sizeof(int));

	int current_fragment_record_len =   length_ - first_layer_window_length_ +1;

	distance_set.resize (current_fragment_record_len) ;

	for (int jj=0; jj< current_fragment_record_len ;jj++)
		distance_set[jj].resize (diva_number_of_variables );

	double *t_arr	= new double [number_of_cases	]; 	memset (t_arr	,0,number_of_cases *sizeof(double));
	for (int ii=0; ii< diva_number_of_variables ;ii++)
	{
		memset (				t_arr	,0,	number_of_cases * sizeof(double));
		memcpy (t_arr,	observation_variables_current_ + 2*sizeof(int) + ii*number_of_cases * sizeof(double), number_of_cases * sizeof(double));

		for (int jj=obs_start_pos; jj< obs_start_pos + length_ - first_layer_window_length_ +1 ;jj++)
				distance_set [jj-obs_start_pos][ii] = t_arr [jj] ;
	}

	delete [] t_arr;


// ����������� 30 ��� 60 ������� ��������� � ������ �� current_path
	return distance_set;
}

char * Mordehay::
refresh_variables_current ( const string & current_path)
{

	ifstream in( current_path.c_str() ,ios::binary);
	if ( ! in )
	{
		log_stream << "can't open" << current_path<< endl;
		cout       << "can't open" << current_path<< endl;
		exit (1);
	}

	int check = (int) in.tellg();

	in.seekg(0,ios::end);
	int file_length = (int) in.tellg();
	in.seekg(0,ios::beg);

	char * buff = new char [file_length];

	in.read ( (char* ) buff ,	file_length*sizeof (char)  );

	return buff;

}
