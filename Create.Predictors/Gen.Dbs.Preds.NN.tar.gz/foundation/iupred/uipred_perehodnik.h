#pragma warning( disable : 4786 )

#ifndef UIPRED_PEREHODNIK_H
#define UIPRED_PEREHODNIK_H

#include <string>
#include <vector>

using namespace std;


vector <double> uipred_perehodnik(
	const string & name,
	const string & sequence,
	int run_mode, // mode for calculation: glob, short, long
	const string &path_constant_store); // The path to the files required for the program iupred

double * iupred_perehodnik_c(
	char *name,
	char *sequence,
	int run_mode,
	char *path);

// Work version. other - govno
vector < vector <double> > iupred_perehodnik_c1(
	char *path_to_fasta_file);

// reasd ready prediction from text file created by iupred programm
vector <double>  get_iupred_prediction_from_file(
	const string & path_to_iupred_file,
	string & sequence_by_iupred);



#endif