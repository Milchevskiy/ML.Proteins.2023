#pragma warning( disable : 4786 )

#include "Uipred_test.h"
#include "uipred_perehodnik.h"

#include "../ELM/save_as_fasta.h"

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>

using namespace std;

extern ofstream log_stream;

Uipred_test::~Uipred_test()
{
	cout << "Uipred_test PASSED: " << "  failed: " << get_failed() << "	passed: " << get_passed() << endl;

}
/*
void Uipred_test::uipred_perehodnik_test()
{
	string path_constant_store = "../Store/iupred/";
	string path_to_fasta_file = path_constant_store + string("P53_HUMAN.seq");

	string fasta_head, sequence;
	read_fasta(
		path_to_fasta_file,
		fasta_head,
		sequence);
		
	int run_mode = 0;

	vector <double> Seq_en = uipred_perehodnik(
		fasta_head,
		sequence,
		run_mode,				// mode for calculation: glob, short, long
		path_constant_store);	// The path to the files required for the program iupred

	string path_to_output = "../Test/uipred_perehodnik_test";
	ofstream out(path_to_output.c_str() );
	if (!out)
	{
		cout		<< " Can't create file " << path_to_output << endl;
		log_stream	<< " Can't create file " << path_to_output << endl;
		throw;
	}
	for (int ii = 0; ii < Seq_en.size(); ii++)
	{
		out << sequence[ii] << "\t" << Seq_en[ii] << endl;
	}
};
*/
/*

void Uipred_test::uipred_perehodnik_c_test()
{
	string path_constant_store = "../Store/iupred/";
	string path_to_fasta_file = path_constant_store + string("P53_HUMAN.seq");

	string fasta_head, sequence;
	read_fasta(
		path_to_fasta_file,
		fasta_head,
		sequence);

	int run_mode = 0;

	char *seq = "MEEPQSDPSVEPPLSQETFSDLWKLLPENNVLSPLPSQAMDDLMLSPDDIEQWFTEDPGPDEAPRMPEAAPPVAPAPAAPTPAAPAPAPSWPLSSSVPSQKTYQGSYGFRLGFLHSGTAKSVTCTYSPALNKMFCQLAKTCPVQLWVDSTPPPGTRVRAMAIYKQSQHMTEVVRRCPHHERCSDSDGLAPPQHLIRVEGNLRVEYLDDRNTFRHSVVVPYEPPEVGSDCTTIHYNYMCNSSCMGGMNRRPILTIITLEDSSGNLLGRNSFEVRVCACPGRDRRTEEENLRKKGEPHHELPPGSTKRALPNNTSSSPQPKKKPLDGEYFTLQIRGRERFEMFRELNEALELKDAQAGKEPGGSRAHSSHLKSKKGQSTSRHKKLMFKTEGPDSD\0";
	char *path = "../Store/iupred/\0";
	char *name = "AAAAAAAAA";

	double *Se_en = iupred_perehodnik_c(
		name,
		seq,
		run_mode,
		path);
}
*/
void Uipred_test::uipred_perehodnik_c1_test()
{
	//string path_constant_store = "../Store/iupred/";

	string path_constant_store = "D:/PredictorFactory/Store/iupred/";
	string path_to_fasta_file = path_constant_store + string("P53_HUMAN.seq");

	string fasta_head, sequence;
	read_fasta(
		path_to_fasta_file,
		fasta_head,
		sequence);

	//int run_mode = 0;

//	char *seq = "MEEPQSDPSVEPPLSQETFSDLWKLLPENNVLSPLPSQAMDDLMLSPDDIEQWFTEDPGPDEAPRMPEAAPPVAPAPAAPTPAAPAPAPSWPLSSSVPSQKTYQGSYGFRLGFLHSGTAKSVTCTYSPALNKMFCQLAKTCPVQLWVDSTPPPGTRVRAMAIYKQSQHMTEVVRRCPHHERCSDSDGLAPPQHLIRVEGNLRVEYLDDRNTFRHSVVVPYEPPEVGSDCTTIHYNYMCNSSCMGGMNRRPILTIITLEDSSGNLLGRNSFEVRVCACPGRDRRTEEENLRKKGEPHHELPPGSTKRALPNNTSSSPQPKKKPLDGEYFTLQIRGRERFEMFRELNEALELKDAQAGKEPGGSRAHSSHLKSKKGQSTSRHKKLMFKTEGPDSD\0";
//	char *path = "../Store/iupred/\0";
//	char *name = "AAAAAAAAA";

	char *path_to_fasta_file_c = "../Store/iupred/P53_HUMAN.seq";

	for (int ii = 0; ii < 10000; ii++)
	{
		vector <vector <double> > Se_en = iupred_perehodnik_c1(
			path_to_fasta_file_c);
		cout << ii << endl;
	}



/*
	for (int ii = 0; ii < Se_en[0].size(); ii++)
	{
		cout << sequence[ii] << "\t" 
			 << Se_en[0][ii] << "\t" 
			 << Se_en[1][ii] << "\t" << endl;
	}
	*/
}