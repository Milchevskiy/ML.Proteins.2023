#include "../CommonFunc.h"
#include <fstream>


extern ofstream log_stream;

vector <double>  get_iupred_prediction_from_file(
	const string & path_to_iupred_file,
	string & sequence_by_iupred)
{
/*
		# IUPred
		# Copyright(c) Zsuzsanna Dosztanyi, 2005
#
		# Z.Dosztanyi, V.Csizmok, P.Tompa and I.Simon
		# J.Mol.Biol. (2005) 347, 827 - 839.
#
#
		# Prediction output
		# sp | O00206 | TLR4_HUMAN
*/
	ifstream  in(path_to_iupred_file.c_str());
	if (!in)
	{
		cout << " file " << path_to_iupred_file << " not found " << endl;
		log_stream << " file " << path_to_iupred_file << " not found " << endl;
		exit(1);
	}
	vector <double> Se_en;
	int current_index;
	char current_aa;
	double current_value;

	string current_line;

	for (int ii = 0; ii < 9;ii++)
		getline(in, current_line, '\n');

		while (in >> current_index >> current_aa >> current_value)
		{
			sequence_by_iupred += current_aa;
			Se_en.push_back(current_value);
		}

		return Se_en;
}