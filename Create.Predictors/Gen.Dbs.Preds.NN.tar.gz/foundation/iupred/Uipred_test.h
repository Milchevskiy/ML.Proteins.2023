#ifndef UIPRED_TEST_H
#define UIPRED_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class Uipred_test : public Simple_test
{
public:
	~Uipred_test();

	void run()

	{
	//	uipred_perehodnik_test(); 
		//uipred_perehodnik_c_test();
		uipred_perehodnik_c1_test();
	}
	void uipred_perehodnik_test();
	void uipred_perehodnik_c_test();
	void uipred_perehodnik_c1_test();
	
};

#endif

