#ifdef WIN32
#pragma warning (disable : 4996)
#endif

//#include "Timer.h"
//#include "Log.h"

#include <math.h>
#include <string.h>
#include <iostream>

#include "Min.h"

//#include "File_text_output.h"
//#include "Path.h"

#include "Defs.h"
#include "Mach_eps.h"
//#include "Performance.h"
//#include "User.h"
//#include "Text.h"

#include "MinMax.h"

#include <cmath>
#include <cfloat>

namespace MM
{

///extern  clock_t t1, t2, __div__;

//void (*start_minimization)( Minimizer * );
//void (*stop_minimization)( Minimizer * );
//void (*current_minimization_iteration)( Minimizer * );


//#ifndef max
////#define max(a,b)            (((a) >= (b)) ? (a) : (b))
//#define max(a,b)            (((a) > (b)) ? (a) : (b))
//#endif


//=====================================================
//          Minimizer
//=====================================================

Minimizer::
Minimizer (functional_interface              & Functional_interface,
           retrievable_coordinates_interface & Coordinate_interface,

           double                                Typ_f,
           double                                Typ_g,
           MM::Array< double >                   Typ_x,
           double                                Brack_step,
           int                                   Iter_max,
           Stop_logic                            s_l,
           double                                Func_tol,
           double                                Step_tol,
           double                                Grad_tol )
:
    func_   (Functional_interface ),
    coord_  (Coordinate_interface ),
    f_      (0),
    f_pr_   (0),
    typ_f_  (Typ_f),
    typ_g_  (Typ_g),
    typ_x_  (Typ_x),
    iter_   (0),
    iter_max_   (Iter_max),
    brack_step_ (Brack_step),
    brack_K_    (1.618034),
    scale_      (1.),
    func_tol_   (Func_tol),
    step_tol_   (Step_tol),
    grad_tol_   (Grad_tol),
    xmin_       (Brack_step),//fix
    start_time_         (0),
    stop_time_          (0),
    current_time_       (0),
    stop_logic_         (s_l),
    line_search_type_   (BRENT),
    max_f_              (0)

{
    operation_flag_ = opOTHER;
    start_minimization             = NULL;
    stop_minimization              = NULL;
    current_minimization_iteration = NULL;

    n_ = coord_.size();
    step_.    reserve (n_);
    g_.       reserve (n_);
    g_old_.   reserve (n_);
    d_.       reserve (n_);
    grad_tmp_.reserve (n_);

    for (int i=0;  i<n_;  i++)
    {
        step_.    push_back (0);
        g_.       push_back (1);
        g_old_.   push_back (1);
        d_.       push_back (1);
        grad_tmp_.push_back (0);
    }

    f_ = func_val  ();
    accept_changes ();
}

// Current
Minimizer::
Minimizer (functional_interface              & Functional_interface,
           retrievable_coordinates_interface & Coordinate_interface,

           double                                Typ_f,
           double                                Typ_g,
           double                                Typ_x,
           double                                Brack_step,
           int                                   Iter_max,
           Stop_logic                            s_l,
           double                                Func_tol,
           double                                Step_tol,
           double                                Grad_tol)
:
    func_   (Functional_interface),
    coord_  (Coordinate_interface),
    f_      (0),
    f_pr_   (0),
    typ_f_  (Typ_f),
    typ_g_  (Typ_g),
    //fix typ_x_(Typ_x),
    iter_   (0),
    iter_max_   (Iter_max),
    brack_step_ (Brack_step),
    brack_K_    (1.618034),
    scale_      (1.),
    func_tol_   (Func_tol),
    step_tol_   (Step_tol),
    grad_tol_   (Grad_tol),
    xmin_       (Brack_step),
    start_time_         (0),
    stop_time_          (0),
    current_time_       (0),
    stop_logic_         (s_l),
    line_search_type_   (BRENT),
    max_f_              (0)

{
    operation_flag_ = opOTHER;
    start_minimization             = NULL;
    stop_minimization              = NULL;
    current_minimization_iteration = NULL;

    n_ = coord_.size();
    step_.    reserve (n_);
    g_.       reserve (n_);
    g_old_.   reserve (n_);
    d_.       reserve (n_);
    grad_tmp_.reserve (n_);
    typ_x_.   reserve (n_);

    for (int i=0;  i<n_;  i++)
    {
        step_.    push_back (0);
        g_.       push_back (1);
        g_old_.   push_back (1);
        d_.       push_back (1);
        grad_tmp_.push_back (0);
        typ_x_.   push_back (Typ_x);
    }

    f_ = func_val  ();
    accept_changes ();
}

Minimizer::~Minimizer()
{
//fix    init();
}

void  Minimizer::
init ()
{
    operation_flag_          = opOTHER;
    bracketing_func_counter_ = 0;
    brent_func_counter_      = 0;
    quadratic_func_counter_  = 0;
    cubic_func_counter_      = 0;
    other_func_counter_      = 0;

    stop_flag_ = No_stop;

    f_pr_         = 0;
    f_priv_       = 0;

    iter_         = 0;
    max_f_        = 0;
    xmin_         = brack_step_;

    func_counter_ = 0;
    grad_counter_ = 0;

//    start_time_            = Test_Performance::get_time();
//    stop_time_             = 0;
 //   current_time_          = 0;
  // current_time_priv_     = 0;
  //  current_external_time_ = 0;
  //  sum_external_time_     = 0;

    step_.clear     ();
    g_.clear        ();
    g_old_.clear    ();
    d_.clear        ();
    grad_tmp_.clear ();

    step_.    reserve (n_);
    g_.       reserve (n_);
    g_old_.   reserve (n_);
    d_.       reserve (n_);
    grad_tmp_.reserve (n_);

    for( int i=0;  i<n_;  i++ )
    {
        step_.    push_back (0);
        g_.       push_back (1);
        g_old_.   push_back (1);
        d_.       push_back (1);
        grad_tmp_.push_back (0);
    }

    f_ = func_val();
    accept_changes();
}

double  Minimizer::
func_val ()
{
    func_counter_++;
    f_ = func_.value();

    switch (operation_flag_)
    {
        case opBRAKETING:   bracketing_func_counter_ ++;  break;
        case opBRENT:       brent_func_counter_      ++;  break;
        case opQUADRATIC:   quadratic_func_counter_  ++;  break;
        case opCUBIC:       cubic_func_counter_      ++;  break;
        case opOTHER:       other_func_counter_      ++;  break;

//        default: to_user().error("Minimizer::func_val");
    }

    return f_;
}

void  Minimizer::
grad (Array <double> & gr)
{
    grad_counter_++;
    const double    val = func_val();
    accept_changes();
    coord_.first();

    for (int i=0;  i<gr.size();  i++)
    {
        double  x = coord_.get_current();

        double  h = d_mach_eps_2 * max (fabs (x), 1.0);
//              double  h = d_mach_eps_2*max( fabs( x ), typ_x_[i] );       // ! true
//              double  h = 0.001;                                             //!!!???
//              double  h = 0.0000000001;   // BC45

        double  tmp = x + h;
        h = tmp - x;
        coord_.add_to_current (h);
        gr[i] = (func_val() - val) / h;
        reject_changes ();
        coord_.next ();
    }
}

double  Minimizer::
f_grad (Array <double> & gr)
{
    grad (gr);
    return f_; //fix ?
}

double  Minimizer::
relative_gradient()
{
    //double  rel_step = 0;
    double  rel_grad = 0;
//    File_text_output out (Path::report() +"Minimizer relative_gradient.txt");

//    coord_.first();
    for (int i=0;  i<coord_.size();  ++i)
    {
        //MM::log () << "g_[" << i << "] " << g_[i] << "\n";
//        out.text ("g_[");
    //    out.text (i);
    //    out.text ("] ");
    //    out.line (g_[i]);
        //double X = max( fabs( coord.get_current() ), typ_x[i] );
        //rel_step = max( fabs( step[i] ) / X, rel_step );
//              rel_grad = max( fabs( xi[i] ) * X / max_f, rel_grad );
        rel_grad += g_[i] * g_[i];
//              coord_.next();
    }
    return sqrt (rel_grad) / coord_.size();
}

functional_interface &   Minimizer::
get_functional_interface()
{
    return func_;
}

retrievable_coordinates_interface &   Minimizer::
get_retrievable_coordinates_interface()
{
    return coord_;
}

int     Minimizer::get_function_calls()       {return func_counter_;}
int     Minimizer::get_gradient_calls()       {return grad_counter_;}
int     Minimizer::get_bracketing_func_calls(){return bracketing_func_counter_;}
int     Minimizer::get_brent_func_calls()     {return brent_func_counter_;}
int     Minimizer::get_quadratic_func_calls() {return quadratic_func_counter_;}
int     Minimizer::get_cubic_func_calls()     {return cubic_func_counter_;}
int     Minimizer::get_other_func_calls()     {return other_func_counter_;}

/*
double  Minimizer::get_start_time()           {return start_time_;  }
double  Minimizer::get_stop_time()            {return stop_time_;   }
double  Minimizer::get_current_time()         {return current_time_;}
double  Minimizer::get_iteration_time()
          {return  current_time_ - current_time_priv_;}
*/
//double  Minimizer::get_pure_iteration_time()
 //         {return  current_time_ - current_time_priv_ -
 //                   current_external_time_/Test_Performance::get_frequency();}
 /*
double  Minimizer::get_minimization_time()
          {return  stop_time_ - start_time_;}
double  Minimizer::get_pure_minimization_time()
          {return  stop_time_ - start_time_ -
                    sum_external_time_/Test_Performance::get_frequency();}
*/
int     Minimizer::get_iteration()            {return iter_;}

void    Minimizer::set_line_search_type (Line_search_type type) {line_search_type_ = type;}
void    Minimizer::set_brack_K (double K)      {brack_K_ = K; }


void  Minimizer::
get_stop_reason (char * buffer)
{
//    char *str = new char[200];        //!!!

    strcpy( buffer, "" );
    if (stop_flag_ & No_stop         ) strcat (buffer, "No stop, "                   );
    if (stop_flag_ & Grad_tol_reached) strcat (buffer, "Gradient tolerance reached, ");
    if (stop_flag_ & Step_tol_reached) strcat (buffer, "Step tolerance reached, "    );
    if (stop_flag_ & Func_tol_reached) strcat (buffer, "Function tolerance reached, ");
    if (stop_flag_ & No_improvement  ) strcat (buffer, "No improvement, "            );
    if (stop_flag_ & Iter_exceeding  ) strcat (buffer, "Iterations exceeding "       );

//    return buffer;
}



/** conjugate gradient

 http://en.wikipedia.org/wiki/Nonlinear_conjugate_gradient_method
 SIAM J. OPTIMIZATION, Vol. 2, No. 1, pp. 21-42, February 1992

 d - search direction
 g - gradient

 x_new = x + alpha * d               alpha - from line search

     | -g                   for k=1
 d = |
     | -g + beta * d_old    for k>1

 Fletcher�Reeves  beta = (g * g)           / (g_old * g_old)
 Polak�Ribiere    beta = (g * (g - g_old)) / (g_old * g_old)
 Hestenes-Stiefel beta = (g * (g - g_old)) / (d * (g - g_old))
*/
void   Minimizer::
conjugate_gradient (Type type, int N)
{
    int    i,k;
    if (start_minimization)  (*start_minimization)(this);
    init();
    derivative_flag_ = 1;
    double beta = 0;

    if (N != 0)  iter_max_ = N;

    grad (g_);
    for (i=0;  i<n_;  ++i)
    {
        d_[i]     = -g_[i];
        g_old_[i] =  g_[i];
    }

    for (k=0;  k<iter_max_;  ++k)
    {
        iter_ = k+1;

        line_min ();

        f_priv_ = f_;
        f_grad (g_);
        f_pr_ = f_;

        stop_flag_ = check_stop();

        if (Stop & stop_flag_)
        {
       //     stop_time_ = Test_Performance::get_time();
            if (stop_minimization)  (*stop_minimization)(this);
            return;
        }

        double numerator = 0., denominator = d_mach_eps;

        switch (type)
        {
        case Hestenes_Stiefel:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += g_[i] * (g_[i] - g_old_[i]);
                denominator  += d_[i] * (g_[i] - g_old_[i]);
            }
            beta = numerator / denominator;
            break;
        case Lui_Storey:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += -g_[i] * (g_[i] - g_old_[i]);
                denominator  +=  g_old_[i] * d_[i];
            }
            beta = numerator / denominator;
            break;
        case Polak_Ribiere:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += g_[i] * (g_[i] - g_old_[i]);
                denominator  += g_old_[i] * g_old_[i];
            }
            beta = numerator / denominator;
            break;
        case Fletcher_Reeves:
            for (i=0;  i<n_;  ++i)
            {
                numerator   += g_[i] * g_[i];
                denominator += g_old_[i] * g_old_[i];
            }
            beta = numerator / denominator;
            break;
        case Dai_Yuan:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += g_[i] * g_[i];
                denominator  += d_[i] * (g_[i] - g_old_[i]);
            }
            beta = numerator / denominator;
            break;
        case Conjugate_Descent:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += -g_[i] * g_[i];
                denominator  +=  g_old_[i] * d_[i];
            }
            beta = numerator / denominator;
            break;
        case Hu_Storey:
        {
            // Polak_Ribiere
            for (i=0;  i<n_;  ++i)
            {
                numerator    += g_[i] * (g_[i] - g_old_[i]);
                denominator  += g_old_[i] * g_old_[i];
            }
            double betaPR = numerator / denominator;
            // Fletcher_Reeves
            for (i=0;  i<n_;  ++i)
            {
                numerator   += g_[i] * g_[i];
                denominator += g_old_[i] * g_old_[i];
            }
            double betaFR = numerator / denominator;
            beta = max (0., min (betaPR, betaFR));
            break;
        }
        case Hybrid_Dai_Yuan_zero:
        {
            // Hestenes_Stiefel:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += g_[i] * (g_[i] - g_old_[i]);
                denominator  += d_[i] * (g_[i] - g_old_[i]);
            }
            double betaHS = numerator / denominator;
            // Dai_Yuan:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += g_[i] * g_[i];
                denominator  += d_[i] * (g_[i] - g_old_[i]);
            }
            double betaDY = numerator / denominator;
            beta = max (0., min (betaHS, betaDY));
            break;
        }
        case Hybrid_Lui_Storey_and_Conjugate_Descent:
        {
            // Lui_Storey:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += -g_[i] * (g_[i] - g_old_[i]);
                denominator  +=  g_old_[i] * d_[i];
            }
            double betaLS = numerator / denominator;
            // Conjugate_Descent:
            for (i=0;  i<n_;  ++i)
            {
                numerator    += -g_[i] * g_[i];
                denominator  +=  g_old_[i] * d_[i];
            }
            double betaCD = numerator / denominator;
            beta = max (0., min (betaLS, betaCD));
            break;
        }
        case Steepest_Descent:
            beta = 0.;
            break;

   //     default: FLAW ("Wrong Minimizer::Type");
        }

        //if (beta<0.)
        //    beta = 0.;

        for (i=0;  i<n_;  ++i)
        {
            d_[i] = -g_[i] + beta * d_[i];
            g_old_[i]  = g_[i];
        }

        current_time_priv_ = current_time_;
//        current_time_ = Test_Performance::get_time();
   //     Test_Performance::get_interval();
        if (current_minimization_iteration) (*current_minimization_iteration)(this);
  //      sum_external_time_ += current_external_time_ = Test_Performance::get_interval();
    }

   // to_user().error ("Minimizer::conjugate_gradient");
}

void  Minimizer::
line_min ()
{
    int i;
    double len=0;

    for (i=0;  i<n_;  ++i)
        len += d_[i] * d_[i];
    len = sqrt (len);

    if (len < d_mach_eps_2)
        return;  // gradient == 0

    for (i=0;  i<n_;  ++i)
        step_[i] = d_[i] / len;

    switch (line_search_type_)
    {
        case BRENT:   line_min_brent();  break;
        case CUBIC:   line_min_cubic();  break;
    //    default:      to_user().error ("Minimizer::line_min");
    }
    accept_changes();                  //???
}

//Energy = -25.8768060972996
//Gradient--- 0.000843427
//Step ------ 8.32e-006
//Function -- 1.06e-008
//Iteration - 29
//Gradient tolerance reached, Step tolerance reached, Function tolerance reached,
//1.46777sec
//
//Calls
//238. function
//30. gradient
//58. bracketing
//178. Brent
//0. quadratic
//0. cubic
//2. others

void  Minimizer::
line_min_brent ()
{
    double fx,fb,fa;

    double a=0.0;
    double x=1.0 * xmin_ * brack_step_;             //fix   1.0 * xmin_ * brack_K_;
    double b=2.0 * xmin_ * brack_step_;             //fix

        //MM::log()
        //    << "xmin_ "       << xmin_ << "\n"
        //    << "brack_step_ " << brack_step_ << "\n"
        //    << "\n";

    bracket (&a, &x, &b, &fa, &fx, &fb);
    brent (a, x, b,  fx);

    coord_.first();
    for (int j=0;  j<n_;  ++j)
    {
        step_[j] *= xmin_ * scale_;
        coord_.add_to_current( step_[j] );
        coord_.next();
    }
}

void  Minimizer::
bracket (double * a,  double * b,  double * c,
         double * fa, double * fb, double * fc)
{
    operation_flag_ = opBRAKETING;
    ++bracketing_func_counter_;
    int loop_count = 0, max_loop = 100;

    double scale = brack_step_; // 254
    //double scale = 1.3; // 263
    //double scale = 1.5; // 253
    //double scale = 1.7; // 263
    //double scale = 2.0; // 254
    //double scale = 3.0; // 279
    //double scale = 5.0; // 274

    *fa = f_;
    *fb = f (*b);
    *c = *b + scale * (*b - *a);
    *fc = f (*c);

    while (*fb + d_mach_eps > *fa)
    {
        *c = *b;                *fc = *fb;
        *b = 0.5 * (*b - *a);   *fb =  f (*b);

        if (++loop_count > max_loop)
        {
            loop_count = 0;
            *c += brack_step_;      *fc = f (*c);

            while (*fb + d_mach_eps > *fa)
            {
                //*c = *b;                        *fc = *fb;
                *b = *a;                        *fb = *fa;
                *a = *b - scale * (*c - *b);    *fa = f (*a);

//                if (++loop_count > max_loop)
//                    FLAW ("Infinite loop");
            }
        }
    }

    loop_count = 0;

    while (*fb + d_mach_eps > *fc)
    {
            //MM::log()
            //    << "a " << *a << "\n"
            //    << "b " << *b << "\n"
            //    << "c " << *c << "\n"
            //    << "fa " << *fa << "\n"
            //    << "fb " << *fb << "\n"
            //    << "fc " << *fc << "\n"
            //    << "\n";

        //*a = *b;                        *fa = *fb;
        *b = *c;                        *fb = *fc;
        *c = *b + scale * (*b - *a);    *fc = f (*c);

        if (++loop_count > max_loop)
            throw ;
 //           FLAW ("Infinite loop");
    }
    operation_flag_ = opOTHER;
}

// Abopted from John D. Cook 'Minimize' procedure.
// CPOL license.
// Notation and implementation based on Chapter 5 of Richard Brent's book
// "Algorithms for Minimization Without Derivatives".

double  Minimizer::
brent (double a, double x, double b,   double fx)
{
    operation_flag_ = opBRENT;

    double d, e, m, p, q, r, tol, t2, u, v, w, fu, fv, fw/*, fx*/;
    static const double c = 0.5 * (3.0 - sqrt(5.0));
    ///static const double SQRT_DBL_EPSILON = sqrt (DBL_EPSILON);

    //static const double t = 2e-4;
                                    //              Cubic
    //static const double t = 1e-7;   //650 7153      658 1780
    static const double t = 1e-6;   //650 5541      658 1780
    //static const double t = 1e-5;   //655 5250
    //static const double t = 1e-4;   //654 4974
    //static const double t = 1e-3;   //586 4207
    //static const double t = 1e-2;   // -

    ///double& a = leftEnd; double& b = rightEnd; double& x = minLoc;
//    CHECK ("a = leftEnd and b = rightEnd", a < b);

    ///v = w = x = a + c*(b - a); d = e = 0.0;
    u =      v = w = x;
    d = e = 0.0;
    ///fv = fw = fx = f(x);
    fu =     fv = fw = fx;
	int counter = 0;

loop:
	counter++;
    m = 0.5 * (a + b);
    ///tol = SQRT_DBL_EPSILON*fabs(x) + t; t2 = 2.0*tol;
    tol = d_mach_eps_2 * fabs (x) + t/3; t2 = 2.0*tol;

    // Check stopping criteria
    if (fabs(x - m) > t2 - 0.5*(b - a) && counter < 30) //fix max_brent_it_
    {
        p = q = r = 0.0;
        if (fabs(e) > tol)
        {
            // fit parabola
            r = (x - w)*(fx - fv);
            q = (x - v)*(fx - fw);
            p = (x - v)*q - (x - w)*r;
            q = 2.0*(q - r);
            (q > 0.0) ? p = -p : q = -q;
            r = e;
            e = d;//
        }
        ///if (fabs(p) < fabs(0.5*q*r) && p < q*(a - x) && p < q*(b - x))
        if (fabs(p) < fabs(0.5*q*r) && q*(a - x) < p && p < q*(b - x))
        {
            // A parabolic interpolation step
            d = p/q;
            u = x + d;
            // f must not be evaluated too close to a or b
            if (u - a < t2 || b - u < t2)
                d = (x < m) ? tol : -tol;
        }
        else
        {
            // A golden section step
            e = (x < m) ? b : a;
            e -= x;
            d = c*e;
        }
        // f must not be evaluated too close to x
        if (fabs(d) >= tol)
            u = x + d;
        else if (d > 0.0)
            u = x + tol;
        else
            u = x - tol;
        fu = f(u);
        // Update a, b, v, w, and x
        if (fu <= fx)
        {
            (u < x) ? b = x : a = x;
            v = w; fv = fw;
            w = x; fw = fx;
            x = u; fx = fu;
        }
        else
        {
            (u < x) ? a = u : b = u;

            if (fu <= fw || w == x)
            {
                v = w; fv = fw;
                w = u; fw = fu;
            }
            else if (fu <= fv || v == x || v == w)
            {
                v = u; fv = fu;
            }
        }
        goto loop;
        // Yes, the dreaded goto statement.
        // But the code here is faithful to Brent's orginal pseudocode.
    }
    xmin_ = x;
    operation_flag_ = opOTHER;
    return  fx;
}

//Energy = -25.8768061257175
//Gradient--- 0.000880909
//Step ------ 6.12e-006
//Function -- 6.31e-009
//Iteration - 29
//Gradient tolerance reached, Step tolerance reached, Function tolerance reached,
//26.4568sec
//
//Calls
//112. function
//30. gradient
//43. bracketing
//38. Brent
//29. quadratic
//0. cubic
//2. others

void  Minimizer::
line_min_cubic ()
{
    // min in the step_ direction
    double a = 0.0; //fix remove
    double x, b, fa,fx,fb, da=0.0;
    int cur = 0;
    int i;

    const double GOLD = 1.618034;


    // bracketing
    operation_flag_ = opBRAKETING;

    //x = 1.0 ;
    x = 1. * xmin_ * brack_step_;

    // grad in  the step_ direction
    for (i=0;  i<n_;  i++) da += g_old_[i] * step_[i];

    fa = f_;
    fx = f (x);
    int br_flag = 0;

    // if positive defined than quadratic interpolation
    if (da*x + fa < fx)
    {
        operation_flag_ = opQUADRATIC;
        b = -da /( 2*( fx - fa - da ) );
        b *= x;

        //if (b < 0.1*x)
        //    {b = 0.1*x; br_flag = 1;}
        //if (b > 10*x)
        //    {b = 10*x; br_flag = 1;}

        fb = f (b);

        if (b < x)
        {
            if (fb >= fa)
            {
                x = b / GOLD;
                br_flag = 1;
            }
            else
            {
                if (fb < fx)      //fix
                {           //fix
                    double tmpx = b, tmpf = fb;
                    b = x;    fb = fx;
                    x = tmpx; fx = tmpf;
                   // br_flag = 1;
                }
                else                            // Bad approximation
                {
                    b = x * GOLD;
                    br_flag = 1;
                }
            }
        }
        else if (b > x)
        {
            if (fx > fa)     // very bad approximation
            {
                b = x;
                x = b / GOLD;
                br_flag = 1;
            }
            else
            {
                if (fb < fx)
                {
                    std::cout << ".";
//                                      out << ".";
                    cur++;
                    x = b;    fx = fb;
                    b *= GOLD;
                    fb = f (b);
                    if (fb < fx)
                    {                 // Bad approximation
                        x = b;
                        b *= GOLD;
                        br_flag = 1;
                    }
                }
            }
        }
        else if (b == x)
        {
            b *= GOLD;
            br_flag = 1;
        }
    }
    else
    {
        br_flag = 1;
    }

    if( br_flag )
    {
        bracket (&a, &x, &b, &fa, &fx, &fb);
        std::cout << "!";
        cur++;
        brent (a, x, b,  fx);
    }
    else
    {
    //
    //  // quadratic interpolation
    //  double a2 = a*a;
    //  double x2 = x*x;
    //  double b2 = b*b;
    //
    //  xmin = 0.5*((x2-b2)*fa + (b2-a2)*fx + (a2-x2)*fb) /
    //                          ((x-b)*fa + (b-a)*fx + (a-x)*fb);
    //

        // cubic interpolation
        operation_flag_ = opCUBIC;
        double  K  = 1. / (x - b);
        double  C  = fx - fa - da*x;
        double  D  = fb - fa - da*b;

        double  b2 = b*b, x2 = x*x;
        double  A1 =  1. / x2;
        double  A2 = -1. / b2;
        double  B1 = -b / x2;
        double  B2 =  x / b2;

        double  A = K* (A1*C + A2*D);
        double  B = K* (B1*C + B2*D);
        double  DET = B*B - 3*A*da;
        if (DET >= 0)
        {
            xmin_ = (-B + sqrt (DET)) / (3 * A);
            xmin_ += a;
        }
        else brent (a, x, b,  fx);

    }

    for (i = 2;  i>cur;  i--)  {std::cout << " ";/* out << " ";*/}

    coord_.first();
    for (int j=0;  j<n_;  ++j)
    {
        step_[j] *= xmin_ * scale_;
        coord_.add_to_current (step_[j]);
        coord_.next ();
    }
    //      func();
    operation_flag_ = opOTHER;
}

double  Minimizer::
f (double x)
{
    coord_.first();

    for (int i=0;  i<n_;  ++i)
    {
        coord_.add_to_current (x *step_[i]);
        coord_.next();
    }

    double  value = func_val ();
    reject_changes ();
    return value;
}

void   Minimizer::
stop()
{
//    log() << "User break.\n";
    stop_flag_ = Stop;
}

//Minimizer::Stop_flag   Minimizer::
int   Minimizer::
check_stop()
{
    int   i;

    if (stop_flag_ == Stop)
        return Stop;

    stop_flag_ = No_stop;

//      cout << endl << "#" << setw( 2 ) << iter_;
//      cout << " f " << setprecision( 8 ) << setw( 10 ) << f_;

    find_max_f();

    rel_step_ = 0;
    rel_grad_ = 0;

    if (derivative_flag_)
    {
        coord_.first();

        for (i=0;  i<coord_.size();  ++i)
        {
            double X = max (fabs (coord_.get_current()), typ_x_[i]);
            rel_step_= max (fabs (step_[i]) / X, rel_step_);
//              rel_grad = max (fabs (g_[i]) * X / max_f, rel_grad);
            rel_grad_ += g_[i] * g_[i];
            coord_.next();
        }
        rel_grad_ = sqrt (rel_grad_) / coord_.size();
    }

    if (rel_step_ <= step_tol_)
        stop_flag_ |= Step_tol_reached;

    if (derivative_flag_)
    {
        if (rel_grad_ <= grad_tol_)
            stop_flag_ |= Grad_tol_reached;
    }
    else if (stop_logic_ == AND)
    {
        stop_flag_ |= Grad_tol_reached;
    }
//      cout << " G "  << setprecision( 3 ) << setw(8) << rel_grad << " ";
//      cout << " dS " << setprecision( 3 ) << setw(8) << rel_step << " ";

    rel_func_ = 2.0 * fabs (f_priv_ - f_) /
                     (fabs (f_priv_) + fabs (f_) + d_mach_eps_2);

    if (rel_func_ <= func_tol_)
        stop_flag_ |= Func_tol_reached;
//      cout << " dF " << setw(8) << rel_func << " ";

//    if( ret_code )  { stop_flag |= No_improvement;  return  stop_flag; }
    if (iter_ >= iter_max_)
        stop_flag_ |= Iter_exceeding;

    switch (stop_logic_)
    {
        case OR:
            if (stop_flag_ & Grad_tol_reached ||
                stop_flag_ & Step_tol_reached ||
                stop_flag_ & Func_tol_reached ||
                stop_flag_ & No_improvement   ||
                stop_flag_ & Iter_exceeding  )

                stop_flag_ |= Stop;
            break;

        case AND:
            if (stop_flag_ & Grad_tol_reached &&
                stop_flag_ & Step_tol_reached &&
                stop_flag_ & Func_tol_reached ||
                stop_flag_ & Iter_exceeding  )

                stop_flag_ |= Stop;
            break;

//            default: to_user().error( "Undefined logic in minimizer" );
    }

    return  stop_flag_;
}

double  Minimizer::
find_max_f()
{
    return max_f_ = max (f_, typ_f_);
}

void  Minimizer::
accept_changes()
{
    f_pr_ = f_;
    coord_.accept_changes();
}

void  Minimizer::
reject_changes()
{
    f_ = f_pr_;
    coord_.reject_changes();
}

//=====================================================
//            Gradient minimizer
//=====================================================

void  Gradient_minimizer::
grad (Array <double> & gr)
{
    //Minimizer::grad (gr);
    //return;

    grad_counter_++;
    diff_func_.grad( gr );
    accept_changes();
}

double  Gradient_minimizer::
f_grad (Array <double> & gr)
{
    //return  f_ = Minimizer::f_grad( gr );

    grad_counter_++;
    return  f_ = diff_func_.f_grad( gr );
}
/*
Gradient_minimizer::
Gradient_minimizer (
    differentiable_interface          & Differentiable_interface,
    retrievable_coordinates_interface & Coordinate_interface,
    double            Typ_f,
    double            Typ_g,
    Array <double>    Typ_x,
    double            Brak_step,
    int               Iter_max,
    Stop_logic        s_l,
    double            Func_tol,
    double            Step_tol,
    double            Grad_tol/*,
    //ostream &       o )
:
    Minimizer (Differentiable_interface, Coordinate_interface,
               Typ_f, Typ_g, Typ_x, Brak_step, Iter_max, s_l,
               Func_tol, Step_tol, Grad_tol,
    diff_func_ (Differentiable_interface)
{
}
*/

Gradient_minimizer::
Gradient_minimizer (
    differentiable_interface          & Differentiable_interface,
    retrievable_coordinates_interface & Coordinate_interface,
    double            Typ_f,
    double            Typ_g,
    double            Typ_x,
    double            Brak_step,
    int               Iter_max,
    Stop_logic        s_l,
    double            Func_tol,
    double            Step_tol,
    double            Grad_tol/*,
    ostream &       o*/  )
:
    Minimizer (Differentiable_interface, Coordinate_interface,
               Typ_f, Typ_g, Typ_x, Brak_step, Iter_max, s_l,
               Func_tol, Step_tol, Grad_tol/*, o*/),
    diff_func_ (Differentiable_interface)
{
}

//======================= Samples =================================
real SQ( real x );
real SQ( real x )  { return x*x; }

double    simple_as_differentiable::
value()
  {
    return SQ( obj.x[0] - 1.5 ) + 1.2;
  }

void    simple_as_differentiable::
grad( MM::Array< double > & gr )
  {
    gr[0] = obj.x[0] - 1.5;
  }

int     simple_as_retrievable_coordinates::size() const             { return 1;          }
double    simple_as_retrievable_coordinates::get( int   ) const      { return obj.x[0];   }
void    simple_as_retrievable_coordinates::set( int , double value ) { obj.x[0] = value; }
void    simple_as_retrievable_coordinates::add( int , double value ) { obj.x[0] += value; }
//double  simple_as_retrievable_coordinates::first( void )            { return obj.x[0];   }
//double  simple_as_retrievable_coordinates::next( void )             { return obj.x[0];   }
void    simple_as_retrievable_coordinates::first( void )            {  }
void    simple_as_retrievable_coordinates::next( void )             {  }
double    simple_as_retrievable_coordinates::get_current( void )      { return obj.x[0];   }
//double  simple_as_retrievable_coordinates::retrieve( void )         { return obj.x_pr[0];}
double    simple_as_retrievable_coordinates::retrieve( int  )        { return obj.x_pr[0]; }
double    simple_as_retrievable_coordinates::retrieve_current( void ) { return obj.x_pr[0]; }
void    simple_as_retrievable_coordinates::set_current( double value ){ obj.x[0] = value; }
void    simple_as_retrievable_coordinates::add_to_current( double value ) { obj.x[0] += value; }
void    simple_as_retrievable_coordinates::accept_changes()         { obj.x_pr = obj.x;  }
void    simple_as_retrievable_coordinates::reject_changes()         { obj.x = obj.x_pr;  }
int     simple_as_retrievable_coordinates::is_changed()             { return 0; }
//double    simple_as_retrievable_coordinates::delta_x( int i )     { return x[i]-x_pr[i]; }

simple::simple()
  : current( 0 )
  {
    //x.add_by_default( 1 );
    //x_pr.add_by_default( 1 );
    x.push_back( 0 );
    x_pr.push_back( 0 );

    x[0] = x_pr[0] = 0;
  }

simple_as_differentiable::simple_as_differentiable( simple & Obj )
  : obj( Obj )
  {
  }
simple_as_retrievable_coordinates::simple_as_retrievable_coordinates( simple & Obj )
  : obj( Obj )
  {
  }
//--------------------- Rosenbrok --------------------------

double  rosenbrok_as_differentiable::
value()
  {
//    cout << "..." << x[0] << "  " << x[1] << endl;
    return obj.K_ * SQ( SQ( obj.x[0] ) - obj.x[1] ) + SQ( 1 - obj.x[0] );
  }

void  rosenbrok_as_differentiable::
grad( MM::Array< double > & gr )
  {
    gr[0] = 4*obj.K_*( SQ( obj.x[0] ) - obj.x[1] ) * obj.x[0] - 2 + 2*obj.x[0];
    gr[1] = -2*obj.K_*( SQ( obj.x[0] ) - obj.x[1] );
  }

int     rosenbrok_as_retrievable_coordinates::size( void ) const        { return 2;                }
double    rosenbrok_as_retrievable_coordinates::get( int i  ) const       { return obj.x[i];         }
void    rosenbrok_as_retrievable_coordinates::set( int i, double value )  { obj.x[i] = value;        }
void    rosenbrok_as_retrievable_coordinates::add( int i, double value )  { obj.x[i] += value;       }

//double  rosenbrok_as_retrievable_coordinates::first( void )             { return obj.x[current=0]; }
//double  rosenbrok_as_retrievable_coordinates::next( void )              { return obj.x[current=1]; }
void    rosenbrok_as_retrievable_coordinates::first( void )             { current=0; }
void    rosenbrok_as_retrievable_coordinates::next( void )              { current=1; }
double  rosenbrok_as_retrievable_coordinates::get_current( void )         { return obj.x[current];   }
//double  rosenbrok_as_retrievable_coordinates::retrieve( void )                  { return obj.x_pr[current];}
double    rosenbrok_as_retrievable_coordinates::retrieve( int i )         { return obj.x_pr[i]; }
double    rosenbrok_as_retrievable_coordinates::retrieve_current( void )  { return obj.x_pr[current]; }
void    rosenbrok_as_retrievable_coordinates::set_current( double value ) { obj.x[current] = value;  }
void    rosenbrok_as_retrievable_coordinates::add_to_current( double value ) { obj.x[current] += value; }
void    rosenbrok_as_retrievable_coordinates::accept_changes()          { obj.x_pr = obj.x;                }
void    rosenbrok_as_retrievable_coordinates::reject_changes()          { obj.x = obj.x_pr;                }
int     rosenbrok_as_retrievable_coordinates::is_changed()              { return 0; }
//double    rosenbrok_as_retrievable_coordinates::delta_x( int i )                  { return x[i]-x_pr[i]; }

rosenbrok::rosenbrok()
  : K_( 100.0 )
    {
        /*x.add_by_default( 2 );
        x_pr.add_by_default( 2 );
        x[0] = x_pr[0] = -1.2;
        x[1] = x_pr[1] = 1;//*/
        x.push_back( -1.2 );  x_pr.push_back( -1.2 );
        x.push_back(  1   );  x_pr.push_back(  1   );
    }

rosenbrok::rosenbrok( double x1, double x2 )
  : K_( 100.0 )
    {
        /*x.add_by_default( 2 );
        x_pr.add_by_default( 2 );
        x[0] = x_pr[0] = x1;
        x[1] = x_pr[1] = x2;//*/
        x.push_back( x1 );    x_pr.push_back( x1 );
        x.push_back( x2 );    x_pr.push_back( x2 );
    }

rosenbrok_as_differentiable::rosenbrok_as_differentiable( rosenbrok & Obj )
  : obj( Obj )
  {
  }
rosenbrok_as_retrievable_coordinates::rosenbrok_as_retrievable_coordinates( rosenbrok & Obj )
  : obj( Obj ),
      current( 0 )
  {
  }

//------------------ test -------------------------------
/*
void main()
    {
        cout << "d_mach_eps  " << d_mach_eps << "  " << d_mach_eps_2 << "  "
            << d_mach_eps_3 << "  " << d_mach_eps_4 << endl << endl;

        Rosenbrok           ros;
//      Array< double >     typical_x;  typical_x.add( 0.1 ); typical_x.add( 0.1 );
        Minimizer  gmin( &ros, 1, 1, 1, 0.2, 100,
                                         Minimizer::OR, 1e-4, 2e-4, 1e-4 );

//      gmin.Fletcher_Reeves( 100 );
//      gmin.Polak_Ribiere( 100 );
//      gmin.Steepest_Descent( 0.7, 100 );     // 0.7
//      gmin.Ravine( 1.4, 1.5, 100 );          // 1.4, 1.5
//      gmin.Huk_Jivs( 1.618034, 100 );        //  1.618034
        gmin.Coord( 1.618034, 100 );           //  1.618034

        cout << "x[1] = " << ros.first_coord() << "   ";
        cout << "x[2] = " << ros.next_coord() << "   ";
        cout << "f count = " << gmin.func_counter << "   ";
        cout << "g count = " << gmin.grad_counter << "   ";
    }
*/
}//MM
