#ifndef FUNCTIONAL_H
#define FUNCTIONAL_H

#ifndef ARRAY_H
#include "Array.h"
#endif

class functional_interface;
class differentiable_interface;
class retrievable_interface;
class retrievable_coordinates_interface;
class minimizer_interface;

class coordinates_interface
{
public:
    virtual ~coordinates_interface() {}          

    virtual int                 size() const                  =0; //fix  is_valid()

    //virtual double              get( int i  ) const           =0;
    //virtual void                set( int i, double value )    =0;
    //virtual void                add( int i, double value )    =0;

    virtual void                first()                       =0;
    virtual void                next()                        =0;
    virtual double              get_current()                 =0;
    virtual void                set_current( double value )   =0;
    virtual void                add_to_current( double value )=0;
};

class functional_interface
{
public:
    virtual ~functional_interface() {}
    virtual double                value()=0;
};

class differentiable_interface : public functional_interface
{
public:
    virtual void                grad  (MM::Array <double> & gr) =0;
    virtual double              f_grad(MM::Array <double> & gr) {grad(gr); return value();}
};

class retrievable_interface
{
public:
    virtual void                accept_changes()=0;
    virtual void                reject_changes()=0;
    virtual int                 is_changed()=0;
};

class retrievable_coordinates_interface 
    : public coordinates_interface, public retrievable_interface
{
public:
      //virtual int                 size( void )=0;

      virtual double                retrieve( int i )       =0;
      virtual double                retrieve_current( void )=0;
      //virtual double                delta_x( int i )=0;
};


class minimizer_interface
{
public:
    virtual double              func_val()                                                =0;
    virtual void                grad   (MM::Array <double> & gr)                          =0;
    virtual double              f_grad (MM::Array <double> & gr)                          =0;

    virtual functional_interface & get_functional_interface()                             =0;
    virtual retrievable_coordinates_interface & get_retrievable_coordinates_interface()   =0;

    virtual void                Fletcher_Reeves ( int N=0 )                               =0;
    virtual void                Polak_Ribiere   ( int N=0 )                               =0;
    virtual void                Steepest_Descent( int N=0, double scale=1 )                 =0;
    virtual void                Ravine          ( int N=0, double scale1=1, double scale2=1 ) =0;
    virtual void                Huk_Jivs        ( int N=0, double scale=1 )                 =0;
    virtual void                Coord           ( int N=0, double scale=1 )                 =0;
};


#endif//FUNCTIONAL_H
