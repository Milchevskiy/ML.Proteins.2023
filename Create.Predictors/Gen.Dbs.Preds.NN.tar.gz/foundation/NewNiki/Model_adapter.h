
#ifndef MODEL_ADAPTER_H
#define MODEL_ADAPTER_H

#ifndef FUNCTIONAL_H
#include "Functional.h"
#endif

/*
#ifndef POINT_3D_IMPL_H
#include "Point_3D_impl.h"
#endif
*/

//#include "../Restore_cartesian/Restore_cartesian.h"


class Restore_cartesian;

namespace MM
{
class Model_adapter
:
    public differentiable_interface,
    public retrievable_coordinates_interface
{
    Restore_cartesian &                 model_;
    int                     current_;
    Array <int>             change_list_;
    //Array <Point_3D_impl>   previous_;
    Array <double>              previous_;
    Array <int>             coords_was_changed_;

    double                  E_;
    int                     E_flag_;

    double                  previous_E_;
    int                     previous_E_flag_;

public:
    Model_adapter (Restore_cartesian & model);

    //  functional_interface
    double  value();

    // differentiable_interface
    void    grad  (Array <double> & gr);
    double  f_grad(Array <double> & gr)     {grad(gr); return value();}

    // retrievable_coordinates_interface
    double  retrieve (int)                  {/*FIX;*/ return 0;}
    double  retrieve_current (void)         {/*FIX*/; return 0;}

    // retrievable_interface
    void    accept_changes();
    void    reject_changes();

    int     is_changed()                    {/*FIX*/; return 0;}

    // coordinates_interface
    int     size() const;              //fix  is_valid()

    void    first ()                        {current_ = 0;}
    void    next  ()                        {++current_;}
    double  get_current ()                  {return get (current_);}
    void    set_current (double /*value*/)      {/*FIX;*/}
    void    add_to_current (double value)   {add (current_, value);}




protected:
    double  get (int i) const;
    //void  set( int i, double value )      =0;
    void    add (int i, double value);

    std::vector <double> & dihedrals_;
};

}//MM

#endif //MODEL_ADAPTER_H
