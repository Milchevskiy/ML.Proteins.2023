#ifndef MIN_H
#define MIN_H

#ifndef INTERFACE_MIN_H
#include "Functional.h"
#endif
/*
#ifndef DBC_H
#include "DBC.h"
#endif
*/

class simple;
class simple_as_differentiable;
class simple_as_retrievable_coordinates;

class Minimizer;
class Gradient_minimizer;

//----------------------------------------------------------------

#define         ITER_MAX 100
#define         FUNC_TOL 1e-4
#define         STEP_TOL 2e-4
#define         GRAD_TOL 1e-4

namespace MM
{

class   Minimizer //: public MM::DbC
    // : public minimizer_interface
{
protected:
    functional_interface              & func_;
    retrievable_coordinates_interface & coord_;

    double                  f_;       // function value
    double                  f_pr_;    // previous function value
    double                  f_priv_;  // function value at previous stop() call
    double                  typ_f_;   // typical function value
    double                  typ_g_;   // typical gradient value
    Array <double>          typ_x_;   // typical argument value

    int                     iter_;
    int                     iter_max_;
    int                     n_;       // number of variables

    double                  brack_step_;
    double                  brack_K_;
    double                  scale_;

    double                  rel_func_;
    double                  rel_step_;
    double                  rel_grad_;

    double                  func_tol_;
    double                  step_tol_;
    double                  grad_tol_;

    Array <double>          g_, g_old_, d_;
    Array <double>          step_;
    double                  xmin_;

    int                     func_counter_;
    int                     grad_counter_;
    double                  start_time_, stop_time_, current_time_,
                            current_time_priv_, current_external_time_,
                            sum_external_time_;

    enum {opBRAKETING, opBRENT, opQUADRATIC, opCUBIC, opOTHER} operation_flag_;
    int                     bracketing_func_counter_,
                            brent_func_counter_,
                            quadratic_func_counter_,
                            cubic_func_counter_,
                            other_func_counter_;

    int                     derivative_flag_;

public:

    enum Type
        {
            Hestenes_Stiefel,
            Lui_Storey,
            Polak_Ribiere,
            Fletcher_Reeves,
            Dai_Yuan,
            Conjugate_Descent,
            Hu_Storey,
            Hybrid_Dai_Yuan_zero,
            Hybrid_Lui_Storey_and_Conjugate_Descent,

            Steepest_Descent
        };


    void (*start_minimization) (Minimizer *);
    void (*stop_minimization ) (Minimizer *);
    void (*current_minimization_iteration) (Minimizer *);

    enum Stop_logic       {AND, OR}         stop_logic_;
    enum Line_search_type {BRENT, CUBIC}    line_search_type_;

    enum  Stop_flag
        { No_stop = 0,
          Grad_tol_reached  = 1,
          Step_tol_reached  = 2,
          Func_tol_reached  = 4,
          No_improvement    = 8,
          Iter_exceeding    = 16,
          Stop              = 32 };
    int                            stop_flag_;

    Minimizer (functional_interface              & Functional_interface,
               retrievable_coordinates_interface & Coordinate_interface,
               double               Typ_f,
               double               Typ_g,
               Array <double>       Typ_x,
               double               Brak_step,
               int                  Iter_max = ITER_MAX,
               Stop_logic           s_l      = OR,
               double               Func_tol = FUNC_TOL,
               double               Step_tol = STEP_TOL,
               double               Grad_tol = GRAD_TOL );

    Minimizer (functional_interface              & Functional_interface,
               retrievable_coordinates_interface & Coordinate_interface,
               double               Typ_f,
               double               Typ_g,
               double               Typ_x,
               double               Brak_step,
               int                  Iter_max = ITER_MAX,
               Stop_logic           s_l      = OR,
               double               Func_tol = FUNC_TOL,
               double               Step_tol = STEP_TOL,
               double               Grad_tol = GRAD_TOL );

    virtual ~Minimizer();
    void                    init();

    virtual double          func_val();
    virtual void            grad   (Array <double> & gr);
    virtual double          f_grad (Array <double> & gr);
    virtual double          relative_gradient();

    virtual double          gradient_tolerance   () const                       {return rel_grad_;}
    virtual double          step_tolerance       () const                       {return rel_step_;}
    virtual double          functional_tolerance () const                       {return rel_func_;}

    virtual void            set_gradient_tolerance   (double tol)               {grad_tol_ = tol;}
    virtual void            set_step_tolerance       (double tol)               {step_tol_ = tol;}
    virtual void            set_functional_tolerance (double tol)               {func_tol_ = tol;}

    virtual functional_interface &              get_functional_interface();
    virtual retrievable_coordinates_interface & get_retrievable_coordinates_interface();

    virtual int             get_function_calls();
    virtual int             get_gradient_calls();
    virtual int             get_bracketing_func_calls();
    virtual int             get_brent_func_calls();
    virtual int             get_quadratic_func_calls();
    virtual int             get_cubic_func_calls();
    virtual int             get_other_func_calls();
/*
    virtual double          get_start_time();
    virtual double          get_stop_time();
    virtual double          get_current_time();
    virtual double          get_iteration_time();
    virtual double          get_pure_iteration_time();
    virtual double          get_minimization_time();
    virtual double          get_pure_minimization_time();

    */

    virtual void            get_stop_reason( char * );
    virtual int             get_iteration();

    void                    set_line_search_type( Line_search_type type );
    void                    set_brack_K( double );
    void                    set_scale (double v)       {scale_ = v;}

    virtual void            conjugate_gradient (Type type = Hestenes_Stiefel, int N=0);

    void                    line_min ();
    void                    line_min_brent ();
    void                    line_min_cubic ();

    void                    bracket (double * a,  double * b,  double * c,
                                     double * fa, double * fb, double * fc);

    double                  brent (double a,  double x,  double b,  double fx);

    double                  f (double x);

    void                    stop ();

protected:
    Array <double>          grad_tmp_;

    double                  max_x_;
    double                  max_f_;

    double                  find_max_f  ();

    void                    accept_changes();
    void                    reject_changes();
    virtual int             check_stop();
};

class Gradient_minimizer : public Minimizer
{
//      Array< double >             p;        // starting vector
    differentiable_interface    &   diff_func_;

//      Array< double >           grad;

public:
    void                            grad   (Array <double> & gr);
    double                          f_grad (Array <double> & gr);

//      virtual      ~Gradient_minimizer();
/*
      Gradient_minimizer (differentiable_interface           & Differentiable_interface,
                          retrievable_coordinates_interface  & Coordinate_interface,
                          double                Typ_f,
                          double                Typ_g,
                          Array <double>        Typ_x,
                          double                Brak_step,
                          int                   Iter_max = ITER_MAX,
                          Stop_logic            s_l      = OR,
                          double                Func_tol = FUNC_TOL,
                          double                Step_tol = STEP_TOL,
                          double                Grad_tol = GRAD_TOL);
*/
      Gradient_minimizer( differentiable_interface           & Differentiable_interface,
                          retrievable_coordinates_interface  & Coordinate_interface,
                          double                Typ_f,
                          double                Typ_g,
                          double                Typ_x,
                          double                Brak_step,
                          int                   Iter_max = ITER_MAX,
                          Stop_logic            s_l      = OR,
                          double                Func_tol = FUNC_TOL,
                          double                Step_tol = STEP_TOL,
                          double                Grad_tol = GRAD_TOL);
  };

#undef         ITER_MAX
#undef         FUNC_TOL
#undef         STEP_TOL
#undef         GRAD_TOL

//======================= Samples =================================

class   simple
{
private:
public:
    Array <double>              x;
    Array <double>              x_pr;
    unsigned int                current;

public:
    simple();

    friend class simple_as_differentiable;
    friend class simple_as_retrievable_coordinates;
};

class   simple_as_differentiable : public differentiable_interface
{
    private:
    simple                      &obj;

public:
    double                      value();
    void                        grad (Array <double> & gr );
    simple_as_differentiable (simple &);
};

class simple_as_retrievable_coordinates
    : public retrievable_coordinates_interface
{
private:
    simple                      &obj;

public:
    virtual int                 size() const;

    virtual double              get( int i  ) const;
    virtual void                set( int i, double value );
    virtual void                add( int i, double value );

    void                        first( void );
    void                        next( void );
    int                         size( void );
    virtual double              get_current( void );
    virtual void                set_current( double value );
    virtual void                add_to_current( double value );

    void                        accept_changes();
    void                        reject_changes();
    virtual int                 is_changed();
    virtual double              retrieve( int i );
    virtual double              retrieve_current( void );
//      virtual double                delta_x( int i );

    simple_as_retrievable_coordinates( simple & );
};

//----------------------- rosenbrok -------------------------------

class rosenbrok
  {
    private:
      MM::Array <double>            x;
      MM::Array <double>            x_pr;

    public:
      double                      K_;

      rosenbrok ();
      rosenbrok (double, double);

      friend class rosenbrok_as_differentiable;
      friend class rosenbrok_as_retrievable_coordinates;
  };

class   rosenbrok_as_differentiable : public differentiable_interface
  {
    private:
      rosenbrok                   &obj;

    public:
      double                        value();
      void                        grad (MM::Array< double > & gr);
      rosenbrok_as_differentiable (rosenbrok &);
  };

class rosenbrok_as_retrievable_coordinates : public retrievable_coordinates_interface
  {
    private:
      rosenbrok                   &obj;
      unsigned int                current;

    public:
      virtual int                 size() const;

      virtual double                get( int i  ) const;
      virtual void                set( int i, double value );
      virtual void                add( int i, double value );

      void                        first( void );
      void                        next( void );
      int                         size( void );
      virtual double                get_current( void );
      virtual void                set_current( double value );
      virtual void                add_to_current( double value );

      void                        accept_changes();
      void                        reject_changes();
      virtual int                 is_changed();
      virtual double                retrieve( int i );
      virtual double                retrieve_current( void );
//      virtual double                delta_x( int i );

      rosenbrok_as_retrievable_coordinates( rosenbrok & );
  };

}//MM

#endif//MIN_H
