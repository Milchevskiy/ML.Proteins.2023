#include "Model_adapter.h"

//#include "../Restore_cartesian_test.h"
#include "../Restore_cartesian/Restore_cartesian.h"

#include "../Censorship.h"

#include "../CommonFunc.h"


#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"

#include "../Cluster_set/Cluster_set.h"

#include "../by_Qmol/EigenValues3D.h"
#include "../by_Qmol/kabsch_stolen.h"
#include "Defs.h"



namespace MM
{



int Model_adapter::
size () const
{
    //return 3 * model_.atom_count ();
    return 2*model_.fragment_length();
}

void Model_adapter::
add (int i, real value)
{
   // int n = i/2;
    //Atom & atom = model_.atom (n);

 //   if (atom.kit().was_frozen())
   //     return;

  //  if (!coords_was_changed_[n])
 //   {
     //   change_list_.push_back (n);
  ////      coords_was_changed_ [n] = true;
   // }

    //switch (i%3)
    //{
    //    case 0: atom.set_x (value + atom.x());  break;
    //    case 1: atom.set_y (value + atom.y());  break;
    //    case 2: atom.set_z (value + atom.z());  break;
    //}
  /*  switch (i%3)
    {
        case 0: atom.move (Vector_3D_impl(value,0,0), true);  break;
        case 1: atom.move (Vector_3D_impl(0,value,0), true);  break;
        case 2: atom.move (Vector_3D_impl(0,0,value), true);  break;
    }
*/
        model_.get_dihedrals ()[i] += value;


    E_flag_ = 0;  /// ???? f
}

real Model_adapter::
get (int i) const
{
/*
    switch (i%3)
    {
        //fix x___;
        case 0: return model_.atom (i/3).x();
        case 1: return model_.atom (i/3).y();
        case 2: return model_.atom (i/3).z();
    }
    */


    return  model_.get_dihedrals ()[i];
}

void Model_adapter::
reject_changes()
{
    E_           = previous_E_;
    E_flag_      = previous_E_flag_;

 /*   int i=0, n;

    for (;  i<change_list_.size();  i++)
    {
        n = change_list_[i];
        Atom & atom = model_.atom (n);

        //model_.atom (n). set_x (previous_[n].x());
        //model_.atom (n). set_y (previous_[n].y());
        //model_.atom (n). set_z (previous_[n].z());

        atom.set_position (Point_3D_impl (previous_[n].x(),
                                          previous_[n].y(),
                                          previous_[n].z()), true);

        coords_was_changed_ [n] = false;
    }
    change_list_.clear();
    */

    model_.get_dihedrals ().insert (  dihedrals_.begin(), previous_.begin(), previous_.end()  );
}

void Model_adapter::
accept_changes()
{
    previous_E_            = E_;
    previous_E_flag_       = E_flag_;

 /*   int i=0, n;

    for (;  i<change_list_.size();  i++)
    {
        n = change_list_[i];
        previous_[n].set_x (model_.atom(n).x());
        previous_[n].set_y (model_.atom(n).y());
        previous_[n].set_z (model_.atom(n).z());

        coords_was_changed_ [n] = false;
    }
    change_list_.clear ();

    model_.kit().event().conformation_changed ();
    model_.kit().visual().renew ();
    qApp->processEvents(QEventLoop::ExcludeSocketNotifiers);
    */

  //  previous_.insert (  previous_.begin(), dihedrals_.begin(), dihedrals_.end()  );
     previous_.assign (dihedrals_.begin(),dihedrals_.end() );

}

void Model_adapter::
grad (Array <real> & gr)
{

/*
    int coord_count = size();
    int atom_count  = model_.atom_count();

    if (gr.size() != coord_count)
    {
        gr.clear();
        gr.reserve (coord_count);
    }

    bool ad_hoc = model_.kit().interaction().common().ad_hoc();
    model_.kit().force_field().start_work (!ad_hoc);
    {
        model_.kit().interaction().force();
    }
    if  (!ad_hoc && model_.kit().force_field().was_problems ())
        throw Text ("Force Field problem");

    for (int i=0;  i<atom_count;  ++i)
    {
        Vector_3D const & force = model_.atom(i).kit().potential_force ();
        if (model_.atom(i).kit().was_frozen())
        {
            gr [3*i  ]  = 0.;
            gr [3*i+1]  = 0.;
            gr [3*i+2]  = 0.;
            continue;
        }
        gr [3*i  ]  = -force.x();
        gr [3*i+1]  = -force.y();
        gr [3*i+2]  = -force.z();
    }

    */

    model_.gradient    (dihedrals_,gr);

}

real Model_adapter::
value()
{
    //FIX;
    //return model_.kit().interaction().potential ();
/*
    if (E_flag_)
        return E_;

    E_flag_ = true;

    bool ad_hoc = model_.kit().interaction().common().ad_hoc();
    model_.kit().force_field().start_work (!ad_hoc);
    {
        E_ = model_.kit().interaction().potential ();
    }
    if  (!ad_hoc && model_.kit().force_field().was_problems ())
        throw Text ("Force Field problem");

*/
    E_ = model_.value    (dihedrals_);

    return E_;
}

Model_adapter::
Model_adapter (Restore_cartesian & model)
    :
    model_(model), current_(0),
    E_              (0.),
    E_flag_         (0),
    previous_E_     (0.),
    previous_E_flag_(0),
    dihedrals_ (  model_.get_dihedrals () )
{


     previous_.assign (dihedrals_.begin(),dihedrals_.end() );  // -1 ???

}

}//MM
