#ifndef MINMAX_H
#define MINMAX_H

#ifndef max
#define max(a,b)            (((a) >= (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) <= (b)) ? (a) : (b))
#endif

#endif//MINMAX_H

