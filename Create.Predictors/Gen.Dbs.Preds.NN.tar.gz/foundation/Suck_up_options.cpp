#pragma warning( disable : 4786 )

#include <fstream>
#include <iostream>
#include <cassert>
#include <sstream>
#include <map>
#include <cstdlib>


using namespace std;

map < string, string  >    Suck_up_options ( string & option_file_name)
{

	map < string, string  > options;

	ifstream  option_stream ( option_file_name.c_str() );
	if ( ! option_stream )	{	cout << "can't find file " << option_file_name << endl;
		assert (  option_stream );		exit (1);	}

	string current_line;
	while( getline( option_stream , current_line, '\n' ) )
	{
		if (current_line[0] == '/' || current_line[0] == '#' )
			continue;

		string key,meaning;
		istringstream ist (current_line);
		ist >> key >> meaning;

		options [key] = meaning;
	}
	return options;
}
