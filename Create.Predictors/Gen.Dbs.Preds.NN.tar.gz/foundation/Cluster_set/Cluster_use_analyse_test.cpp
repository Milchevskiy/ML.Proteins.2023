#include "Cluster_use_analyse_test.h"
#include "Cluster_use_analyse.h"

#include "Cluster_set.h"

#include "Single_cluster_record.h"

#include "../Fragment_base/Chain_binary.h"
#include "../Fragment_base/Fragment_base_subtle.h"

#include "../CommonFunc.h"
#include "../Censorship.h"

#include "../Geometry_util/Geometry_util.h"

#include <fstream>
#include <iostream>

#include "../Pair_int_double.h"

#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

extern ofstream log_stream;
extern Censorship configuration;


Cluster_use_analyse_test::
~Cluster_use_analyse_test()
{
	cout << "Cluster_use_analyse_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Cluster_use_analyse_test::
init_claster_motif_test()
{

   // string cluster_set_name = "16_5a_20";
    string cluster_set_name = "PB";
	Cluster_use_analyse ob(cluster_set_name);

	int number_of_classes   = ob.number_of_classes();
	int fragment_length     = ob.fragment_length  ();

	double **claster_motif_coordinates =  ob.get_claster_motif_coordinates();

	string host_dir = ob.get_host_dir();
	string chech_file_name = host_dir + string ("cartesian_coordinates.test");

	ofstream out( chech_file_name .c_str() );
	if ( ! out	)
	{
		log_stream << "can't create " << chech_file_name<< endl;
		cout       << "can't create " << chech_file_name<< endl;
		exit (1);
	}
	out << "// Here we check the correspondence of the coordinates that were read from the file with the actual data file " << endl;
	out << number_of_classes << " # Number of clusters" << endl;
	out << fragment_length << " # Fragment length" << endl;

	for (int ii=0; ii<number_of_classes;ii++)
	{
              for (int kk=0;kk<fragment_length*9;kk++)
           PutVaDouble(claster_motif_coordinates[ii][kk],out,15,10,'l');

        out << endl;
	}

}


void Cluster_use_analyse_test::
subtle_claster_show_test()
{
   // string cluster_set_name = "16_5a_20";
    string cluster_set_name = "PB";
   	Cluster_use_analyse ob(cluster_set_name);

//	int number_of_classes   = ob.number_of_classes();
//	int fragment_length     = ob.fragment_length  ();

    string fragment_base_subtle_name = string("5b");
 	string output_file_name	= string ("subtle_claster_show.by_new_cluster");

    ob.subtle_claster_show(
        fragment_base_subtle_name,
        output_file_name);

}
void Cluster_use_analyse_test::
plain_claster_show_test()
{
    //string cluster_set_name = "16_5a_20";
    string cluster_set_name = "PB";
   	Cluster_use_analyse ob(cluster_set_name);

//	int number_of_classes   = ob.number_of_classes();
//	int fragment_length     = ob.fragment_length  ();

    string fragment_base_subtle_name = string("5b");
 	string output_file_name	= string ("plain_claster_show.by_new_cluster");

    ob.plain_claster_show(
        fragment_base_subtle_name,
        output_file_name);

}


