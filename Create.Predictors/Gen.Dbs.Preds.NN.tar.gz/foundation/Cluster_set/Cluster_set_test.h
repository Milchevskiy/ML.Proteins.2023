#ifndef CLUSTER_SET_TEST_H
#define CLUSTER_SET_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Cluster_set_test: public Simple_test
{
public:
	~Cluster_set_test();

    void run()
    {

///newlife_constructor_test();

///protocol_rmds_test();
   // dummy_check_rmsd();///

  //  wrire_ready_PB_cartesian_test ();

// не нужна эта хереня - поправил вроде бы accepted_chain_list.bin
 ///   restore_accepted_chain_list ();
    // проверим те ли данные получаем по номеру фрагмента из fragment_base.
    // кажется накосячил с accepted_chain_list.bin
   /// НЕРАВИЛЬНО было держать его в бинареном виде.
   ///
  //  check_accepted_chain_list();




    ///готовит данные для диаграммы распределения расстояния фрагментов от PB
//   single_usage_only_for_graph_creation ();


    //   prepare_cluster_torsion_set_test();
      // Distance Matrix для PB - ok
//		prepare_cluster_distance_matrix_test();

		/// готовит матрицу RMSDA для PB de Brewern  // пока не доделана
	///	prepare_RMSDA_cluster_distance_matrix_test();


     //   Torsion_angles_report_for_PB ();



	//	optimize_clasterization_test();  // !!! ÃËÀÂÍÎÅ . ÒÓÒ ÔÎÐÌÈÐÓÞÒ ÊËÀÑÒÅÐÛ



// проверял работу       subtle_claster_show_for_whole_base()   .
	//pull_out_claster_origin_structure_list_test();

/// готовит данныке для диаграммы распределение фрагметнов по расстояниям до PB
//	prepare_occurence_frequency_diagram_data_test ();

/// new 2019

    /// utiloties for steepest descrent etc.  RECOVER CARTESIAN COORDINATES BY RMDS SET
   // utilities_for_cartesian_recovery_by_rmds_set_test();


		//pull_out_claster_origin_structure_list_test ( );  // Ïîõîæå ïðàâèëüíûé ïîñëåäíèé âàðèàíò
//		predict_dssp_eight_letter_by_sequence_test ();

	//	prepare_cluster_picture_and_description ();


//		check_manually_settin_mode();
	//	optimize_clasterization_test();   // ÈÌÅÍÍÎ ÒÓÒ ÃÅÍÅÐßÒÑß BS!!!!!

//		check_COMMON_USAGE_CLUSTER_SET_MODE_test ();

//		newlife_constructor_test();
//		constructor_test ();
//		optimize_clasterization_test ();

	//	mutual_distance_for_BS_show_test();
//		analyse_analyse_setted_regular_structure_presence();

	}

	void protocol_rmds_test();

	void utilities_for_cartesian_recovery_by_rmds_set_test();

	void wrire_ready_PB_cartesian_test ();

    void restore_accepted_chain_list ();
	void predict_dssp_eight_letter_by_sequence_test ();
	void prepare_cluster_picture_and_description ();


	void prepare_RMSDA_cluster_distance_matrix_test();
	void prepare_cluster_distance_matrix_test();
//	void check_get_length_etc();
	void check_manually_settin_mode();
	void check_COMMON_USAGE_CLUSTER_SET_MODE_test ();
	void optimize_clasterization_test();
	void newlife_constructor_test();
	void constructor_test ();
//	void optimize_clasterization_test ();
	void pull_out_claster_origin_structure_list_test ( );
	void mutual_distance_for_BS_show_test();
	void analyse_analyse_setted_regular_structure_presence();
	void Torsion_angles_report_for_PB ();
    void prepare_cluster_torsion_set_test();
    void prepare_occurence_frequency_diagram_data_test ();
    void single_usage_only_for_graph_creation ();

    void check_accepted_chain_list();
     void dummy_check_rmsd();
};

#endif
