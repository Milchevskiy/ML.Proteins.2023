#ifndef CLUSTER_USE_ANALYSE_INCLUDED
#define CLUSTER_USE_ANALYSE_INCLUDED
#include <vector>
#include <string>
#include <fstream>
#include <map>

#include "Single_cluster_record.h"


using namespace std;

class	Sheduler;

class	Fragment_base_subtle;

class  Cluster_use_analyse
{
public:

   ~Cluster_use_analyse();
   Cluster_use_analyse () {};

	Cluster_use_analyse (
		const string & cluster_set_name_name);

	int number_of_classes() const {return number_of_classes_;}
	int fragment_length  () const {return fragment_length_;};

	double ** get_claster_motif_coordinates() const { return claster_motif_coordinates_;} ;

	string get_host_dir() const { return host_dir_;}


//	void subtle_claster_show (
 //       const string & output_file_name,
   //     vector < Single_cluster_record > & claster_diversity );

    ///Выводит подробные данные о данных базы фрагментов в файл.
    ///Результаты отсотрированы: по размерам кластеров и внутри кластеров по RMSD до центра кластера
    void subtle_claster_show (
        const string & fragment_base_subtle_name,
        const string & output_file_name	 );

    /// Выводит данные о базисный структурах. Процентное осношение для кластеров в базе.
    /// Матрицу расстояний и проч. общуюю инф. про PB.
    void plain_claster_show (
        const string & fragment_base_subtle_name,
        const string & output_file_name	 );


private:

    string cluster_set_mame_;

    Sheduler		*sheduler_;

    string host_dir_;

    int number_of_classes_;
    int fragment_length_;

    Fragment_base_subtle	 * fragment_base_;

    double **claster_motif_coordinates_;

    void init_claster_motif();

    void regulate_PB_population(
        const string & fragment_base_subtle_name,  //
        vector < Single_cluster_record > & claster_diversity,
        double & distance_scattering,
        double & quadrate_distance_scattering);

};
#endif
