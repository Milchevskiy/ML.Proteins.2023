#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "Cluster_set_test.h"
#include "Cluster_set.h"

#include "Single_cluster_record.h"

#include "../Sheduler.h"

#include "../Fragment_base/Chain_binary.h"
#include "../Fragment_base/Fragment_base_subtle.h"

#include "../CommonFunc.h"
#include "../Censorship.h"

#include "../Geometry_util/Geometry_util.h"

#include <fstream>
#include <iostream>

#include "../Pair_int_double.h"

#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

#include "../by_Qmol/kabsch_stolen.h"

#include "../Fragment_base/accepted_chain_data.h"

// dummny founction single usage only/
bool is_coord_same (
    double * coord_1,
    double * coord_2,
    int coord_number);



using namespace std;

extern ofstream log_stream;
extern Censorship configuration;


vector <vector <int> >
analyase_local_structure_presence (
	vector < vector < double > >  & coord_in_cluster_system,
	const double constrain,
	const int number_of_classes,
	const int fragment_length);

void print_local_result(
	string cluster_set_name,
	string &PDB_chain_ID,
	vector < vector < double > >  & coord_in_cluster_system,
	string & sequence,
	vector <vector <int> > local_presence,
	const int fragment_length,
	const double constrain );

Cluster_set_test::
~Cluster_set_test()
{
	cout << "Cluster_set_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Cluster_set_test::
protocol_rmds_test()
{

/*

    string  cluster_set_name = string ("PB");
	Cluster_set *cls = new Cluster_set  (	cluster_set_name,COMMON_USAGE_CLUSTER_SET_MODE);

	string chain_ID_list_file =		string("xray_3a_dev_03_few_nonstandard");


   vector <string>  chain_ID_list;

	fill_up_accepted_chain_data_text (
		chain_ID_list,
		chain_ID_list_file );


	cls->protocol_rmds(chain_ID_list);

	delete cls;
	*/


    string  cluster_set_name = string ("15_3d_20");
	Cluster_set *cls = new Cluster_set  (	cluster_set_name,COMMON_USAGE_CLUSTER_SET_MODE);

//	string chain_ID_list_file =		string("xray_3a_dev_03_few_nonstandard");


  /// vector <string>  chain_ID_list;


    double **claster_motif_coordinates = cls->get_claster_motif_coordinates();

    for (int kk=0;kk<15;kk++)
    {
        for (int jj=0;jj<27;jj++)
            PutVaDouble(claster_motif_coordinates[kk][jj],log_stream,8,3,'l');

        log_stream << endl;

    }

    string chain_store_list ="/home/milch/projects/Didona/Store/Chain_store/Culled_30";

   	ifstream in( chain_store_list .c_str() );
	if ( ! in	)
	{
		log_stream << "can't create " << chain_store_list<< endl;
		cout       << "can't create " << chain_store_list<< endl;
		exit (1);
	}

      vector < string > pdb_chain_ID_set;

    string word;
    while ( in >> word )
    {
        string chain_ID = word.substr(0,5);
        pdb_chain_ID_set.push_back(chain_ID) ;
    }

/*	fill_up_accepted_chain_data_text (
		chain_ID_list,
		chain_ID_list_file );
*/

	cls->protocol_rmds(pdb_chain_ID_set);

	delete cls;




}
void Cluster_set_test::
 dummy_check_rmsd()
 {

    int fragment_length_  = 5;

    vector <double>  torsion_set_1;
    vector <double>  torsion_set_2;
    torsion_set_1.resize( 3*fragment_length_ );
    torsion_set_2.resize( 3*fragment_length_ );

    double *coord_1 = new double [ fragment_length_ * 9 * sizeof (double) ];
    double *coord_2 = new double [ fragment_length_ * 9 * sizeof (double) ];

     ///1IQ8A WRLVD     328       329
    string data1 =   "  14.031  52.058  73.337    13.337  51.148  72.425    13.233  51.717  71.002    13.039  53.028  70.906    12.930  53.718  69.622    14.269  53.635  68.873    15.369  53.833  69.594    16.698  53.754  69.003    16.961  52.316  68.524    16.605  51.343  69.357    16.792  49.937  69.014    16.028  49.637  67.733    14.788  50.108  67.674    13.956  49.901  66.505    14.670  50.496  65.283   ";
    {
        istringstream ist (data1);
        for (int ii=0;ii<fragment_length_ * 9;ii++)
            ist >> coord_1[ii];
    }


     ///1QSGA HSIGF     92        90


     string data2 =   " 12.522   3.906  20.448    13.591   4.485  19.619     13.036   5.768  18.994    13.447   6.946  19.475    12.898   8.201  18.939   14.055   9.122  18.558     14.793   8.709  17.528    16.079   9.214  17.103   16.177   9.320  15.568     16.632  10.476  15.120   16.868  10.685  13.660     17.868  11.816  13.442     18.625  11.766  12.311     19.585  12.770  11.936   20.010  12.614  10.455  ";

    {
        istringstream ist (data2);
        for (int ii=0;ii<fragment_length_ * 9;ii++)
            ist >> coord_2[ii];
    }


    fill_up_fragment_torsion_angles (
        coord_1,
        fragment_length_,
        torsion_set_1,
        'd');

   fill_up_fragment_torsion_angles (
        coord_2,
        fragment_length_,
        torsion_set_2,
        'd');


    double *w	= new double [fragment_length_*9];
	for ( int kk=0;kk<(fragment_length_*9);kk++)		w[kk] = 1;

    bool error_flag=true;;
    double current_distance = kabsch_rmsd (
            coord_1,
            coord_2,
            w,
            3*fragment_length_,
            error_flag);


    delete [] coord_1;
    delete [] coord_2;
    delete [] w;
 }

void Cluster_set_test::
 utilities_for_cartesian_recovery_by_rmds_set_test()
 {


 }

void Cluster_set_test::
wrire_ready_PB_cartesian_test ()
{

   // string cluster_set_name = "16_5a_20";
    string cluster_set_name = "PB";
	Cluster_set ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

    ob.wrire_ready_PB_cartesian();


}

void Cluster_set_test::restore_accepted_chain_list ()
{


    string chain_store_list ="/home/milch/projects/Didona/Store/Chain_store/binary/chain_store_list";

   	ifstream in( chain_store_list .c_str() );
	if ( ! in	)
	{
		log_stream << "can't create " << chain_store_list<< endl;
		cout       << "can't create " << chain_store_list<< endl;
		exit (1);
	}



    vector < string > pdb_chain_ID_set;

    string word;
    while ( in >> word )
    {
        string chain_ID = word.substr(0,5);
        pdb_chain_ID_set.push_back(chain_ID) ;
    }

    int pdb_chain_ID_set_size = pdb_chain_ID_set.size();

    Fragment_base_subtle fr_ba("5a",FRAGMENT_BASE_SUBTLE_COMMON_USAGE);

    string restore_accepted_chain_list =fr_ba.get_host_dir() + "restore_accepted_chain_list";

 	ofstream out( restore_accepted_chain_list .c_str() );
	if ( ! out	)
	{
		log_stream << "can't create " << chain_store_list<< endl;
		cout       << "can't create " << chain_store_list<< endl;
		exit (1);
	}

    int total_fragment_number = fr_ba.get_total_fragment_number();
    int fragment_length =   fr_ba.get_fragment_length();

    double *coord_by_chain  = new double [fragment_length*9];
    double *coord_by_fragment_base  = new double [fragment_length*9];

    string current_pdb_chain_ID = "*****";
    Chain_binary * chain = 0;
    for (int ii=0;ii<total_fragment_number;ii++)
    {

         int chain_serial_number;
         int position_in_chain;

          fr_ba.get_chain_index (	ii,
              &chain_serial_number,
              &position_in_chain );

            if ( ! fr_ba.get_coord (ii,coord_by_fragment_base )  )
            {
                log_stream << "fragment " << ii << " not found ";
                    continue;
            }

            for (int kk=0; kk< pdb_chain_ID_set_size; kk++)
            {


                if (current_pdb_chain_ID != pdb_chain_ID_set[kk] )
                {
                    if ( chain != 0 )
                        delete chain;
                    chain = 	new Chain_binary (  pdb_chain_ID_set[kk]);
                    current_pdb_chain_ID = pdb_chain_ID_set[kk];
                }

             //   chain.extract_fragment
                if ( ! chain->extract_fragment (position_in_chain,fragment_length,coord_by_chain ) )
                    continue;

                bool is_same_flag = is_coord_same (coord_by_chain,coord_by_fragment_base,fragment_length*9);
                if ( is_same_flag )
                {
                    out << chain_serial_number << "\t" << position_in_chain << "\t" << current_pdb_chain_ID  << endl;

                }

           }

    //    ob.get_accepted_chain_ID_by_index(ii);
    }

    delete [] coord_by_chain;
    delete [] coord_by_fragment_base;

 /*   ob.fill_up_record_items (
			global_index  ,
			pdb_chain_ID,
			fragment_sequence,
			serial_number,
			pdb_resudue_number	);

*/

}
// dummny founction single usage only/
bool is_coord_same (
    double * coord_1,
    double * coord_2,
    int coord_number)
{

    double difference = 0;
    for (int ii=0;ii<coord_number;ii++)
    {
        difference += fabs (coord_1[ii]-coord_2[ii]);
    }

    if ( difference  < 0.000000001 )
        return true;
    else
        return false;


}



void Cluster_set_test::
Torsion_angles_report_for_PB ()
{

 //   string id_PB ="0123456789ABCDEF";
 //string cluster_set_name = "16_5a_20";
    string id_PB ="abcdefghigklmnop";
    string cluster_set_name = "PB";


	Cluster_set ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

    int number_of_classes   =   ob. number_of_classes();
    int fragment_length     =   ob. fragment_length();
    double **claster_motif_coordinates = ob.get_claster_motif_coordinates();

    string cluster_motiff_torsions_file = ob.get_host_dir() + string("motiff_torsions");
	ofstream out( cluster_motiff_torsions_file .c_str() );
	if ( ! out	)
	{
		log_stream << "can't create " << cluster_motiff_torsions_file<< endl;
		cout       << "can't create " << cluster_motiff_torsions_file<< endl;
		exit (1);
	}


    vector < double > torsion;
    for (int ii=0; ii<number_of_classes; ii++)
    {
         fill_up_fragment_torsion_angles (
            claster_motif_coordinates[ii],
            fragment_length,
            torsion,
            'd');

        out << id_PB[ii] <<':'<<'\t';
        for (int kk=0;kk<torsion.size();  kk++ )
            PutVaDouble(torsion[kk],out,10,3,'l');
        out << endl;


        torsion.resize(0);
    }







}

void Cluster_set_test::
prepare_cluster_picture_and_description ()
{
	string  cluster_set_name = string ("30_5a_20");

	Cluster_set cla_ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

	string host_dir = cla_ob.get_host_dir() + string("analyze_cluster/");
	string analyse_protocol = host_dir + string("analise_protocol");

	ofstream out( analyse_protocol .c_str() );
	if ( ! out	)
	{
		log_stream << "can't create " << analyse_protocol<< endl;
		cout       << "can't create " << analyse_protocol<< endl;
		exit (1);
	}


	vector <int > choosen_indexes = cla_ob.get_claster_motif_index();

	for (int ii=0; ii<choosen_indexes.size(); ii++ )
	{
		cout << choosen_indexes [ii] << endl;
	}

	Fragment_base_subtle *fragment_base = cla_ob.get_fragment_base();


	int length = cla_ob.fragment_length();
//	double *cord_set_1 = new double [length *9*10];


	double *cord_set_buffer_1 = new double [length *9*100];
	double *cord_set_buffer_2 = new double [length *9*100];

	double *cord_set_2 = new double [length *9*10];
	vector <string> residue_names_2;
	vector <string> in_chain_residue_number_2;


	{
			string pdb_chain_ID;
			string fragment_sequence;
			int serial_number;
			string pdb_resudue_number;

			fragment_base->fill_up_record_items (
				choosen_indexes [0] ,
				pdb_chain_ID,
				fragment_sequence,
				serial_number,
				pdb_resudue_number	);


			out << choosen_indexes [0] << "\t" ;
			out << pdb_chain_ID			<< "\t" ;
			out << fragment_sequence	<< "\t" ;
			out << serial_number		<< "\t" ;
			out << pdb_resudue_number	<< endl;



			Chain_binary *cb = new Chain_binary ( pdb_chain_ID);
			int start_pos = serial_number;


//			cb->extract_fragment (start_pos,length,cord_set_1 );
			vector <string> total_residue_names				= cb->get_residue_names () ;
			vector <string> total_in_chain_residue_number	= cb->get_in_chain_residue_number ();


			for ( int kk=0;kk<length;kk++)
			{
				residue_names_2.push_back(total_residue_names[start_pos+kk]);
				in_chain_residue_number_2.push_back(total_in_chain_residue_number[start_pos+kk]);
			}

			cb->extract_fragment (start_pos,length,cord_set_2 );

			origin_to_zero (cord_set_2,length*3);

			ostringstream ost ;
			int ii=0;
			ost << ii ;
			string s_number = ost.str();

//			string path_to_pdb = host_dir + s_number + string (".ent");
//			cb->save_pdb_fragment (	cord_set_2, length, path_to_pdb, residue_names_2, in_chain_residue_number_2);

	}


	string chain_ID_set = "!BCDEFGHIJKLMNOPQRSTUVWXYZ12345";

	for (int ii=1; ii<choosen_indexes.size(); ii++ )
	{
			string pdb_chain_ID;
			string fragment_sequence;
			int serial_number;
			string pdb_resudue_number;

			fragment_base->fill_up_record_items (
				choosen_indexes [ii] ,
				pdb_chain_ID,
				fragment_sequence,
				serial_number,
				pdb_resudue_number	);


			out << choosen_indexes [ii] << "\t" ;
			out << pdb_chain_ID			<< "\t" ;
			out << fragment_sequence	<< "\t" ;
			out << serial_number		<< "\t" ;
			out << pdb_resudue_number	<< endl;



			Chain_binary *cb = new Chain_binary ( pdb_chain_ID);
			int start_pos = serial_number;


//			cb->extract_fragment (start_pos,length,cord_set_1 );
			vector <string> total_residue_names				= cb->get_residue_names () ;
			vector <string> total_in_chain_residue_number	= cb->get_in_chain_residue_number ();

			vector <string> residue_names;
			vector <string> in_chain_residue_number;

			for ( int kk=0;kk<length;kk++)
			{
				residue_names.push_back(total_residue_names[start_pos+kk]);
				in_chain_residue_number.push_back(total_in_chain_residue_number[start_pos+kk]);
			}

			double *cord_set_1 = new double [length *9*10];

			cb->extract_fragment (start_pos,length,cord_set_1 );

			ostringstream ost ;
			ost << ii ;
			string s_number = ost.str();

	//		string path_to_pdb = host_dir + s_number + string (".ent");
	//		cb->save_pdb_fragment (	cord_set_1, length, path_to_pdb, residue_names, in_chain_residue_number);


		bool is_ok_alignment = align_two_chains (
			cord_set_1,
			cord_set_2,
			length);


		double rotation_matrix[9];
		memset (rotation_matrix,0,9*sizeof(double));

		make_rotation_matrix_by_cartesian_triad (
			cord_set_2,	//double *c_1,
			cord_set_2+3,	//double *cur,
			cord_set_2+6,	//double *c_2,
			rotation_matrix);	//double *rotation_matrix_nb);

		memset(cord_set_buffer_1,0,9*length*sizeof(double));
		memset(cord_set_buffer_2,0,9*length*sizeof(double));

		for (int kk=0;kk<length*3;kk++)
		{
			Geometry_util::multiplication_row_by_3x3_by_transposed (
				cord_set_2+3*kk,//const double	a[3],
				rotation_matrix,//const double	b[9],
				cord_set_buffer_2+3*kk); // double			r[3] );

			Geometry_util::multiplication_row_by_3x3_by_transposed (
				cord_set_1+3*kk,//const double	a[3],
				rotation_matrix,//const double	b[9],
				cord_set_buffer_1+3*kk); // double			r[3] );


		}

// Withous rotation
/*		string path_to_pdb_no_rotation_1 = host_dir +   s_number + string ("_no_rotation") + string (".ent");
		cb->save_pdb_fragment (	cord_set_1, length, path_to_pdb_no_rotation_1, residue_names, in_chain_residue_number);
		string path_to_pdb_0_no_rotation_2 = host_dir +   string ("0_no_rotation") + string (".ent");
		cb->save_pdb_fragment (	cord_set_2, length, path_to_pdb_0_no_rotation_2, residue_names_2, in_chain_residue_number_2);
*/
//  rotation
		string path_to_pdb_rotation_1 = host_dir +   s_number + string (".pdb");
		cb->save_pdb_fragment (	cord_set_buffer_1, length, path_to_pdb_rotation_1, residue_names, in_chain_residue_number,chain_ID_set[ii]);
		if (ii==1)
		{
			string path_to_pdb_rotation_2  = host_dir +   string ("0") + string (".pdb");
			cb->save_pdb_fragment (	cord_set_buffer_2, length, path_to_pdb_rotation_2, residue_names_2, in_chain_residue_number_2,'A');
		}


		delete [] cord_set_1;

	}

	delete [] cord_set_buffer_1 ;
	delete [] cord_set_buffer_2 ;
	delete [] cord_set_2;

	/*
		fragment_base_->fill_up_record_items (
			global_index  ,
			pdb_chain_ID,
			fragment_sequence,
			serial_number,
			pdb_resudue_number	);
*/




}

// ������� ��� 3-��������
void Cluster_set_test::
optimize_clasterization_test ()
{
		//string cluster_set_name = "13_3a_20";
	//string cluster_set_name = "30_5a_20_copy_t";
		string cluster_set_name = "20_3d_20";


		Cluster_set ob(
			cluster_set_name,
			FILL_UP_MODEL_CLUSTER_SET_MODE);


	//	ob.optimize_clasterization();

}
void Cluster_set_test::
check_manually_settin_mode()
{
	string cluster_set_name = "Manulally_3";
	Cluster_set ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);


}

#include "../Fragment_base/accepted_chain_data.h"
#include "../Fragment_base/Chain_binary.h"

#define  MAX_STURCTURE_LENGTH 100

void Cluster_set_test::
analyse_analyse_setted_regular_structure_presence()
{

	double constrain = 0.8;
	string cluster_set_name = "Manulally_3";
	Cluster_set ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

	int number_of_classes = ob.number_of_classes();
	int fragment_length = ob.fragment_length();


	double **claster_motif_coordinates = ob.get_claster_motif_coordinates();



	string binary_file_name ("accepted_chain_list.bin");
	vector <string>		accepted_chain_ID_list;
	vector <int>		accepted_chain_lenth;


	fill_up_accepted_chain_data (
		accepted_chain_ID_list,
		accepted_chain_lenth,
		binary_file_name );


//accepted_chain_ID_list.resize(0);
//accepted_chain_ID_list.push_back("1ET1A");


	vector < vector < int > > global_presence;
	global_presence.resize(number_of_classes);
	for (int kk=0;kk<number_of_classes;kk++)
		global_presence[kk].resize(MAX_STURCTURE_LENGTH);



	for (int ii =0; ii < accepted_chain_ID_list.size(); ii++ )
	{
		cout << ii << " " << accepted_chain_ID_list[ii] << endl;
		if ( accepted_chain_ID_list[ii]  == "3IOXA" )
			continue;

		Chain_binary cb( accepted_chain_ID_list[ii]);


		vector < vector < double > >  coord_in_cluster_system = cb.positioning_chain_by_clasters_set (
			claster_motif_coordinates,
			fragment_length,
			number_of_classes ) ;


		vector <vector <int> > local_presence =  analyase_local_structure_presence (
			coord_in_cluster_system,
			constrain,
			number_of_classes,
			fragment_length);


		string sequence = cb.get_sequence();
		print_local_result(
			cluster_set_name,
			accepted_chain_ID_list[ii],
			coord_in_cluster_system,
			sequence,
			local_presence,
			fragment_length,
			constrain );


		for (int tt=0;tt<number_of_classes ;tt++ )
		{
			for (int jj=0;jj<MAX_STURCTURE_LENGTH  ;jj++ )
				global_presence [tt][jj] += local_presence[tt][jj];
		}
	}

		string result_file_name =
			configuration.option_meaning("Path_to_Cluster_set") + 	cluster_set_name +
			string ("/occurece_protocol/") +
			"FINAL_OCCURENCE" + string (".TXT") ;

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}

		for (int ii=0;ii<number_of_classes ;ii++)
		{
			for (int jj=0;jj<MAX_STURCTURE_LENGTH  ;jj++)
			{
				PutVa(global_presence [ii][jj],out,8,3,'l');
			}
			out << endl;
		}


}

void print_local_result(
	string cluster_set_name,
	string &PDB_chain_ID,
	vector < vector < double > >  & coord_in_cluster_system,
	string & sequence,
	vector <vector <int> > local_presence,
	const int fragment_length,
	const double constrain )
{


	Chain_binary cb( PDB_chain_ID);  // ����� ������ � ��� ����� ��� ������

	int shift = fragment_length/2;

		string result_file_name =
			configuration.option_meaning("Path_to_Cluster_set") + 	cluster_set_name +
			string ("/occurece_protocol/") +
			PDB_chain_ID + string (".struct_occurence") ;

		ofstream out( result_file_name .c_str() );
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}


		for ( int kk=0;kk<coord_in_cluster_system.size();kk++)
		{
			PutVa(sequence[kk+shift],out,3,1,'l');
			for (int ii=0;ii<local_presence.size();ii++)  // ��� �� �� ��� number_of_classes�
			{
				if (coord_in_cluster_system [kk][ii] < constrain && coord_in_cluster_system [kk][ii] != -1 )
				{
					out << "Yes "  ;
// ��� ��� ���������� ����� ����. ������ ������ ����
					if (ii==1)
					{


					}

				}
				else
					out << "No  "  ;

			}
			out << "   ";
			int test = local_presence.size();
			for (int ii=0;ii<test ;ii++)  // ��� �� �� ��� number_of_classes�
			{
				PutVaDouble (coord_in_cluster_system[kk][ii],out,8,3,'l');
			}
			out << endl;

		}

		for (int ii=0;ii<local_presence.size();ii++)
		{
			for (int jj=0;jj<local_presence[0].size();jj++)
			{
				PutVa(local_presence[ii][jj],out,8,3,'l');
			}
			out << endl;
		}
}

// ������������ ������ �����

vector <vector <int> >
analyase_local_structure_presence (
	vector < vector < double > >  & coord_in_cluster_system,
	const double constrain,
	const int number_of_classes,
	const int fragment_length)
{
	vector < vector < int > > local_presence;
	local_presence.resize(number_of_classes);
	for (int kk=0;kk<number_of_classes;kk++)
		local_presence[kk].resize(MAX_STURCTURE_LENGTH);

	int current_len ;
	bool catch_flag;

	for (int ii=0;ii<number_of_classes;ii++)
	{
		catch_flag=false;

		for (int kk=0;kk<coord_in_cluster_system.size();kk++)
		{
			if (coord_in_cluster_system[kk][ii] == -1)
			{
				catch_flag=false;
				continue;
			}

			if ( catch_flag == false )
			{
				current_len = 0;
				if (coord_in_cluster_system[kk][ii] < constrain )
				{
					catch_flag = true;
					current_len = fragment_length;
				}
				else
					continue;
			}
			else
			{
				if (coord_in_cluster_system[kk][ii] < constrain )
				{
					current_len ++;
				}
				else
				{
					local_presence [ii][current_len] ++;
					catch_flag = false ;

					current_len = 0;

				}
			}

		}
		if (catch_flag)
			local_presence [ii][current_len] ++;

	}

	return local_presence ;
}


void Cluster_set_test::
prepare_cluster_torsion_set_test()
{
	//string cluster_set_name = "PB";
	string cluster_set_name = "16_5a_20";
   // string cluster_set_name = "PB";
	Cluster_set ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

	vector < vector <double> >  cluster_torsion_set =
		ob.prepare_cluster_torsion_set() ;

//Protein_Blocks
	string path_to_cluster_distance_matrix_file = configuration.option_meaning("Path_to_Cluster_set")  +  cluster_set_name + string ("/") + 		string ("cluster_torsion_set");

	ofstream output ( path_to_cluster_distance_matrix_file.c_str());
	if ( ! output )
	{
		log_stream << "path_to_cluster_distance_matrix_file: ERROR -  can't cluster_distance_matrix_file" << path_to_cluster_distance_matrix_file << endl;
		cout       << "path_to_cluster_distance_matrix_file: ERROR -  can't cluster_distance_matrix_file" << path_to_cluster_distance_matrix_file << endl;
		exit (1);
	}


	output << cluster_torsion_set .size() << endl;
	for (int tt=0;tt<cluster_torsion_set .size();tt++)
	{
		for (int pp=0;pp<cluster_torsion_set[tt].size();pp++)
			PutVaDouble (cluster_torsion_set[tt][pp],output ,8,1,'l');
		output << endl ;
	}
}


void Cluster_set_test::
prepare_RMSDA_cluster_distance_matrix_test()
{

	string path_to_current_schedule = configuration.option_meaning("Path_to_Cluster_set")  +  string("PB") + string ("/") + 		string ("sheduler") ;

	Sheduler *sheduler_					= new Sheduler  (path_to_current_schedule);

    string path_manually_setted_angles_flag =
        configuration.option_meaning("Path_to_Cluster_set")  +
			string ("PB/angles.txt");

	int fragment_length_	= atoi(sheduler_->option_meaning("FRAGNMENT_LENGTH").c_str() ) ;
	int number_of_classes_	= atoi(sheduler_->option_meaning("NUMBER_OF_CLASSES").c_str() ) ;

    vector <vector <double> >	Phi_set;
    vector <vector <double> >	Psi_set;
    vector <vector <double> >	Omega_set;
    vector <string> conformation_name;


    /// ����� ��������
/*    get_angles_from_tune_file (
        Phi_set,
        Psi_set,
        Omega_set,
        conformation_name,
        path_to_manually_setted_angles);
*/
    vector <vector <double> >  rmsdA_matrix;
    rmsdA_matrix.resize(number_of_classes_);
    for (int ii=0;ii<number_of_classes_;ii++)
    {
        rmsdA_matrix[ii].resize(number_of_classes_);
    }

//    for (int ii=0;ii<)

    delete sheduler_;
}

void Cluster_set_test::
prepare_cluster_distance_matrix_test()
{
	//string cluster_set_name = "Manulally_3";
	string cluster_set_name = "16_5a_20";
   // string cluster_set_name = "PB";

	Cluster_set ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

	vector < vector <double> >  cluster_distance_matrix =
		ob.prepare_cluster_distance_matrix() ;

//Protein_Blocks
	string path_to_cluster_distance_matrix_file = configuration.option_meaning("Path_to_Cluster_set")  +  cluster_set_name + string ("/") + 		string ("cluster_distance_matrix");

	ofstream output ( path_to_cluster_distance_matrix_file.c_str());
	if ( ! output )
	{
		log_stream << "path_to_cluster_distance_matrix_file: ERROR -  can't cluster_distance_matrix_file" << path_to_cluster_distance_matrix_file << endl;
		cout       << "path_to_cluster_distance_matrix_file: ERROR -  can't cluster_distance_matrix_file" << path_to_cluster_distance_matrix_file << endl;
		exit (1);
	}


	output << cluster_distance_matrix .size() << endl;
	for (int tt=0;tt<cluster_distance_matrix .size();tt++)
	{
		for (int pp=0;pp<cluster_distance_matrix .size();pp++)
			PutVaDouble (cluster_distance_matrix[tt][pp],output ,8,3,'l');
		output << endl ;
	}

/// !!!!!!!!!!!!!!!!!!!!
	vector < Pair_int_double > row_indexed_metrics;

	vector < vector < Pair_int_double > > matrix_indexed_metrics;
	int ii;
	for (  int kk=0; kk<cluster_distance_matrix .size();kk++)
	{
		for (  ii=0;ii<cluster_distance_matrix .size();ii++)
			row_indexed_metrics.push_back ( Pair_int_double (ii,cluster_distance_matrix[kk][ii]) );
		sort (row_indexed_metrics.begin(),row_indexed_metrics.end() );
		matrix_indexed_metrics.push_back(row_indexed_metrics);
		row_indexed_metrics.resize(0);
	}
	output << "Indexed array (sorted by distance)" << endl;


	for (  int kk=0; kk<cluster_distance_matrix .size();kk++)
	{
		for (  ii=0;ii<cluster_distance_matrix .size();ii++)
		{
			PutVa (matrix_indexed_metrics[kk][ii].index(),output ,3,0,'l');
			output << '(';
			PutVaDouble (matrix_indexed_metrics[kk][ii].value(),output ,5,3,'l');
			output << ')';
		}
		output << endl;
	}

// SCORE MATRIX

	int nu_clu = cluster_distance_matrix .size();

	vector < vector <double> >  score_matrix_1;
	score_matrix_1.resize(cluster_distance_matrix .size());
	for (int tt=0;tt<cluster_distance_matrix .size();tt++)
		score_matrix_1[tt].resize(cluster_distance_matrix .size() );

	for (int kk=0;kk<cluster_distance_matrix .size();kk++)
	{
		for (int ii=0;ii<cluster_distance_matrix .size();ii++)
		{
			int index = matrix_indexed_metrics[kk][ii].index();
			score_matrix_1[kk][index]= nu_clu - ii;
		}
	}


	for (  int kk=0; kk<cluster_distance_matrix .size();kk++)
	{
		for (  ii=0;ii<cluster_distance_matrix .size();ii++)
		{
			PutVa (score_matrix_1[kk][ii],output ,8,0,'l');

/*			output << '(';
			PutVaDouble (matrix_indexed_metrics[kk][ii].value(),output ,5,3,'l');
			output << ')';
*/
		}
		output << endl;
	}



}

void Cluster_set_test::
check_COMMON_USAGE_CLUSTER_SET_MODE_test ()
{
		string cluster_set_name = "30_5a_20";

		Cluster_set ob(
			cluster_set_name,
			COMMON_USAGE_CLUSTER_SET_MODE);


		vector <int> claster_motif_index = ob.get_claster_motif_index();

		int number_of_classes = ob.number_of_classes();
		int fragment_length  = ob.fragment_length();

		double **claster_motif_coordinates  = ob.get_claster_motif_coordinates();
		for (int ii=0;ii<number_of_classes;ii++)
		{
			for (int kk=0;kk<fragment_length*9;kk++)
				cout << claster_motif_coordinates[ii][kk] << '\t';
			cout << endl;
		}

		test_( "number_of_classes ",	number_of_classes  	== 30	);
		test_( "fragment_length ",		fragment_length  	== 5	);
}


void Cluster_set_test::
newlife_constructor_test()
{
//		string cluster_set_name = "30_5a_debug";
        string cluster_set_name = "20_3d_20";

		Cluster_set ob(
			cluster_set_name,
			FILL_UP_MODEL_CLUSTER_SET_MODE);

		//ob.optimize_clasterization();

		/*
		int waited_claster_number = 30;
		double upper_dist=		1.7;
		double lower_dist=		0.8;
		double step_dist=      0.1;
*/

		int waited_claster_number = 15;
		double upper_dist=		1.1;
		double lower_dist=		0.3;
		double step_dist=      0.1;


		string metrics_mode("SQUARE_ROOT_INVERSE_DISTANCE");


		vector <int> choosen_indexes = ob.algorithm_2(
			upper_dist,
			lower_dist,
			step_dist,
			waited_claster_number,
			metrics_mode);


			vector < Single_cluster_record >  claster_diversity;
			double  distance_scattering, quadrate_distance_scattering;

			ob.regulate_choseen_index_subsample_version(
				choosen_indexes,
				claster_diversity,
				distance_scattering,
				quadrate_distance_scattering ) ;


			const string output_file_name = string("plain_cluster_show_test");
				ob.plain_claster_show_subsample_version (
					output_file_name,
					claster_diversity,
					distance_scattering,
					quadrate_distance_scattering);



	ofstream output ( "D:/Didona/Test/newlife_constructor_test");
	if ( ! output )
	{
		log_stream	<< "can't create " << endl;
		cout		 << "can't create " << endl;
		exit (1);
	}

	for (int ii=0;ii<choosen_indexes.size();ii++)
		output << choosen_indexes[ii] << endl;

}
/*
void Cluster_set_test::
constructor_test ()
{

	string  fragment_base_subtle_name = string ("5a");
	int zip_factor = 50;
	int shift = 3;

	Cluster_set cla_ob(
		fragment_base_subtle_name,
		zip_factor,
		shift,
		CLUSTER_SET_FILL_UP);

	double upper_dist = 30;

	double	lower_dist				= 1.5;
	double	step_dist				=  .1;
	int		waited_claster_number	= 50;

//	string metrics_mode = "SQUARED_INVERSE_DISTANCE";

//	string metrics_mode = "FOURTH_POWER_INVERSE_DISTANCE";

//	string metrics_mode = "PLAIN_INVERSE_DISTANCE";
	string metrics_mode = "SQUARED_INVERSE_DISTANCE";

//	string metrics_mode = "MULTIPLIED_PLAIN_SQUARED_INVERSE_DISTANCE";
//	string metrics_mode = "SQUARE_ROOT_INVERSE_DISTANCE";

//SQUARED_INVERSE_DISTANCE

	vector < int >  choosen_indexes = cla_ob.algorithm_2(
			upper_dist,
			lower_dist,
			step_dist,
			waited_claster_number,
			metrics_mode);

	vector < Single_cluster_record >  claster_diversity;
	double  distance_scattering, quadrate_distance_scattering;

	cla_ob.regulate_choseen_index(
		choosen_indexes,
		claster_diversity,
		distance_scattering,
		quadrate_distance_scattering) ;


	cla_ob.plain_claster_show (
		"TEST/Cluster_set_test",
		claster_diversity,
		distance_scattering,
		quadrate_distance_scattering) ;

}
*/
/*
void Cluster_set_test::
optimize_clasterization_test ()
{

	string  fragment_base_subtle_name = string ("5a");
	int zip_factor = 50;
	int shift = 3;


	Cluster_set cla_ob(
		fragment_base_subtle_name,
		zip_factor,
		shift,
		CLUSTER_SET_FILL_UP);


	int waited_claser_number= 8;
	cla_ob.optimize_clasterization(waited_claser_number);

}





void Cluster_set_test::
mutual_distance_for_BS_show_test ()
{

	vector <int > choosen_indexes = pull_out_claster_origin_structure_list (
		"D:/Agony/Store/Sane_metrics/5a/50_3/30/protocol",
		30 );

	for (int ii=0; ii<choosen_indexes.size(); ii++ )
	{
		cout << choosen_indexes [ii] << endl;
	}

	string  fragment_base_subtle_name = string ("5a");
	int zip_factor = 50;
	int shift = 3;

	Cluster_set cla_ob(
		fragment_base_subtle_name,
		zip_factor,
		shift,
		CLUSTER_SET_COMMON_USAGE);



	ofstream output ( "D:/Agony/Store/Supplement/BS_mutual_distance.txt");
	if ( ! output )
	{
		log_stream << "fill_up_database(): ERROR -  can't create rejected_files.protocol" << endl;
		cout       << "fill_up_database(): ERROR -  can't create rejected_files.protocol" << endl;
		exit (1);
	}


	vector < vector <double> > Cluster_distance_matrix;

	Cluster_distance_matrix.resize( choosen_indexes.size());
	for (int tt=0;tt<choosen_indexes.size();tt++)
		Cluster_distance_matrix[tt].resize( choosen_indexes.size() );
	int tt;
	for (tt=0;tt<choosen_indexes.size();tt++)
		Cluster_distance_matrix[tt][tt]=0;


	cla_ob.mutual_distance_for_BS_show(
		choosen_indexes,
		Cluster_distance_matrix);

	output << "             ";
	for (int ii=0;ii<Cluster_distance_matrix.size();ii++)
		PutVa (ii,output,6,3 ,'l');
	output << endl << "______________________________________________________________________________________________________________________________________________________________________________________________"<< endl;

	for (int ii=0;ii<Cluster_distance_matrix.size();ii++)
	{
		PutVa (ii,output,6,3 ,'l');		PutVa ("|",output,6,3 ,'l');
		for (int jj=0;jj<Cluster_distance_matrix[0].size();jj++)
		{
			PutVaDouble (Cluster_distance_matrix[ii][jj],output,6,3 ,'l');
		}
		output << endl;
	}
}
*/

void Cluster_set_test::
pull_out_claster_origin_structure_list_test ( )
{
//	vector <int > choosen_indexes = pull_out_claster_origin_structure_list (
//		"D:/Didona/Store/Cluster_set/DSSP_SET_30/protocol");

	/*vector <int > choosen_indexes = pull_out_claster_origin_structure_list (
		"D:/Didona/Store/Cluster_set/30_7a_20/protocol");

	for (int ii=0; ii<choosen_indexes.size(); ii++ )
	{
		cout << choosen_indexes [ii] << endl;
	}
*/
	 //   string  cluster_set_name = string ("16_5a_20");
 //   string  cluster_name ="0123456789ABCDEF";


    string  cluster_set_name = string ("PB");
    string  cluster_name ="abcdefghijklmnop";


	Cluster_set cla_ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

	vector < Single_cluster_record >  claster_diversity;
	double  distance_scattering, quadrate_distance_scattering;

	cla_ob.regulate_choseen_index_for_whole_base_explicit_motiff_coord(
		claster_diversity,
		distance_scattering,
		quadrate_distance_scattering) ;


    log_stream  << "before la_ob.subtle_claster_show_for_whole_base"<< endl;

    string host_dir  = cla_ob.get_host_dir();

    string subtle_cluster_show_file = host_dir + "subtle_cluster_show";
	cla_ob.subtle_claster_show_for_whole_base(
		subtle_cluster_show_file,
		claster_diversity);

/*
    string diagram_show_file = host_dir + "diagram_show_file_with_RMSDA";
    cla_ob.prepare_occurence_diagram (
        diagram_show_file,
        claster_diversity,
        cluster_name);
*/
}

void Cluster_set_test::
prepare_occurence_frequency_diagram_data_test ( ) // plain_cluster_show
{

   string  cluster_set_name = string ("PB");
	Cluster_set cla_ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

	vector < Single_cluster_record >  claster_diversity;
	double  distance_scattering, quadrate_distance_scattering;

	cla_ob.regulate_choseen_index_for_whole_base_explicit_motiff_coord(
		claster_diversity,
		distance_scattering,
		quadrate_distance_scattering) ;

		// fix debug only
		log_stream  << claster_diversity[0].neighbour_number()<< endl;
		log_stream  << claster_diversity[1].neighbour_number()<< endl;
		log_stream  << claster_diversity[3].neighbour_number()<< endl;
		log_stream  << claster_diversity[4].neighbour_number()<< endl;
		log_stream  << claster_diversity[5].neighbour_number()<< endl;
		log_stream  << claster_diversity[6].neighbour_number()<< endl;
		log_stream  << claster_diversity[7].neighbour_number()<< endl;
        log_stream  << claster_diversity[8].neighbour_number()<< endl;
		log_stream  << claster_diversity[9].neighbour_number()<< endl;
		log_stream  << claster_diversity[10].neighbour_number()<< endl;
		log_stream  << claster_diversity[11].neighbour_number()<< endl;
		log_stream  << claster_diversity[12].neighbour_number()<< endl;
		log_stream  << claster_diversity[13].neighbour_number()<< endl;
		log_stream  << claster_diversity[14].neighbour_number()<< endl;
		log_stream  << claster_diversity[15].neighbour_number()<< endl;


    string output_file_name = cla_ob.get_host_dir() + "plain_cluster_show.new_version";

	cla_ob.plain_claster_show_subsample_version(
				output_file_name,
					claster_diversity,
					distance_scattering,
					quadrate_distance_scattering);




    log_stream  << "before prepare_occurence_frequency_diagram_data"<< endl;

    string host_dir  = cla_ob.get_host_dir();

    string occurence_frequency_diagram_data = host_dir + "occurence_frequency_diagram_data.txt";

    cla_ob.prepare_occurence_frequency_diagram_data(
        occurence_frequency_diagram_data,
        claster_diversity,
        3,
        0.01);




}
void Cluster_set_test::
single_usage_only_for_graph_creation ()
{

    string path_to_data_file="../Store/Cluster_set/16_5a_20/subtle_cluster_show.save_good";



	ifstream in( path_to_data_file .c_str() );
	if ( ! in	)
	{
		log_stream << "can't open " << path_to_data_file<< endl;
		cout       << "can't open " << path_to_data_file<< endl;
		exit (1);
	}

   string path_to_result_file  = "../Store/Cluster_set/16_5a_20/diagram_data.txt";

	ofstream out( path_to_result_file .c_str() );
	if ( ! out	)
	{
		log_stream << "can't create " << path_to_result_file<< endl;
		cout       << "can't create " << path_to_result_file<< endl;
		exit (1);
	}

	double upper_distance = 3.0;
    int number_of_classes = 16;
    double step_size = 0.01;

	int step_number = upper_distance/step_size;

    vector < vector <int> > occurence_for_diagram;
    occurence_for_diagram.resize(number_of_classes);
    for (int kk=0;kk<number_of_classes;kk++)
        occurence_for_diagram[kk].resize(step_number+1);


	string current_line;
	while( getline( in , current_line, '\n' ) )
	{
        if ( current_line.size() < 1 )
            continue;

        string cluster_word;
        string dummy_word;
        int index;
        double current_distance;

       	istringstream ist (current_line);
		ist >> cluster_word >> dummy_word >> index  >> current_distance;

		if (current_distance > upper_distance)
            continue;

        int index_diagram = (int) (current_distance / step_size );

        occurence_for_diagram[index][index_diagram] ++;

	}

	for (int ii=0;ii<number_of_classes;ii++)
	{
        out << "CLUSTER " << ii << endl;
        for (int kk=0;kk<step_number;kk++)
        {
            PutVaDouble ( (kk+1)*step_size,out,5,2,'l');
            out << '\t';
            PutVa(occurence_for_diagram[ii][kk],out,8,0,'l');
            out << endl;
        }
        out << endl;out << endl;
	}


}
void Cluster_set_test::
check_accepted_chain_list()
{

    string  cluster_set_name = string ("16_5a_20");
	Cluster_set cla_ob(
		cluster_set_name,
		COMMON_USAGE_CLUSTER_SET_MODE);

    string host_dir = cla_ob.get_host_dir();
    string path_to_result_file  = host_dir + string ("check_torsrion_angles.txt");

	ofstream out( path_to_result_file .c_str() );
	if ( ! out	)
	{
		log_stream << "can't create " << path_to_result_file<< endl;
		cout       << "can't create " << path_to_result_file<< endl;
		exit (1);
	}



	int number_of_classes   =   cla_ob.number_of_classes();
	int fragment_length     =   cla_ob.fragment_length();
    double ** claster_motif_coordinates = cla_ob.get_claster_motif_coordinates();

    vector < vector < double > > torsion_vector;
    torsion_vector.resize(number_of_classes);

    for (int ii=0; ii<number_of_classes; ii++)
    {
         fill_up_fragment_torsion_angles (
            claster_motif_coordinates[ii],
            fragment_length,
            torsion_vector[ii],
            'd');
    }
   for (int ii=0; ii<number_of_classes; ii++)
   {
        for (int kk=0;kk<torsion_vector[ii].size();kk++)
        {
            PutVaDouble(torsion_vector[ii][kk],out,10,3,'l');
        }
        out << endl;
   }


   //********************

        vector <int> claster_motif_index;
        claster_motif_index.push_back(1649124  );
        claster_motif_index.push_back(1070624  );
        claster_motif_index.push_back(2250344  );
        claster_motif_index.push_back(1642024   );
        claster_motif_index.push_back(1648924   );
        claster_motif_index.push_back(2823824   );
        claster_motif_index.push_back(512384    );
        claster_motif_index.push_back(2516444   );
        claster_motif_index.push_back(1518164   );
        claster_motif_index.push_back(1326984   );
        claster_motif_index.push_back(824304    );
        claster_motif_index.push_back(783304    );
        claster_motif_index.push_back(2620624   );
        claster_motif_index.push_back(2323184   );
        claster_motif_index.push_back(413404    );
        claster_motif_index.push_back(1090244 );

        string fragment_base_subtle_name = "5a";
        Fragment_base_subtle *fragment_base_  = new Fragment_base_subtle ( fragment_base_subtle_name , FRAGMENT_BASE_SUBTLE_COMMON_USAGE);
// ****
   		double **claster_motif_coordinates_1 = new double* [number_of_classes] ;
		for ( int ii=0; ii < number_of_classes; ii++  )
			claster_motif_coordinates_1[ii]  = new double [fragment_length*9];


		for (int kk=0;kk<number_of_classes;kk++)
			fragment_base_->get_coord( claster_motif_index [kk], claster_motif_coordinates_1[kk]);

        delete fragment_base_;

    out        << "***************************************" << endl;
       vector < vector < double > > torsion_vector_1;
    torsion_vector_1.resize(number_of_classes);

    for (int ii=0; ii<number_of_classes; ii++)
    {
         fill_up_fragment_torsion_angles (
            claster_motif_coordinates_1[ii],
            fragment_length,
            torsion_vector_1[ii],
            'd');
    }
   for (int ii=0; ii<number_of_classes; ii++)
   {
        for (int kk=0;kk<torsion_vector[ii].size();kk++)
        {
            PutVaDouble(torsion_vector_1[ii][kk],out,10,3,'l');
        }
        out << endl;
   }


}
