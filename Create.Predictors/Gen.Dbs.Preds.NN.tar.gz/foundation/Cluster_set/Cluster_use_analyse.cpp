#include "Cluster_use_analyse.h"

#include "../Censorship.h"
#include "../Sheduler.h"

#include "../Fragment_base/Fragment_base_subtle.h"
#include "../Pair_int_double.h"
#include "../by_Qmol/kabsch_stolen.h"

#include "../CommonFunc.h"

#include "../Fragment_base/fill_up_fragment_torsion_angles.h"

#include "Single_cluster_record.h"

#include <iostream>
#include <cmath>
#include <cassert>

#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"

#include "../get_nearest_claster_index.h"



extern Censorship configuration;
extern ofstream log_stream;

//string current_algorithm_name;


using namespace std;


Cluster_use_analyse::~Cluster_use_analyse()
{
	 if ( fragment_base_  )
		 delete fragment_base_;


	 if ( sheduler_  )
		delete sheduler_ ;

	if ( claster_motif_coordinates_ )
	{
		for (int kk=0; kk<number_of_classes_; kk++)			delete [] claster_motif_coordinates_[kk];
		delete [] claster_motif_coordinates_;
		claster_motif_coordinates_=0;
	}

}

Cluster_use_analyse::Cluster_use_analyse (
		const string & cluster_set_mame):

	cluster_set_mame_ 					(cluster_set_mame),
	fragment_base_						(0),
	claster_motif_coordinates_          (0),
	sheduler_							(0)
{

	//string path_to_current_schedule = configuration.option_meaning("Path_to_Cluster_set")  +  string(cluster_set_mame) + string ("/") + 		string ("sheduler.Cluster_use_analyse");

	host_dir_ = 	configuration.option_meaning("Path_to_Cluster_set")  +
			cluster_set_mame_ + string ("/");

	//sheduler_					= new Sheduler  (path_to_current_schedule);

	init_claster_motif();

}


void Cluster_use_analyse::
init_claster_motif()
{
    string path_to_coordinates_file = host_dir_ + string ("cartesian_coordinates");

    ifstream in( path_to_coordinates_file .c_str() );
	if ( ! in	)
	{
		log_stream << "can't open " << path_to_coordinates_file<< endl;
		cout       << "can't open " << path_to_coordinates_file<< endl;
		exit (1);
	}

	string description_line;
	getline( in , description_line, '\n' );

	string current_line;
	getline( in , current_line, '\n' );
	{
		istringstream ist (current_line);
		ist >> number_of_classes_;
    }

	getline( in , current_line, '\n' );
	{
		istringstream ist (current_line);
		ist >> fragment_length_;
    }

/// allocation array for coordinates
    claster_motif_coordinates_ = new double* [number_of_classes_] ;
    for ( int ii=0; ii < number_of_classes_; ii++  )
        claster_motif_coordinates_[ii]  = new double [fragment_length_*9];


    for ( int ii=0; ii < number_of_classes_; ii++  )
    {
        for ( int kk=0; kk < fragment_length_*9; kk++  )

            in >> claster_motif_coordinates_[ii][kk];


    }

}


/// Распределяет все фрагменты по PB, сортирует кдастеры по размеру и внутри кластеров сотрируеьт фрагмены по RMSD до центрального фрагмента
void Cluster_use_analyse::
regulate_PB_population(
    const string & fragment_base_subtle_name,  //
	vector < Single_cluster_record > & claster_diversity,
	double & distance_scattering,
	double & quadrate_distance_scattering)

{


	claster_diversity.resize(0);
	distance_scattering = 0;
	quadrate_distance_scattering = 0;


 //   length_ = fragment_length_;

	vector < int >		neighbour_numbers; 					neighbour_numbers.					resize	( number_of_classes_ );
	vector < double >	distances_sum_to_origin; 			distances_sum_to_origin.			resize	( number_of_classes_ );
	vector < double >	distances_sum_to_origin_squared ; 	distances_sum_to_origin_squared .	resize	( number_of_classes_ );

	vector < vector < Pair_int_double > > pair_neighbour_index_distances;  pair_neighbour_index_distances.resize	( number_of_classes_ );


 ///   string fragment_base_subtle_name =  sheduler_->option_meaning("FRAGMENT_BASE_SUBTLE_NAME");
    if ( fragment_base_ == 0 )
        fragment_base_  = new Fragment_base_subtle ( fragment_base_subtle_name , FRAGMENT_BASE_SUBTLE_COMMON_USAGE);


	double *cur_fragment = new double [fragment_length_*9];
	double *bs_fragment_lcopy = new double [fragment_length_*9];


	double *w	= new double [fragment_length_*9];
	for ( int kk=0;kk<(fragment_length_*9);kk++)		w[kk] = 1;

	int total_fragment_number = fragment_base_->get_total_fragment_number();

        /// ONLY DEBUG FIX FIX
    //    total_fragment_number = 10000;

	for (  int ii=0;ii< total_fragment_number ; ii++ )
	{
		 vector < Pair_int_double > indexed_dist_store;

		 fragment_base_->get_coord ( ii , cur_fragment  );


		 for (int kk=0; kk< number_of_classes_;kk++ )
		 {
			memcpy(bs_fragment_lcopy,claster_motif_coordinates_[kk],fragment_length_*9*sizeof(double));

 			bool error_flag=true;;
					double current_distance = kabsch_rmsd (
					cur_fragment,
					//bs_fragments [kk],
					bs_fragment_lcopy,
					w,
					3*fragment_length_,
					error_flag);

			indexed_dist_store.push_back( Pair_int_double (kk,current_distance) );
		 }

 		sort (indexed_dist_store.begin(),indexed_dist_store.end() );
		int			nearest_index 	=	indexed_dist_store.front().index() ;
		double 		nearest_distance =	indexed_dist_store.front().value() ;
		neighbour_numbers				[ nearest_index]	++;
		distances_sum_to_origin			[ nearest_index]	+=  nearest_distance;
		distances_sum_to_origin_squared [ nearest_index]	+=  nearest_distance*nearest_distance;

		distance_scattering								+=  nearest_distance;
		quadrate_distance_scattering						+=  nearest_distance*nearest_distance;

		// index in database and distance to origin
		pair_neighbour_index_distances	[ nearest_index].push_back( Pair_int_double (ii,nearest_distance) ) ;

		indexed_dist_store.clear();
	 }

		for (int  kk=0; kk <number_of_classes_ ;kk++ )
			sort(	pair_neighbour_index_distances[kk].begin(),	pair_neighbour_index_distances[kk].end() );


// тут собака порылась ************************
	for ( int kk=0; kk < number_of_classes_;kk++ )
		claster_diversity.push_back( Single_cluster_record (
//			choosen_indexes[kk],
            kk,
			neighbour_numbers[kk],
			distances_sum_to_origin[kk],
			distances_sum_to_origin_squared[kk],
			pair_neighbour_index_distances [kk]) );


	sort (claster_diversity.begin(),
		  claster_diversity.end() );


	delete []	cur_fragment ;
	delete []	bs_fragment_lcopy ;
	delete []	w;
}

///Выводит подробные данные о данных базы фрагментов в файл.
///Результаты отсотрированы: по размерам кластеров и внутри кластеров по RMSD до центра кластера
void Cluster_use_analyse::subtle_claster_show (
    const string & fragment_base_subtle_name,
 	const string & output_file_name	 )
{

    vector < Single_cluster_record >  claster_diversity;
    double  distance_scattering,quadrate_distance_scattering;

    regulate_PB_population(
        fragment_base_subtle_name,
        claster_diversity,
        distance_scattering,
        quadrate_distance_scattering);


    int total_fragment_number = fragment_base_->get_total_fragment_number();

   // log_stream <<  " subtle_claster_show () after regulate_PB_population" << endl;

    string path_to_output_file_name = host_dir_ + output_file_name;

   // log_stream <<  " subtle_claster_show () path_to_output_file_name:" <<path_to_output_file_name << endl;


	ofstream output ( path_to_output_file_name.c_str());
	if ( ! output )
	{
		log_stream << "subtle_claster_show(): ERROR -  can't create output file" << endl;
	  	cout       << "subtle_claster_show(): ERROR -  can't create output file" << endl;
		exit (1);
	}
    log_stream <<  " subtle_claster_show () after ofstream opeh" << endl;

    PutVa ( claster_diversity.size(),			output,8,1 ,'l');
	PutVaDouble (distance_scattering /total_fragment_number ,			output,10,3 ,'l');
	PutVaDouble (quadrate_distance_scattering/total_fragment_number ,	output,10,3 ,'l');

	output << endl;
	output << "___________________________________________________________________________" << endl;


	double *w	= new double [fragment_length_*9];
	for ( int kk=0;kk<(fragment_length_*9);kk++)		w[kk] = 1;

	double *cur_fragment   = new double [fragment_length_*9];
	double *cur_fragment_1 = new double [fragment_length_*9];


	int counter =0;

//	double *cur_fragment = new double [fragment_length_*9];

    string path_to_names = host_dir_ + "cluster_names.txt";

    ifstream in ( path_to_names.c_str()  );
	if ( ! in )
	{
		log_stream << "subtle_claster_show(): ERROR -  can't open cluster names file" << endl;
	  	cout       << "subtle_claster_show(): ERROR -  can't open cluster names file" << endl;
		exit (1);
	}
    string one_letter_names;
    in >> one_letter_names;

    if ( one_letter_names.size() != number_of_classes_ )
    {
        log_stream   << "Check " << path_to_names << " number of clusters does not coincides to names size" << endl;
        cout         << "Check " << path_to_names << " number of clusters does not coincides to names size" << endl;
        exit(1);
    }


	for  ( int ii=claster_diversity.size()-1 ; ii >= 0; ii-- )
	{
		counter++ ;

		int in_data_base_index = claster_diversity[ii].in_data_base_index();

		fragment_base_->get_coord (
			claster_diversity[ii].in_data_base_index() ,
			cur_fragment );

		vector < Pair_int_double >  pair_neighbour_index_distance = claster_diversity[ii].pair_neighbour_index_distance() ;

		output << endl;

		output << "CLASTER ";
		PutVa ( counter ,			output,6,	5 ,'l');
		output << "start ";
		output << "neighbour number: " << pair_neighbour_index_distance.size() << endl;

		for ( int jj=0; jj<pair_neighbour_index_distance.size(); jj++ )
		{
			output << "CLASTER ";
			PutVa ( counter ,			output,6,	5 ,'l');
			PutVa ( in_data_base_index ,			output,6,	5 ,'l');
			PutVa ( one_letter_names[in_data_base_index] ,			output,3,	1 ,'l');

			PutVaDouble ( pair_neighbour_index_distance[jj].value(),output,10,5 ,'r');

			output << "  " ;


			int test1 = pair_neighbour_index_distance[jj].index();

			fragment_base_->get_coord (
				pair_neighbour_index_distance[jj].index() ,
				cur_fragment );


			string	 pdb_ID_chain_ID;
			string	 sequence;
			int		 serial_number;
			string   pdb_resudue_number;

			fragment_base_->fill_up_record_items (
				pair_neighbour_index_distance[jj].index() ,
				pdb_ID_chain_ID,
				sequence,
				serial_number,
				pdb_resudue_number);

			PutVa (  pair_neighbour_index_distance[jj].index() ,			output,10,	5 ,'l');
			PutVa ( pdb_ID_chain_ID	,			output,6,	5 ,'l');
			PutVa (sequence,					output,10,	1 ,'l');

			PutVa (serial_number,					output,10,	1 ,'l');
			PutVa (pdb_resudue_number,				output,10,	1 ,'l');

			output << " | " ;

			vector < double > torsion;
			fill_up_fragment_torsion_angles (
				cur_fragment,
				fragment_length_,
				torsion,
				'd');

			for ( int kk =0; kk<torsion.size(); kk++ )
				PutVaDouble ( torsion[kk],output,10,3 ,'r');

			output << endl;

		}
	}
	delete [] cur_fragment;
}



void Cluster_use_analyse::
plain_claster_show (
    const string & fragment_base_subtle_name,
 	const string & output_file_name	 )
{

    vector < Single_cluster_record >  claster_diversity;
    double  distance_scattering,quadrate_distance_scattering;

    regulate_PB_population(
        fragment_base_subtle_name,
        claster_diversity,
        distance_scattering,
        quadrate_distance_scattering);


    string path_to_names = host_dir_ + "cluster_names.txt";

    ifstream in ( path_to_names.c_str()  );
	if ( ! in )
	{
		log_stream << "subtle_claster_show(): ERROR -  can't open cluster names file" << endl;
	  	cout       << "subtle_claster_show(): ERROR -  can't open cluster names file" << endl;
		exit (1);
	}
    string one_letter_names;
    in >> one_letter_names;

    if ( one_letter_names.size() != number_of_classes_ )
    {
        log_stream   << "Check " << path_to_names << " number of clusters does not coincides to names size" << endl;
        cout         << "Check " << path_to_names << " number of clusters does not coincides to names size" << endl;
        exit(1);
    }


//   log_stream <<  " plain_claster_show () after regulate_PB_population" << endl;
    string path_to_output_file_name = host_dir_ + output_file_name;
//    log_stream <<  " plain_claster_show () path_to_output_file_name:" <<path_to_output_file_name << endl;


	ofstream output ( path_to_output_file_name.c_str());
	if ( ! output )
	{
		log_stream << "plain_claster_show(): ERROR -  can't create output file" << endl;
	  	cout       << "plain_claster_show(): ERROR -  can't create output file" << endl;
		exit (1);
	}
    log_stream <<  " _claster_show () after ofstream opeh" << endl;


    int total_fragment_number = fragment_base_->get_total_fragment_number();

	PutVa ( claster_diversity.size(),			output,8,1 ,'l');
	PutVaDouble (distance_scattering /total_fragment_number ,			output,10,3 ,'l');
	PutVaDouble (quadrate_distance_scattering/total_fragment_number ,	output,10,3 ,'l');

	output << endl;
	output << "___________________________________________________________________________" << endl;


	double *w	= new double [fragment_length_*9];
	for ( int kk=0;kk<(fragment_length_*9);kk++)		w[kk] = 1;

	double *cur_fragment = new double [fragment_length_*9];
//	double *cur_fragment_1 = new double[fragment_length_ * 9];


	for  ( int ii=claster_diversity.size()-1 ; ii >= 0; ii-- )
	{



		int in_data_base_index = claster_diversity[ii].in_data_base_index();

        vector < Pair_int_double >  pair_neighbour_index_distance = claster_diversity[ii].pair_neighbour_index_distance() ;

        int global_index = pair_neighbour_index_distance[0].index(); // the first element in neigbours list is the center of cluster (protein block)

		fragment_base_->get_coord (
			global_index ,
			cur_fragment );

		vector < double > torsion_set;


		fill_up_fragment_torsion_angles (
			cur_fragment,
			fragment_length_,
			torsion_set,
			'd');

		string	 pdb_chain_ID;
		string	 fragment_sequence;
		int		 serial_number;
		string   pdb_resudue_number;

		fragment_base_->fill_up_record_items (
			global_index  ,
			pdb_chain_ID,
			fragment_sequence,
			serial_number,
			pdb_resudue_number	);


		PutVa (global_index ,			output,10,	5 ,'l');
		PutVa (one_letter_names[in_data_base_index] ,			output,3,	1 ,'l');
		PutVa (pdb_chain_ID	,			output,6,	5 ,'l');
		PutVa (fragment_sequence,								output,10,	1 ,'l');
		PutVa (serial_number,								output,10,	1 ,'l');
		PutVa (pdb_resudue_number,								output,10,	1 ,'l');

		PutVa (claster_diversity[ii].neighbour_number(),						output,12,	1 ,'l');
		PutVaDouble ( 100* ( ( double) claster_diversity[ii].neighbour_number() ) /total_fragment_number,	output,10, 3,'l');

		PutVaDouble ( claster_diversity[ii].distance_sum_to_origin()  /claster_diversity[ii].neighbour_number(),	output,10,3 ,'l');
		PutVaDouble ( claster_diversity[ii].distance_sum_to_origin_squared()  /claster_diversity[ii].neighbour_number(),	output,10,3 ,'l');

		for ( int kk =0; kk<torsion_set.size(); kk++ )
			PutVaDouble (torsion_set[kk],output,10,1 ,'r');


		output << endl;

	}

}
