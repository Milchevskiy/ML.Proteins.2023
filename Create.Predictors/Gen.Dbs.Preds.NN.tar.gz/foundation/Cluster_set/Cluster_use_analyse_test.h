#ifndef CLUSTER_USE_ANALYSE_TEST_H_INCLUDED

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class Cluster_use_analyse_test: public Simple_test
{
public:
	~Cluster_use_analyse_test();

    void run()
    {

   //     init_claster_motif_test();

        plain_claster_show_test    ();
        subtle_claster_show_test();
	}
	void init_claster_motif_test    ();
    void subtle_claster_show_test   ();
    void plain_claster_show_test    ();

};





#endif // CLUSTER_USE_ANALYSE_TEST_H_INCLUDED
