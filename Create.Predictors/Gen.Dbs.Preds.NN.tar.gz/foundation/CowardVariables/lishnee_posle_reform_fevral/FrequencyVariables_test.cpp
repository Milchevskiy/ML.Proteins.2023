#pragma warning( disable : 4786 )

#include "FrequencyVariables_test.h"
#include "FrequencyVariables.h"

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>

using namespace std;

extern ofstream log_stream;

FrequencyVariables_test::~FrequencyVariables_test()
{
	cout << "FrequencyVariables_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;

}

void FrequencyVariables_test::first_test			()
{
	FrequencyVariables  fv ("D:/Didona/Store/Model_store/test_model/Frequency_extrapolation.task");


	string sequence = "KVFGRCELAAAMKRHGLDNYRGYSLGNWVCAAKFESNFNTQATNRNTDGSTDYGILQINSRWWCNDGRTPGSRNLCNIPCSALLSSDITASVNCAKKIVSDGNGMNAWVAWRNRCKGTDVQAWIRGCRL";

	vector < vector < double > > sophisticated_variables  ;

	fv.process_chain (
		sequence, 
		sophisticated_variables );


	ofstream  out( "D:/Didona/TEST/FrequencyVariables_test");

	if ( ! out)	{	
		log_stream << "CowardVariables_test: ERROR -  can't create file" << endl;
		cout       << "CowardVariables_test: ERROR -  can't create file" << endl;
		exit (1);	
	}


	int number_of_variables = fv.get_number_of_variables() ;
	for (int ii=0; ii<sophisticated_variables.size() ;ii++)
	{
		for (int kk=0;kk<number_of_variables ;kk++)
		{
			double test = sophisticated_variables [ii][kk];
			PutVaDouble (sophisticated_variables [ii][kk], out,10, 3 , 'l');
			PutVaDouble (sophisticated_variables [ii][kk], cout,10, 3 , 'l');

		}
		out << endl;
	}

} 