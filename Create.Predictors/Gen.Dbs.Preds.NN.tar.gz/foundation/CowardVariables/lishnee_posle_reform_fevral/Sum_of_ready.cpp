#pragma warning( disable : 4786 )

#include "Sum_of_ready.h"
 
#include <sstream>
#include <cassert>
#include <iostream> 
#include <fstream>
#include <map>
#include <cmath>

//extern map    < string, int >			co_task_variable_name_to_index; 


extern ofstream log_stream;

Sum_of_ready::Sum_of_ready( 
	const string & task_string,
	map    < string, int >		&	co_task_variable_name_to_index	) 
{

//	Sum_of_ready 	0 mass_sum  	3     mbb_1    mbb_2     mbb_3   1 2 3 0.25

	istringstream ist( task_string );
	ist >> name_ ;
	assert ( name_ == "Sum_of_ready" ) ;

	int tmp_int; 
	ist >> tmp_int;
	is_subsidiary_ = ( tmp_int == 1 ) ? true : false;


	ist >> variable_name_in_list_;

	ist >> size_of_array_;
 
	string word;
	for ( int ii=0;ii<size_of_array_; ii++ ) 
	{
		ist >> word; 

		if ( co_task_variable_name_to_index.find( word ) == co_task_variable_name_to_index.end() ) 
		{
			log_stream << " Sum_of_ready ERROR: dummy keyword " <<  word << endl;
			cout       << " Sum_of_ready ERROR: dummy keyword " <<  word << endl;
			exit(1);
		}
		else 
		{
			int current_ID = (* co_task_variable_name_to_index.find( word ) ).second;
			ready_var_ID_list_.push_back ( current_ID );
		}
	}
	
	double current_power;
	for ( int ii=0;ii<size_of_array_; ii++ ) 
	{
		if ( ! (ist >> current_power ) )
		{
			log_stream << " Sum_of_ready ERROR: strange format for record \n" <<  task_string  << endl;
			cout       << " Sum_of_ready ERROR: strange format for record \n" <<  task_string  << endl;
			exit(1);
		}
		pow_for_ready_var_.push_back ( current_power );
	}

	if ( ! (ist >> power_ ) ) 		power_ =1; 

}
 
Base_coward* Sum_of_ready::
clone ( 
	const string & task_string, 
	map   < string, int >&	co_task_variable_name_to_index   ) const
{
		return new Sum_of_ready(  task_string, co_task_variable_name_to_index  );
}

void    Sum_of_ready::calc_value ( 
		const int   position_in_chain,  
			  int	var_set_cursor, 
		const		vector < vector < double > >   & Chain_Prime_Constants,
					vector < vector < double > >   & sophisticated_variables    )  
{
	double sum = 0;
	int size_of_ID_set = ready_var_ID_list_.size(); 

	for ( int ii = 0; ii < size_of_ID_set ; ii++ ) 
		sum +=  pow ( sophisticated_variables [position_in_chain][ ready_var_ID_list_[ ii ] ], pow_for_ready_var_[ii]  ) ;

	sophisticated_variables [position_in_chain][var_set_cursor] = pow (sum,power_);
}