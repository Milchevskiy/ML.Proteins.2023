#ifndef FREQUENCYVARIABLES_TEST_H
#define FREQUENCYVARIABLES_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  FrequencyVariables_test: public Simple_test
{
public:
	~FrequencyVariables_test();

    void run()
    {
		first_test				();
	}
	void first_test				();

};

#endif 


