#ifndef FREQUENCYVARIABLES_H
#define FREQUENCYVARIABLES_H

//#include "Base_frequency.h"

#include	<map>
#include	<vector>

using namespace std;

class Frequency_extrapolation; 
class Base_frequency;
class Frequency_chain_constants;

class FrequencyVariables
{
public:
FrequencyVariables() {}
	explicit FrequencyVariables( const string & Sequence_to_values_file_name);
	~FrequencyVariables() {};

	void process_chain ( 
		const string & sequense, 
		vector < vector < double > >& sophisticated_variables );

	void   process_chain ( 
		const	string				&	sequense, 
		vector < vector < double > >&	sophisticated_variables,
		const string & chain_ID );

	int get_number_of_variables () const {return number_of_variables_ ;}  

	map    < string, int >					get_coward_variable_name_to_index () const
												{ return coward_variable_name_to_index_;}  

protected:

	vector < Base_frequency *  >				array_derived_SequenceMap_toValues_;
	map    < string, Base_frequency * >			known_templates_map_SequenceMap_toValue_; 
	map    < string, int >						coward_variable_name_to_index_;

	int		number_of_variables_ ;

	vector < Frequency_extrapolation * >		frequency_pull_;
	map    < string, int >						frequency_name_to_pull_index_;
	void init_frequency_prichindales(const vector < string >   & all_mapped_definite_task);

	vector < Frequency_chain_constants >  	frequency_constant_for_chain ( 
		const string & sequence,
		const string & chain_ID );

	void  init_known_templates_map ();


	void calc_values (
	  int position, 
	  vector < Frequency_chain_constants > & pull_fcc,
	  vector < vector < double > >			& sophisticated_variables) ;


	FrequencyVariables ( const FrequencyVariables& );
	void operator =    ( const FrequencyVariables& );
};

#endif
