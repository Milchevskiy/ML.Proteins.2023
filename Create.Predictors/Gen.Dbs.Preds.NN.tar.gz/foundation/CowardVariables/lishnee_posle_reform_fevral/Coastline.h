#ifndef COASTLINE_H
#define COASTLINE_H

#ifndef BASE_COWARD_H
#include "Base_coward.h"
#endif

#include <string>
#include <vector>

using namespace std;

class  Coastline: public Base_coward
{
public:

	Coastline () {} ;

	explicit Coastline ( 	const string			& task_string,
				map   < string, int	>	&	co_task_variable_name_to_index );


    Base_coward*			clone	( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index  ) const;

	void    calc_value ( 
		const int   position_in_chain,  
			  int	var_set_cursor, 
		const		vector < vector < double > >   & Chain_Prime_Constants,
					vector < vector < double > >   & sophisticated_variables    )  ;
protected:


	string	name_of_property_ ;  

	string	variable_name_in_list_; // ��� ���������� ��� ������� ������ ������

	int left_border_ ;
	int right_border_ ;
	int averaging_range_ ;

	double		power_;

	int		property_ID_;

	Coastline(const Coastline&);
	Coastline& operator = (const Coastline&);
};

#endif