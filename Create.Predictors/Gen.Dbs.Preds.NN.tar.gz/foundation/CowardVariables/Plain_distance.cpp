#pragma warning( disable : 4786 )

#include "Plain_distance.h"
//#include "CowardVariables.h"
#include "Distance_to_claster_variables.h"

//#include "Base_distance_to_claster.h"

//#include "../WiseVariables/get_property_ID_by_property_name.h"

using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>
 
Plain_distance::Plain_distance ( 
	Distance_to_claster_variables & cowa_store,
	const string	& task_string
	) : Property_distance(cowa_store)
{

// Plain_distance 	0 pl_dist_0 0  	1 
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "Plain_distance" ) ;

	int tmp_int; 
	ist >> tmp_int;
//	is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;
	ist >> 	claster_index_ ;

	if ( ! (ist >>  power_)  ) 
		power_ = 1;
}

Property_distance* Plain_distance::
clone(const string & task_string) const
{
	return new Plain_distance(cowa_store_, task_string);
}

double    Plain_distance::calc_value(const int   position_in_chain)
{
	double sum = cowa_store_.set_of_coordinate_in_clasters_system_[position_in_chain][claster_index_];
	return  pow(sum, power_);
}