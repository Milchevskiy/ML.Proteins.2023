#ifndef PLAIN_DISTANCE_H
#define PLAIN_DISTANCE_H

#ifndef PROPERTY_DISTANCE_H
#include "Property_distance.h"
#endif

//#ifndef BASE_COWARD_H
//#include "Base_distance_to_claster.h"
//#endif

#include <string>
#include <vector>

using namespace std;

class  Plain_distance: public Property_distance
{
public:

	Plain_distance(Distance_to_claster_variables & cowa_store) :
		Property_distance(cowa_store)
	{}

	explicit Plain_distance(
		Distance_to_claster_variables & cowa_store,
		const string	& task_string);

	Property_distance* clone(const string & task_string) const;

	double    calc_value(const int   position_in_chain);

protected:

	string variable_name_in_list_;
	int claster_index_ ;
	double power_;

	Plain_distance(const Plain_distance&);
	Plain_distance& operator = (const Plain_distance&);
};

#endif