#pragma warning( disable : 4786 )

#include "Distance_to_claster_variables.h"
#include "../Censorship.h"
#include "../Sheduler.h"
//#include "Base_distance_to_claster.h"
#include "Property_distance.h"

#include "../Cluster_set/Cluster_set.h"
#include "../Sane_metrics/Sane_metrics.h"

#include <iostream>
#include <fstream>
#include <cassert>
#include <sstream>

#include "Plain_distance.h"
#include "Plain_inverse_distance.h"

#include "Distance_to_MC.h"
#include "Distance_to_MC_norm.h"


#include "Inverse_exponent_3.h"

//#include "Product_of_distances.h"
//#include "Product_of_inv_distances.h"
//#include "Sum_of_distances.h"
//#include "Dull_Sum_of_distances.h"

#include "../Fragment_base/Fragment_base_subtle.h"
#include "../Fragment_base/Chain_binary.h"

extern ofstream log_stream;
extern Censorship configuration;

typedef   map < string, Property_distance * > MAP_SEQUENCEMAP_TOVALUE ;
typedef   map < string, int >           MAP_NAME_TO_INDEX ;


Distance_to_claster_variables::
~Distance_to_claster_variables()
{
	if ( ! fbs_ )
		delete fbs_ ;

	if ( !  claster_motif_coordinates_ )
	{
		for ( int ii=0; ii < number_of_classes_; ii++  )
			delete [] claster_motif_coordinates_[ii];

		delete  [] claster_motif_coordinates_;
	}

	if ( ! cls_)
		delete cls_ ;
};


Distance_to_claster_variables::
Distance_to_claster_variables(
	const string &model_name
//	,const string & path_to_structure_assignment_file
	) :
	sheduler_					(0),
	fbs_						(0),
	cls_						(0),   // Claster_set
	claster_motif_coordinates_	(0)
{
	sheduler_		= new Sheduler  (configuration.option_meaning("Path_to_Model_store")  + model_name + string ("/") + string ("sheduler") ) ;


	string cluster_set_name_ =   sheduler_->option_meaning("CLUSTER_SET_NAME");
	cls_ = new Cluster_set  (	cluster_set_name_,COMMON_USAGE_CLUSTER_SET_MODE);


	string sane_metrics_name   = cls_->get_sane_metrics_mame();

	//??? FIX
	number_of_classes_ = cls_->number_of_classes();

/*
	Sane_metrics *san_me= new  Sane_metrics ( sane_metrics_name,SANE_METRICS_COMMON_USAGE);
	string fbs_file_name = san_me->get_fragment_base_subtle_name();
	delete san_me;
	fbs_= new  Fragment_base_subtle (fbs_file_name ,FRAGMENT_BASE_SUBTLE_COMMON_USAGE)  ;
*/
//	fragment_length_ = fbs_->get_fragment_length();

	fragment_length_ = cls_->fragment_length();
	shift_ = fragment_length_/2;

	claster_motif_coordinates_  = cls_->get_claster_motif_coordinates();

//	init_claster_motif();

	string path_to_claster_function_task_file = configuration.option_meaning("Path_to_Model_store")  + model_name + string ("/") + string ("cluster_function.task");

	ifstream  in_stream( path_to_claster_function_task_file.c_str() );
	if ( ! in_stream)
	{
		cout       << "can't find file "  << path_to_claster_function_task_file << endl;
		log_stream << "can't find file "  << path_to_claster_function_task_file << endl;
		assert (  in_stream);
		exit (1);
	}

	vector < string >   all_mapped_definite_task ;

	string current_line;
	while ( getline(in_stream,current_line,'\n' ) )
	{
		if (   current_line[0] == '/'  ||
		       current_line[0] == '#'  ||
		       current_line[0] == ' '  ||
		       current_line[0] == '\n' ||
		       current_line[0] == '\0'  )
		  continue;

		all_mapped_definite_task.push_back( current_line );
	}

	number_of_variables_ = all_mapped_definite_task.size();

	init_known_templates_map ();


    MAP_SEQUENCEMAP_TOVALUE ::iterator theIterator_MAP_SEQUENCEMAP_TOVALUE;
	MAP_NAME_TO_INDEX       ::iterator theIterator_MAP_NAME_TO_INDEX;

	for (int ii=0;ii<number_of_variables_ ;ii++)
	{
		istringstream ist ( all_mapped_definite_task[ii] );

		string current_procedure_key_word, dummy, current_task_name ;
		ist >> current_procedure_key_word >> dummy >> current_task_name;

		theIterator_MAP_SEQUENCEMAP_TOVALUE = known_templates_map_SequenceMap_toValue_.find ( current_procedure_key_word  );
		if ( theIterator_MAP_SEQUENCEMAP_TOVALUE == known_templates_map_SequenceMap_toValue_.end() )
		{
			log_stream << " Distance_to_claster_variables ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			cout       << " Distance_to_claster_variables ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			exit(1);
		}
		else
		{
			Property_distance * current_derived_object =
			known_templates_map_SequenceMap_toValue_[current_procedure_key_word]->clone(all_mapped_definite_task[ii]);
			array_derived_SequenceMap_toValues_.push_back(  current_derived_object );

			if ( current_task_name != "DUMB" && current_task_name != "dumb")
			{
				if  ( coward_variable_name_to_index_.end() != coward_variable_name_to_index_.find ( current_task_name )  )
				{
					log_stream << " Distance_to_claster_variables ERROR: twice assigned variable name: " <<  current_task_name << endl;
					cout       << " Distance_to_claster_variables ERROR: twice assigned variable name: " <<  current_task_name << endl;
					exit(1);

				}
				else
					coward_variable_name_to_index_ [ current_task_name ] = ii;
			}
		}
	}
}

//process_chain (
//	Chain_binary *record,
//	vector < vector < double > >  & 	sophisticated_distance_variables )
void Distance_to_claster_variables::process_chain(
		Chain_binary *record )
{
	vector < vector < double > >	fragments_cartesian_set;

	record->positioning_chain_by_clasters_set (
			claster_motif_coordinates_,
			fragment_length_,
			number_of_classes_,
			set_of_coordinate_in_clasters_system_);

	/// for Distance_to_MC like function only
		current_coord_set_ = record->get_coord_set();
		record->center_of_mass(current_center_of_mass_);
		current_length_    = record->get_sequence().size();
    //*******************

	int task_size = set_of_coordinate_in_clasters_system_.size();
	sophisticated_distance_variables_.resize(task_size );

	for (int jj=0;jj<task_size ; jj++)
	{
		sophisticated_distance_variables_[jj].resize(number_of_variables_);

		calc_values (
			jj) ;
	}
}
/*
void Distance_to_claster_variables::
init_claster_motif()
{
	string claster_origin_structure_file =  sheduler_->option_meaning("CLASTER_ORIGIN_STRUCTURE_LIST");

	claster_motif_index_ = pull_out_claster_origin_structure_list (
								claster_origin_structure_file,
								number_of_classes_);

	claster_motif_coordinates_ = new double* [number_of_classes_] ;
	for ( int ii=0; ii < number_of_classes_; ii++  )
		claster_motif_coordinates_[ii]  = new double [fragment_length_*9];

	for (int kk=0;kk<number_of_classes_;kk++)
		fbs_->get_coord( claster_motif_index_ [kk], claster_motif_coordinates_[kk]);

}
*/

//void Frequency_extrapolation::
void Distance_to_claster_variables::
init_claster_motif()
{
//	string claster_origin_structure_file =  sheduler_->option_meaning("CLASTER_ORIGIN_STRUCTURE_LIST");

//	claster_motif_index_ = pull_out_claster_origin_structure_list (	path_to_cluster_set_protocol_file_name_);
	claster_motif_index_ = cls_->get_claster_motif_index();

	claster_motif_coordinates_ = new double* [number_of_classes_] ;
	for ( int ii=0; ii < number_of_classes_; ii++  )
		claster_motif_coordinates_[ii]  = new double [fragment_length_*9];


	for (int kk=0;kk<number_of_classes_;kk++)
		fbs_->get_coord( claster_motif_index_ [kk], claster_motif_coordinates_[kk]);

}

void Distance_to_claster_variables::
calc_values (  int position )
	//,
	//  const  vector < vector < double > >   & set_of_coordinate_in_clasters_system,
	//  vector < vector < double > >			& sophisticated_distance_variables)
{
	for (int ii=0;ii<number_of_variables_ ;ii++)
	{
		double current_value = array_derived_SequenceMap_toValues_[ii]->calc_value(
			position);
			//,
			//ii,
			//set_of_coordinate_in_clasters_system,
			//sophisticated_distance_variables ) ;

		sophisticated_distance_variables_[position][ii] = current_value;

	}
}

void  Distance_to_claster_variables::
init_known_templates_map ()
{
	Plain_distance *Plain_distance_pointer = new Plain_distance (*this);
	known_templates_map_SequenceMap_toValue_["Plain_distance"] = Plain_distance_pointer ;

	Plain_inverse_distance *Plain_inverse_distance_pointer = new Plain_inverse_distance (*this);
	known_templates_map_SequenceMap_toValue_["Plain_inverse_distance"] = Plain_inverse_distance_pointer ;

	Distance_to_MC *Distance_to_MC_pointer = new Distance_to_MC (*this);
	known_templates_map_SequenceMap_toValue_["Distance_to_MC"] = Distance_to_MC_pointer;

	Distance_to_MC_norm *Distance_to_MC_norm_pointer = new Distance_to_MC_norm(*this);
	known_templates_map_SequenceMap_toValue_["Distance_to_MC_norm"] = Distance_to_MC_norm_pointer;

	Inverse_exponent_3 *Inverse_exponent_3_pointer = new Inverse_exponent_3(*this);
	known_templates_map_SequenceMap_toValue_["Inverse_exponent_3"] = Inverse_exponent_3_pointer;

#include "Inverse_exponent_3.h"


/*
	Product_of_distances *Product_of_distances_pointer = new Product_of_distances ();
	known_templates_map_SequenceMap_toValue_["Product_of_distances"] = Product_of_distances_pointer ;

	Product_of_inv_distances *Product_of_inv_distances_pointer = new Product_of_inv_distances ();
	known_templates_map_SequenceMap_toValue_["Product_of_inv_distances"] = Product_of_inv_distances_pointer ;

	Sum_of_distances *Sum_of_distances_pointer = new Sum_of_distances ();
	known_templates_map_SequenceMap_toValue_["Sum_of_distances"] = Sum_of_distances_pointer ;

	Dull_Sum_of_distances *Dull_Sum_of_distances_pointer = new Dull_Sum_of_distances ();
	known_templates_map_SequenceMap_toValue_["Dull_Sum_of_distances"] = Dull_Sum_of_distances_pointer ;
*/
}
string  Distance_to_claster_variables::
    PB_setting_by_det_distance_set(
        vector < vector < double > > &det_distance_set)

{
    return cls_->PB_setting_by_det_distance_set(det_distance_set);
}
string  Distance_to_claster_variables::
get_cluster_set_mame () const
{
    return cls_->get_cluster_set_mame ();
}



