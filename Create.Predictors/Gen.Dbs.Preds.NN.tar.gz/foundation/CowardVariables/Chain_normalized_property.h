#ifndef CHAIN_NORMALIZED_PROPERTY_H
#define CHAIN_NORMALIZED_PROPERTY_H

#ifndef BASE_COWARD_H
#include "Base_coward.h"
#endif

#include <string>
#include <vector>

using namespace std;

class  Chain_normalized_property: public Base_coward
{
public:

	Chain_normalized_property () {} ;

	explicit Chain_normalized_property ( 	const string			& task_string,
				map   < string, int	>	&	co_task_variable_name_to_index );

    Base_coward*			clone	( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index  ) const;

	void    calc_value ( 
		const int   position_in_chain,  
			  int	var_set_cursor, 
		const		vector < vector < double > >   & Chain_Prime_Constants,
					vector < vector < double > >   & sophisticated_variables    )  ;
protected:
	
	string	variable_name_in_list_; // ��� ���������� ��� ������� ������ ������

	double  power_ ;

	int		property_ID_;

	char    fabs_mode_;

	Chain_normalized_property(const Chain_normalized_property&);
	Chain_normalized_property& operator = (const Chain_normalized_property&);
};

#endif