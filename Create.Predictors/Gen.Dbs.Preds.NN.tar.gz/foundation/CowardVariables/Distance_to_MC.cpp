#pragma warning( disable : 4786 )

#include "Distance_to_MC.h"
//#include "CowardVariables.h"
#include "Distance_to_claster_variables.h"

//#include "Base_distance_to_claster.h"

//#include "../WiseVariables/get_property_ID_by_property_name.h"

using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>

Distance_to_MC::Distance_to_MC(
	Distance_to_claster_variables & cowa_store,
	const string	& task_string
	) : Property_distance(cowa_store)
{

	
	//Distance_to_MC          0  DUMB 1
	istringstream ist(task_string);

	ist >> name_;
	assert(name_ == "Distance_to_MC");

	int tmp_int;
	ist >> tmp_int;
	//	is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;
	ist >> claster_index_;
	ist >> denominator_shift_;

	if (!(ist >> power_))
		power_ = 1;
}

Property_distance* Distance_to_MC::
clone(const string & task_string) const
{
	return new Distance_to_MC(cowa_store_, task_string);
}

double    Distance_to_MC::calc_value(const int   position_in_chain)
{

	/// for Distance_to_MC like function only
	//current_coord_set_ = record->get_coord_set();
	//record->center_of_mass(current_center_of_mass_);

// !!!!! ���� �� ������ shift_ value 
	double x = cowa_store_.current_coord_set_[9 * position_in_chain];			// That's coordinate for N atom!
	double y = cowa_store_.current_coord_set_[9 * position_in_chain + 1];
	double z = cowa_store_.current_coord_set_[9 * position_in_chain + 2];


	double result =
		(x - cowa_store_.current_center_of_mass_[0]) *
		(x- cowa_store_.current_center_of_mass_[0]) +

		(y - cowa_store_.current_center_of_mass_[1]) *
		(y - cowa_store_.current_center_of_mass_[1]) +

		(z - cowa_store_.current_center_of_mass_[2]) *
		(z - cowa_store_.current_center_of_mass_[2]);

	result = sqrt(result);
//	double norm_coeff = pow(double(cowa_store_.current_length_), 1 / 3);
//	result /= norm_coeff;
	return  pow(result, power_);
}
