#ifndef DISTANCE_TO_CLASTER_VARIABLES_TEST_H
#define DISTANCE_TO_CLASTER_VARIABLES_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Distance_to_claster_variables_test: public Simple_test
{
public:
	~Distance_to_claster_variables_test();

    void run()
    {
		test1 ();
		test2 ();

	}
	void test1 ();
	void test2 ();
};

#endif
