#pragma warning( disable : 4786 )

#include "T_statistics_window.h"
#include "CowardVariables.h"

//#include "Base_distance_to_claster.h"


#include "../WiseVariables/get_property_ID_by_property_name.h"

#include "../Frequency_extrapolation/Frequency_extrapolation.h"

#include "../Special_function/special_function.h"

#include "../Statistical_utilits/calc_dispersion_and_average.h"


using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>
#include <iostream>
#include <fstream>
#include <cstdlib>

double DEFAULT_PROBABILITY = 0.2;

extern ofstream log_stream;
extern int MINIMAL_ACCEPTABLE_OCCURENCE;

T_statistics_window::T_statistics_window(
	CowardVariables & cowa_store,
	const string	& task_string
	) : Property(cowa_store)
{

// T_statistics_window  0	DUMB	W5_01234_dx2 12  1

//T_statistics_window 0	DUMB	W5_01234_dx2 12     -2 2    1
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "T_statistics_window" ) ;

	int tmp_int;
	ist >> tmp_int;
	//is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;

	ist >> frequency_map_name_;
	ist >> 	claster_index_ ;

	ist >> 	left_border_ ;
	ist >> 	right_border_ ;

///	ist >> 	value_shift_koef_;

	if ( ! (ist >>  power_)  )
		power_ = 1;

//	double cluster_averqage_;
//	double this_cluster_sigma_;

	if  (cowa_store_.frequency_name_to_pull_index_.end() != cowa_store_.frequency_name_to_pull_index_.find ( frequency_map_name_)  ) // нашел значит
		index_in_frequency_pull_ = cowa_store_.frequency_name_to_pull_index_[frequency_map_name_];
	else
	{
		cout << frequency_map_name_ ;
		cout << "T_statistics_window() ERROR: can't associate Frequency_extrapolation object for name " << endl;
		exit (-1);
	}


}

Property* T_statistics_window::
clone (const string & task_string) const
{
	return new T_statistics_window(cowa_store_, task_string);
}

double    T_statistics_window::
calc_value(const int   position_in_chain)
{
	int pre_start	= position_in_chain + left_border_;
	int pre_end		= position_in_chain + right_border_;

	int seq_len		= cowa_store_.sophisticated_variables_.size ();

	int start	= max ( 0,		pre_start	);
	int end		= min ( pre_end,	seq_len		);

//int seq_len		= cowa_store_.sophisticated_variables_.size ();


	double av1_glo  = cowa_store_.pull_fcc_ [index_in_frequency_pull_ ].tot_distance_to_clusters_sum()[claster_index_];
    double s1_glo   = cowa_store_.pull_fcc_ [index_in_frequency_pull_ ].tot_squared_distance_to_clusters_sum()[claster_index_];
    int casenum_glo = cowa_store_.pull_fcc_ [index_in_frequency_pull_ ].total_sample_size();

    double average_glo,sigma_glo;

    calc_dispersion_and_average_by_known_sums (
        av1_glo,
        s1_glo,
        casenum_glo,
        average_glo,
        sigma_glo );


	double probability_sum = 0;

	for ( int ii = start; ii < end; ii++ )
	{
        double av1_loc  = cowa_store_.pull_fcc_ [index_in_frequency_pull_ ].distance_to_clusters_sum()          [ii][claster_index_];
        double s1_loc   = cowa_store_.pull_fcc_ [index_in_frequency_pull_ ].squared_distance_to_clusters_sum()  [ii][claster_index_];
        int casenum_loc = cowa_store_.pull_fcc_ [index_in_frequency_pull_ ].respect_occurence ()                [ii];

        //if (casenum_loc==1)        cout << "VAH!" << endl;

        if (cowa_store_.current_set_of_coordinate_in_clasters_system_.size() != 0 && ii >=2 && ii < seq_len-4)
        {
            if (casenum_loc > 0 )
            {
                casenum_loc -= 1;
                av1_loc  -=  cowa_store_.current_set_of_coordinate_in_clasters_system_[ii-2][claster_index_];
                s1_loc   -=  cowa_store_.current_set_of_coordinate_in_clasters_system_[ii-2][claster_index_]*cowa_store_.current_set_of_coordinate_in_clasters_system_[ii-2][claster_index_];
            }

        }

        double average_loc,sigma_loc;

        if (casenum_loc>0)
        {
            calc_dispersion_and_average_by_known_sums (
                av1_loc,
                s1_loc,
                casenum_loc,
                average_loc,
                sigma_loc );
        }
        else
        {
            average_loc = average_glo;
            sigma_loc = sigma_glo;
        }

        double t =     ( average_glo - average_loc ) * sqrt ( (double (casenum_loc) ) )/ sigma_loc;
        if (casenum_loc==1 || t == 0.0 )
               probability_sum += DEFAULT_PROBABILITY;
        else
        {
            double current_prob  = prob_by_student (t, casenum_loc  );
            probability_sum += current_prob;
        }

    }

    return pow(fabs(probability_sum), power_);
}

