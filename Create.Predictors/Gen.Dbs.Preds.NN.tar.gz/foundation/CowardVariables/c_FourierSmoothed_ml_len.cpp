#pragma warning( disable : 4786 )

#include "c_FourierSmoothed_ml_len.h"

#include "../WiseVariables/get_property_ID_by_property_name.h"
#include "../CommonFunc.h"
#include "../WiseVariables/exponent_factor.h"


using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>

c_FourierSmoothed_ml_len::c_FourierSmoothed_ml_len (
	const string			& task_string,
	map   < string, int	>	&	co_task_variable_name_to_index )
{

// c_FourierSmoothed_ml_len 	0 mbb_1 	Mass_and_backbone -1 1  2 -0.25

	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "c_FourierSmoothed_ml_len" ) ;

	int tmp_int;
	ist >> tmp_int;
	is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;

	string current_property_name;
	ist >> current_property_name;
	property_ID_ = get_property_ID_by_property_name ( current_property_name ) ;

	ist >>	period_lenfth_;
	ist >>	period_number_;

	ist >>  power_ ;

	ist >>  power_of_len_;


	left_border_	= - period_number_ * period_lenfth_ /2 ;
	right_border_	=	period_number_ * period_lenfth_ /2 ;

	point_number_ =  right_border_ - left_border_;

}

Base_coward* c_FourierSmoothed_ml_len::
clone ( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index   ) const
{
		return new c_FourierSmoothed_ml_len(  task_string,co_task_variable_name_to_index  );
}

void    c_FourierSmoothed_ml_len::calc_value (
		const int   position_in_chain,
			  int	var_set_cursor,
		const		vector < vector < double > >   & Chain_Prime_Constants,
					vector < vector < double > >   & sophisticated_variables    )
{
	double Coefficient = 2*Pythagorean_Number () / period_lenfth_;

	int pre_start	= position_in_chain + left_border_;
	int pre_end		= position_in_chain + right_border_;

	int seq_len		= Chain_Prime_Constants [ property_ID_ ].size ();

	int start	= max ( 0,		pre_start	);
	int end		= min ( pre_end,	seq_len		);

	double A_value=0, B_value=0,property_value =0;
	for ( int ii = start; ii < end; ii++ )
	{
		double x = ii * Coefficient ;
		double current_value = Chain_Prime_Constants [ property_ID_ ] [ ii ] ;
		double factor = exponent_factor ( point_number_, position_in_chain - ii ) ;

		A_value += current_value * sin (x) * factor ;
		B_value += current_value * cos (x) * factor ;
	}
	value_ = sqrt (A_value *A_value + B_value * B_value );
	value_ = pow ( value_,power_ );

	double chain_length = (double) Chain_Prime_Constants.size();
	double koef = pow ( chain_length ,power_of_len_);

	sophisticated_variables [position_in_chain][var_set_cursor] = koef*value_ ;
}
