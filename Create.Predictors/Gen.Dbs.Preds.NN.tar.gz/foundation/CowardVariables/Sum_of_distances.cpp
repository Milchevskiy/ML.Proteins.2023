#pragma warning( disable : 4786 )

#include "Sum_of_distances.h"

#include "Base_distance_to_claster.h"

#include "../WiseVariables/get_property_ID_by_property_name.h"

using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>
 
Sum_of_distances::Sum_of_distances ( 
	const string			& task_string,
	map   < string, int	>	&	co_task_variable_name_to_index )
{

	claster_index_set_.resize(0); 

// Sum_of_distances 0 pr_of_dist_0  2 0 1 	1 
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "Sum_of_distances" ) ;

	int tmp_int; 
	ist >> tmp_int;
	is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;

	ist >> size_of_claster_index_set_ ;

	for ( int ii=0; ii < size_of_claster_index_set_ ; ii++)
	{
		int current_claster_index ;
		ist >> 	current_claster_index ;
		claster_index_set_.push_back ( current_claster_index );
	}

	if ( ! (ist >>  power_)  ) 
		power_ = 1;

//	assert ( denominator_shift_ > 0 );
}

Base_distance_to_claster* Sum_of_distances::
clone ( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index   ) const
{
		return new Sum_of_distances(  task_string,co_task_variable_name_to_index  );
}


void    Sum_of_distances::calc_value ( 
	const int   position_in_chain,  
		  int	var_set_cursor, 
	const		vector < vector < double > >   & set_of_coordinate_in_clasters_system,
				vector < vector < double > >   & sophisticated_distance_variables    )

{
	double sum = 0;
	for (int ii =0; ii< size_of_claster_index_set_; ii++ )
	{
		sum += set_of_coordinate_in_clasters_system[position_in_chain] [claster_index_set_[ii]];
	}

	sophisticated_distance_variables [position_in_chain][var_set_cursor] = pow ( sum,power_ );
}