#pragma warning( disable : 4786 )


#include "Censorship.h"

#include <iostream>
#include <cstdlib>

#include "ServerUtil/ServerUtil.h"


using namespace std;

Censorship configuration;
ofstream log_stream;

/*
#ifndef SERVERUTIL_H
#define SERVERUTIL_H
	void prediction_by_sequence (
		string &sequence,const
		string &outputfilename );
	void prediction_by_sequence_from_fasta_file (
		const string &sourcefilename,
		const string &outputfilename);
	void compare_prediction_by_PDB_file (
		const string &sourcePDBfilename,
		const string &outputfilename,
		char chain_ID);
#endif
*/
/// programm argument
///aaaaaaaa -p -f./ServerTmp/pdb2cro.ent -cA

int main(int argc,char  **argv)
{
	string  output_file ("log");
	log_stream.open (output_file.c_str()  ); // fix log or not log
	configuration.init("config") ;


//	Claster_set_test claster_set_test_;
//	claster_set_test_.run();


	string sequence;
	char chain_ID;

//	argv[1] = "-sGPPGPPAAAAAAAAAAAA";
//    argc = 2;

// debug only
/*
	argv[1] = "pdbtest";
	argv[2] = "-p";
	argv[3] = "-f1shg.pdb";
	argc = 4;
*/

/*	argv[1] = "aaaaaaaaaaa";
	argv[2] = "-p";
	argv[3] = "-fpdb2cro.ent";
	argv[4] = "-cA";
	argc = 5;
*/
	string outputfilename = string (argv[1]);
	string sourcefilename;

	bool run_prediction_by_sequence_flag = false;
	bool is_exist_source_frag			 = false;
	bool run_prediction_by_pdb_flag		 = false;
	bool is_setted_chain_ID				 = false;

	for (int ii=1;ii<argc;ii++)
	{
		if (argv[ii][0]=='-')
		{
			switch (argv[ii][1])
			{
				case 's' :
                        /// ����������� ���   ������ ������������ ���������
                    sequence = string (argv[ii]+2);
					//cout << sequence << endl;
	/*		/// test only
                         sequence =  string ("> Test Fasta file !!!! \n") ;
                         sequence += string ("PPPAAAAAAAAA\n");
                         sequence += string ("PPPPPPPPPPP IIIIIII\n");
                         sequence += string ("VVVVVVVVVVV\tLLLLAGT\n");

                         */

    	 				run_prediction_by_sequence_flag = true;


					break;
				case 'f' :
					sourcefilename = string (argv[ii]+2);
					is_exist_source_frag = true;
	  				break;
				case 'p' :							// ������������ ��� ���������� PDB �����
					run_prediction_by_pdb_flag= true;
					break;
				case 'c' :
					chain_ID = argv[ii][2];
					is_setted_chain_ID = true;
			}

		}
	}
	if (run_prediction_by_sequence_flag)
	{
		if (!is_exist_source_frag)
		{
            string empty_header = string ("");
			prediction_by_sequence_for_server (sequence,outputfilename ,empty_header );

		}

		else
            prediction_by_sequence_from_fasta_file (sourcefilename,outputfilename) ;


		cout << sequence << endl;
	}
	else if (run_prediction_by_pdb_flag)
	{
		if (!is_setted_chain_ID )
		{
            string result_file_name = 	outputfilename;
			ofstream out( result_file_name .c_str() );
			if ( ! out	)
			{
				cout       << "result_file_name   can't create " << result_file_name<< endl;
				exit (1);
			}
			out	<< "ERROR. Chain ID for PDB file not choosen.";
		}
		else
                log_stream << "before prediction_pdb_for_server()";
            prediction_pdb_for_server (sourcefilename,outputfilename,chain_ID);
                log_stream << "after prediction_pdb_for_server()";
	}
	return 0;
}
