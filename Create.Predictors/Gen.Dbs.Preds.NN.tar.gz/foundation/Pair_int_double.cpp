#include "Pair_int_double.h"

Pair_int_double::
Pair_int_double ( const int index, const double value ) :
 index_ (index),
 value_ (value) 
{
}
