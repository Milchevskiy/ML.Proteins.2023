#pragma warning( disable : 4786 )

#include <fstream>
#include <cassert>
#include <string>
#include <map>


using namespace std;

	bool is_standard_one_letter_aminoacid( const char residue_name );
	map <char, int>  set_index_by_name() ;




bool is_standard_one_letter_aminoacid_sequence (const string & current_sequence)
{
	bool flag = true;
	for (int ii=0;ii<current_sequence.size();ii++)
	{
		char ch = current_sequence[ii];
		flag = flag & is_standard_one_letter_aminoacid(ch);
	}

	return flag;
	
}


bool is_standard_one_letter_aminoacid( const char residue_name )
{
	static	map <char, int> map_1_n_ = set_index_by_name();
	int		index = map_1_n_[ residue_name ];
	if (  index > 0 )
		return true;
	else 
		return false;

}



map <char, int>  set_index_by_name() 
{

	std::map < char, int >          map_1_n_ ;


    map_1_n_ [  'A'  ] =   1 ;
    map_1_n_ [  'R'  ] =   2 ;
    map_1_n_ [  'N'  ] =   3 ;
    map_1_n_ [  'D'  ] =   4 ;
    map_1_n_ [  'V'  ] =   5 ;
    map_1_n_ [  'H'  ] =   6 ;
    map_1_n_ [  'G'  ] =   7 ;
    map_1_n_ [  'Q'  ] =   8 ;
    map_1_n_ [  'E'  ] =   9 ;
    map_1_n_ [  'I'  ] =   10 ;
    map_1_n_ [  'L'  ] =   11 ;
    map_1_n_ [  'K'  ] =   12 ;
    map_1_n_ [  'M'  ] =   13 ;
    map_1_n_ [  'P'  ] =   14 ;
    map_1_n_ [  'S'  ] =   15 ;
    map_1_n_ [  'Y'  ] =   16 ;
    map_1_n_ [  'T'  ] =   17 ;
    map_1_n_ [  'W'  ] =   18 ;
    map_1_n_ [  'F'  ] =   19 ;
    map_1_n_ [  'C'  ] =   20 ;

	return map_1_n_;

}