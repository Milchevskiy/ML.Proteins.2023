#include <math.h>
#include "..\\include\\CommonFunc.h"

long ExtractEulerianAngles( double *Mtr ,double &Phi, double &Psi, double &Tet ) {

	Tet = acos (Mtr [8]);
	double SinTet = sqrt ( 1 - Mtr[8]*Mtr[8]);

	double SinPsi = Mtr [2]/SinTet;
	double CosPsi = -Mtr [5]/SinTet;

	Psi=SolveSinCosAmbiguity(SinPsi,CosPsi);

	double SinPhi = Mtr [6]/SinTet;
	double CosPhi = Mtr [7]/SinTet;

	Phi=SolveSinCosAmbiguity(SinPhi,CosPhi);

	return 0;
}