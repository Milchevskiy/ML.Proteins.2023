#include "Geometry_util.h"

#include <cassert>

using namespace Geometry_util;

//#define M_PI		3.1415926535897932384626433832795
//#define M_1_PI		0.31830988618379067153776752674503

void Geometry_util::make_rotation_matrix_X_Z  ( 
	const double angle_around_X,
	const double angle_around_Z, 
	double  * rotation_matrix_X_Z ) 
{
	
	double sin_a_X1	= sin (angle_around_X);	double cos_a_X1	= cos (angle_around_X);
	double sin_a_Z	= sin (angle_around_Z);	double cos_a_Z  = cos (angle_around_Z);

	rotation_matrix_X_Z	[0]   =	+	cos_a_Z ; 
	rotation_matrix_X_Z	[1]   =	-	sin_a_Z ; 
	rotation_matrix_X_Z	[2]   =	0; 
	rotation_matrix_X_Z	[3]   =	+	cos_a_X1	*	sin_a_Z ; 
	rotation_matrix_X_Z	[4]   =	+	cos_a_X1	*	cos_a_Z ; 
	rotation_matrix_X_Z	[5]   =	-	sin_a_X1 ; 
	rotation_matrix_X_Z	[6]   =	+	sin_a_X1	*	sin_a_Z ;
	rotation_matrix_X_Z	[7]   =	+	sin_a_X1	*	cos_a_Z ; 
	rotation_matrix_X_Z	[8]   =	+	cos_a_X1 ; 
}


void Geometry_util::make_rotation_matrix_X_Z_X  (
	const double first_angle_around_X,
	const double angle_around_Z, 
	const double second_angle_around_X,  
	double  * rotation_matrix_X_Z_X ) 
{
	
	double sin_a_X1	= sin (first_angle_around_X);	double cos_a_X1	= cos (first_angle_around_X);
	double sin_a_Z	= sin (angle_around_Z);			double cos_a_Z  = cos (angle_around_Z);
	double sin_a_X3 = sin (second_angle_around_X);	double cos_a_X3 = cos (second_angle_around_X);

	rotation_matrix_X_Z_X [0]   = +cos_a_Z ; 
	rotation_matrix_X_Z_X [1]   = -sin_a_Z	*	cos_a_X3 ; 
	rotation_matrix_X_Z_X [2]   = +sin_a_Z	*	sin_a_X3 ; 
	rotation_matrix_X_Z_X [3]   = +cos_a_X1	*	sin_a_Z ; 
	rotation_matrix_X_Z_X [4]   = +cos_a_X1	*	cos_a_Z	*	cos_a_X3	-	sin_a_X1	*	sin_a_X3 ; 
	rotation_matrix_X_Z_X [5]   = -cos_a_X1	*	cos_a_Z	*	sin_a_X3	-	sin_a_X1	*	cos_a_X3 ; 
	rotation_matrix_X_Z_X [6]   = +sin_a_X1	*	sin_a_Z ; 
	rotation_matrix_X_Z_X [7]   = +sin_a_X1	*	cos_a_Z	*	cos_a_X3	+	cos_a_X1	*	sin_a_X3 ; 
	rotation_matrix_X_Z_X [8]   = -sin_a_X1	*	cos_a_Z	*	sin_a_X3	+	cos_a_X1	*	cos_a_X3 ; 
}


void Geometry_util::normalize_vector (double &Ax, double &Ay,double &Az) 
{
	double Length = sqrt (Ax*Ax + Ay*Ay +Az*Az );

    assert ( Length > Geometry_util::epsilon_float() );//  vector is too short

	double InvLength = 1/Length;

	Ax *= InvLength ; 
	Ay *= InvLength ; 
	Az *= InvLength ; 
}

double Geometry_util::solve_sin_cos_indeterminacy(	const double sin_val,const double cos_val) {

	assert ( fabs( sin_val*sin_val + cos_val*cos_val - 1) <  Geometry_util::epsilon_float()  ) ;

    double f_cos_val = fabs( cos_val );
    double angle_in_first_quadrant = acos ( f_cos_val );

//	if		( fabs(	sin_val) < Geometry_util::epsilon_float() )			return	0;
//  else if ( fabs (cos_val) < Geometry_util::epsilon_float() )			return	Geometry_util::Pythagorean_Number () / 2;
    if      ( (sin_val	>=	0)	&&	(cos_val	>=	0) )	return	angle_in_first_quadrant ;
    else if ( (sin_val	>=	0)	&&	(cos_val	<	0) )	return  Geometry_util::Pythagorean_Number ()	- angle_in_first_quadrant ;
    else if ( (sin_val	<	0)	&&	(cos_val	<	0) )	return	angle_in_first_quadrant	- Geometry_util::Pythagorean_Number () ;
    else if ( (sin_val	<	0)	&&	(cos_val	>=	0) )	return -angle_in_first_quadrant ;

    throw "strange sin or cos value"; 
}



void Geometry_util::multiplication_matrixes_3x3_by_3x3	(
	const double	a[9],
	const double	b[9], 
	double			r[9] ) 
{
	r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
	r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
	r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
	
	r [3] = a[3]*b[0] + a[4]*b[3] + a[5]*b[6];
	r [4] = a[3]*b[1] + a[4]*b[4] + a[5]*b[7];
	r [5] = a[3]*b[2] + a[4]*b[5] + a[5]*b[8];
	
	r [6] = a[6]*b[0] + a[7]*b[3] + a[8]*b[6];
	r [7] = a[6]*b[1] + a[7]*b[4] + a[8]*b[7];
	r [8] = a[6]*b[2] + a[7]*b[5] + a[8]*b[8];
}

void  Geometry_util::multiplication_matrixes_rowx3_by_3x3 (
	const int row_number, 
	const double a[12],
	const double b[9], 
	double		 r[12] ) 
{

	switch (row_number) {
		case 1:
			r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
			r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
			r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
			break;

		case 2:
			r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
			r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
			r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
			
			r [3] = a[3]*b[0] + a[4]*b[3] + a[5]*b[6];
			r [4] = a[3]*b[1] + a[4]*b[4] + a[5]*b[7];
			r [5] = a[3]*b[2] + a[4]*b[5] + a[5]*b[8];
			break;

		case 3:
			r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
			r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
			r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
			
			r [3] = a[3]*b[0] + a[4]*b[3] + a[5]*b[6];
			r [4] = a[3]*b[1] + a[4]*b[4] + a[5]*b[7];
			r [5] = a[3]*b[2] + a[4]*b[5] + a[5]*b[8];
			
			r [6] = a[6]*b[0] + a[7]*b[3] + a[8]*b[6];
			r [7] = a[6]*b[1] + a[7]*b[4] + a[8]*b[7];
			r [8] = a[6]*b[2] + a[7]*b[5] + a[8]*b[8];
			break;

		case 4:
			r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
			r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
			r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
			
			r [3] = a[3]*b[0] + a[4]*b[3] + a[5]*b[6];
			r [4] = a[3]*b[1] + a[4]*b[4] + a[5]*b[7];
			r [5] = a[3]*b[2] + a[4]*b[5] + a[5]*b[8];
			
			r [6] = a[6]*b[0] + a[7]*b[3] + a[8]*b[6];
			r [7] = a[6]*b[1] + a[7]*b[4] + a[8]*b[7];
			r [8] = a[6]*b[2] + a[7]*b[5] + a[8]*b[8];

			r [9] = a[9]*b[0] + a[10]*b[3] + a[11]*b[6];
			r [10]= a[9]*b[1] + a[10]*b[4] + a[11]*b[7];
			r [11]= a[9]*b[2] + a[10]*b[5] + a[11]*b[8];
			break;

		default: 
			throw " meanwhile multiplication_matrixes_rowx3_by_3x3() "
				"does not handle with row number more then 4 ";
			break;
	
	}

}

void  Geometry_util::multiplication_row_by_3x3 ( 
	const double	a[3],
	const double	b[9], 
	double			r[3] ) {

		r [0] = a[0]*b[0] + a[1]*b[3] + a[2]*b[6];
		r [1] = a[0]*b[1] + a[1]*b[4] + a[2]*b[7];
		r [2] = a[0]*b[2] + a[1]*b[5] + a[2]*b[8];
}


void  Geometry_util::make_rotation_matrix_by_euler_angles(	
	const double Ph,
	const double Ks,
	const double Te,
	double rotation_matrix [9]  ) {

	double cos_Ks =		cos(Ks );
	double sin_Ks =		sin(Ks ); 
	double cos_Ph =		cos(Ph );
	double sin_Ph =		sin(Ph );
	double cos_Te =		cos(Te );
	double sin_Te =		sin(Te);
   
	rotation_matrix [0] =	cos_Ks *cos_Ph  - sin_Ks *cos_Te *sin_Ph;
	rotation_matrix [1] =	sin_Ks *cos_Ph  + cos_Ks *cos_Te *sin_Ph ;;
	rotation_matrix [2] =	sin_Te *sin_Ph ;
	rotation_matrix [3] =  -cos_Ks *sin_Ph -sin_Ks *cos_Te *cos_Ph ;
	rotation_matrix [4] =  -sin_Ks *sin_Ph +cos_Ks *cos_Te *cos_Ph ;;
	rotation_matrix [5] =	sin_Te *cos_Ph ;
	rotation_matrix [6] =	sin_Ks *sin_Te ;
	rotation_matrix [7] =  -cos_Ks *sin_Te ;
	rotation_matrix [8] =	cos_Te ;
}


double Geometry_util::diheral_by_four_poins (double p1[3],double p2[3] ,double p3[3],double p4[3] ) 
{

	double   A[3],B[3],C[3];
	substract_coordinates ( p2,p1,A) ;
	substract_coordinates ( p3,p2,B) ;
	substract_coordinates ( p4,p3,C) ;
	
	double  AxB[3],BxC[3];
	vector_product (A,B,AxB);
	vector_product (B,C,BxC);


//	double CosAngle = �os_by_vectors( AxB , BxC );
	double CosAngle = cos_by_vectors (AxB,BxC); // �os_by_vectors( AxB , BxC );
	
	double M[9]; 
	M[0] = A[0];	M[1] = A[1];	M[2] = A[2];
	M[3] = B[0];	M[4] = B[1];	M[5] = B[2];
	M[6] = C[0];	M[7] = C[1];	M[8] = C[2];

	double Determinant = determinant_3x3 ( M );

	return ( Determinant > 0) ?  acos (CosAngle) : - acos (CosAngle);
}

void	Geometry_util::substract_coordinates ( const double p_2[3] ,const double p_1[3], double r[3] ) 
{	
	r[0] = p_2[0] - p_1[0];	
	r[1] = p_2[1] - p_1[1];	
	r[2] = p_2[2] - p_1[2];
}
void	Geometry_util::vector_product (const double A[3],const double B[3],double AxB[3]) 
{
	AxB[0] = A[1]*B[2]-A[2]*B[1]	 ;
	AxB[1] = A[2]*B[0]-A[0]*B[2]	 ;
	AxB[2] = A[0]*B[1]-A[1]*B[0]	 ;
}

double Geometry_util::cos_by_vectors (const double l[3],const double m[3] ) 
{
	double denominator = sqrt(	
			(l[0]*l[0] + l[1]*l[1] + l[2]*l[2]) * (m[0]*m[0] + m[1]*m[1] + m[2]*m[2]));
	return ( epsilon_float() <   denominator ) ? (l[0]*m[0]+l[1]*m[1]+l[2]*m[2])/denominator : 0;

}

double Geometry_util::determinant_3x3 ( const double M [9] ) {	
	return (
		M[0]*M[4]*M[8]	+	M[3]*M[7]*M[2]		+	M[1]*M[5]*M[6]  - 
	   -M[6]*M[4]*M[2]	-	M[3]*M[1]*M[8]		-	M[7]*M[5]*M[0] ) ;

	
}
