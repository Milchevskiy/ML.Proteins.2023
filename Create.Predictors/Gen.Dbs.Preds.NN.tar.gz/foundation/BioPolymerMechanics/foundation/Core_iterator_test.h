#ifndef CORE_ITERATOR_TEST_H
#define CORE_ITERATOR_TEST_H

#include "../../Simple_test.h"

class  Core_iterator_test: public Simple_test
{
public:
	~Core_iterator_test();
    
    void run()
    {
		first_validity_test ();
	}
	void first_validity_test ();
};

#endif

