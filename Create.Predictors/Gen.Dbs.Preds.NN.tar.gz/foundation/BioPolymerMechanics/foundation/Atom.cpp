#include "Core_attributes.h"
#include "Atom.h"
 
Atom::	Atom (  int    zhorov_atom_index, 
                const  std::string & element_name, 
                const  std::string & pdb_atom_name, 
                const  std::string & zhorov_atom_name, 
                int    residue_index, 
                const  std::string & residue_name, 
                double bond_length, 
                double charge ) :
//	neighbors_ (0),
	core_attributes_ (0)

{
	zhorov_atom_index_	= zhorov_atom_index;
	element_name_		= element_name;
	pdb_atom_name_		= pdb_atom_name;
	zhorov_atom_name_	= zhorov_atom_name;
	residue_index_		= residue_index;
	residue_name_		= residue_name;
	bond_length_		= bond_length;
	charge_		    	= charge;
	// FIX: it would be very nice to check all included values by comparing them to set of possible values
}

Atom::	Atom (  ) :
	core_attributes_ (0)
{

}
Atom::	~Atom ( ) 
{
	if ( core_attributes_ )		
		delete [] core_attributes_;
}

void    Atom::	add_neighbor   ( Atom * atom ) 
{
	    neighbors_.push_back( atom );
}
void	Atom::	remove_neighbor( const int index )
{
//fix
}
void	Atom::	change_neighbor( Atom * old_neighbor, Atom *  new_neighbor )
{
		int number = number_of_neighbors(); 

		for (int ii=0; ii< number ; ii++ ) {
			if ( neighbors_[ii] ==  old_neighbor)
			{
				neighbors_[ii] =  new_neighbor ;
				return;
			}
	}
}

void Atom::set_vector_model	( const std::vector < double > & vector_model )
{
	core_attributes_->set_vector_model(vector_model);
}
void Atom::set_rotation_matrix( const std::vector < double > & rotation_matrix)
{
	core_attributes_->set_rotation_matrix(rotation_matrix);
}
void Atom::set_dihedral		( const double dihedral)
{
	core_attributes_->set_dihedral(dihedral);
}

void Atom::get_ray	(const int i, double * ray) const
{
	core_attributes_->get_ray(i,ray);
}

double	Atom::dihedral	() const 
{ 
	return core_attributes_->dihedral(); 
}

void Atom:: init_core_attributes ()
{
	core_attributes_ = new Core_attributes;
}
Atom * 	Atom:: 	get_neighbors		(const int index ) const 
{
	int number = number_of_neighbors();

	if (index >=0 && index < number )
		return neighbors_[index];
	else 
		return 0;
}
bool Atom:: is_core_atom () const
{
	return  (  core_attributes_ != 0 );
}



int Atom::
ray_serial_number() const 
{
    int ray_serial_number = -1;
    Atom *  incoming_atom = get_neighbors(0) ;

    for (int jj=0; jj< incoming_atom->number_of_neighbors(); jj++ ) 
    {
        if ( incoming_atom->get_neighbors(jj)->get_pdb_atom_name() == get_pdb_atom_name() ) 
        {
            ray_serial_number = jj;
            break;
        }
    }
/*    
    ENSURE ("If incoming atom is terminal then "
            "ray serial number must be zerro",
        incoming_atom.is_core_atom() 
        ? ray_serial_number >= 1 
        : ray_serial_number == 0 );
*/
    return  ray_serial_number;
}
