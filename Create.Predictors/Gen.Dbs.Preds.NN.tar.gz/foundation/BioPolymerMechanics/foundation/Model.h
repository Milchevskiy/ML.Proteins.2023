//#pragma warning( disable : 4786 )

#ifndef MODEL_H
#define MODEL_H

#include <string>
#include <vector>

class Atom;

using namespace std;

// auxiliary class for class Model
class Coordinate
{
public:
	Coordinate () {} ;
	Coordinate (const double x,const double y,const double z)  { coord_vector_.resize(3); coord_vector_[0] = x; coord_vector_[1] = y; coord_vector_[2] = z;   }
	double get_x() const { return coord_vector_[0]; }
	double get_y() const { return coord_vector_[1]; }
	double get_z() const { return coord_vector_[2]; }
private:
	std::vector < double > coord_vector_;
};


class Model
{
public:

	Model () {};
	~Model () {};


	void  load		( const std::string & source_file_name );
	void  save_as	( const std::string & file_name );


	void save_own (const std::string &filename);
	void calc_cartesain_coordinates( Atom * initial_atom );
	void calc_cartesain_coordinates( );// ������ ���� � ������ ��������� � ���


	std::vector < std::vector < std::string > >  get_sequence () const { return sequence_; }

// only for checkout. another time - private function
	void new_aminoacid(
		const string & residue_name,
		vector < Atom * > & all_atoms,
		vector < Atom * > & core_atoms);
// only for checkout. another time - private function
	void  join_aminoacid(
		const string & residue_name,
		bool first_residue_status ) ;

// for Core_iterator_test  only
	std::vector < Atom * > get_core_atoms  ()const { return core_atoms_;}

	vector < Atom * > get_backbone_set () const {	return backbone_set_;}


	//vector <double> get_continuous_phi_psi ();

	vector <double> get_phi_set () ;
	vector <double> get_psi_set () ;
	vector <double> get_ome_set () ;

	void set_phi_set (const vector <double> & dihedrals) ;
	void set_psi_set (const vector <double> & dihedrals) ;
	void set_ome_set (const vector <double> & dihedrals) ;


	void set_phi (const int position_in_sequence, const double Phi);
	void set_psi (const int position_in_sequence, const double Psi);
	void set_ome (const int position_in_sequence, const double Ome);



	void init_phi_psi_owega_backbone_set ();

// ���������� ���� ������� ����
	Atom * backbone_set (const unsigned num) {return backbone_set_[num]; }

	Atom *  phi_atom_set (const unsigned num) {return phi_atom_set_[num]; };
	Atom *  psi_atom_set (const unsigned num) {return psi_atom_set_ [num]; };
	Atom *  ome_atom_set (const unsigned num) {return ome_atom_set_ [num]; };

	int		seqlen () const { return  sequence_.size() ; }

	void  assign_phi_psi_ome_by_cont_torsion_set(
		vector < double >  & cont_torsion_set,
		vector < double >  & phi_set,
		vector < double >  & psi_set,
		vector < double >  & ome_set);


	void fill_up_main_chain_coordinates(double *chain_coord);

// only for debug
//	vector < Atom * > get_core_atoms () const { return core_atoms_;}

private:

	std::vector < Atom * > strand_origin_;
	std::vector < Atom * > all_atoms_;
	std::vector < Atom * > core_atoms_;


	vector < Atom * > phi_atom_set_;
	vector < Atom * > psi_atom_set_;
	vector < Atom * > ome_atom_set_;

	vector < Atom * > backbone_set_;


	std::vector < std::vector < std::string > > sequence_;

/*
	void new_aminoacid(
		const string & residue_name,
		vector < Atom * > & all_atoms,
		vector < Atom * > & core_atoms);
*/




};

Model * init_model(const int len_seq);  // ���������� ���� �� ������ Gly len_seq ���� � � ������ ���������.

void refresh_cartesian_by_dihedral (
	Model *model,
	vector <double> & phi_set,
	vector <double> & psi_set,
	vector <double> & ome_set,
	double *chain_coord);


double * get_main_chain_coordinates(
	Model *model);

#endif
