#pragma warning( disable : 4786 )
#pragma warning( disable : 4503 )

#include "Atom_test.h"
#include "Atom.h"

//#include <cassert>
#include <iostream>

using namespace std;

Atom_test::~Atom_test()
{
	cout << "Atom_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Atom_test::constructor_test ()
{

	int zhorov_atom_index	= 7;
	string element_name		= "C";
	string pdb_atom_name	= "CB";
	string zhorov_atom_name	= "CP";
	int residue_index 		= 1;
	string residue_name		= "VAL";
	double bond_length		= 1.530;
	double charge    		= -0.030;

	Atom atom(  zhorov_atom_index, 
                element_name, 
                pdb_atom_name, 
                zhorov_atom_name, 
                residue_index, 
                residue_name, 
                bond_length, 
                charge );

//	test( "neighbors_			were not defined yet",	atom.get_neighbors().size()	== 0	);
//	test( "core_attributes_		were not defined yet", atom.get_Core_attributes() == 0	);

//	test( "charge was setted to value -0.030", atom.get_charge() == -0.030	);

}

