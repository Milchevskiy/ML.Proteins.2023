#ifndef AMINOACID_NAME_TRANSLATOR_H
#define AMINOACID_NAME_TRANSLATOR_H

#include <map> 
#include <string> 

using namespace std;

class Aminoacid_name_translator
{
public:
	Aminoacid_name_translator (){};

    

	std::string translate( const string & name );

private:
    std::map < std::string, std::string >  map_1_3_;
    std::map < std::string, std::string >  map_3_3_;

   // Aminoacid_name_translator( const Aminoacid_name_translator_impl & );
     Aminoacid_name_translator & operator =
       (  Aminoacid_name_translator & );
};

Aminoacid_name_translator  aminoacid_name();
#endif 