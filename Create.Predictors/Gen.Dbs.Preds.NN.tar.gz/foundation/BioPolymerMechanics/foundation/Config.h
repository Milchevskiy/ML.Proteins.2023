#ifndef CONFIG_H
#define CONFIG_H

const char DIR_parameters   [] = "..\\Parameters\\";
const char DIR_tests        [] = "DIR_tests//";

//const char DIR_tests_rubbish[] = "..\\TestsRubbish\\";
const char DIR_20aminoacids [] = "Repository\\20Aminoacids\\";
//const char DIR_AMBER94      [] = "..\\Parameters\\AMBER94\\";

#endif//CONFIG_H