//#pragma warning( disable : 4786 )

#ifndef CORE_ITERATOR_H
#define CORE_ITERATOR_H

#include <stack> 

class Atom;

class Core_iterator 
{
public:
    Core_iterator		( Atom * );
    void                 next    ();
    Atom *			     current ();
    bool                 has_next() const;
    //const Zhorov_atom &                     current () const;

private:
    std::stack < Atom *  >	stack_;
	Atom *					current_atom_;
    
	void find_neigbors();
};

#endif

