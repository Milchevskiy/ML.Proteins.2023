
#ifndef AMINOACID_NAME_TRANSLATOR_IMPL_H
#define AMINOACID_NAME_TRANSLATOR_IMPL_H

#ifndef AMINOACID_NAME_TRANSLATOR_H
#include "Aminoacid_name_translator.h"
#endif

#ifndef DBC_H
#include "DbC.h"
#endif

#ifndef TEXT_H
#include "Text.h"
#endif

#include <map> 

class Aminoacid_name_translator_impl
: public Aminoacid_name_translator, protected DbC
{
public:
    friend Aminoacid_name_translator & aminoacid_name();

    virtual const Text & translate( const Text & name );

private:
    Aminoacid_name_translator_impl();
    std::map < Text, Text >  map_1_3_;
    std::map < Text, Text >  map_3_3_;

    Aminoacid_name_translator_impl( const Aminoacid_name_translator_impl & );
    const Aminoacid_name_translator_impl & operator =
       ( const Aminoacid_name_translator_impl & );
};
#endif //AMINOACID_NAME_TRANSLATOR_IMPL_H