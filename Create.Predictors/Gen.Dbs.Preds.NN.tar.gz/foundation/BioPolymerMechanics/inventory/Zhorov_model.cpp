
#include "Zhorov_model.h"

#include "Bond.h"
#include "Geometry_util.h"
#include "Zhorov_core_iterator.h"
#include "Pdb_attributes.h"

#include <fstream>

void Zhorov_model::save_own(const Text & filename)
{
	using namespace std;
	int i;

	ofstream out( filename.c_str() );
	int number_of_atoms = all_atoms_.size();
	out << number_of_atoms << endl;

	
	 for( i=0;  i<all_atoms_.size();  ++i )
	 {
		out << all_atoms_[i].pdb().number() + 1 << " "; // fix
		out << all_atoms_[i].element().c_str() << " ";
		out << all_atoms_[i].pdb().name().c_str() << " ";
		out << all_atoms_[i].zhorov_atom_name().c_str() << " ";
		out << all_atoms_[i].pdb().residue_number() << " ";
		out << all_atoms_[i].pdb().residue_name().c_str() << " ";

		out << all_atoms_[i].neighbor(0).pdb().number() + 1 << " "; //fix "+ 1"

		if ( all_atoms_[i].number_of_neighbors() > 1 )
			out << all_atoms_[i].neighbor(1).pdb().number() + 1 << " "; //fix "+ 1"
		else 
			out  << "0 "; 

		if ( all_atoms_[i].number_of_neighbors() > 2 )
			out << all_atoms_[i].neighbor(2).pdb().number() + 1 << " "; //fix "+ 1"
		else 
			out  << "0 "; 

		if ( all_atoms_[i].number_of_neighbors() > 3 )
			out << all_atoms_[i].neighbor(3).pdb().number() + 1 << " "; //fix "+ 1"
		else 
			out  << "0 "; 


		out << all_atoms_[i].length() << " ";
		 //out << all_atoms_.current().charge() << endl; //fix
		out << "0"<< endl;

	}

	out << "VECTOR MODELS ";

    int number_of_core_atoms = core_atoms_.size();
	out << number_of_core_atoms << endl;

	for( i=0;  i<core_atoms_.size();  ++i )
	{
		out << core_atoms_[i].pdb().number() + 1 << " "; // fix
		out << core_atoms_[i].pdb().name().c_str() << " ";

		int number_of_neighbors = core_atoms_[i].number_of_neighbors();
		
		for (int ii=1; ii<number_of_neighbors ;++ii) 
		{
			double ray[3];
			core_atoms_[i].core().get_ray(ii,ray);
			out << ray[0] << " " << ray[1] << " "  << ray[2]<< "    " ;

		}
		out << endl;
	}
	out << "DIHEDRAL ANGLES ";
	out << number_of_core_atoms << endl;

	for( i=0;  i<core_atoms_.size();  ++i )
	{
		out << core_atoms_[i].pdb().number() + 1 << " "; // fix
		out << core_atoms_[i].pdb().name().c_str() << " ";
		out << core_atoms_[i].core().dihedral() << " ";

		out << "//* * * *" << endl;
	}
}
Atom & Zhorov_model::prototype()
{
    return model().prototype();
}//*/

void Zhorov_model::
calc_cartesain_coordinates( Zhorov_atom & initial_atom )
{
    REQUIRE("initial_atom.is_core_atom()", initial_atom.is_core_atom() );
    using namespace Geometry_util;

    double transform_matrix[ 9 ],	current_transform_matrix[ 9 ];

    double x = initial_atom.x();
    double y = initial_atom.y();
    double z = initial_atom.z();
    memcpy ( transform_matrix, initial_atom.core().rotation_matrix(),
    9 * sizeof ( double ) );

    CHECK( "True transform matrix for 1-st atom", 
        fabs ( 1 - determinant_3x3( transform_matrix ) ) < epsilon_float() ) ;

    // setting cartesion coordinates for neighbors of the FIRST atom
    int number_of_neighbors_first = initial_atom.number_of_neighbors();
    for ( int  kk = 0 ; kk < number_of_neighbors_first; kk++ )
    {
        double ray[ 3 ],				oriented_ray[ 3 ];

        initial_atom.core().get_ray( kk, ray );
        multiplication_row_by_3x3
        ( ray, transform_matrix, oriented_ray );

        Zhorov_atom & neighbor_atom = initial_atom.neighbor( kk );
        double length = neighbor_atom.length();

        neighbor_atom.set_x ( x + oriented_ray[ 0 ] * length );
        neighbor_atom.set_y ( y + oriented_ray[ 1 ] * length );
        neighbor_atom.set_z ( z + oriented_ray[ 2 ] * length );
    }

    Zhorov_core_iterator	it( initial_atom );
    while ( it.has_next() )
    {
        it.next();
        Zhorov_atom & current_atom = it.current();
        CHECK( "current_atom.is_core_atom()", 
            current_atom.is_core_atom());            //fix error !!!!!!!!!!

        CHECK( "Incoming atom should not terminal atom", 
            current_atom.neighbor( 0 ).is_core_atom() );

        Zhorov_atom & incoming_atom = current_atom.neighbor( 0 );
        CHECK( "incoming_atom.is_core_atom()", 
            incoming_atom.is_core_atom() );

        double ray[ 3 ];
        int ray_serial_number = current_atom.ray_serial_number() ;
        incoming_atom.core().get_ray( ray_serial_number, ray );

        double first_around_axis_X	=	- current_atom.core().dihedral();
        double around_axis_Z		=	- acos ( ray[ 0 ] );
        double second_around_axis_X;

        if( ray_serial_number == 1 )
        {
            make_rotation_matrix_X_Z( first_around_axis_X,
            around_axis_Z ,
            current_transform_matrix );
        }
        else
        {
			double zerro = 0.0;
            normalize_vector ( zerro , ray[ 1 ], ray[ 2 ] );
			CHECK ( "",fabs(zerro) < epsilon_float() );
			CHECK ( "",fabs( ray[1]*ray[1] + ray[2]*ray[2] -1 ) < epsilon_float() );



            second_around_axis_X =
            solve_sin_cos_indeterminacy( -ray[ 2 ], ray[ 1 ] ) ;

            make_rotation_matrix_X_Z_X(	first_around_axis_X,
            around_axis_Z ,
            second_around_axis_X,
            current_transform_matrix );
        }

        multiplication_matrixes_3x3_by_3x3( current_transform_matrix,
        incoming_atom.core().rotation_matrix(),
        transform_matrix );


        current_atom.core().set_rotation_matrix ( transform_matrix ) ;

        double current_x = current_atom.x();
        double current_y = current_atom.y();
        double current_z = current_atom.z();

         int number_of_neighbors = current_atom.number_of_neighbors(); // why
        // without () ???
        for ( int  kk = 1 ; kk < number_of_neighbors; kk++ )
        {
            double ray[ 3 ],				oriented_ray[ 3 ];
            current_atom.core().get_ray( kk, ray );
            multiplication_row_by_3x3
               (	ray, transform_matrix, oriented_ray );

            Zhorov_atom & neighbor_atom = current_atom.neighbor( kk );
            double length = neighbor_atom.length();

            neighbor_atom.set_x ( current_x + oriented_ray[ 0 ] * length );
            neighbor_atom.set_y ( current_y + oriented_ray[ 1 ] * length );
            neighbor_atom.set_z ( current_z + oriented_ray[ 2 ] * length );
        }
    }
}
Array_of< Chain > * Zhorov_model::
create_chains_collection()
{
    Array_of_dynamic_objects< Chain > * chains;

    return chains;
}

void Zhorov_model::adjust_structure_by_template()
{
    // get list of chains
    // for each chain
        // get list of residue names
        // build homologous peptide in auxiliary Zhorov_ model
        // assign binding from auxiliary Zhorov_ model to this model
        // remove the auxiliary Zhorov_ model
   /*Janitor< Collection_of< Chain > > chain( create_chains_collection() );

   for (chain().first();  chain().is_valid();  chain().next())
   {
        Collection_of< Text > residue_name = chain().current().residue_name();
        Default_molecular_model base_model;  // fix remove
        Zhorov_model  model( base_model );
        Zhorov_amino_acid_builder amino_acid_builder( model );

        for (residue_name.first();residue_name.is_vaild(); residue_name.next() )
        {
            amino_acid_builder.add_aminoacid(residue_name.current());
        }

        // assign binding from auxiliary Zhorov_ model to this model
   }//*/
    
}
Array_of < Zhorov_atom > & Zhorov_model::
core_atoms()
{
    return core_atoms_;
}

Array_of < Zhorov_atom > & Zhorov_model::
atoms()
{
    return all_atoms_;
}

Zhorov_model::
Zhorov_model( MM_model & model )
: model_( model )
{
    //fix  convert atoms to zhorov_atoms
}

Zhorov_atom & Zhorov_model::
new_terminal_atom( Element element )
{
/*    Zhorov_atom * new_atom = new Zhorov_atom( element );
    model().add_atom( new_atom );
    all_atoms_.push_back( * new_atom );
    return *new_atom;
//*/
    Atom *        new_atom    = prototype().clone();
    Zhorov_atom * zhorov_atom = dynamic_cast< Zhorov_atom * >( new_atom );
    CHECK("New atom is Zhorov atom",  zhorov_atom !=0  );
    zhorov_atom->set_element( element );
    model().add_atom( zhorov_atom );
    all_atoms_.push_back( *zhorov_atom );
    return *zhorov_atom;//*/
}

Zhorov_atom & Zhorov_model::
new_core_atom( Element element )
{
/*    Zhorov_atom * new_atom = new Zhorov_atom( element );
    model().add_atom( new_atom );
    new_atom->make_core_atom( new Zhorov_core_attributes() );
    all_atoms_.push_back( * new_atom );
    core_atoms_.push_back( * new_atom );
    return *new_atom;
//*/
    Atom *        new_atom    = prototype().clone();
    Zhorov_atom * zhorov_atom = dynamic_cast< Zhorov_atom * >( new_atom );
    CHECK("New atom is Zhorov atom",  zhorov_atom !=0  );
    zhorov_atom->set_element( element );
    model().add_atom( zhorov_atom );
    zhorov_atom->make_core_atom( new Zhorov_core_attributes() );
    all_atoms_.push_back( * zhorov_atom );
    core_atoms_.push_back( * zhorov_atom );
    return *zhorov_atom;
}

MM_model & Zhorov_model::
model()
{
    return model_;
}

void Zhorov_model::clear() { model().clear(); }

void Zhorov_model::add( const Text & filename )
{
    model().add( filename );
    adjust_structure_by_template();
//    adjust_pdb_model();
}

void Zhorov_model::load( const Text & filename )
{
    model().load( filename );
    adjust_structure_by_template();
//    adjust_pdb_model();
}

void Zhorov_model::save() { model().save(); }

void Zhorov_model::save_as( const Text & file_name )
{
    model().save_as( file_name );
}

void Zhorov_model::adjust_pdb_model()
{
    //create residues
        //setup names
        //setup bonds
///    Zhorov_natural20_aminoacid_iterator it( model.atoms() );

    //Array_of_referesces< Zhorov_natural20_aminoacid > residues;

    /*int current_residue_number =
        model().atoms()[0].aspect().pdb_atom()().residue_number();
*/
 /*   for( int i=0;  i<model.atoms().size();  ++i )
    {
  //      Array_of_references< Atom > residue_atoms;
        Zhorov_residue 
        int  current_residue_number;
        while(  current_residue_number ==
                model.atoms()[i].aspect().pdb_atom()().residue_number() )
        {
            residue_atoms.push_back( model.atoms()[i] );
            ++i;
        }
        //Zhorov_natural20_aminoacid residue( residue_atoms );
        //residues.push_back( residue );
    }
    //adjust_bonds_between_residues( residues );
//*/
    //for all atoms
    //adjust_pdb_lengths();

    //for core
    //adjust_pdb_core();//*/
/*    adjust_pdb_vector model();
    adjust_pdb_torsions();
    adjust_pdb_rotation_matrixes();*/
}
