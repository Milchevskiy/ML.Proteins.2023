
#ifndef ZHOROV_CORE_ATTRIBUTES_H
#define ZHOROV_CORE_ATTRIBUTES_H

#ifndef ARRAY_H
#include "Array.h"
#endif

#ifndef ZHOROV_ATOM_H
#include "Zhorov_atom.h"
#endif

#ifndef DBC_H
#include "DbC.h"
#endif

class Text;
class ID;

class Zhorov_core_attributes : protected DbC
{
public:
    /*Zhorov_core_attributes( Atom & current_atom,
    int zhorov_atom_index,
    const Text & element_name,
    const Text & pdb_atom_name,
    const Text & zhorov_atom_name,
    int residue_index,
    const Text & residue_name,
    double bond_length,
    double charge );//*/

    Zhorov_core_attributes();
    virtual double dihedral() { return dihedral_ ; }

/*    virtual double theta();

    virtual double delta();
*/

    virtual void set_dihedral( double dihedral ) { dihedral_ = dihedral; }

/*  virtual void set_theta(double);

    virtual void set_delta(double );
*/

    //    virtual void                    set_vector_model(const Array< double > & );
    //    void                            ray(int i, double * ray);
    //    virtual Zhorov_terminal_atom & neighbor(int i);

    virtual void set_vector_model( const Array < double > & );
    virtual const Array < double > &
    vector_model() const { return vector_model_ ; };

    void get_ray( int i, double * ray ) const;

    double * rotation_matrix();
    void set_rotation_matrix( double [ 9 ] );
    virtual bool invariant() const;


private:
    Array < double >                vector_model_;
    double                          rotation_matrix_ [ 9 ];
    double                          dihedral_;
};

#endif //ZHOROV_CORE_ATTRIBUTES_H

