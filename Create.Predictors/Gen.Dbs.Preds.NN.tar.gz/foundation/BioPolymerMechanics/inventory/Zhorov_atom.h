#ifndef ZHOROV_ATOM_H
#define ZHOROV_ATOM_H

#ifndef MM_ATOM_H
#include "MM_atom.h"
#endif

#ifndef DBC_H
#include "DbC.h"
#endif

#ifndef ARRAY_OF_REFERENCES_H
#include "Array_of_references.h"
#endif

#ifndef ZHOROV_CORE_ATTRIBUTES_H
#include "Zhorov_core_attributes.h"
#endif

#ifndef JANITOR_H
#include "Janitor.h"
#endif

class Text;
class Zhorov_core_attributes;

class Zhorov_atom :  public MM_atom
{
    double length_;
    Text zhorov_atom_name_	;
    Array_of_references < Zhorov_atom > neighbors_;

    Janitor< Zhorov_core_attributes >   core_attributes_;
    //	const Zhorov_terminal_atom & operator=(const Zhorov_terminal_atom &Right);

public:
    virtual ~Zhorov_atom();
    virtual void                    set_element( Element e );
    Zhorov_core_attributes & core()               { return core_attributes_(); }
    bool                     is_core_atom() const { return core_attributes_.is_valid(); }
    void                     make_core_atom( Zhorov_core_attributes * adoptee );
    void                     make_terminal_atom();

    Zhorov_atom(    int zhorov_atom_index, 
                    const Text & element_name, 
                    const Text & pdb_atom_name, 
                    const Text & zhorov_atom_name, 
                    int          residue_index, 
                    const Text & residue_name, 
                    double       bond_length, 
                    double       charge );

    Zhorov_atom ( const Element & element );

    virtual double                  length() { return length_; }
    const Text &                    zhorov_atom_name(){ return zhorov_atom_name_; }
    virtual void                    set_zhorov_atom_index( int );
    virtual void                    set_zhorov_atom_name( const Text & ); 
    virtual void                    set_length          ( double length );

    virtual int                     number_of_neighbors () const
    { return neighbors_.size(); }
    
    virtual Zhorov_atom &           neighbor( int index )
    { return neighbors_[ index ]; }
    
    virtual const Zhorov_atom &     neighbor( int index ) const
    { return neighbors_[ index ]; }

    virtual void                    add_neighbor( Zhorov_atom
    & atom );
    virtual void                    remove_neighbor( int index );
    virtual void                    change_neighbor( Zhorov_atom &
    old_neighbor, Zhorov_atom & new_neighbor );
    int ray_serial_number() const ;
    bool is_branch_origin () const ;
    virtual Atom *                  clone();
protected:
    void                            handle_clone( Zhorov_atom * );
};

#endif //ZHOROV_ATOM_H




