#ifndef ZHOROV_VIEW_H
#define ZHOROV_VIEW_H

#ifndef INVENTOR_VIEW_H
#include "Inventor_view.h"
#endif

#ifndef VIEW_H
#include "View.h"
#endif

#ifndef ARRAY_OF_DYNAMIC_OBJECTS_H
#include "Array_of_dynamic_objects.h"
#endif

class SoSeparator;
class SoQtRenderArea;
class MM_model;

//namespace MM
//{


class Zhorov_view : public Inventor_view
{

public:
    Zhorov_view(    MM_model &       model,
                    SoSeparator &    scene,
                    SoQtRenderArea & render_area );
    //fix remove
};

//}//MolMeccano

#endif //ZHOROV_VIEW_H


