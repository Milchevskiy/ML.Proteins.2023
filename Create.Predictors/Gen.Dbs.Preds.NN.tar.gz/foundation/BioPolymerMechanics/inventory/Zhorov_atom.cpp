
#include "Zhorov_atom.h"
 
#include "Id.h"
#include "Pdb_attributes.h"
#include "Hyperchem_attributes.h"
void Zhorov_atom::
set_element( Element e )
{
    MM_atom::set_element( e );

    if( is_core_atom() )
        make_terminal_atom();
}
Atom * Zhorov_atom::clone()
{
    Zhorov_atom * new_atom = new Zhorov_atom( element() );
    handle_clone( new_atom );
    return new_atom;
}

void Zhorov_atom::
handle_clone( Zhorov_atom * new_atom )
{
    // Handle precursor.
    MM_atom::handle_clone( new_atom );

    new_atom->set_length          ( this->length() );
    new_atom->set_zhorov_atom_name( this->zhorov_atom_name() );  

    //Clone is a terminal atom and has not core attributes.
}

Zhorov_atom::~Zhorov_atom(){}

bool Zhorov_atom::
is_branch_origin () const 
{
    return  ray_serial_number() != 1;
}

int Zhorov_atom::
ray_serial_number() const 
{
    int ray_serial_number = -1;
    const Zhorov_atom & incoming_atom = neighbor(0) ;

    for (int jj=0; jj< incoming_atom.number_of_neighbors(); jj++ ) 
    {
        if ( incoming_atom.neighbor(jj) == *this ) 
        {
            ray_serial_number = jj;
            break;
        }
    }
    
    ENSURE ("If incoming atom is terminal then "
            "ray serial number must be zerro",
        incoming_atom.is_core_atom() 
        ? ray_serial_number >= 1 
        : ray_serial_number == 0 );

    return  ray_serial_number;
}

void Zhorov_atom::
make_core_atom( Zhorov_core_attributes * adoptee )
{
    REQUIRE("This is a terminal atom", !core_attributes_.is_valid() );
    core_attributes_.adopt( adoptee );
    ENSURE ("This is a core atom",      core_attributes_.is_valid() );
}

void Zhorov_atom::
make_terminal_atom()
{
    REQUIRE("This is a core atom",      core_attributes_.is_valid() );
    core_attributes_.orphan();
    ENSURE ("This is a terminal atom", !core_attributes_.is_valid() );
}

void Zhorov_atom::
set_zhorov_atom_index( int )
{
    //FIX;
}

void Zhorov_atom::
set_zhorov_atom_name( const Text & zhorov_atom_name )
{
    zhorov_atom_name_ = zhorov_atom_name;
}

void Zhorov_atom::
set_length( double length )
{
    length_ = length;
}

Zhorov_atom::Zhorov_atom(   int zhorov_atom_index, 
                            const Text & element_name, 
                            const Text & pdb_atom_name, 
                            const Text & zhorov_atom_name, 
                            int residue_index, 
                            const Text & residue_name, 
                            double bond_length, 
                            double charge
                 // fix: may be extra field
                )
: MM_atom( Element( element_name.c_str() ) ),
//zhorov_atom_index_	(zhorov_atom_index), 
//element_name_ (element_name ),
//pdb_atom_name_		(pdb_atom_name ),
zhorov_atom_name_	(zhorov_atom_name),
//residue_index_		(residue_index_),
//residue_name_		(residue_name_),
length_				(bond_length)
//                double charge )
{
} 

void Zhorov_atom::
add_neighbor(Zhorov_atom & atom )
{
    neighbors_.push_back( atom );
    add_bound( atom );
}

void Zhorov_atom::
remove_neighbor( int index ) 
{
    int neighbors = number_of_neighbors();
    REQUIRE ( "Valid index", index < neighbors );

//    //fix remove_bound( neighbor(index) );
//    neighbors_.remove(index );
    //fix neighbor(index).destroy();

    ENSURE("Atom was removed", number_of_neighbors() == neighbors-1 );
}

void Zhorov_atom::
change_neighbor( Zhorov_atom & old_neighbor, Zhorov_atom & new_neighbor ) 
{

	int number = number_of_neighbors(); 

	/*Check*/ //Zhorov_terminal_atom & ttt = neighbors_[1];

    	for (int ii=0; ii< number ; ii++ ) {
		if ( &neighbors_[ii] == & old_neighbor)
		{
			remove_bound( old_neighbor );
			neighbors_.put( ii, new_neighbor );
			add_bound( new_neighbor );
			return;
		}
	}
         
	ENSURE("This point should not be reached", false);
}

Zhorov_atom::Zhorov_atom(const Element & element)
: MM_atom( element )
{
}
