
#ifndef ZHOROV_AMINO_ACID_BUILDER_H
#define ZHOROV_AMINO_ACID_BUILDER_H

#ifndef DBC_H
#include "DbC.h"
#endif

#ifndef REF_H
#include "Ref.h"
#endif

#ifndef ARRAY_OF_REFERENCES_H
#include "Array_of_references.h"
#endif

class Element;
class Text;
class Zhorov_atom;
class Zhorov_core_attributes;
class Zhorov_model;

template < class T >
class Array_of;

class Zhorov_amino_acid_builder :  protected DbC
{
    Zhorov_model &  							    model_;
    Ref < Zhorov_atom >					            joined_atom_;
    Array_of_references < Zhorov_atom >             zhorov_peptide_;


public:
    Zhorov_amino_acid_builder(Zhorov_model & model);

    virtual void        add_aminoacid( const Text & residue_name );
    virtual void        add_aminoacid( const Text & residue_name,
       const double Phi, const double Psi, const double Omeg );
    Zhorov_atom &                           new_core_atom    ( Element );
    Zhorov_atom &                           new_terminal_atom( Element );
    Array_of< Zhorov_atom > & 
                        peptide(){ return zhorov_peptide_; }

protected:
    Zhorov_model &  							    model() { return model_; }

private:
    void                new_aminoacid( const Text & residue_name,
                            Array_of_references< Zhorov_atom > &, 
                            Array_of_references< Zhorov_atom > &);

    virtual void        join ( Array_of < Zhorov_atom > & aminoacid );
private:
};

#endif //ZHOROV_AMINO_ACID_BUILDER_H
