
#ifndef AMINOACID_NAME_TRANSLATOR_H
#define AMINOACID_NAME_TRANSLATOR_H

class Text;
class Aminoacid_name_translator;

Aminoacid_name_translator & aminoacid_name();

class Aminoacid_name_translator
{
    
    
public:    
    virtual const Text & translate(const Text & name) =0;
};
#endif //AMINOACID_NAME_TRANSLATOR_H