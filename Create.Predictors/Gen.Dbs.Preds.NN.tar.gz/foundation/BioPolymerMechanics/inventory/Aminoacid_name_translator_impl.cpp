
#pragma warning( disable : 4786 )

#include "Aminoacid_name_translator_impl.h"
#include "Ref.h"

const Text & Aminoacid_name_translator_impl::translate( const Text & name )
{
    REQUIRE( "Correct name length", name.size() == 1 || name.size() == 3 );

    Ref < std::map < Text, Text > > map;
    Text key;
    for( int i=0;  i<name.size();  ++i )
        key += (char)toupper( name[i] );

    switch ( name.size() )
    {
        case 1 :
            map = map_1_3_;
            break;

        case 3 :
            map = map_3_3_;
            break;

        default :
            FLAW( "Wrong aminoacid name." );
    }

    const Text & result = map() [ key ];

    ENSURE( "Correct aminoacid name", name !=  "" && result.size() == 3 );
    return result;
}

Aminoacid_name_translator & aminoacid_name()
{
    static Aminoacid_name_translator_impl singleton;
    return singleton;
}

Aminoacid_name_translator_impl::Aminoacid_name_translator_impl()
{
    map_1_3_ [ Text( "A" ) ] =  Text( "Ala" );
    map_1_3_ [ Text( "R" ) ] =  Text( "Arg" );
    map_1_3_ [ Text( "N" ) ] =  Text( "Asn" );
    map_1_3_ [ Text( "D" ) ] =  Text( "Asp" );
    map_1_3_ [ Text( "V" ) ] =  Text( "Val" );
    map_1_3_ [ Text( "H" ) ] =  Text( "His" );
    map_1_3_ [ Text( "G" ) ] =  Text( "Gly" );
    map_1_3_ [ Text( "Q" ) ] =  Text( "Gln" );
    map_1_3_ [ Text( "E" ) ] =  Text( "Glu" );
    map_1_3_ [ Text( "I" ) ] =  Text( "Ile" );
    map_1_3_ [ Text( "L" ) ] =  Text( "Leu" );
    map_1_3_ [ Text( "K" ) ] =  Text( "Lys" );
    map_1_3_ [ Text( "M" ) ] =  Text( "Met" );
    map_1_3_ [ Text( "P" ) ] =  Text( "Pro" );
    map_1_3_ [ Text( "S" ) ] =  Text( "Ser" );
    map_1_3_ [ Text( "Y" ) ] =  Text( "Tyr" );
    map_1_3_ [ Text( "T" ) ] =  Text( "Thr" );
    map_1_3_ [ Text( "W" ) ] =  Text( "Trp" );
    map_1_3_ [ Text( "F" ) ] =  Text( "Phe" );
    map_1_3_ [ Text( "C" ) ] =  Text( "Cys" );
    map_1_3_ [ Text( "O" ) ] =  Text( "Hyp" );

    map_3_3_ [ Text( "ALA" ) ] =  Text( "Ala" );
    map_3_3_ [ Text( "ARG" ) ] =  Text( "Arg" );
    map_3_3_ [ Text( "ASN" ) ] =  Text( "Asn" );
    map_3_3_ [ Text( "ASP" ) ] =  Text( "Asp" );
    map_3_3_ [ Text( "VAL" ) ] =  Text( "Val" );
    map_3_3_ [ Text( "HIS" ) ] =  Text( "His" );
    map_3_3_ [ Text( "GLY" ) ] =  Text( "Gly" );
    map_3_3_ [ Text( "GLN" ) ] =  Text( "Gln" );
    map_3_3_ [ Text( "GLU" ) ] =  Text( "Glu" );
    map_3_3_ [ Text( "ILE" ) ] =  Text( "Ile" );
    map_3_3_ [ Text( "LEU" ) ] =  Text( "Leu" );
    map_3_3_ [ Text( "LYS" ) ] =  Text( "Lys" );
    map_3_3_ [ Text( "MET" ) ] =  Text( "Met" );
    map_3_3_ [ Text( "PRO" ) ] =  Text( "Pro" );
    map_3_3_ [ Text( "SER" ) ] =  Text( "Ser" );
    map_3_3_ [ Text( "TYR" ) ] =  Text( "Tyr" );
    map_3_3_ [ Text( "THR" ) ] =  Text( "Thr" );
    map_3_3_ [ Text( "TRP" ) ] =  Text( "Trp" );
    map_3_3_ [ Text( "PHE" ) ] =  Text( "Phe" );
    map_3_3_ [ Text( "CYS" ) ] =  Text( "Cys" );
    map_3_3_ [ Text( "HYP" ) ] =  Text( "Hyp" );

    ENSURE( "21 aminoacids",
        map_1_3_.size() == 21 && map_3_3_.size() == 21 );
}
