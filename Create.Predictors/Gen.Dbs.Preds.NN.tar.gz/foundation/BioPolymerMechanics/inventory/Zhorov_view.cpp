#include "Zhorov_view.h"

#include "Zhorov_inventor_atom.h"
#include "MM_model.h"
#include "Inventor_atom_attributes.h"
#include "Bond.h"

Zhorov_view::Zhorov_view( MM_model &        model,
                          SoSeparator &     scene,
                          SoQtRenderArea &  render_area )

:  Inventor_view( model, scene, render_area )
{
    Zhorov_inventor_atom & prototype =
        dynamic_cast< Zhorov_inventor_atom & >( model_.prototype() );

    prototype.add_view( *this );
}
