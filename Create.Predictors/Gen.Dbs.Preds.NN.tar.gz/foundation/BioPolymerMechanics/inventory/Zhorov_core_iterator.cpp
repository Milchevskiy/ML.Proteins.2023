
#include "Zhorov_core_iterator.h"

#include "Zhorov_core_attributes.h"

Zhorov_core_iterator::Zhorov_core_iterator( Zhorov_atom & initial_atom )
{
    REQUIRE("Initial atom is a core atom", initial_atom.is_core_atom() );
	current_atom_ = initial_atom;
    find_neigbors();
}

bool Zhorov_core_iterator::
has_next() const
{
    return ! stack_.empty();
}

const Zhorov_atom & Zhorov_core_iterator::
current () const
{
    ENSURE("Current atom is a core atom", current_atom_().is_core_atom() );
    return current_atom_();
}

Zhorov_atom & Zhorov_core_iterator::
current ()
{
    ENSURE("Current atom is a core atom", current_atom_().is_core_atom() );
    return current_atom_();
}

void Zhorov_core_iterator::
next    ()
{
    current_atom_ = stack_.top();
    stack_.pop();
    find_neigbors();
}

void Zhorov_core_iterator::
find_neigbors()
{
    int neighbor_size = current_atom_().number_of_neighbors();
    for (int ii=neighbor_size-1; ii>=1; --ii ) 
    {
        Zhorov_atom & neighbor = current_atom_().neighbor(ii);
        if (  neighbor.is_core_atom() )
            stack_.push( neighbor );
    }
}