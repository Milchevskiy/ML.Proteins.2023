
#ifndef ZHOROV_CORE_ITERATOR_H
#define ZHOROV_CORE_ITERATOR_H

#ifndef REF_H
#include <Ref.h>
#endif

#ifndef DBC_H
#include "DbC.h"
#endif

#include <stack> //fix

class Zhorov_atom;

class Zhorov_core_iterator : protected DbC
{
private:
    std::stack < Ref < Zhorov_atom > >      stack_;
    Ref < Zhorov_atom >                     current_atom_;

    void find_neigbors();

public:
    Zhorov_core_iterator( Zhorov_atom & );
    void                                    next    ();
    Zhorov_atom &                           current ();
    const Zhorov_atom &                     current () const;
    bool                                    has_next() const;
};

#endif //ZHOROV_CORE_ITERATOR_H


