
#ifndef ZHOROV_MODEL_H
#define ZHOROV_MODEL_H
class Atom;

#ifndef MM_MODEL_H
#include "MM_model.h"
#endif

#ifndef ARRAY_OF_HOOKS_H
#include "Array_of_hooks.h"
#endif

#ifndef DBC_H
#include "DbC.h"
#endif

#ifndef CHAIN_H
#include "Chain.h"
#endif

#ifndef ZHOROV_ATOM_H
#include "Zhorov_atom.h"
#endif
/*
#ifndef RESIDUE_H
#include "Residue.h"
#endif
//*/
class Zhorov_atom;
class Zhorov_core_attributes;
class Text;
class MM_model;
class Element;

//template < class T > class Collection_of;
template < class T > class Array_of;

class Zhorov_model :  protected DbC
{
    MM_model &                           model_;
    Array_of_hooks < Zhorov_atom >              core_atoms_;
    Array_of_hooks < Zhorov_atom >              all_atoms_;
  //  Array_of_dynamic_objects< Residue >         residues_;
    MM_model &                           model();
    void                                        adjust_pdb_model();


public:
    Zhorov_model( MM_model & );
    virtual Atom &                          prototype();
    virtual Array_of < Zhorov_atom > &      core_atoms();
    virtual Array_of < Zhorov_atom > &      atoms();
    Zhorov_atom &                           new_core_atom    ( Element );
    Zhorov_atom &                           new_terminal_atom( Element );
    virtual void                            save_as( const Text & file_name );
    virtual void                            save();
    virtual void                            load( const Text & filename );
    virtual void                            add ( const Text & filename );
    virtual void                            clear();
    void adjust_structure_by_template();
    Array_of< Chain > *						create_chains_collection();
    void                                    calc_cartesain_coordinates
                                                ( Zhorov_atom & initial_atom );
    void save_own(const Text & filename);
};

#endif //ZHOROV_MODEL_H




