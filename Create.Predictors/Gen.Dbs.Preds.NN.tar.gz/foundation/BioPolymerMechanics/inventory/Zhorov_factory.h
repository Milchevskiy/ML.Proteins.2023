#ifndef ZHOROV_FACTORY_H
#define ZHOROV_FACTORY_H

#ifndef FACTORY2_H
#include "Factory2.h"
#endif

class Element;
class MM_model;
class Inventor_view;

class Zhorov_factory : public Factory2
{
public:    
    virtual Inventor_view *     create_inventor_view(
                                        MM_model &       model,
                                        SoSeparator &    scene,
                                        SoQtRenderArea & render_area );
    virtual  Atom * create_atom( Element element );
};

#endif //ZHOROV_FACTORY_H
