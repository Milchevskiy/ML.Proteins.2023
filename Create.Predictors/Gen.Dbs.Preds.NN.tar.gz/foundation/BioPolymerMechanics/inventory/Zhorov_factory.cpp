#include "Zhorov_factory.h"

#include "Zhorov_view.h"
#include "Zhorov_inventor_atom.h"

#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/Qt/SoQtRenderArea.h>

Atom * Zhorov_factory::
create_atom( Element element )
{
    return new Zhorov_inventor_atom( element );
}

Inventor_view * Zhorov_factory::
create_inventor_view( MM_model &       model,
                      SoSeparator &    scene,
                      SoQtRenderArea & render_area )
{
    return new Zhorov_view( model, scene, render_area );
}
