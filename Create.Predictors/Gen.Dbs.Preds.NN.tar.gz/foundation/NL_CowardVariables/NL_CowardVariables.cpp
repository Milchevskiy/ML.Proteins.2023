
#pragma warning( disable : 4786 )

#include "NL_CowardVariables.h"

#include "Predicted_Clusters_via_Observed_SUM.h"
#include "Predicted_Clusters_via_Observed_SUM_iva.h"

#include "_Predicted_Clusters_via_Observed_SUM.h"

#include "PC_mlt_divided_OC_mlt.h"
#include "PC_mlt_divided_OC_mlt_iva.h"
#include <iostream>
#include <fstream>
#include <cassert>
#include <sstream>

#include <cstdlib>

extern ofstream log_stream;

typedef   map < string, NL_Base_coward * > MAP_SEQUENCEMAP_TOVALUE_NL ;
typedef   map < string, int >              MAP_NAME_TO_INDEX ;

NL_CowardVariables::
NL_CowardVariables(
	const string & Sequence_to_values_file_name )
//	,	const int seqlen_leak):
//		seqlen_leak_ (seqlen_leak)
{
	ifstream  in_stream( Sequence_to_values_file_name.c_str() );
	if ( ! in_stream)
	{
		cout       << "can't find file "  << Sequence_to_values_file_name << endl;
		log_stream << "can't find file "  << Sequence_to_values_file_name << endl;
		assert (  in_stream);
		exit (1);
	}

	vector < string >   all_mapped_definite_task ;

	string current_line;
	while ( getline(in_stream,current_line,'\n' ) )
	{
		if (   current_line[0] == '/'  ||
		       current_line[0] == '#'  ||
		       current_line[0] == ' '  ||
		       current_line[0] == '\n' ||
		       current_line[0] == '\0'  )
		  continue;

		all_mapped_definite_task.push_back( current_line );
	}

	number_of_variables_ = all_mapped_definite_task.size();

	init_known_templates_map ();


	int size = all_mapped_definite_task.size();
///	values_.resize( size );
	number_of_variables_ = size;

    MAP_SEQUENCEMAP_TOVALUE_NL ::iterator theIterator_MAP_SEQUENCEMAP_TOVALUE_NL;
	MAP_NAME_TO_INDEX       ::iterator theIterator_MAP_NAME_TO_INDEX;

	for (int ii=0;ii<size;ii++)
	{
		istringstream ist ( all_mapped_definite_task[ii] );

		string current_procedure_key_word, dummy, current_task_name ;
		ist >> current_procedure_key_word >> dummy >> current_task_name;

		theIterator_MAP_SEQUENCEMAP_TOVALUE_NL = known_templates_map_SequenceMap_toValue_.find ( current_procedure_key_word  );
		if ( theIterator_MAP_SEQUENCEMAP_TOVALUE_NL == known_templates_map_SequenceMap_toValue_.end() )
		{
			log_stream << " WiseSequenceTranslator ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			cout       << " WiseSequenceTranslator ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			exit(1);
		}
		else
		{
			NL_Base_coward * current_derived_object = known_templates_map_SequenceMap_toValue_[current_procedure_key_word]->clone(all_mapped_definite_task[ii],coward_variable_name_to_index_);
			array_derived_SequenceMap_toValues_.push_back(  current_derived_object );

			if ( current_task_name != "DUMB" && current_task_name != "dumb")
			{
				if  ( coward_variable_name_to_index_.end() != coward_variable_name_to_index_.find ( current_task_name )  )
				{
					log_stream << " WiseSequenceTranslator ERROR: twice assigned variable name: " <<  current_task_name << endl;
					cout       << " WiseSequenceTranslator ERROR: twice assigned variable name: " <<  current_task_name << endl;
					exit(1);

				}
				else
					coward_variable_name_to_index_ [ current_task_name ] = ii;
			}
		}
	}
}

void   NL_CowardVariables::
calc_values (
		vector <vector <double> > & predicted, // ������������� ���������� (� �������� ) �� ���������
		vector <vector <double> > & observed, // ���������� ���������� (� �������� ) �� ��������� �������� ��� ������ ���������
		vector  < double > 	& sofi_var_vector)
{


	for (int ii=0;ii<number_of_variables_ ;ii++)
	{

		int test = predicted[0].size();
		array_derived_SequenceMap_toValues_[ii]->calc_value (
					ii,
					predicted,
					observed,
					sofi_var_vector) ;

		test = predicted[0].size();


	}
}
/*
void   NL_CowardVariables::
process_chain (
	const vector <vector <double> > & predicted, // ������������� ���������� (� �������� ) �� ���������
	const vector <vector <double> > & observed, // ���������� ���������� (� �������� ) �� ��������� �������� ��� ������ ���������

	vector < vector < double > >&	sophisticated_variables )
{

    int row_number	=	predicted.size() - seqlen_leak_;
	int col_nunmber	=	observed.size()  - seqlen_leak_;

	int number_of_distance_measurement =	( predicted.size() - seqlen_leak_) *
											( observed.size()  - seqlen_leak_);

	sophisticated_variables.resize( number_of_distance_measurement );


//	for (int jj=0;jj<residue_number_in_chain; jj++)
	for (int jj=0;jj<number_of_distance_measurement; jj++)
	{
		sophisticated_variables[jj].resize(number_of_variables_);

		int row_current = jj / col_nunmber;
		int col_current = jj % col_nunmber;

		calc_values (
			row_current,
			col_current,
			jj,
			predicted,
			observed,
//			Chain_Prime_Constants,
			sophisticated_variables) ;
	}
}

*/
void  NL_CowardVariables::
init_known_templates_map ()
{
	Predicted_Clusters_via_Observed_SUM *		Predicted_Clusters_via_Observed_SUM_pointer = new Predicted_Clusters_via_Observed_SUM();
	known_templates_map_SequenceMap_toValue_["Predicted_Clusters_via_Observed_SUM"]			=     Predicted_Clusters_via_Observed_SUM_pointer ;


	PC_mlt_divided_OC_mlt *		PC_mlt_divided_OC_mlt_pointer								= new PC_mlt_divided_OC_mlt();
	known_templates_map_SequenceMap_toValue_["PC_mlt_divided_OC_mlt"]						=     PC_mlt_divided_OC_mlt_pointer ;

	Predicted_Clusters_via_Observed_SUM_iva *		Predicted_Clusters_via_Observed_SUM_iva_pointer = new Predicted_Clusters_via_Observed_SUM_iva();
	known_templates_map_SequenceMap_toValue_["Predicted_Clusters_via_Observed_SUM_iva"]			=     Predicted_Clusters_via_Observed_SUM_iva_pointer ;

	PC_mlt_divided_OC_mlt_iva *		PC_mlt_divided_OC_mlt_iva_pointer								= new PC_mlt_divided_OC_mlt_iva();
	known_templates_map_SequenceMap_toValue_["PC_mlt_divided_OC_mlt_iva"]						=     PC_mlt_divided_OC_mlt_iva_pointer ;

	_Predicted_Clusters_via_Observed_SUM *		_Predicted_Clusters_via_Observed_SUM_pointer = new _Predicted_Clusters_via_Observed_SUM();
	known_templates_map_SequenceMap_toValue_["_Predicted_Clusters_via_Observed_SUM"]			=     _Predicted_Clusters_via_Observed_SUM_pointer ;

}


