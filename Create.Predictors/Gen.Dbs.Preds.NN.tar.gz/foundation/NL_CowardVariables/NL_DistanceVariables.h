#ifndef NL_DISTANCEVARIABLES_H
#define NL_DISTANCEVARIABLES_H

#include	<map>
#include	<vector>
#include	<string>

using namespace std;
//class Single_masticated_structure_record;
//class Base_distance_to_claster;

class Base_distance_var;

class Sheduler;

//class Structure_assignment;


class 	Shedulerl;
class 	Fragment_base_subtle;
class 	Chain_binary;


using namespace std;

class NL_DistanceVariables
{
public:
	~NL_DistanceVariables() ;
	 NL_DistanceVariables();

	NL_DistanceVariables (
		const string & model_name);

	int get_number_of_variables () const {return number_of_variables_ ;}

	void calc_values (
		const  double distance,
		vector < double > & distance_variables);


private:
	Sheduler					*sheduler_;
	int number_of_variables_;

	//	int shift_ ;

	vector < Base_distance_var *  >				array_derived_SequenceMap_toValues_;
	map    < string, Base_distance_var * >		known_templates_map_SequenceMap_toValue_;
	map    < string, int >						coward_variable_name_to_index_;


	void init_known_templates_map ();

	NL_DistanceVariables(const NL_DistanceVariables&);
	void operator = (const NL_DistanceVariables&);

};

#endif
