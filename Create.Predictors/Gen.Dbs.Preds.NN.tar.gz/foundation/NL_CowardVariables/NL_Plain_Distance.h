#ifndef NL_PLAIN_DISTANCE_H
#define NL_PLAIN_DISTANCE_H

#ifndef BASE_DISTANCE_VAR_H
#include "Base_distance_var.h"
#endif

#include <string>
#include <vector>

using namespace std;

class  NL_Plain_Distance: public Base_distance_var
{
public:

	NL_Plain_Distance() {} ;

	explicit NL_Plain_Distance( 	const string	& task_string,
				map   < string, int	>	&	co_task_variable_name_to_index );

	//explicit Dull_Sum		( const string & task_string  );

    Base_distance_var*			clone	( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index  ) const;

	void    calc_value ( 
						int	var_set_cursor, 
						double	distance,
						vector < double > & sofi_distances )  ;  

protected:
	
	string	variable_name_in_list_; // ��� ���������� ��� ������� ������ ������

	//int cluster_index_;

	double  power_ ;

	char	fabs_mode_;

	NL_Plain_Distance(const NL_Plain_Distance&);
	NL_Plain_Distance& operator = (const NL_Plain_Distance&);
};

#endif

