
#pragma warning( disable : 4786 )

#include "NL_CowardVariables_test.h"
#include "NL_CowardVariables.h"

#include "../CommonFunc.h"

#include <fstream>
#include <iostream>

using namespace std;

extern ofstream log_stream;

NL_CowardVariables_test::~NL_CowardVariables_test()
{
	cout << "NL_CowardVariables_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;

}

void NL_CowardVariables_test::first_test			()
{
	int seqlen_leak = 10 - 5  + 1 ;

	NL_CowardVariables  nl_cvs (
		"D:/Agony/Store/Model_store_next_layer/10_first/NextLayer_CowardVariables.task");
		//,	seqlen_leak);
	
//	string sequence = "APARTEID";

	vector < vector < double > > sophisticated_variables  ;
/*
	cvs.process_chain(
		sequence, 
		sophisticated_variables );
	

	ofstream  out( "DIR_tests//CowardVariables_test___first_test");

	if ( ! out)	{	
		log_stream << "CowardVariables_test: ERROR -  can't create file" << endl;
		cout       << "CowardVariables_test: ERROR -  can't create file" << endl;
		exit (1);	
	}


	int number_of_variables = cvs.get_number_of_variables() ;
	for (int ii=0; ii<sophisticated_variables.size() ;ii++)
	{
		for (int kk=0;kk<number_of_variables ;kk++)
			PutVaDouble (sophisticated_variables [ii][kk], out,10, 3 , 'l');
		out << endl;
	}

*/
}
