#ifndef NL_COWARDVARIABLES_TEST_H
#define NL_COWARDVARIABLES_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  NL_CowardVariables_test: public Simple_test
{
public:
	~NL_CowardVariables_test();

    void run()
    {
		first_test				();
	}
	void first_test				();

};

#endif 


