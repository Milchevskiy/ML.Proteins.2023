#pragma warning( disable : 4786 )

#include "NL_Base_coward.h"

NL_Base_coward::~NL_Base_coward()  
{
}

