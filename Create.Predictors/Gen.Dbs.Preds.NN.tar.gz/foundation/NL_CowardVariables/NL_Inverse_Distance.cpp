#pragma warning( disable : 4786 )

#include "NL_Inverse_Distance.h"

using namespace std;

#include <sstream>
#include <cassert>
#include <cmath>
 
NL_Inverse_Distance::NL_Inverse_Distance ( 
	const string			& task_string,
	map   < string, int	>	&	co_task_variable_name_to_index )
	
{

// NL_Inverse_Distance		0	DUMB	       	2
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "NL_Inverse_Distance" ) ;

	int tmp_int; 
	ist >> tmp_int;
	is_subsidiary_ = ( tmp_int == 1 ) ? true : false;

	ist >> variable_name_in_list_;

	ist >> denominator_;

//	ist >> cluster_index_;

	if ( ! (ist >>  power_)  ) 
		power_ = 1;

	ist >>  fabs_mode_ ;
}

Base_distance_var* NL_Inverse_Distance::
clone ( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index   ) const
{
	return new NL_Inverse_Distance(  task_string,co_task_variable_name_to_index  );
}

void    NL_Inverse_Distance::
	calc_value ( 
				int	var_set_cursor, 
				double	distance,
				vector < double > & sofi_distances )   

{
	double tmp;
	if ( distance < 0 )
		tmp = ( 1 + fabs(distance) ) / (denominator_);
	else 
		tmp = ( 1  ) / (denominator_ + fabs(distance));


	sofi_distances  [var_set_cursor] = pow ( tmp ,power_ );

}