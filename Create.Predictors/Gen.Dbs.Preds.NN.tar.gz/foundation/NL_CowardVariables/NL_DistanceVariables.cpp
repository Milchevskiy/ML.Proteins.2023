#include "NL_DistanceVariables.h"
#include "Base_distance_var.h"

#include "NL_Plain_Distance.h"
#include "NL_Inverse_Distance.h"

#include "../Censorship.h"
#include "../Sheduler.h"

#include <iostream>
#include <fstream>
#include <cassert>
#include <sstream>
#include <cstdlib>

//#include "Plain_distance.h"
//#include "Plain_inverse_distance.h"
//#include "Product_of_distances.h"
//#include "Product_of_inv_distances.h"
//#include "Sum_of_distances.h"
//#include "Dull_Sum_of_distances.h"

extern ofstream log_stream;
extern Censorship configuration;

typedef   map < string, Base_distance_var * > MAP_SEQUENCEMAP_TOVALUE ;
typedef   map < string, int >           MAP_NAME_TO_INDEX ;


NL_DistanceVariables::
~NL_DistanceVariables()
{
	if (sheduler_)
		delete sheduler_;
};


NL_DistanceVariables::
NL_DistanceVariables(
	const string &model_name) :
	sheduler_					(0)
{

	sheduler_		= new Sheduler  (configuration.option_meaning("Path_to_Model_store_next_layer")  + model_name + string ("/") + string ("sheduler") ) ;

	//****************************************************************************

	string path_to_claster_function_task_file = configuration.option_meaning("Path_to_Model_store_next_layer")  + model_name + string ("/") +
		sheduler_->option_meaning("NL_DISTANCE_FUNCTION_TASK_FILE");


	ifstream  in_stream( path_to_claster_function_task_file.c_str() );
	if ( ! in_stream)
	{
		cout       << "can't find file "  << path_to_claster_function_task_file << endl;
		log_stream << "can't find file "  << path_to_claster_function_task_file << endl;
		assert (  in_stream);
		exit (1);
	}

	vector < string >   all_mapped_definite_task ;

	string current_line;
	while ( getline(in_stream,current_line,'\n' ) )
	{
		if (   current_line[0] == '/'  ||
		       current_line[0] == '#'  ||
		       current_line[0] == ' '  ||
		       current_line[0] == '\n' ||
		       current_line[0] == '\0'  )
		  continue;

		all_mapped_definite_task.push_back( current_line );
	}

	number_of_variables_ = all_mapped_definite_task.size();

	init_known_templates_map ();

	MAP_SEQUENCEMAP_TOVALUE ::iterator theIterator_MAP_SEQUENCEMAP_TOVALUE;
	MAP_NAME_TO_INDEX       ::iterator theIterator_MAP_NAME_TO_INDEX;

	for (int ii=0;ii<number_of_variables_ ;ii++)
	{
		istringstream ist ( all_mapped_definite_task[ii] );

		string current_procedure_key_word, dummy, current_task_name ;
		ist >> current_procedure_key_word >> dummy >> current_task_name;

		theIterator_MAP_SEQUENCEMAP_TOVALUE = known_templates_map_SequenceMap_toValue_.find ( current_procedure_key_word  );
		if ( theIterator_MAP_SEQUENCEMAP_TOVALUE == known_templates_map_SequenceMap_toValue_.end() )
		{
			log_stream << " NL_DistanceVariables ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			cout       << " NL_DistanceVariablesERROR: dummy keyword " <<  current_procedure_key_word << endl;
			exit(1);
		}
		else
		{
			Base_distance_var * current_derived_object =
				known_templates_map_SequenceMap_toValue_[current_procedure_key_word]->clone(all_mapped_definite_task[ii],coward_variable_name_to_index_);
			array_derived_SequenceMap_toValues_.push_back(  current_derived_object );

			if ( current_task_name != "DUMB" && current_task_name != "dumb")
			{
				if  ( coward_variable_name_to_index_.end() != coward_variable_name_to_index_.find ( current_task_name )  )
				{
					log_stream << " NL_DistanceVariables ERROR: twice assigned variable name: " <<  current_task_name << endl;
					cout       << " NL_DistanceVariables ERROR: twice assigned variable name: " <<  current_task_name << endl;
					exit(1);

				}
				else
					coward_variable_name_to_index_ [ current_task_name ] = ii;
			}
		}
	}
}

void NL_DistanceVariables::
calc_values (
	  const   double   distance,
	  vector < double > & distance_variables )
{
	for (int ii=0;ii<number_of_variables_ ;ii++)
	{
		array_derived_SequenceMap_toValues_[ii]->calc_value (
			ii,
			distance,
			distance_variables ) ;



	}
}

void  NL_DistanceVariables::
init_known_templates_map ()
{

	NL_Plain_Distance *		NL_Plain_Distance_pointer = new NL_Plain_Distance();
	known_templates_map_SequenceMap_toValue_["NL_Plain_Distance"]		=		NL_Plain_Distance_pointer ;

	NL_Inverse_Distance *		NL_Inverse_Distance_pointer = new NL_Inverse_Distance();
	known_templates_map_SequenceMap_toValue_["NL_Inverse_Distance"]		=		NL_Inverse_Distance_pointer ;


}
