#pragma warning( disable : 4786 )

#include "Base_distance_var.h"

Base_distance_var::~Base_distance_var()  
{
}

