#ifndef BASE_DISTANCE_VAR_H
#define BASE_DISTANCE_VAR_H

#include	<string>
#include	<vector>
#include	<map>

using namespace std;

class  Base_distance_var
{
public:
	  
	Base_distance_var(): 
	  value_( 0 ),
	  is_subsidiary_ (false)
	  {}

	virtual			~Base_distance_var() ;
	virtual			Base_distance_var* clone (const string & task_string, map   < string, int >&	co_task_variable_name_to_index   ) const					= 0;

	virtual			void    calc_value ( 
						int	var_set_cursor, 
						double	distance,
						vector < double > & sofi_distances )   = 0;  // ��� ����� ������ ���������� ������
	
	double			get_value		() const { return value_; } 

	bool			is_subsidiary () const { return is_subsidiary_; }

protected:	
	double	value_;
	string	name_;
	bool    is_subsidiary_;
};

#endif