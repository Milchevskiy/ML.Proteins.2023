#ifndef MASSIVEPREDICTORANALYSIS_H_INCLUDED
#define MASSIVEPREDICTORANALYSIS_H_INCLUDED

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

using namespace std;

class  MassivePredictoranAlysis_test: public Simple_test
{
public:
	~MassivePredictoranAlysis_test();

    void run()
    {
        c_FourierSmoothedParameter_search ();
	}

    void c_FourierSmoothedParameter_search ();

};



#endif // MASSIVEPREDICTORANALYSIS_H_INCLUDED
