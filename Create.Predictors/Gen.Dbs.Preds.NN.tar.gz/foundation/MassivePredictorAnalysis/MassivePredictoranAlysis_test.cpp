#pragma warning( disable : 4786 )

#include "MassivePredictorAnalysis.h"
#include <fstream>


#include <cassert>
#include <iostream>
#include <vector>

#include "../Main_model/Abu_Maimonides_Rambam.h"

using namespace std;

extern ofstream log_stream;

MassivePredictoranAlysis_test::
~MassivePredictoranAlysis_test()
{
	cout << "MassivePredictoranAlysis_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void MassivePredictoranAlysis_test::c_FourierSmoothedParameter_search()
{
    string path_to_coward_file = "Store/Model_store/DebuggingPredictorParameters/CowardVariables.task" ;

    ofstream  out( path_to_coward_file.c_str());

	if ( ! out)	{
		log_stream << path_to_coward_file << "ERROR -  can't create file" << endl;
		cout       << path_to_coward_file << "ERROR -  can't create file" << endl;
		throw;
	}


   // vector<std::string> AAINDEX_properties = { "QIAN880134", "KUMS000103", "WERD780101","RACS820104","CHOP780207","PTIO830101","LEVM780103","KUMS000103" };

  // vector<std::string> AAINDEX_properties = {  "WERD780101","PTIO830101" };
  //vector<std::string> AAINDEX_properties = { "EISD860101", "JANJ790102", "NOZY710101","WERD780101","PTIO830101","PTIO830102","MUNV940105"};

  vector<std::string> AAINDEX_properties = {  "EISD860101",  "GUYH850101",  "JANJ790102",  "MIYS850101",  "NOZY710101",  "RADA880107",  "ROBB790101",  "YUTK870101",  "MUNV940105",  "WOLR810101",  "PTIO830101",  "PTIO830102"  };



   /*
   EISD860101 Solvation free energy (Eisenberg-McLachlan, 1986)
   GUYH850101 Partition energy (Guy, 1985)
   JANJ790102 Transfer free energy (Janin, 1979)
   MIYS850101 Effective partition energy (Miyazawa-Jernigan, 1985)
   NOZY710101 Transfer energy, organic solvent/water (Nozaki-Tanford, 1971)
   RADA880107 Energy transfer from out to in(95%buried) (Radzicka-Wolfenden, 1988)
   ROBB790101 Hydration free energy (Robson-Osguthorpe, 1979)
   YUTK870101 Unfolding Gibbs energy in water, pH7.0 (Yutani et al., 1987)
   MUNV940105 Free energy in beta-strand region (Munoz-Serrano, 1994)
   WOLR810101 Hydration potential (Wolfenden et al., 1981)
   PTIO830101 Helix-coil equilibrium constant (Ptitsyn-Finkelstein, 1983)
   PTIO830102 Beta-coil equilibrium constant (Ptitsyn-Finkelstein, 1983)
*/


    double T_min=1.0,T_max=13,T_step=0.2;
    double SmoothingParameter_min = 4, SmoothingParameter_max=9, SmoothingParameter_step=2;
    double power_min=1, power_max=3,power_step=1;

        for(double xx=T_min; xx< T_max; xx+=T_step)
        {
             for(double yy=SmoothingParameter_min; yy< SmoothingParameter_max; yy+=SmoothingParameter_step)
             {
                  for(double zz=power_min; zz< power_max; zz+=power_step)
                  {
                      for (int ii=0;ii<AAINDEX_properties.size();ii++ )
                            out << "c_FourierSmoothed	0	DUMB	" << AAINDEX_properties[ii] << "\t" << xx << "\t" << yy << "\t" << zz << endl;

                  }


             }
        }



    /// Fill up cross sum for  model DebuggingPredictorParameters
    {
        Abu_Maimonides_Rambam mr ( "DebuggingPredictorParameters", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    }

    /// Fill up cross sum for  model DebuggingPredictorParameters
    {
        Abu_Maimonides_Rambam mr ( "DebuggingPredictorParameters", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
        mr.plain_solution ( "together" );
    }










}
