#ifndef SPECIAL_FUNCTION_H
#define SPECIAL_FUNCTION_H


	double prob_by_student (double t, int njue);
	double betai(double a, double b, double x);
	double betacf(double a, double b, double x);
	double gammln(double xx);


#endif 