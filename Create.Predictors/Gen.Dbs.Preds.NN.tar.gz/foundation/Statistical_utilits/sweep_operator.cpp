#include "Statistic_general_purpose.h"


using namespace std;

void sweep_operator(
	const int wc,
	const int kk,
	const int flag,
	vector < double > & sumxy,
	vector < double > & x) 
{

	double c =sumxy[ one_dimensional_matrix_index(kk,kk,wc) ];

	int i;
	for(int i=0;i<=kk;i++)
	{
		int ij=one_dimensional_matrix_index(i,kk,wc);
		x[i] = sumxy[ij];
		sumxy[ij]=  0;
	}
	for(i=kk;i<wc;i++)
	{
		int ij=one_dimensional_matrix_index(kk,i,wc);
		x[i]= sumxy[ij];
		sumxy[ij]= 0;
	}
	
	x[kk] = flag;

	for(i=0;i<wc;i++)
		for(int j=i;j<wc;j++)
			sumxy[ one_dimensional_matrix_index(i,j,wc) ] -= x[i]*x[j]/c;

}



void sweep_operator(
	const int wc,
	const int kk,
	const int flag,
	double * sumxy,
	double * x) 
{

	double c =sumxy[ one_dimensional_matrix_index(kk,kk,wc) ];
	int i;
	for( i=0;i<=kk;i++)
	{
		int ij=one_dimensional_matrix_index(i,kk,wc);
		x[i] = sumxy[ij];
		sumxy[ij]=  0;
	}
	for(i=kk;i<wc;i++)
	{
		int ij=one_dimensional_matrix_index(kk,i,wc);
		x[i]= sumxy[ij];
		sumxy[ij]= 0;
	}
	
	x[kk] = flag;

	for(i=0;i<wc;i++)
		for(int j=i;j<wc;j++)
			sumxy[ one_dimensional_matrix_index(i,j,wc) ] -= x[i]*x[j]/c;

}

