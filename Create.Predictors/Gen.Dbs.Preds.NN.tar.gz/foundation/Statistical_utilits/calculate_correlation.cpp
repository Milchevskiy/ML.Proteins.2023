#pragma warning( disable : 4786 )

#include "../Geometry_util/Geometry_util.h"

#include "../CommonFunc.h"

#include <cmath>
#include <vector>
#include <cassert>

using namespace std;

double    calculate_correlation(
		vector <double> & v1,
		vector <double> & v2)

{
	static double very_small_value =  Geometry_util::epsilon_float() ; 

	assert (v1.size() == v2.size() );

	int casenum = v1.size();

	double fte,corr,av1=0,av2=0,s1=0,s1_2=0,s2=0;

	for(int i=0;i<casenum;i++) {
		 av1  += v1[i];
		 av2  += v2[i];
		 s1   += v1[i]*v1[i];
		 s1_2 += v1[i]*v2[i];
		 s2   += v2[i]*v2[i];
	}
	corr= casenum*s1_2 - av1*av2;

	fte = (casenum*s1 - av1*av1)*(casenum*s2 - av2*av2) ;

	corr = ( fabs (corr) > very_small_value ) ? ( corr/ sqrt(fte) ) : 0;

	return corr;
}

	
double    calculate_correlation(
		const double * v1,
		const double * v2,
		const int casenum)
{
	static double very_small_value =  Geometry_util::epsilon_float() ; 

	//int casenum = v1.size();

	double fte,corr,av1=0,av2=0,s1=0,s1_2=0,s2=0;

	for(int i=0;i<casenum;i++) {
		 av1  += v1[i];
		 av2  += v2[i];
		 s1   += v1[i]*v1[i];
		 s1_2 += v1[i]*v2[i];
		 s2   += v2[i]*v2[i];
	}
	corr= casenum*s1_2 - av1*av2;

	fte = (casenum*s1 - av1*av1)*(casenum*s2 - av2*av2) ;

	corr = ( fabs (corr) > very_small_value ) ? ( corr/ sqrt(fte) ) : 0;

	return corr;
}

	