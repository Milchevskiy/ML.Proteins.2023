#ifndef DISCRIMINANT_STEPWISE_TEST
#define DISCRIMINANT_STEPWISE_TEST

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Discriminant_stepwise_test: public Simple_test
{
public:
	~Discriminant_stepwise_test();

    void run()
    {


	//	prepare_data_test();
		minimal_existance_test ();  // ability to use standard text file
	}
	void prepare_data_test();
	void minimal_existance_test ();
};

#endif
