#ifndef CALC_DISPERSION_AND_AVERAGE_H
#define CALC_DISPERSION_AND_AVERAGE_H

#include <vector>

using namespace std;


void calc_dispersion_and_average (
	vector <double> & x,
	double & av_y,
	double & si_y );

void calc_dispersion_and_average_by_known_sums (
	double av1,
	double s1,
	int casenum,
	double & average,
	double & sigma );


#endif

