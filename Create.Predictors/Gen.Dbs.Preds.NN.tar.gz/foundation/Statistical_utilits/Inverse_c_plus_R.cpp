#pragma warning( disable : 4786 )

#include "Inverse_c_plus_R.h"

#include <sstream>
#include <cassert>
#include <cmath>
 
Inverse_c_plus_R::Inverse_c_plus_R( const string & task_string  ) //:  SequenceMap_toValue ( task_string  )
{
// Inverse_c_plus_R 0.1 2 0.5
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "Inverse_c_plus_R" );

	ist >> add_constant_;
	ist >> power_R_;
	ist >> power_G_;
}

Base_value_transformer* Inverse_c_plus_R::
clone ( const string & task_string   ) const
{
		return new Inverse_c_plus_R (  task_string  );
}

double   Inverse_c_plus_R::calc_value ( double seed)  
{
	double seed_pow = pow (seed,power_R_);
	value_ = pow ( 1/(add_constant_ + seed_pow ), power_G_)  ;
	
	return  value_;
}
