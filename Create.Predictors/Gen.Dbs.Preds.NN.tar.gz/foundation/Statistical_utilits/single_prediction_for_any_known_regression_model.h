#ifndef SINGLE_PREDICTION_FOR_ANY_KNOWN_REGRESSION_MODEL_H
#define SINGLE_PREDICTION_FOR_ANY_KNOWN_REGRESSION_MODEL_H

#include <vector>

using namespace std; 

double single_prediction_for_any_known_regression_model (
	const vector <double> &	variables,
	const double			absolute_term ,
	const double *			regression_coefficients,
	const int				number_of_predictors);


#endif


