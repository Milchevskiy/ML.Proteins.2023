#pragma warning( disable : 4786 )

#include "RegBase_test.h"
#include "RegBase.h"

#include "../Censorship.h"
#include "../CommonFunc.h"

#include <fstream>
#include <iostream>
#include <cassert>

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

RegBase_test::~RegBase_test()
{
	cout << "RegBase_testPASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void RegBase_test::
prepare_data()
{
   ifstream stream_in ( "DIR_tests/Reg_degbug/small.dat ");
   if ( ! stream_in)
   	{	
		log_stream		<< "ERROR -  can't read data file " << endl;
		cout			<< "ERROR -  can't read data file " << endl;
		exit (1);	
	}

   ofstream stream_bin_out ( "DIR_tests/Reg_degbug/small_binary.bin", ios::binary);
   if ( ! stream_bin_out )
   {	
		log_stream		<< "ERROR -  can't read data file " << endl;
		cout			<< "ERROR -  can't read data file " << endl;
		exit (1);	
	}

   int number_of_records, number_of_predictors_and_dependent;

   stream_in >> number_of_records;
   stream_in >> number_of_predictors_and_dependent;

   int number_of_predictors = number_of_predictors_and_dependent -1 ;
     int number_of_dependent  =	1;

   stream_bin_out.write ( (char* ) & number_of_predictors,	sizeof (int)  );
	int test_pos = stream_bin_out.tellp();
   stream_bin_out.write ( (char* ) & number_of_dependent,	sizeof (int)  );
	test_pos = stream_bin_out.tellp();



   double *current_array = new double [number_of_predictors_and_dependent];
   for ( int ii=0; ii<number_of_records;ii++ ) 
   {
	   for ( int kk=0;kk<number_of_predictors_and_dependent;kk++) 
		   stream_in >> current_array [kk];
	   stream_bin_out.write ( (char* )  current_array ,	number_of_predictors_and_dependent*sizeof (double)  );
   }


	//delete [] current_array ;
	stream_bin_out.close();	stream_in.close();


//   ifstream stream_bin_in ( "DIR_tests/Reg_degbug/small_binary.bin", ios::binary);
//	 stream_bin_in .read (  (char* ) & buff, length_*sizeof (char) );

   ofstream out ( "DIR_tests/Reg_degbug/small_binary_bin_check", ios::binary);
   if ( ! out )
   {	
		log_stream		<< "ERROR -  can't create file " << endl;
		cout			<< "ERROR -  can't create file " << endl;
		exit (1);	
	}


   RegBase rb ("DIR_tests/Reg_degbug/small_binary.bin");

   number_of_predictors	=	rb.get_number_of_predictors();//
   number_of_records	=	rb.get_number_of_records();
    number_of_dependent	=	rb.get_number_of_dependent();


   out << "number_of_predictors: "  << number_of_predictors << endl; 
   out << "number_of_dependent: "  << number_of_dependent	<< endl; 
   out << "number_of_records: "  << number_of_records	<< endl; 

   rb.get_record(3, current_array );
   out << "4-th record: " << endl;

   for (int jj=0;jj<number_of_predictors + number_of_dependent; jj++)
   {
	   PutVaDouble (current_array [jj], out, 8,3,'l');
   }
   out << endl;
}