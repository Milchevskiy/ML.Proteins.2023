#ifndef REGBASE_H
#define REGBASE_H

class RegBase ;

#include <vector>
#include <string>
#include <fstream>

using namespace std;

class RegBase
{
public:
	RegBase ( const string & name );
	~RegBase ();

	int get_number_of_predictors	() const { return number_of_predictors_; }
	int get_number_of_dependent		() const { return number_of_dependent_; }
	int get_number_of_records		() const { return number_of_records_; } 

	bool get_record			(  int index, double *record );
	bool get_record_subtle	(  int index, double *record, int dependent_index );

	vector < string > get_predictor_names () const { return predictor_names_;}
	vector < string > get_dependent_names () const { return dependent_names_;}

private:
	string name_; 
	int number_of_predictors_;
	int number_of_dependent_;
	int	number_of_records_;  // the same as number_of_cases_

	vector < string > predictor_names_;
	vector < string > dependent_names_;
	
	int data_origin_pos_;
	int record_length_ ;

	double *local_read_buffer_;
	
	ifstream		binary_base_stream_;

	void fill_up_names ();
	void init_base_insight(); 
};

#endif