#include "single_prediction_for_any_known_regression_model.h"

#include <cassert>

double single_prediction_for_any_known_regression_model (
	const vector <double> &	variables,
	const double			absolute_term ,
	const double *			regression_coefficients,
	const int				number_of_predictors)
{

	assert (variables.size() == number_of_predictors);

	double sum = absolute_term ;
	for (int ii=0;ii<number_of_predictors; ii++)
    {
            double v_i = variables[ii];
            double r_c = regression_coefficients[ii];

		sum += variables[ii]*regression_coefficients[ii];
    }

	return sum;
}




