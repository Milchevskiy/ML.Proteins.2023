#pragma warning( disable : 4786 )

#include "Discriminant_stepwise_test.h"
#include "DiscrIminant_stepwise.h"
 //#include "Frequency_extrapolation_ZIP.h"

#include "../Censorship.h"

#include "../CommonFunc.h"

#include "../Main_model/Abu_Maimonides_Rambam.h"

#include "../Chain_store/DSSP_binary_test.h"
#include "../Chain_store/DSSP_binary.h"

//#include "../Chain_store/DSSP_binary.h"

#include "../Fragment_base/Chain_binary.h"
#include "../Fragment_base/accepted_chain_data.h"

#include "../Pair_int_double.h"

#include <fstream>
#include <iostream>
#include <cassert>

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

int get_nearest_index( 	const vector <double> & distance_set );

void make_prediction_quality_matrix (string & sourse_file_name);

Discriminant_stepwise_test::~Discriminant_stepwise_test()
{
	cout << "Discriminant_stepwise_testPASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}


void Discriminant_stepwise_test::
minimal_existance_test ()
{

	Discriminant_stepwise  object (
		string ("D:/Didona/Test/Prob_Discr.dat"),
		string ("D:/Didona/Test/regression_options"),
		TEXT_MODE);
	object.print_orthodox_result ();
	object.print_prediction_parameters();



	string current_path = string("D:/Didona/Test/Prob_Discr.orthodox_result");
	make_prediction_quality_matrix (current_path);

}

void Discriminant_stepwise_test::
prepare_data_test()
{

	ofstream output ( "D:/Didona/Test/Prob_Discr.dat");
	if ( ! output )
	{
		log_stream	<< "can't create " << endl;
		cout		 << "can't create " << endl;
		exit (1);
	}

	ofstream out_od ( "D:/Didona/Test/counter_ordered_disordered");
	if ( ! out_od )
	{
		log_stream	<< "can't create " << endl;
		cout		 << "can't create " << endl;
		exit (1);
	}





	vector < string >	chain_ID_list;
	vector < int >      accepted_chain_lenth;
	string				path_to_accepted_chain_list_file;


	string binary_file_name ("accepted_chain_list.bin");

	fill_up_accepted_chain_data (
		chain_ID_list,
		accepted_chain_lenth,
		binary_file_name );



	Abu_Maimonides_Rambam mr ( "second_model", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;


	int ordered_num = 0;
	int disordered_num = 0;

	int shift = mr.get_shift();

	for (int ii=0; ii < chain_ID_list.size()/3; ii++ )
	{
		vector < vector < double > >  predicted_det_distance_set = mr.read_det_distance_set (
			chain_ID_list [ii], string(".dist_data_predicted") );


		vector < vector < double > >  det_distance_set = mr.read_det_distance_set (
			chain_ID_list [ii], string(".dist_data") );


		int pre_dist_set_size = predicted_det_distance_set.size();

		DSSP_binary dsb_com	( chain_ID_list [ii],COMMON_USAGE);
		Chain_binary cbi	( chain_ID_list [ii]);

		int number_of_residues = cbi.get_number_of_residues();

		int *serial_index = cbi.get_serial_index();

		map <int,char> serial_index_to_DSSP				= dsb_com.get_serial_index_to_DSSP();
		map <int,char> serial_index_to_amino_acid_name	= dsb_com.get_serial_index_to_amino_acid_name();

		for (int kk=0;kk<pre_dist_set_size;kk++)
		{
		//	bool *flag = cbi.is_there_coord_();
//			if (! (*flag) )
//				continue;


			int curren_in_pdb_number = serial_index[kk+shift];

/*

			if ( serial_index_to_amino_acid_name .find(curren_in_pdb_number) != serial_index_to_amino_acid_name.end()  )
				output << serial_index_to_amino_acid_name [curren_in_pdb_number];

			else
				continue;

			output << "  ";

			if ( serial_index_to_DSSP .find(curren_in_pdb_number) != serial_index_to_DSSP .end()  )
				output << '\"' << serial_index_to_DSSP [curren_in_pdb_number] << '\"';

			else
				continue;


			PutVa(serial_index[kk+shift],output,5,2,'l');


			int class_ID;
			char class_letter= serial_index_to_DSSP [curren_in_pdb_number];
			switch (class_letter)
			{
			case'H':
				class_ID = 0;
				break;
			case'G':
				class_ID = 1;
				break;
			case 'E':
				class_ID = 2;
				break;
			case 'B':
				class_ID = 3;
				break;
			case 'S':
				class_ID = 4;
				break;
			case 'T':
				class_ID = 5;
				break;
			default:
				class_ID = 6;
				break;
			}
*/

		int number_of_clasters = 30;


			for (int ttt=0;ttt<number_of_clasters;ttt++)
			{
				predicted_det_distance_set	[kk][ttt] = - predicted_det_distance_set[kk][number_of_clasters+ttt];
				det_distance_set			[kk][ttt] = - det_distance_set			[kk][number_of_clasters+ttt];
			}

			predicted_det_distance_set[kk].resize(number_of_clasters);
			det_distance_set[kk].resize(number_of_clasters);

			int predicted_nearest_index =
				get_nearest_index(			predicted_det_distance_set[kk]);
			int nearest_index =
				get_nearest_index(			det_distance_set[kk]);

			if(det_distance_set[kk][0] == -1.0)
			{

				disordered_num ++;

				output << " 1  " ;
			}
			else
			{
				 ordered_num ++;
				output << " 0  " ;
			}


//			output << "   " << nearest_index << "   ";
//			cout << kk<< "   " << nearest_index << "   " << endl;


			int check = predicted_det_distance_set[kk].size();
			for (int jj=0; jj < predicted_det_distance_set[kk].size(); jj++)
			{
				PutVaDouble (-predicted_det_distance_set[kk][jj],output,8,4,'l');
				PutVaDouble ( predicted_det_distance_set[kk][jj]*predicted_det_distance_set[kk][jj],output,8,4,'l');
				PutVaDouble ( -predicted_det_distance_set[kk][jj]*predicted_det_distance_set[kk][jj]*predicted_det_distance_set[kk][jj],output,8,4,'l');
			}

			output << endl;

		}
cout << ii << " " << chain_ID_list [ii] << endl;
	//	delete [] serial_index ;
		}


	out_od << ordered_num << " " << disordered_num << " " << endl;

}


int get_nearest_index( 	const vector <double> & distance_set )
{
	vector < Pair_int_double > indexed_dist_store;  		indexed_dist_store.clear();

	for ( int kk=0;kk<distance_set.size(); kk++)
		indexed_dist_store.push_back( Pair_int_double (kk,distance_set[kk]) );

	sort (indexed_dist_store.begin(),indexed_dist_store.end() );
	int		nearest_index 	=	indexed_dist_store.front().index() ;

	return nearest_index ;

}

void make_prediction_quality_matrix (string & sourse_file_name)
{

	ifstream  energy_data_stream ( sourse_file_name.c_str() );
	if ( ! energy_data_stream )	{	cout << "can't find file " << sourse_file_name << endl;
		assert (  energy_data_stream );		exit (1);	}


	string current_line,current_word;;
	int groop_index,predictred_groop_index,groop_number ;

	if ( getline( energy_data_stream, current_line, '\n' ) )
	{
		istringstream ist (current_line);
		ist >> groop_number ;
	}
	else
	{
		cout << "gross error in file " << sourse_file_name;
		exit (1);
	}

	vector < vector < double > > matrix;
	matrix.resize(groop_number);
	for (int ii=0;ii<groop_number;ii++)
		matrix[ii].resize(groop_number);

	int current_case_number = 0;
	while( getline( energy_data_stream, current_line, '\n' ) )
	{
		current_case_number ++;

		istringstream ist (current_line);
		ist >>  predictred_groop_index ;
		ist >>  groop_index ;
/*
		double value;
		vector < double > probabilities;
		int count = 0;
		while ( ist >> value )
		{
			probabilities.push_back(value);
			 count ++;
		}

		if (count != groop_number)
		{
			cout << " number of groups for case " << current_case_number << "does not correspond early declared" << endl ;
			exit (1);

		}

		vector < double > sorted_probabilities = probabilities;
		sort (sorted_probabilities.begin(),sorted_probabilities.end() );

		int coincidence_index;
		for (int ii=0;ii<groop_number;ii++)
		{
			if ( sorted_probabilities[groop_number-1] == probabilities [ii] )
			{
				coincidence_index = ii;
				break;
			}
		}
*/
		matrix [groop_index][predictred_groop_index ] += 1;
	}




	string result_name = new_extension_file_name ( string (sourse_file_name), "pred_accur_matrix" ) ;
	ofstream  result_stream ( result_name.c_str()  );
	if ( ! result_stream )	{	cout << "can't create file " << result_name << endl;
		assert (  result_stream );		exit (1);	}


	for ( int ii=0;ii<groop_number;ii++)
	{
		for ( int jj=0;jj<groop_number;jj++)
			PutVaDouble (matrix [ii][jj],result_stream ,20, 1,'l');


		result_stream << endl;

	}

	result_stream << "Percent!";
	for ( int ii=0;ii<groop_number;ii++)
	{
		for ( int jj=0;jj<groop_number;jj++)
			PutVaDouble (matrix [ii][jj]*100/current_case_number ,result_stream ,20, 1,'l');


		result_stream << endl;

	}




}


