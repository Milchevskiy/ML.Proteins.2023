#include "calc_dispersion_and_average.h"

#include <cmath>

void calc_dispersion_and_average (
	vector <double> & dist_vector,
	double & average,
	double & sigma )
{
	int casenum = dist_vector.size();
	double av1 = 0;
	double s1=0;

	for(int i=0;i<casenum;i++)
	{
		 av1  += dist_vector[i];
		 s1   += dist_vector[i]*dist_vector[i];
	}

	double fte = (casenum*s1 - av1*av1);
	fte /= casenum;
	fte /=  casenum;

	average = av1 / casenum;
	sigma = sqrt (fabs(fte) );
}


void calc_dispersion_and_average_by_known_sums (
	double av1,
	double s1,
	int casenum,
	double & average,
	double & sigma )
{
	double fte = (casenum*s1 - av1*av1);
	fte /= casenum;
	fte /=  casenum;

	average = av1 / casenum;
	sigma = sqrt (fabs(fte) );
}

