#ifndef STANDARDIZE_TO_KNOWN_GAUSS_H
#define STANDARDIZE_TO_KNOWN_GAUSS_H

#include <vector>

using namespace std;

void standardize_to_known_gauss (
			vector <double> & x, 
			const double av_y,
			const double si_y);

#endif
