#pragma warning( disable : 4786 )

#include "Log_c_plus_R.h"

#include <sstream>
#include <cassert>
#include <cmath>
 
Log_c_plus_R::Log_c_plus_R( const string & task_string  ) //:  SequenceMap_toValue ( task_string  )
{
// Log_c_plus_R 0.5 2 
	istringstream ist( task_string );

	ist >> name_ ;
	assert ( name_ == "Log_c_plus_R" );

	ist >> add_constant_;
	ist >> power_G_;

}

Base_value_transformer* Log_c_plus_R::
clone ( const string & task_string   ) const
{
		return new Log_c_plus_R (  task_string  );
}


double   Log_c_plus_R::calc_value ( double seed)  
{
	value_ = pow( log ( add_constant_ + seed ), power_G_)   ;
	return  value_;
}
