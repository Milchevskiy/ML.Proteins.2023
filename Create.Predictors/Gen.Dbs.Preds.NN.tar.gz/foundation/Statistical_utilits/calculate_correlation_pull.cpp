#pragma warning( disable : 4786 )

#include "calculate_correlation_pull.h"

#include "../CommonFunc.h"



vector <double> calculate_correlation_pull (
		vector < vector < double > > & first_pull_raw,
		vector < vector < double > > & second_pull_raw,
		const int size )
{

	vector < vector < double > >  first_pull;
	vector < vector < double > >  second_pull;

	int number_of_case_raw = first_pull_raw.size();

	for (int ii=0;ii<number_of_case_raw;ii++)
	{
		if(second_pull_raw[ii][0]== -1)
			continue;

		first_pull.push_back(first_pull_raw[ii]);
		second_pull.push_back(second_pull_raw[ii]);

	}

	int number_of_case = second_pull.size();

	vector <double> correlation_pull;
//	correlation_pull.resize( first_pull[0].size());

 /// тут добавил для случая, когда нету пентапептидов экспериментальных
    correlation_pull.resize( first_pull_raw[0].size());

    if (first_pull.size()==0)
    {
        for (int kk=0; kk<size; kk++ )
            correlation_pull[kk] = 0;

        return correlation_pull;

    }

	vector < vector < double > > transposed_first_pull;
	vector < vector < double > > transposed_second_pull;

	transposed_first_pull	.resize(size);
	transposed_second_pull	.resize(size);
	int ii;
	for (ii=0; ii<size; ii++ )
	{
		transposed_first_pull	[ii].resize(number_of_case) ;
		transposed_second_pull	[ii].resize(number_of_case) ;
	}

	for ( ii=0; ii<size; ii++ )
	{
		for (int jj=0; jj<number_of_case; jj++ )
		{
			transposed_first_pull	[ii][jj] = first_pull[jj][ii];
			transposed_second_pull	[ii][jj] = second_pull[jj][ii];
		}
	}


	for ( ii=0; ii< size ;ii++ )
	{
		correlation_pull[ii] =
			calculate_correlation (
				transposed_first_pull	[ii],
				transposed_second_pull	[ii]);
	}


	return correlation_pull;
}

