#pragma warning( disable : 4786 )

#include "Janireg_test.h"
#include "Janireg.h"
#include "RegBase.h"
#include "Reg_solution.h"

#include "../Censorship.h"
#include "../CommonFunc.h"

#include <fstream>
#include <iostream>
#include <cassert>

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

Janireg_test::~Janireg_test()
{
	cout << "Janireg_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Janireg_test::
is_alive_test()
{
		//RegBase database ("DIR_tests/Reg_degbug/small_binary.bin"); 
		RegBase database ("DIR_tests/Reg_degbug/penta_training_5_8.regdata"); 
		int dependent_index =0;

		Janireg jnr (   &database, dependent_index );

			cout << "Janireg  constructor ready!!!"<< endl;


  		int	number_of_cases     = jnr.get_number_of_cases();
		int	number_of_variables = jnr.get_number_of_variables();
		double *	avsumx		= jnr.get_avsumx();
		double *	su			= jnr.get_su(); 
		double *	d			= jnr.get_d ();
		double		tolerance	= 0.1;
		double		Fisher_in   = 100.0;
		double		Fisher_out	= 100.0;
		vector < string >  predictor_names   = jnr.get_predictor_names();
		string			   name_of_dependent = jnr.get_name_of_dependent ();


		Reg_solution *sol = jnr.prepare_single_solution (
  			number_of_cases, 
			number_of_variables, 
			avsumx, 
			su, 
			d,
			tolerance,
			Fisher_in,
			Fisher_out,
			predictor_names,
			name_of_dependent);

				cout << "Single solution ready!!!"<< endl;

		jnr.make_plain_prediction( sol, dependent_index);

		sol->show_reg_model(
			"DIR_tests/Reg_degbug/small_binary.reg_model",
			jnr.get_plain_correlation(),
			jnr.get_virgin_avsumx	 () 			) ;

		delete sol;
}

void Janireg_test::
jack_nife_quality_estimation_test()
{


//		RegBase database ("DIR_tests/Reg_degbug/small_binary.bin"); 
		RegBase database ("DIR_tests/Reg_degbug/penta_training_5_8.regdata"); 

		int dependent_index =3 ;
		Janireg jnr (   &database, dependent_index );


  		int	number_of_cases     = jnr.get_number_of_cases();
		int	number_of_variables = jnr.get_number_of_variables();
		double *	avsumx		= jnr.get_avsumx();
		double *	su			= jnr.get_su(); 
		double *	d			= jnr.get_d ();
		double		tolerance	= 0.1;
		double		Fisher_in   = 100.0;
		double		Fisher_out	= 100.0;
		vector < string >  predictor_names   = jnr.get_predictor_names();
		string			   name_of_dependent = jnr.get_name_of_dependent ();


		Reg_solution *sol = jnr.prepare_single_solution (
  			number_of_cases, 
			number_of_variables, 
			avsumx, 
			su, 
			d,
			tolerance,
			Fisher_in,
			Fisher_out,
			predictor_names,
			name_of_dependent);

		cout << "Single solution ready!!!"<< endl;

		vector < vector <int> >  group_index;
		vector < int > curren_set;
		for (int ii=0;ii<number_of_cases;ii++)
		{
			curren_set.resize(0);
			curren_set.push_back(ii);
			if ( ii+1 < number_of_cases )
				curren_set.push_back(ii+1);

			group_index.push_back(curren_set);
		}

		vector < int >  forcibly_included_index = sol->get_index_of_included();



		jnr.jack_nife_quality_estimation ( 
			group_index,
			dependent_index,
			tolerance,
			forcibly_included_index ) ;


		double * observed				=jnr.get_observed				(); 
		double * jack_nife_prediction	=jnr.get_jack_nife_prediction	();  
		double * plain_prediction		=jnr.get_plain_prediction		(); 


	   ofstream out ( "DIR_tests/Reg_degbug/jack_nife_quality_estimation_test", ios::binary);
	   if ( ! out )
	   {	
			log_stream		<< "ERROR -  can't read data file " << endl;
			cout			<< "ERROR -  can't read data file " << endl;
			exit (1);	
		}
	   for ( ii=0;ii<number_of_cases;ii++)
	   {
		   PutVa		(ii, out, 5,1, 'l'); out << "  " ;
		   PutVaDouble	(observed				[ii], out, 10,3, 'l');out << "  " ;
   		   PutVaDouble	(plain_prediction		[ii], out, 10,3, 'l');out << "  " ;
		   PutVaDouble	(jack_nife_prediction	[ii], out, 10,3, 'l');
		   out << endl;
	   }


		double plain_correlation		= 
			jnr.get_plain_correlation		();
		double jack_nife_correlation	= 
			jnr.get_jack_nife_correlation	() ;

	out << "******************************************************" << endl;
	out << " PLAIN CORRELATION:   " ;
	PutVaDouble	(plain_correlation, out, 10,3, 'l');		out << endl;
	
	out << " JCKNF CORRELATION:   " ;
	PutVaDouble	(jack_nife_correlation, out, 10,3, 'l');	cout <<  endl;

	delete sol;
}
void Janireg_test::
jack_nife_optimal_quality_search_test()
{


		RegBase database ("DIR_tests/Reg_degbug/penta_training_5_8.regdata"); 
		int dependent_index =3;

		string task_string = string( "Inverse_c_plus_R 10 1 1");
		//string task_string = string( "Log_c_plus_R 2 -0.5");

		Janireg jnr (   &database, dependent_index, task_string );

			cout << "Janireg  constructor ready!!!"<< endl;


  		int	number_of_cases     = jnr.get_number_of_cases();
		int	number_of_variables = jnr.get_number_of_variables();
		double *	avsumx		= jnr.get_avsumx();
		double *	su			= jnr.get_su(); 
		double *	d			= jnr.get_d ();
		double		tolerance	= 0.1;
		double		Fisher_in   = 10.0;
		double		Fisher_out	= 10.0;
		vector < string >  predictor_names   = jnr.get_predictor_names();
		string			   name_of_dependent = jnr.get_name_of_dependent ();


		Reg_solution *sol = jnr.prepare_single_solution (
  			number_of_cases, 
			number_of_variables, 
			avsumx, 
			su, 
			d,
			tolerance,
			Fisher_in,
			Fisher_out,
			predictor_names,
			name_of_dependent);

				cout << "Single solution ready!!!"<< endl;

		jnr.make_plain_prediction( sol, dependent_index);

		ostringstream ost;
		ost << "DIR_tests/Reg_degbug/penta_training_5_8.r" 
			<< dependent_index ;

		string output_file_name = ost .str();

		sol->show_reg_model(
			output_file_name ,
			jnr.get_plain_correlation(),
			jnr.get_virgin_avsumx	 () 			) ;

		delete sol;



}
