#include "z_value_table.h"

double get_z_value_probfbility(const double parameter)
{
        if ( parameter >= 0 && parameter <= 4.0 )
        {
	    int index = (int) 100*parameter;
	    return z_value_table[index];
        }
	else if (parameter >= -4.0 && parameter <= 0.0 )
	{
	    int index = - (int) 100*parameter;
	    return 1-z_value_table[index];
	}
	else if (parameter > 4.0 )
	    return 1.0;
       else if (parameter < -4.0)
	    return 0.0;


}
