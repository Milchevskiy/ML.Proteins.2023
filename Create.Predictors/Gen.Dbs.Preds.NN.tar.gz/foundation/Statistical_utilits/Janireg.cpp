#pragma warning( disable : 4786 )

#include "Janireg.h"
#include "RegBase.h"
#include "Reg_solution.h"

#include "Statistic_general_purpose.h"
#include "../CommonFunc.h"

#include "../Censorship.h"
#include "Base_value_transformer.h"


#include "Inverse_c_plus_R.h"
#include "Log_c_plus_R.h"

extern ofstream		log_stream;
extern Censorship	configuration;


Janireg::
Janireg (   
		 RegBase *database, 
		 const int dependent_index,
		 const string task_string ):
 avsumx_(0),
 su_(0),
 virgin_avsumx_(0),
 virgin_su_(0),
 d_(0), 
 x_(0),
 observed_(0),
 options_ (0),
 jack_nife_prediction_(0),
 plain_prediction_(0),
 plain_correlation_ (-100),
 jack_nife_correlation_(-100),
 database_ (database),
 dep_val_transformer_ (0)
{

	string transformer_name;
 	istringstream ist( task_string );
	ist >> transformer_name ;
	if ( transformer_name  == "Inverse_c_plus_R" ) 
	{
		Base_value_transformer *dummy  = new Inverse_c_plus_R ();
		dep_val_transformer_ = dummy->clone  (task_string);
	}
	else if ( transformer_name  == "Log_c_plus_R" ) 
	{
		Base_value_transformer *dummy  = new Log_c_plus_R ();
		dep_val_transformer_ = dummy->clone  (task_string);
	}
	else 
	{
		log_stream << "strange transaformer name" << endl;
		cout       << "strange transaformer name" << endl;
		exit(-1);
	}


	 number_of_variables_	= database_->get_number_of_predictors() + 1;
	 number_of_cases_		= database_->get_number_of_records();

	 upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	 avsumx_			= new double [number_of_variables_]; 	 memset (avsumx_,0,sizeof(double)*number_of_variables_);
	 virgin_avsumx_		= new double [number_of_variables_]; 	 memset (virgin_avsumx_,0,sizeof(double)*number_of_variables_);
	 d_					= new double [number_of_variables_]; 	 memset (d_,		0,sizeof(double)*number_of_variables_);

	 int database_buffer_size = database_->get_number_of_dependent() +  database_->get_number_of_predictors();
	 x_					= new double [database_buffer_size]; 	 memset (x_,			0,sizeof(double)*database_buffer_size);
	
	 su_				= new double [upper_triange_matrix_size_]; 	 memset (su_,			0,sizeof(double)*upper_triange_matrix_size_);
	 virgin_su_			= new double [upper_triange_matrix_size_]; 	 memset (virgin_su_,	0,sizeof(double)*upper_triange_matrix_size_);

	 observed_			= new double [number_of_cases_];	 memset (observed_,	0,sizeof(double)*number_of_cases_);

	fill_up_task(dependent_index);

	predictor_names_	= database_->get_predictor_names();
	name_of_dependent_	= database_->get_dependent_names()[dependent_index];
 	
	prepare_covariation_matrix( 
		number_of_cases_,			
		number_of_variables_,		
		avsumx_,					
		su_,						
		d_)	;	

 }



Janireg::
Janireg (   RegBase *database, const int dependent_index  ):
 avsumx_(0),
 su_(0),
 virgin_avsumx_(0),
 virgin_su_(0),
 d_(0), 
 x_(0),
 observed_(0),
 options_ (0),
 jack_nife_prediction_(0),
 plain_prediction_(0),
 plain_correlation_ (-100),
 jack_nife_correlation_(-100),
 database_ (database),
 dep_val_transformer_ (0)
{
	 number_of_variables_	= database_->get_number_of_predictors() + 1;
	 number_of_cases_		= database_->get_number_of_records();

	 upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	 avsumx_			= new double [number_of_variables_]; 	 memset (avsumx_,0,sizeof(double)*number_of_variables_);
	 virgin_avsumx_		= new double [number_of_variables_]; 	 memset (virgin_avsumx_,0,sizeof(double)*number_of_variables_);
	 d_					= new double [number_of_variables_]; 	 memset (d_,		0,sizeof(double)*number_of_variables_);

	 int database_buffer_size = database_->get_number_of_dependent() +  database_->get_number_of_predictors();
	 x_					= new double [database_buffer_size]; 	 memset (x_,			0,sizeof(double)*database_buffer_size);
	
	 su_				= new double [upper_triange_matrix_size_]; 	 memset (su_,			0,sizeof(double)*upper_triange_matrix_size_);
	 virgin_su_			= new double [upper_triange_matrix_size_]; 	 memset (virgin_su_,	0,sizeof(double)*upper_triange_matrix_size_);

	 observed_			= new double [number_of_cases_];	 memset (observed_,	0,sizeof(double)*number_of_cases_);

	fill_up_task(dependent_index);

	predictor_names_	= database_->get_predictor_names();
	name_of_dependent_	= database_->get_dependent_names()[dependent_index];
 	
	prepare_covariation_matrix( 
		number_of_cases_,			
		number_of_variables_,		
		avsumx_,					
		su_,						
		d_)	;	

}

Reg_solution * Janireg::prepare_single_solution (
  		const int	number_of_cases, 
		const int	number_of_variables, 
		double *	avsumx, 
		double *	su, 
		double *	d,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out,
		const vector < string > & predictor_names,
		const string			& name_of_dependent)
{
	Reg_solution *  solution =	new		Reg_solution (
		number_of_cases, 
		number_of_variables, 
		avsumx, 
		su, 
		d,
		tolerance,
		Fisher_in,
		Fisher_out,
		predictor_names,
		name_of_dependent ) ;

	return solution;
}


void Janireg::
fill_up_task( const int dependent_index )
{
 	for (int ii=0;ii<number_of_cases_;ii++)
	{
		database_->get_record_subtle (  ii, x_,  dependent_index );

		if (dep_val_transformer_ )
			x_[ number_of_variables_ - 1 ] = dep_val_transformer_->calc_value (x_[ number_of_variables_ - 1 ]) ;

		supplement_cross_sum_matrix( 
			number_of_variables_,
			x_,	
			avsumx_, 
			su_, 
			1);  
		
		observed_[ii] = x_[ number_of_variables_ - 1 ];
	}
	memcpy( 
		virgin_avsumx_,
		avsumx_,
		number_of_variables_*sizeof (double)  );
	memcpy( 
		virgin_su_ ,
		su_ ,
		upper_triange_matrix_size_*sizeof (double)  );
}

void Janireg::
make_plain_prediction( Reg_solution *  solution, 
					  const int		dependent_index)
{
	if (! plain_prediction_ ) 
		plain_prediction_		= new double [number_of_cases_];

	for ( int kk=0; kk<number_of_cases_;kk++) 
	{
		database_->get_record_subtle (  kk, x_,  dependent_index );
		plain_prediction_ [ kk ] = solution->make_single_prediction (x_);
	}
	plain_correlation_		= calculate_correlation( 
		observed_,	plain_prediction_,		number_of_cases_);

}

void Janireg::
jack_nife_quality_estimation ( 
 const vector < vector <int> > & group_index,
 const int		dependent_index,
 const double	tolerance,
 vector < int >  & forcibly_included_index )
{
	jack_nife_prediction_	= new double [number_of_cases_];
	plain_prediction_		= new double [number_of_cases_];

	memcpy( avsumx_,virgin_avsumx_,	number_of_variables_		*sizeof (double)  );
	memcpy( su_ ,	virgin_su_,		upper_triange_matrix_size_	*sizeof (double)  );

	prepare_covariation_matrix( 
		number_of_cases_,			
		number_of_variables_,		
		avsumx_,					
		su_,						
		d_)	;	

	Reg_solution *  solution =	new		Reg_solution (
		number_of_cases_, 
		number_of_variables_, 
		avsumx_, 
		su_, 
		d_,
		tolerance,
		forcibly_included_index );

	for ( int kk=0; kk<number_of_cases_;kk++) 
	{
		database_->get_record_subtle (  kk, x_,  dependent_index );
		plain_prediction_ [ kk ] = solution->make_single_prediction (x_);
	}

	for ( int ii=0; ii< group_index.size();ii++ )
	{
		memcpy( avsumx_,virgin_avsumx_,	number_of_variables_		*sizeof (double)  );
		memcpy( su_ ,	virgin_su_,		upper_triange_matrix_size_	*sizeof (double)  );


		for (int kk=0;kk<group_index[ii].size();kk++) 
		{
			database_->get_record_subtle (  group_index[ii][kk], x_,  dependent_index );
			supplement_cross_sum_matrix( 
				number_of_variables_,
				x_,	
				avsumx_, 
				su_, 
				-1);  
		}
		solution->refresh (
			number_of_cases_ - group_index[ii].size(), 
			avsumx_, 
			su_, 
			d_);

		for ( kk=0;kk<group_index[ii].size();kk++) 
		{
			database_->get_record_subtle (  group_index[ii][kk], x_,  dependent_index );
			jack_nife_prediction_ [ group_index[ii][kk] ] = solution->make_single_prediction (x_);
		}
	}
	plain_correlation_		= calculate_correlation( 
		observed_,	plain_prediction_,		number_of_cases_);

	jack_nife_correlation_  = calculate_correlation( 
		observed_,	jack_nife_prediction_,	number_of_cases_);

	delete  solution;
}

Janireg::
~Janireg ()
{
	 if ( avsumx_			== 0)	 delete [] avsumx_;
	 if ( su_				== 0)	 delete [] su_;
	 if ( virgin_avsumx_	== 0)	 delete [] virgin_avsumx_;
	 if ( virgin_su_		== 0)	 delete [] virgin_su_;
	 if ( d_				== 0)	 delete [] d_;
	 if ( x_				== 0)	 delete [] x_;
	 if ( observed_			== 0)	 delete [] observed_;
	 if ( jack_nife_prediction_== 0) delete [] jack_nife_prediction_;
	 if ( plain_prediction_== 0)	 delete [] plain_prediction_;
}


void Janireg::
jack_nife_optimal_quality_search ()
{



}