#ifndef CALCULATE_CORRELATION_PULL_H 
#define CALCULATE_CORRELATION_PULL_H 

#include <vector>

using namespace std;

vector <double> calculate_correlation_pull (
	vector < vector < double > > & first_pull,
	vector < vector < double > > & second_pull,
	const int number_of_case );


#endif