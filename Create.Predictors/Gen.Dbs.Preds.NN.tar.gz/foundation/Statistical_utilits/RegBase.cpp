#pragma warning( disable : 4786 )

#include "RegBase.h"
#include <iostream>

#include "../CommonFunc.h"
#include "../get_names_full_string_from_file.h"

extern ofstream log_stream;

RegBase::
RegBase  ( const string & name ) :
 name_                   (name),
 number_of_predictors_	(-1),
 number_of_dependent_	(-1),
 number_of_records_		(-1),  
 data_origin_pos_		(-1),  
 record_length_			(-1),
 local_read_buffer_		(0)
{
	init_base_insight	();
	fill_up_names		();

	local_read_buffer_ = new double[ number_of_predictors_ + number_of_dependent_ ];
}
RegBase::~RegBase ()
{
	if ( local_read_buffer_ ) 		delete [] local_read_buffer_;
	if ( binary_base_stream_ )		binary_base_stream_.close(); 
}

void RegBase::
init_base_insight ()
{	
   	binary_base_stream_.open  ( name_.c_str(),ios::binary );
	if ( ! binary_base_stream_)	{	
		log_stream << "Frequency: ERROR -  can't find binary name_ file" << name_<< endl;
		cout       << "Frequency: ERROR -  can't find binary name_" << name_<< endl;
		exit (1);	
	}

   binary_base_stream_.read (  (char* ) & number_of_predictors_, sizeof (int) );
   binary_base_stream_.read (  (char* ) & number_of_dependent_,  sizeof (int) );

   data_origin_pos_ = 2*sizeof (int);  // keep in mind 
   record_length_   = (number_of_predictors_ + number_of_dependent_)*sizeof (double);

   binary_base_stream_.seekg(0,ios::end);
   long int filelength = binary_base_stream_.tellg();
   binary_base_stream_.seekg(0,ios::beg);
   number_of_records_ = filelength/record_length_ ;
}
bool RegBase::
get_record (  int index, double *record )
{
	binary_base_stream_.seekg(0);

   int position = data_origin_pos_+ index*record_length_;
   binary_base_stream_.seekg(position,ios::beg);
   binary_base_stream_.read ( (char* ) record,(number_of_predictors_ + number_of_dependent_)*sizeof (double)  );

   if (binary_base_stream_.good() )		   return true;
   else 								   return false;
}

// �� ������ ���������, ������ �� �����, ������� ������� ��� �������
bool RegBase::
get_record_subtle (  int index, double *record, int dependent_index )
{
   get_record (  index, record );
   record [number_of_predictors_] = record [number_of_predictors_ + dependent_index];

   if (binary_base_stream_.good() )		   return true;
   else 								   return false;
}

void RegBase::
fill_up_names ()
{
	string predictor_file_source = new_extension_file_name_from_tail (name_,"predictor_names" );
	string dependent_file_source = new_extension_file_name_from_tail (name_,"dependent_names" );

	predictor_names_ = get_names_full_string_from_file ( predictor_file_source );
	dependent_names_ = get_names_full_string_from_file ( dependent_file_source );
}
