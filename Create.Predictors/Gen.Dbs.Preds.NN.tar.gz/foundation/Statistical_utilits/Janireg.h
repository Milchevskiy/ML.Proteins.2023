#ifndef JANIREG_H
#define JANIREG_H

#include <vector>
#include <string>
#include <fstream>

//#include "Reg_solution.h"

using namespace std;

class	Reg_solution;
class	Sheduler;
class	RegBase;
class	Base_value_transformer; 

class Janireg
{
public:
	Janireg (   
		 RegBase *database, 
		 const int dependent_index,
		 const string task_string );
 
	Janireg (   
		RegBase *database, 
		const int dependent_index  );

	~Janireg ();

	int			get_number_of_cases()		const { return number_of_cases_;} ;
	int			get_number_of_variables()	const { return number_of_variables_;} ;;

	double *	get_avsumx()				const { return avsumx_;} ;;
	double *	get_su()					const { return su_;} ;;
	double *	get_d ()					const { return d_;} ;;

	vector < string > get_predictor_names   () const { return predictor_names_;}
	string			  get_name_of_dependent () const { return name_of_dependent_;} 


	void jack_nife_optimal_quality_search ();


	Reg_solution * prepare_single_solution (
  		const int	number_of_cases, 
		const int	number_of_variables, 
		double *	avsumx, 
		double *	su, 
		double *	d,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out,
		const vector < string > & predictor_names,
		const string			& name_of_dependent); 

	void jack_nife_quality_estimation ( 
		 const vector < vector <int> > & group_index,
		 const int		dependent_index,
		 const double	tolerance,
		 vector < int >  & forcibly_included_index );

	void make_plain_prediction( Reg_solution *  solution, 
					  const int		dependent_index);


	double * get_observed				() const {return observed_;} 
	double * get_jack_nife_prediction	() const {return jack_nife_prediction_;} 
	double * get_plain_prediction		() const {return plain_prediction_;} 
	double * get_virgin_avsumx			() const { return virgin_avsumx_;} 


	double get_plain_correlation		() const { return plain_correlation_;} 
	double get_jack_nife_correlation	() const { return jack_nife_correlation_;} 


private:
	int				number_of_variables_;
	int				number_of_cases_		;
	int				number_of_included_;
	vector < int >  index_of_included_;
	int				upper_triange_matrix_size_;

//	std::vector < std::vector < double> >	task_set_matrix_;

	vector < string > predictor_names_;
    string			  name_of_dependent_;

	RegBase *database_; 
	
	double *avsumx_;
	double *su_;

	double *virgin_avsumx_;
	double *virgin_su_;

	double *d_;
	double *x_;

	double *observed_;
	double *jack_nife_prediction_;
	double *plain_prediction_;

	double plain_correlation_;
	double jack_nife_correlation_;


	Sheduler		*options_ ;


	Base_value_transformer * dep_val_transformer_;


	void fill_up_task( const int dependent_index );



};


#endif