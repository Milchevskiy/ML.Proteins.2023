#ifndef BASE_VALUE_TRANSFORMER_H
#define BASE_VALUE_TRANSFORMER_H

#include	<string>

using namespace std;

class  Base_value_transformer
{
public:
	Base_value_transformer():
	 value_( 0 ) 
	{}

	virtual			~Base_value_transformer() ;
	virtual			Base_value_transformer* clone (const string & task_string ) const					= 0;

	virtual double calc_value ( double seed) = 0;

protected:	
	double	value_;
	string	name_;

};

#endif
