#pragma warning( disable : 4786 )

#include "fill_up_whole_string_names_from_respective_file.h"
#include <fstream>
#include <iostream>
#include <cassert>
#include <cstdlib>
extern ofstream		log_stream;

vector <string > fill_up_whole_string_names_from_respective_file ( const string & file_name )
{
	ifstream  in( file_name .c_str() );
	if ( ! in)
	{
		cout       << "can't find file "  << file_name << endl;
		log_stream << "can't find file "  << file_name << endl;
		assert (  in);
		exit (1);
	}
	vector < string >   names ;

	string current_line;
	while ( getline(in,current_line,'\n' ) )
	{
		if (   current_line[0] == '/'  ||
		       current_line[0] == '#'  ||
		       current_line[0] == ' '  ||
		       current_line[0] == '\n' ||
		       current_line[0] == '\0'  )
		  continue;

		names.push_back( current_line );
	}

	return names;
}

