#ifndef INVERSE_C_PLUS_R_H
#define INVERSE_C_PLUS_R_H

#ifndef BASE_VALUE_TRANSFORMER_H
#include "Base_value_transformer.h"
#endif

#include <string>
#include <vector>

class  Inverse_c_plus_R: public Base_value_transformer
{
public:
	Inverse_c_plus_R() {} ;

	explicit Inverse_c_plus_R ( const string & task_string  );
    Base_value_transformer*		clone	( const string & task_string  ) const;
	
	double   calc_value ( double seed)  ;

protected:

	double add_constant_;
	double power_R_;
	double power_G_;

	Inverse_c_plus_R(const Inverse_c_plus_R&);
	Inverse_c_plus_R& operator = (const Inverse_c_plus_R&);
};

#endif