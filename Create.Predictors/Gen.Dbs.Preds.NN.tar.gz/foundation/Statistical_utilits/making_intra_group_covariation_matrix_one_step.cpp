#include "Statistic_general_purpose.h"

using namespace std;

void making_intra_group_covariation_matrix_one_step 
(	const int wcount,
	vector < double > & current_values,
	vector < double > & group_average_value,
	int  & case_group_index,
	vector < double > & marix_w)
{
	vector < double > new_group_average_value = group_average_value;

	case_group_index ++;

	for ( int ii=0;ii<wcount;ii++ )
		new_group_average_value[ii]  = ( ( case_group_index - 1 ) * group_average_value[ii] + current_values[ii] ) / case_group_index;

	for ( int    ii=0;ii<wcount;ii++ )
		for (int jj=ii; jj<wcount;jj++)
			marix_w[ one_dimensional_matrix_index (ii,jj,wcount) ] += ( current_values[ii] - group_average_value[ii] ) * ( current_values[jj] - new_group_average_value[jj] );

	group_average_value = new_group_average_value;

}

