#include "Statistic_new_test.h"

#include "../CommonFunc.h"
#include "../Sheduler.h"


#include "Statistic_general_purpose.h"

#include <fstream>
#include <iostream>
#include <cmath>
#include <cstdlib>

#include "../Fragment_base/accepted_chain_data.h"
#include  "../Censorship.h"

#include "../Main_model/handle_det_distance_set.h"

#include "../get_nearest_claster_index.h"
#include "standardize_first_to_second.h"

#include <cassert>

#include "calc_dispersion_and_average.h"

using namespace std;

extern ofstream log_stream;


extern Censorship configuration;


double z_value_dummy (double x );


 void  get_moments (
        string & path_to_moments
        //,
//        vector <string> & av,
 //       vector <string> & si
 );

void dummy_get_moments(
    string &fina,
    vector <double> & av,
    vector <double> & si    );


Statistic_new_test::
~Statistic_new_test()
{
	cout << "Statistic_new_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}
void Statistic_new_test:: erf_test()
 {


 	ofstream output ( "../Test/etf_table.txt");
	if ( ! output )
	{
		log_stream	<< "can't create " << endl;
		cout		 << "can't create " << endl;
		exit (1);
	}
   double param, result;

  double left_border = -4.0;
  double right_border = 4.0;
  double step = 0.1;

  double cursor = left_border;

  while ( cursor < right_border)
  {
    result = erf (cursor);

    PutVaDouble(cursor,output,8,3,'l');
    PutVaDouble(result,output,8,5,'l');

    double prob = (result+1)/2; output << "\t";
    PutVaDouble(prob,output,8,5,'l');output << "\t";

    double z_value = z_value_dummy(cursor);
    PutVaDouble(z_value,output,8,5,'l');

    output << endl;
    cursor += step;
  }



 }

 double z_value_dummy (double x )
 {

  double sum =0;

  double left_border = -4.0;
  double right_border = x;
  double step = 0.0000001;

  double cursor = left_border;

  static double A_const = step/ ( sqrt(2.0*Pythagorean_Number() ) );

  while ( cursor < right_border)
  {
    double average_cursor = cursor - step/2;
    double add = A_const * exp (-average_cursor*average_cursor/2) ;
    sum += add;

    cursor += step;
  }

  return sum;

 }
void Statistic_new_test::
get_z_value_probfbility_test()
 {

    double test1 = get_z_value_probfbility(1.3);

    double test2 = get_z_value_probfbility(-1.3);


     double test3 = get_z_value_probfbility(-5);

      double test4 = get_z_value_probfbility(5);



    cout << test1<<test2 << endl;


 }
void Statistic_new_test::
prepare_cluster_distribution_test( )
{
    string ext =  string (".dist_data");

    //string ext =  string (".dist_data_predicted");

    int CLUSTER_NUMBER_SWTTED = 16;

    string name =  string("PB_10");

	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/") + string("sheduler");
	Sheduler *sheduler_		= new Sheduler     (path_current) ;

	string chain_ID_file_name = sheduler_->option_meaning("CHAIN_LIST");
	vector <string> PDB_chain_ID_list;


	fill_up_accepted_chain_data_text (		PDB_chain_ID_list,		 chain_ID_file_name );


	string path_to_dist_data_store =
		configuration.option_meaning("Path_to_Model_store") +
		name					+		"/cross_sum/";

	int wrong_struct_number = 0;
	int accepted_struct_number = 0;

	vector <int> cluster_distribution ;
	cluster_distribution.resize(CLUSTER_NUMBER_SWTTED);

	vector <double> ss; ss.resize(CLUSTER_NUMBER_SWTTED);
	vector <double> ss2; ss2.resize(CLUSTER_NUMBER_SWTTED);

    int number_of_clasters;


	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
//    for (int ii=0;ii<10;ii++)
	{
       // string path_to_dist_data_file = path_to_dist_data_store + PDB_chain_ID_list[ii] + string (".dist_data");
        string path_to_dist_data_file = path_to_dist_data_store + PDB_chain_ID_list[ii] + ext;


        vector < vector < double > >    det_distance_set     =        read_det_distance_set (path_to_dist_data_file);

        number_of_clasters =  det_distance_set[0].size()/2;

        assert (CLUSTER_NUMBER_SWTTED == number_of_clasters);

        for (int kk=0; kk<det_distance_set.size();kk++)
        {

       		det_distance_set[kk].resize(number_of_clasters);

       		if (det_distance_set[kk][0] == -1.0 )  // FIX STRONG ATTENSION
			{

				wrong_struct_number ++ ;
			}
			else
            {
                accepted_struct_number++;


                int nearest_index =	get_nearest_claster_index(			det_distance_set[kk]);

                cluster_distribution [nearest_index] ++;

                for (int zzz=0;zzz<number_of_clasters;zzz++)
                {
                    ss[zzz]     += det_distance_set[kk][zzz];
                    ss2[zzz]    += det_distance_set[kk][zzz]*det_distance_set[kk][zzz];
                }


			}
        }


        cout << ii << " " <<  PDB_chain_ID_list[ii] <<   endl;
	}
    vector <double> average;    average.resize(number_of_clasters);
    vector <double> sigma;      sigma.  resize(number_of_clasters);

    for (int zzz=0;zzz<number_of_clasters;zzz++)
    {
        double av1= ss[zzz];
        double s1 = ss2[zzz];
        int casenum = accepted_struct_number;

        calc_dispersion_and_average_by_known_sums (
                av1,
                s1,
                casenum,
                average[zzz],
                sigma[zzz] );


    }

    string dist_data_moments = path_to_dist_data_store + "moments" + ext;

    ofstream out(dist_data_moments.c_str());
	if(!out)
	{
		log_stream	<< dist_data_moments << "can't find "  << endl;
		cout		 << dist_data_moments << "can't find " << endl;
		exit(1);
	}

//      out << "accepted_struct_number "  << accepted_struct_number << "\t";
//      out << "wrong_struct_number "     << wrong_struct_number << endl;
/*
    out << "sum x :" << endl;
    for (int zzz=0;zzz<number_of_clasters;zzz++)
    {
        PutVaDouble (ss[zzz],out,10,3,'l'); out << "\t";
    }
    out << endl;

    out << "sum x*x :" << endl;
    for (int zzz=0;zzz<number_of_clasters;zzz++)
    {
        PutVaDouble (ss2[zzz],out,10,3,'l'); out << "\t";
    }
    out << endl;
*/
//    out << "average:" << endl;

    out << number_of_clasters << endl;

    for (int zzz=0;zzz<number_of_clasters;zzz++)
    {
        PutVaDouble (average[zzz],out,10,6,'l'); out << "\t";
    }
    out << endl;

//    out << "sigma:" << endl;
    for (int zzz=0;zzz<number_of_clasters;zzz++)
    {
        PutVaDouble (sigma[zzz],out,10,6,'l'); out << "\t";
    }
    out << endl;

//    out << "percentage:" << endl;
    for (int zzz=0;zzz<number_of_clasters;zzz++)
    {
        PutVaDouble (  (double) cluster_distribution[zzz]*100/accepted_struct_number,out,10,6,'l'); out << "\t";
    }
    out << endl;



	delete sheduler_;
}

void Statistic_new_test::
 analyse_and_correction_prediction_by_known_moments ()
 {

    int CLUSTER_NUMBER_SWTTED = 16;

    string name =  string("PB_10");

	string path_current = configuration.option_meaning("Path_to_Model_store") + name + string("/") + string("sheduler");
	Sheduler *sheduler_		= new Sheduler     (path_current) ;

	string chain_ID_file_name = sheduler_->option_meaning("CHAIN_LIST");
	vector <string> PDB_chain_ID_list;


	fill_up_accepted_chain_data_text (		PDB_chain_ID_list,		 chain_ID_file_name );


	string path_to_dist_data_store =
		configuration.option_meaning("Path_to_Model_store") +
		name					+		"/cross_sum/";

     string path_to_predicted_moments    = path_to_dist_data_store + string("moments.dist_data_predicted");
    string path_to_observed_moments     = path_to_dist_data_store + string("moments.dist_data");


    vector < double > av_predicted;
    vector < double > si_predicted;

    vector < double > av_observed;
    vector < double > si_observed;


    dummy_get_moments(
        path_to_predicted_moments,
        av_predicted,
        si_predicted);

      dummy_get_moments(
        path_to_observed_moments,
        av_observed,
        si_observed);



        string protocol_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name + 		string ("/plain_results/") +
			 string ("protocol_corrected") ;

		ofstream protocol_stream( protocol_file_name .c_str() ,ios::binary);
		if ( ! protocol_stream	)
		{
			log_stream << "protocol_file_name   can't create " << protocol_file_name<< endl;
			cout       << "protocol_file_name   can't create " << protocol_file_name<< endl;
			exit (1);
		}

	for (int ii=0;ii<PDB_chain_ID_list.size();ii++)
	{

        string result_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			name + 		string ("/plain_results/") +
			PDB_chain_ID_list[ii] + string (".moments_corrected_prediction") ;


		ofstream out( result_file_name .c_str() ,ios::binary);
		if ( ! out	)
		{
			log_stream << "result_file_name   can't create " << result_file_name<< endl;
			cout       << "result_file_name   can't create " << result_file_name<< endl;
			exit (1);
		}


        //single_analyse_and_correction_by_known_moments (PDB_chain_ID_list[ii]);

        string path_to_observed     = path_to_dist_data_store + PDB_chain_ID_list[ii] + string (".dist_data");
        string path_to_predicted    = path_to_dist_data_store + PDB_chain_ID_list[ii] + string (".dist_data_predicted");


        vector < vector < double > >    observed        =        read_det_distance_set (path_to_observed);
         vector < vector < double > >   predicted       =        read_det_distance_set (path_to_predicted);

        int number_of_clasters =  observed[0].size()/2;

        assert (CLUSTER_NUMBER_SWTTED == number_of_clasters);

        vector <double> corrected; corrected.resize(number_of_clasters);

        double quality_corrected = 0;
        double quality = 0;

		double wrong_struct_number = 0;


        vector < vector <int > > quality_matrix ;
		quality_matrix.resize (number_of_clasters) ;
		for (int kk=0;kk<number_of_clasters;kk++)
			quality_matrix[kk].resize(number_of_clasters);

        vector < vector <int > > quality_matrix_corrected ;
		quality_matrix_corrected.resize (number_of_clasters) ;
		for (int kk=0;kk<number_of_clasters;kk++)
			quality_matrix_corrected[kk].resize(number_of_clasters);



        for (int kk=0; kk<observed.size();kk++)
        {

            observed[kk].resize(number_of_clasters);
       		predicted[kk].resize(number_of_clasters);

            int nearest_index =
				get_nearest_claster_index(			observed[kk]);

			int predicted_nearest_index =
				get_nearest_claster_index(			predicted[kk]);

			for (int zzz=0;zzz<number_of_clasters;zzz++)
			{
                corrected[zzz]=standardize_first_to_second_for_known_moments (
                            predicted   [kk][zzz] ,
                            av_predicted    [zzz],
                            si_predicted    [zzz],
                            av_observed     [zzz],
                            si_observed     [zzz]);
			}

            int corrected_nearest_index =
				get_nearest_claster_index(			corrected );

            PutVa (predicted_nearest_index,out,4,2,'l');
            PutVa (corrected_nearest_index,out,4,2,'l');

       		if (observed[kk][0] == -1.0 )  // FIX STRONG ATTENSION
			{
                PutVa ("*",out,4,2,'l');
				wrong_struct_number ++ ;
			}
			else
			{
				PutVa (nearest_index ,out,4,2,'l');

				quality_matrix              [nearest_index][predicted_nearest_index ] ++;
				quality_matrix_corrected    [nearest_index][corrected_nearest_index ] ++;

				if ( predicted_nearest_index == nearest_index )
					quality +=1;


				if ( corrected_nearest_index == nearest_index )
					quality_corrected +=1;

			}

			out << endl;

        }

        out << "*****************************" << endl;
		out << "Quality predition matrix" << endl;
		for ( int zz=0;zz<number_of_clasters;zz++)
		{
			for (int jj=0;jj<number_of_clasters;jj++)
				PutVa( 	quality_matrix[zz][jj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << observed.size() - wrong_struct_number << " of " << observed.size()<< endl;
		if (quality == 0.0 )
            out << "Quality: " << 0 << endl;
        else
            out << "Quality: " << quality/ ( observed.size() - wrong_struct_number ) << endl;



        out << "*****************************" << endl;
		out << "Corrected quality predition matrix" << endl;
		for (int  zz=0;zz<number_of_clasters;zz++)
		{
			for (int jj=0;jj<number_of_clasters;jj++)
				PutVa( 	quality_matrix_corrected[zz][jj],	out, 8,3,'l');
			out << endl;
		}
		out << "Length: " << observed.size() - wrong_struct_number << " of " << observed.size()<< endl;
		if (quality_corrected==0)
             out << "Quality: " << 0 << endl;
        else
            out << "Quality: " << quality_corrected/ ( observed.size() - wrong_struct_number ) << endl;


       	if (quality_corrected==0)

           PutVaDouble ( 0,protocol_stream,8,3,'l');
        else
            PutVaDouble ( quality_corrected/ ( observed.size() - wrong_struct_number ),protocol_stream,8,3,'l');


		protocol_stream << PDB_chain_ID_list[ii] << " ";
		protocol_stream << "Length: " << observed.size() - wrong_struct_number << " of " << observed.size()<< endl;


        cout << PDB_chain_ID_list[ii] << endl;
    }

 }

 void  get_moments (
        string & path_to_moments
        //,
        //vector <string> & av,
        //vector <string> & si
         )

{

		ifstream in_stream(path_to_moments.c_str() );
		if ( ! in_stream)
		{
			log_stream << "get_moments () ERROR -  can't find " << path_to_moments<< endl;
			cout       << "get_moments () ERROR -  can't find " << path_to_moments<< endl;
			exit (1);
		}

/*
        int number_of_clasters;
        in_stream >> number_of_clasters;

        av.resize(number_of_clasters);
        si.resize(number_of_clasters);

        for (int ii=0;ii<number_of_clasters;ii++)
            in_stream >>av[ii];

        for (int ii=0;ii<number_of_clasters;ii++)
            in_stream >>si[ii];

        in_stream.close();
        */
}

void Statistic_new_test::
dummy_get_moment_test()
{
  string name =  string("PB_10");

	string path_to_dist_data_store =
		configuration.option_meaning("Path_to_Model_store") +
		name					+		"/cross_sum/";


	string result_file = 	path_to_dist_data_store + "moments.compare";

	ofstream output ( result_file.c_str());
	if ( ! output )
	{
		log_stream	<< "can't create " << endl;
		cout		 << "can't create " << endl;
		exit (1);
	}

    string path_to_predicted_moments    = path_to_dist_data_store + string("moments.dist_data_predicted");
    string path_to_observed_moments     = path_to_dist_data_store + string("moments.dist_data");


    vector < double > av_predicted;
    vector < double > si_predicted;

    vector < double > av_observed;
    vector < double > si_observed;


    dummy_get_moments(
        path_to_predicted_moments,
        av_predicted,
        si_predicted);

      dummy_get_moments(
        path_to_observed_moments,
        av_observed,
        si_observed);


      output << "1: average predicted; 2: average predicted; 3: predicted/observed; " << endl;
      for (int ii=0; ii<av_predicted.size();ii++)
        PutVaDouble(av_predicted[ii],output,8,3,'l');
      output << endl;

      for (int ii=0; ii<av_predicted.size();ii++)
        PutVaDouble(av_observed[ii],output,8,3,'l');
      output << endl;


      for (int ii=0; ii<av_predicted.size();ii++)
        PutVaDouble(av_predicted[ii]/av_observed[ii],output,8,3,'l');
      output << endl;


    output << "1: st. dev.  predicted; 2: st. dev. predicted; 3: st. dev. predicted/observed; " << endl;
      for (int ii=0; ii<av_predicted.size();ii++)
        PutVaDouble(si_predicted[ii],output,8,3,'l');
      output << endl;

      for (int ii=0; ii<av_predicted.size();ii++)
        PutVaDouble(si_observed[ii],output,8,3,'l');
      output << endl;


      for (int ii=0; ii<av_predicted.size();ii++)
        PutVaDouble(si_predicted[ii]/si_observed[ii],output,8,3,'l');
      output << endl;




}

void dummy_get_moments(
    string &fina,
    vector <double> & av,
    vector <double> & si    )
{

    	ifstream in_stream(fina.c_str() );
		if ( ! in_stream)
		{
			log_stream << "get_moments () ERROR -  can't find " << fina<< endl;
			cout       << "get_moments () ERROR -  can't find " << fina<< endl;
			exit (1);
		}

		int number_of_clasters;
        in_stream >> number_of_clasters;


        av.resize(number_of_clasters);
        si.resize(number_of_clasters);

        for (int ii=0;ii<number_of_clasters;ii++)
            in_stream >>av[ii];

        for (int ii=0;ii<number_of_clasters;ii++)
            in_stream >>si[ii];


}
