#ifndef CHARMING_REG_SOLUTION_H
#define CHARMING_REG_SOLUTION_H

#include <vector>
#include <string>
#include <fstream>

using namespace std;

class Sheduler;

class  charming_Reg_solution
{
public:

	~charming_Reg_solution ();

	charming_Reg_solution (
		 const string & binary_data_file_name,
		 const Sheduler			*regression_options ) ;


	charming_Reg_solution (
		 const string & binary_data_file_name,
		 const Sheduler			*regression_options,
		 const vector <vector <int> > & index_of_included_pool ) ;
/*
	charming_Reg_solution (
		const double *avsumx_,
		const double *su_,
		const int number_of_cases_,
		const int number_of_predictors,
		const int number_of_dependent,
		const vector <vector <int> > & index_of_included_pool,
		const double tolerance);
*/
	void show_plain_results (
		const string & predictor_file,
		const string & dependent_file,
		const string & result_file_name_base );


	void show_plain_results (
		const vector <string > & predictor_files,
		const string & dependent_file,
		const string & result_file_name_base);


	vector <vector <int> > get_index_of_included_pool () const { return index_of_included_pool_;}

	double * get_glob_avsumx	() const { return glob_avsumx_; }
	double * get_glob_su		() const { return glob_su_; }

	int get_number_of_cases     () const {  return number_of_cases_;    }
    int get_number_of_predictor () const {  return number_of_predictor_;}
	int get_number_of_dependent () const {  return number_of_dependent_;}


	double ** get_regression_coefficient_pool	() const { return regression_coefficient_pool_; }
	double *  get_absolute_term_pool			() const { return absolute_term_pool_; }

	double * get_regression_coefficient	( const int dependent_index ) const { return regression_coefficient_pool_[dependent_index]; }
	double   get_absolute_term			(const int dependent_index  ) const { return absolute_term_pool_[dependent_index]; }

	vector < double > make_single_prediction_vector ( const vector <double> & record );




private:
	int number_of_cases_;
//	int number_of_variables_;
	int number_of_predictor_;
	int number_of_dependent_;

	double * glob_avsumx_;
	double * glob_d_;
	double * glob_su_;

	double ** regression_coefficient_pool_;
	double ** standard_errror_of_regression_coefficient_pool_;
	double *  absolute_term_pool_;

	vector <vector <int> > index_of_included_pool_;

	void shake_down_for_single_dependent (
		const int	dep_index,
		double *avsumx,
		double *su,
		double *d);

	void allocate_solution_pool ();

	vector <double> make_Fisher_values ( const int current_index );


//	vector < double > make_single_prediction_vector ( const vector <double> & record );
};

#endif

// format of data file
// number_of_predictor_ number_of_predictor_  number_of_dependent_
