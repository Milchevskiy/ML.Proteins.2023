#pragma warning( disable : 4786 )

#include "Base_value_transformer.h"

Base_value_transformer::~Base_value_transformer()  
{

}