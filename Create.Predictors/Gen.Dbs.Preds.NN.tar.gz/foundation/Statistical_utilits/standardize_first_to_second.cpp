#include "standardize_first_to_second.h"
#include "calc_dispersion_and_average.h"

using namespace std;

vector < double > standardize_first_to_second (
	vector < double > & x ,
	vector < double > & y)
{
	double av_x, si_x, av_y, si_y;
	calc_dispersion_and_average ( 	x,	av_x, si_x);

	calc_dispersion_and_average ( 	y,	av_y, si_y);

	int task_size = x.size();
	vector < double > z; z.resize(task_size);

	double add = av_y - av_x*si_y/si_x;
	double koef = si_y/si_x;

	for (int ii=0; ii< task_size; ii++ )
		z[ii] = x[ii]* koef + add;

	return z;

}

///The first parameter is assumed to be the predicted value.
/*
	double  & x ,   -
	double  & av_x ,    known average for predicted value (taken from regression model)
	double  & si_x ,    known standard deviation for predicted value (taken from regression model)
	double  & av_y ,     -- ----------------------for observed --
	double  & si_y       -- ----------------------for observed --
*/

double  standardize_first_to_second_for_known_moments (
	double  & x ,
	double  & av_x ,
	double  & si_x ,
	double  & av_y ,
	double  & si_y )
{
	double add = av_y - av_x*si_y/si_x;
	double koef = si_y/si_x;

	double z;

	z = x* koef + add;

	return z;
}
