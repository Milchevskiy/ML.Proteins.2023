#ifndef REGBASE_TEST_H
#define REGBASE_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  RegBase_test: public Simple_test
{
public:
	~RegBase_test();

    void run()
    {
		prepare_data();
	}
	void prepare_data();
};

#endif
