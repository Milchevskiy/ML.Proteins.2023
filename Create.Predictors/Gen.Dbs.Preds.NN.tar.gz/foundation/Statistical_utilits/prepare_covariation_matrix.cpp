//**********************************************************************
//      COVARIATIION MATRIX CALCULATION 
//      filling up array d[] for futher usage during stepwise procedure
//      VERSION WITHOUT PAIR frequency CALCULATION
//**********************************************************************

#include <vector>

using namespace std;

void prepare_covariation_matrix( 
	const int recordnum, 
	const int wc, 
	vector <double> & avsumx, 
	vector <double> & su, 
	vector <double> & d ) 
{
	int ij=0;
	long lt=recordnum*(recordnum-1);

	for(int i=0;i <wc ;i++) 
	{
		 for(int j=i;j <wc ;j++) 
		 {
			  su[ij]=recordnum*su[ij]-avsumx[i]*avsumx[j];
		//	  su[ij]/=lt;
			  su[ij]/=recordnum;
			  su[ij]/=(recordnum-1);

			  if(i==j) 
				  d[i]=su[ij];
			  ij++;
		}
		avsumx[i]=avsumx[i]/recordnum;
	}
}



void prepare_covariation_matrix( 
	const int recordnum, 
	const int wc, 
	double * avsumx, 
	double * su, 
	double *  d ) 
{
	int ij=0;
	long lt=recordnum*(recordnum-1);

	for(int i=0;i <wc ;i++) 
	{
		 for(int j=i;j <wc ;j++) 
		 {
			  su[ij]=recordnum*su[ij]-avsumx[i]*avsumx[j];

			  su[ij]/=recordnum;
			  su[ij]/=(recordnum-1);

			  if(i==j) d[i]=su[ij];
			  ij++;
		}
		avsumx[i]=avsumx[i]/recordnum;
	}
}

