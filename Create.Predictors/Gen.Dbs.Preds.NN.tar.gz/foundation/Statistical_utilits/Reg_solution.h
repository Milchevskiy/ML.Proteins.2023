#ifndef REG_SOLUTION_H
#define REG_SOLUTION_H

#include <vector>
#include <string>
//#include <fstream>

using namespace std;

//class	Sheduler;

class  Reg_solution
{
public:


// Variant for ready su_ & avsumx
	Reg_solution (
   		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out);


	Reg_solution (
   		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		const double		tolerance,
		const vector < int > & forcibly_included_index) ;


	Reg_solution (
 	    const string chewed_data_file_name,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out );

	Reg_solution (
  		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		double *	d,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out,
		const vector < string > & predictor_names,
		const string			& name_of_dependent);

	Reg_solution  () {};

	Reg_solution  (
  		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		double *	d,
		const double		tolerance,
		const vector < int > & forcibly_included_index );

	void  refresh (
		const int	number_of_cases,
		double *	avsumx,
		double *	su,
		double *	d);

	~Reg_solution ();

	void show_reg_model ( const string & filename,
		const double plain_correlation,
		const double *virgin_avsumx ) ;

	void show_reg_model ( const string & filename,
		const double plain_correlation	) ;

	void show_reg_model_plain ( const string & filename);

	double 	make_single_prediction	( const double * record );
	double 	make_single_prediction  ( const vector <double>  & record );

	int				get_number_of_included		() const { return 	number_of_included_ ;	}
	vector < int >	get_index_of_included		() const { return	index_of_included_;		}

	void assign_predictor_names_from_file		( const string chewed_data_file_name );
	void assign_name_of_dependent_from_file		( const string chewed_data_file_name );

	double *	get_regression_coefficient						() const { return regression_coefficient_;                   }
	double *	get_standard_errror_of_regression_coefficient	() const { return standard_errror_of_regression_coefficient_;}
	double		get_absolute_term								() const { return 	absolute_term_;							 }



private:
	int number_of_cases_;
	int number_of_variables_;
	int number_of_included_;

	int upper_triange_matrix_size_;

	vector < int > index_of_included_;

	double *	avsumx_;
	double *	su_;
	double *	d_;

	double *	x_; // subsidiary

	vector < string >  predictor_names_;
	string			   name_of_dependent_;

	double *	regression_coefficient_;
	double *	standard_errror_of_regression_coefficient_;
	double		absolute_term_;

	double		tolerance_;
	double		Fisher_in_;
	double		Fisher_out_	;

	vector < int >forcibly_included_index_;

	bool	pedantic_selvar (int & FLAG,int & K);
	void	fill_up_solution ();


//	void assign_predictor_names_from_file		( const string chewed_data_file_name );
//	void assign_name_of_dependent_from_file		( const string chewed_data_file_name );

};

#endif
