#ifndef LOG_C_PLUS_R_H
#define LOG_C_PLUS_R_H

#ifndef BASE_VALUE_TRANSFORMER_H
#include "Base_value_transformer.h"
#endif

#include <string>
#include <vector>

class  Log_c_plus_R: public Base_value_transformer
{
public:
	Log_c_plus_R() {} ;

	explicit Log_c_plus_R ( const string & task_string  );
    Base_value_transformer*		clone	( const string & task_string  ) const;
	
	double   calc_value ( double seed)  ;

protected:

	double add_constant_;
	double power_R_;
	double power_G_;

	Log_c_plus_R(const Log_c_plus_R&);
	Log_c_plus_R& operator = (const Log_c_plus_R&);
};

#endif