#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "charming_Reg_solution.h"
#include "Statistic_general_purpose.h"
#include "Reg_solution.h"
#include "../Sheduler.h"
#include "../CommonFunc.h"

#include "../Pair_int_double.h"

#include <iostream>
#include <sstream>

#include "fill_up_whole_string_names_from_respective_file.h"


extern ofstream		log_stream;

charming_Reg_solution::
charming_Reg_solution (
 const string & binary_data_file_name,
 const Sheduler			*regression_options ) :
	number_of_cases_								(0),
	number_of_predictor_							(0),
	number_of_dependent_							(0),
	glob_avsumx_									(0),
	glob_d_											(0),
	glob_su_										(0),
	regression_coefficient_pool_					(0),
	standard_errror_of_regression_coefficient_pool_	(0),
	absolute_term_pool_								(0)

{
	ifstream regdata_stream ( binary_data_file_name.c_str() ,ios::binary);
	if ( ! regdata_stream )
	{
		log_stream	<< "charming_Reg_solution: ERROR		-  can't read datafile for constructor " << binary_data_file_name << endl;
		cout		<< "charming_Reg_solution: ERROR		-  can't read datafile for constructor " << binary_data_file_name << endl;
		exit (1);
	}
	regdata_stream.read ( (char* ) & number_of_predictor_,	sizeof (int)  );
	regdata_stream.read ( (char* ) & number_of_dependent_,	sizeof (int)  );
	regdata_stream.read ( (char* ) & number_of_cases_,		sizeof (int)  );

	int nu_of_pred_and_dep = number_of_predictor_ + number_of_dependent_;

	glob_avsumx_		= new double [nu_of_pred_and_dep]; 	 memset (glob_avsumx_,0,sizeof(double)*nu_of_pred_and_dep);
	glob_d_				= new double [nu_of_pred_and_dep]; 	 memset (glob_d_,0,sizeof(double)	 *nu_of_pred_and_dep);

	int global_upper_triange_matrix_size = nu_of_pred_and_dep*(nu_of_pred_and_dep+1)/2;
	glob_su_				= new double [global_upper_triange_matrix_size]; 	 memset (glob_su_,			0,sizeof(double)*global_upper_triange_matrix_size);

	regdata_stream.read ( (char* )  glob_avsumx_,			nu_of_pred_and_dep* sizeof (double)  );
	regdata_stream.read ( (char* )  glob_su_,				global_upper_triange_matrix_size			* sizeof (double)  );

	double *avsumx		= new double [nu_of_pred_and_dep]; 				memset (avsumx,0,sizeof(double)*nu_of_pred_and_dep);
	double *d			= new double [nu_of_pred_and_dep]; 				memset (d,		0,sizeof(double) *nu_of_pred_and_dep);
	double *su			= new double [global_upper_triange_matrix_size]; 	memset (su,		0,sizeof(double)*global_upper_triange_matrix_size);

	double tolerance  = atof (regression_options->option_meaning ("TOLERANCE")	 .c_str()   );
	double Fisher_in  = atof (regression_options->option_meaning ("FISHER_INCLUDE").c_str() );
	double Fisher_out = atof (regression_options->option_meaning ("FISHER_EXCLUDE").c_str() );


	allocate_solution_pool ();
	//print_symmetric_matrix (		glob_su_				, 		nu_of_pred_and_dep ,		log_stream );

	for ( int ii=0;ii<number_of_dependent_;ii++)
	{
		shake_down_for_single_dependent (ii, avsumx,su,d);

			int nu_of_pred_and_dep = number_of_predictor_ + number_of_dependent_;

			//print_symmetric_matrix (				su, 				number_of_predictor_ +1,				log_stream );

		Reg_solution current_sol (
   			number_of_cases_,
			number_of_predictor_+1,
			avsumx,
			su,
			tolerance,
			Fisher_in,
			Fisher_out);

		memcpy(
			regression_coefficient_pool_[ii],
			current_sol.get_regression_coefficient(),
			number_of_predictor_ * sizeof (double) );

		memcpy(
			standard_errror_of_regression_coefficient_pool_[ii],
			current_sol.get_standard_errror_of_regression_coefficient(),
			number_of_predictor_ * sizeof (double) );

		absolute_term_pool_[ii] =
			current_sol.get_absolute_term();

		//cout << ii << "  " << absolute_term_pool_[ii] << endl;

		index_of_included_pool_.push_back (current_sol.get_index_of_included	() );

	}

	delete [] avsumx;
	delete [] d;
	delete [] su;

}

// ********** contains forcibly includec variables ************
charming_Reg_solution::
charming_Reg_solution (
	 const string & binary_data_file_name,
	 const Sheduler			*regression_options,
	 const vector <vector <int> > & index_of_included_pool )
{
	ifstream regdata_stream ( binary_data_file_name.c_str() ,ios::binary);
	if ( ! regdata_stream )
	{
		log_stream	<< "charming_Reg_solution: ERROR		-  can't read datafile for constructor" << endl;
		cout		<< "charming_Reg_solution: ERROR		-  can't read datafile for constructor" << endl;
		exit (1);
	}
	regdata_stream.read ( (char* ) & number_of_predictor_,	sizeof (int)  );
	regdata_stream.read ( (char* ) & number_of_dependent_,	sizeof (int)  );
	regdata_stream.read ( (char* ) & number_of_cases_,		sizeof (int)  );

	int nu_of_pred_and_dep = number_of_predictor_ + number_of_dependent_;

	glob_avsumx_		= new double [nu_of_pred_and_dep]; 	 memset (glob_avsumx_,0,sizeof(double)*nu_of_pred_and_dep);
	glob_d_				= new double [nu_of_pred_and_dep]; 	 memset (glob_d_,0,sizeof(double)	 *nu_of_pred_and_dep);

	int global_upper_triange_matrix_size = nu_of_pred_and_dep*(nu_of_pred_and_dep+1)/2;
	glob_su_				= new double [global_upper_triange_matrix_size]; 	 memset (glob_su_,			0,sizeof(double)*global_upper_triange_matrix_size);

	regdata_stream.read ( (char* )  glob_avsumx_,			nu_of_pred_and_dep* sizeof (double)  );
	regdata_stream.read ( (char* )  glob_su_,				global_upper_triange_matrix_size			* sizeof (double)  );

	double *avsumx		= new double [nu_of_pred_and_dep]; 				memset (avsumx,0,sizeof(double)*nu_of_pred_and_dep);
	double *d			= new double [nu_of_pred_and_dep]; 				memset (d,		0,sizeof(double) *nu_of_pred_and_dep);
	double *su			= new double [global_upper_triange_matrix_size]; 	memset (su,		0,sizeof(double)*global_upper_triange_matrix_size);

	double tolerance  = atof (regression_options->option_meaning ("TOLERANCE")	 .c_str()   );
	double Fisher_in  = atof (regression_options->option_meaning ("FISHER_INCLUDE").c_str() );
	double Fisher_out = atof (regression_options->option_meaning ("FISHER_EXCLUDE").c_str() );

	allocate_solution_pool ();

	for ( int ii=0;ii<number_of_dependent_;ii++)
	{
		shake_down_for_single_dependent (ii, avsumx,su,d);

			int nu_of_pred_and_dep = number_of_predictor_ + number_of_dependent_;

/*

		Reg_solution current_sol (
   			number_of_cases_,
			number_of_predictor_+1,
			avsumx,
			su,
			tolerance,
			Fisher_in,
			Fisher_out);
*/

		Reg_solution current_sol (
   			number_of_cases_,
			number_of_predictor_+1,
			avsumx,
			su,
			tolerance,
			index_of_included_pool[ii]);



		memcpy(
			regression_coefficient_pool_[ii],
			current_sol.get_regression_coefficient(),
			number_of_predictor_ * sizeof (double) );

		memcpy(
			standard_errror_of_regression_coefficient_pool_[ii],
			current_sol.get_standard_errror_of_regression_coefficient(),
			number_of_predictor_ * sizeof (double) );

		absolute_term_pool_[ii] =
			current_sol.get_absolute_term();

		index_of_included_pool_.push_back (current_sol.get_index_of_included	() );

	}

	delete [] avsumx;
	delete [] d;
	delete [] su;
}



/*
charming_Reg_solution::	charming_Reg_solution (
		const double *avsumx_,
		const double *su_,
		const int number_of_cases,
		const int number_of_predictor,
		const int number_of_dependent,
		const vector <vector <int> > & index_of_included_pool,
		const double tolerance) :
	number_of_cases_								(number_of_cases),
	number_of_predictor_							(number_of_predictor),
	number_of_dependent_							(number_of_dependent),
	glob_avsumx_									(0),
	glob_d_											(0),
	glob_su_										(0),
	regression_coefficient_pool_					(0),
	standard_errror_of_regression_coefficient_pool_	(0),
	absolute_term_pool_								(0)

{

	int nu_of_pred_and_dep = number_of_predictor_ + number_of_dependent_;

	glob_avsumx_		= new double [nu_of_pred_and_dep]; 	 memset (glob_avsumx_,0,sizeof(double)*nu_of_pred_and_dep);
	glob_d_				= new double [nu_of_pred_and_dep]; 	 memset (glob_d_,0,sizeof(double)	 *nu_of_pred_and_dep);

	int global_upper_triange_matrix_size = nu_of_pred_and_dep*(nu_of_pred_and_dep+1)/2;
	glob_su_				= new double [global_upper_triange_matrix_size]; 	 memset (glob_su_,			0,sizeof(double)*global_upper_triange_matrix_size);

	double *avsumx		= new double [nu_of_pred_and_dep]; 				memset (avsumx,0,sizeof(double)*nu_of_pred_and_dep);
	double *d			= new double [nu_of_pred_and_dep]; 				memset (d,		0,sizeof(double) *nu_of_pred_and_dep);
	double *su			= new double [global_upper_triange_matrix_size]; 	memset (su,		0,sizeof(double)*global_upper_triange_matrix_size);

	allocate_solution_pool ();

	for ( int ii=0;ii<number_of_dependent_;ii++)
	{

		memcpy (
			//avsumx,
			glob_avsumx_,
			avsumx_,
			nu_of_pred_and_dep * sizeof  (double) ) ;
		memcpy (
			//su,
			glob_su_,
			su_,
			global_upper_triange_matrix_size * sizeof  (double) ) ;

		shake_down_for_single_dependent (ii, avsumx,su,d);


		Reg_solution current_sol (
   			number_of_cases_,
			number_of_predictor_+1,
			avsumx,
			su,
			tolerance,
			index_of_included_pool[ii]);

		memcpy(
			regression_coefficient_pool_[ii],
			current_sol.get_regression_coefficient(),
			number_of_predictor_ * sizeof (double) );

		memcpy(
			standard_errror_of_regression_coefficient_pool_[ii],
			current_sol.get_standard_errror_of_regression_coefficient(),
			number_of_predictor_ * sizeof (double) );

		absolute_term_pool_[ii] =
			current_sol.get_absolute_term();


		index_of_included_pool_.push_back (current_sol.get_index_of_included	() );
	}
}
*/


void charming_Reg_solution::
allocate_solution_pool ()
{

		regression_coefficient_pool_						= new double * [number_of_dependent_];
		standard_errror_of_regression_coefficient_pool_	= new double * [number_of_dependent_];
		absolute_term_pool_								= new double   [number_of_dependent_];

		for (int ii=0;ii <number_of_dependent_; ii++ )
		{
			regression_coefficient_pool_					[ii] = new double [number_of_predictor_];
			standard_errror_of_regression_coefficient_pool_	[ii] = new double [number_of_predictor_];
		}

}

void charming_Reg_solution::
shake_down_for_single_dependent (
	const int	dep_index,
	double *avsumx,
	double *su,
	double *d)
{

	int nu_of_pred_and_dep = number_of_predictor_ + number_of_dependent_;

	memcpy (avsumx,glob_avsumx_,number_of_predictor_*sizeof (double) );
	avsumx [number_of_predictor_] = glob_avsumx_[number_of_predictor_ + dep_index ];

	memcpy (d,glob_d_,number_of_predictor_*sizeof (double) );
	d [number_of_predictor_] = glob_d_[number_of_predictor_ + dep_index ];

	for (int ii=0; ii<number_of_predictor_;ii++ )
	{
		for (int jj=ii; jj<number_of_predictor_;jj++ )
		{
			int old_index = one_dimensional_matrix_index(  ii,  jj,  nu_of_pred_and_dep) ;
			int new_index = one_dimensional_matrix_index(  ii,  jj,  number_of_predictor_+1) ;
			su [new_index]  = glob_su_[old_index ];
		}
		int old_index = one_dimensional_matrix_index(  ii,  number_of_predictor_ + dep_index,  nu_of_pred_and_dep) ;
		int new_index = one_dimensional_matrix_index(  ii,  number_of_predictor_ ,  number_of_predictor_+1) ;
		su [new_index]  = glob_su_[old_index ];
	}

	int old_index = one_dimensional_matrix_index(  number_of_predictor_ + dep_index,  number_of_predictor_ + dep_index,  nu_of_pred_and_dep) ;
	int new_index = one_dimensional_matrix_index(  number_of_predictor_ ,  number_of_predictor_ ,  number_of_predictor_+1) ;
	su [new_index]  = glob_su_[old_index ];


/*
		log_stream << "dep_index: " << dep_index << endl;
		for ( int tt = 0 ;tt < nu_of_pred_and_dep ; tt++ )
		{
			int index = one_dimensional_matrix_index( tt,tt, nu_of_pred_and_dep );
			PutVaDouble (glob_su_[index], log_stream, 10, 3, 'l' );
		}
		log_stream << endl;
		for (  tt = 0 ;tt < number_of_predictor_ +1 ; tt++ )
		{
			int index = one_dimensional_matrix_index( tt,tt, number_of_predictor_ +1 );
			PutVaDouble (su[index], log_stream, 10, 3, 'l' );
		}
		log_stream << endl;
*/

}



charming_Reg_solution::~charming_Reg_solution ()
{

	if ( glob_avsumx_ ) delete [] glob_avsumx_ ;
	if ( glob_d_)		delete [] glob_d_;
	if ( glob_su_)		delete [] glob_su_;

	if ( absolute_term_pool_ )		delete [] absolute_term_pool_ ;

	if ( regression_coefficient_pool_ )
	{
		for (int ii = 0; ii < number_of_dependent_; ii++ )
			delete [] regression_coefficient_pool_[ii];
		delete [] regression_coefficient_pool_;
	}

	if ( standard_errror_of_regression_coefficient_pool_ )
	{
		for (int ii = 0; ii < number_of_dependent_; ii++ )
			delete [] standard_errror_of_regression_coefficient_pool_[ii];
		delete [] standard_errror_of_regression_coefficient_pool_;
	}

	glob_avsumx_	= 0 ;
	glob_d_			= 0 ;
	glob_su_		= 0 ;

	regression_coefficient_pool_					= 0 ;
	standard_errror_of_regression_coefficient_pool_ = 0 ;
	absolute_term_pool_								= 0 ;

}

void charming_Reg_solution::	show_plain_results (
	const string & predictor_file,
	const string & dependent_file,
	const string & result_file_name_base)
{

	vector <string > predictor_names 	=
		fill_up_whole_string_names_from_respective_file (predictor_file);

	vector <string > dependent_names 	=
		fill_up_whole_string_names_from_respective_file (dependent_file);

	for ( int ii=0; ii<dependent_names.size(); ii++ )
	{
		string current_result_name;
		{
			ostringstream ost;
			ost << result_file_name_base   << "_" << ii << ".plain_result" ;
			current_result_name = ost.str();
		}

		vector <double> current_Fisher_values;
		current_Fisher_values.clear();
		current_Fisher_values = make_Fisher_values ( ii );

			int check = current_Fisher_values.size();

		ofstream  out( current_result_name.c_str() );

		out	<< "************************************************************************" << endl;
		out	<< dependent_names[ii] <<  endl ;
		out	<< "************************************************************************" << endl;

			int test = index_of_included_pool_[ii].size();  //fix

		for (int kk=0;kk<index_of_included_pool_[ii].size();kk++)
		{
			PutVaDouble (current_Fisher_values[kk],
				out,10, 3,'r'); out<< " ";

			double true_Fisher_value = regression_coefficient_pool_[ii][ index_of_included_pool_[ii][kk] ]/ standard_errror_of_regression_coefficient_pool_ [ii][ index_of_included_pool_[ii][kk] ];
			true_Fisher_value = true_Fisher_value * true_Fisher_value;

			PutVaDouble (true_Fisher_value ,
				out,10, 3,'r'); out<< " ";

			//PutVa( index_of_included_pool_[ii][kk]+1,out,6,4 ,'r');out<< " ";
			PutVa( index_of_included_pool_[ii][kk],out,6,4 ,'r');out<< " ";

			PutVaDouble (regression_coefficient_pool_[ii][ index_of_included_pool_[ii][kk] ],
				out,15, 8,'r');out<< " ";

			PutVaDouble (standard_errror_of_regression_coefficient_pool_ [ii][ index_of_included_pool_[ii][kk] ],
				out,15, 8,'r');out<< " ";

			out<< " # " << predictor_names [ index_of_included_pool_[ii][kk] ] ;

			out<< endl;
		}
        out	<< "ABSOLUTE_TERM_POOL"     << absolute_term_pool_[ii] << endl;
		out	<< "NUMBER_OF_CASES:	"	<< number_of_cases_		<< endl;
		out	<< "NUMBER_OF_VARIABLES:"	<< number_of_predictor_	<< endl;
		out	<< "NUMBER_OF_INCLUDED:	"	<< index_of_included_pool_[ii].size()	<< endl;

		out.close ();
	}
}

void charming_Reg_solution::	show_plain_results (
	const vector <string > & predictor_files,
	const string & dependent_file,
	const string & result_file_name_base)
{

	vector <string > predictor_names ;
	for ( int tt=0; tt< predictor_files.size(); tt++ )
	{

		vector <string > current_names 	=
			fill_up_whole_string_names_from_respective_file (predictor_files [tt] );
		predictor_names.insert(
			predictor_names.end(),
			current_names.begin(),
			current_names.end()	)  ;

	}

	vector <string > dependent_names 	=
		fill_up_whole_string_names_from_respective_file (dependent_file);

	for ( int ii=0; ii<dependent_names.size(); ii++ )
	{
		string current_result_name;
		{
			ostringstream ost;
			ost << result_file_name_base   << "_" << ii << ".plain_result" ;
			current_result_name = ost.str();
		}

		vector <double> current_Fisher_values;
		current_Fisher_values.clear();
		current_Fisher_values = make_Fisher_values ( ii );

			int check = current_Fisher_values.size();

		ofstream  out( current_result_name.c_str() );

		out	<< "************************************************************************" << endl;
		out	<< dependent_names[ii] <<  endl ;
		out	<< "************************************************************************" << endl;

			int test = index_of_included_pool_[ii].size();  //fix

		for (int kk=0;kk<index_of_included_pool_[ii].size();kk++)
		{
            PutVa (kk,				out,10, 3,'r'); out<< "\t";

            PutVa (index_of_included_pool_[ii][kk],	out,10, 3,'r'); out<< "\t";


             //PutVaDouble (current_Fisher_values[kk],				out,10, 3,'r'); out<< " ";

			double true_Fisher_value = regression_coefficient_pool_[ii][ index_of_included_pool_[ii][kk] ]/ standard_errror_of_regression_coefficient_pool_ [ii][ index_of_included_pool_[ii][kk] ];
			true_Fisher_value = true_Fisher_value * true_Fisher_value;

			PutVaDouble (true_Fisher_value ,out,10, 3,'r'); out<< " ";

			//PutVa( index_of_included_pool_[ii][kk]+1,out,6,4 ,'r');out<< " ";
			PutVa( index_of_included_pool_[ii][kk],out,6,4 ,'r');out<< " ";

			PutVaDouble (regression_coefficient_pool_[ii][ index_of_included_pool_[ii][kk] ],out,15, 8,'r');out<< " ";

			PutVaDouble (standard_errror_of_regression_coefficient_pool_ [ii][ index_of_included_pool_[ii][kk] ],out,15, 8,'r');out<< " ";


			out << index_of_included_pool_[ii][kk]; out<< " ";

			out<< "\t # " << predictor_names [ index_of_included_pool_[ii][kk] ] ;

			out<< endl;
		}


		out	<< "ABSOLUTE_TERM_POOL"     << absolute_term_pool_[ii] << endl;
		out	<< "NUMBER_OF_CASES:	"	<< number_of_cases_		<< endl;
		out	<< "NUMBER_OF_VARIABLES:"	<< number_of_predictor_	<< endl;
		out	<< "NUMBER_OF_INCLUDED:	"	<< index_of_included_pool_[ii].size()	<< endl;

		out.close ();
	}
}


vector <double> charming_Reg_solution::
make_Fisher_values ( const int current_index )
{
	vector < double > Fisher_values;

	double VERY_SMALL_POSITIVE_VALUE = epsilon_float()*epsilon_float()*epsilon_float();

	for (int ii=0;ii<index_of_included_pool_[current_index ].size();ii++)
	{
		int point = index_of_included_pool_[current_index ][ii];

		double value =
			 ( fabs ( standard_errror_of_regression_coefficient_pool_[current_index] [point] ) > VERY_SMALL_POSITIVE_VALUE ) ?
			 (regression_coefficient_pool_[current_index][point] / standard_errror_of_regression_coefficient_pool_[current_index][point] ) *
			 (regression_coefficient_pool_[current_index][point] / standard_errror_of_regression_coefficient_pool_[current_index][point] )  :
			-1;

		Fisher_values.push_back( value ) ;
	}
	return Fisher_values;
}





vector <double> charming_Reg_solution::
make_single_prediction_vector ( const vector <double> & record )
{

	vector < double > result ;
	result.resize(number_of_dependent_) ;

	for ( int ii=0; ii< number_of_dependent_; ii++ )
	{
		double sum = absolute_term_pool_[ii];
		for (int jj=0;jj<number_of_predictor_;jj++)
			sum  += record[jj]*regression_coefficient_pool_[ii][jj];

		result [ii] = sum ;
	}

	return result;
}
