#ifndef STATISTIC_NEW_TEST_INCLUDED
#define STATISTIC_NEW_TEST_INCLUDED

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"


#include <string>

using namespace std;



#endif

#include <string>

class  Statistic_new_test: public Simple_test
{ void prepare_clusdter_distribution_test();
public:
	~Statistic_new_test();

    void run()
    {
        //erf_test();                   /// Идиотские но успешные попытки пострить таблице для z-value в лоб
        //get_z_value_probfbility_test();  /// проверяем таблицу
/// приготавливает данные о средних и стандартных отклонениях для предстазанных и экспериментальных данных. В файлы moments.dist_data_predicted &  moments.dist_data
//        prepare_cluster_distribution_test() ;  /// приготавливает данные о средних и стандартных отклонениях для предстазанных и экспериментальных данных


//        prepare_cluster_distribution_test(string (".dist_data_predicted") );

///The results were corrected for mean and variance moments that differ for experimental and predicted data.
        analyse_and_correction_prediction_by_known_moments ();

     //   dummy_get_moment_test();

    }
        void analyse_and_correction_prediction_by_known_moments ();
        void erf_test();
        void  get_z_value_probfbility_test();
        void prepare_cluster_distribution_test( );
        void dummy_get_moment_test();
};

#endif // STATISTIC_NEW_TEST_INCLUDED
