#ifndef STATISTICS_GENERAL_PURPOSE_H
#define STATISTICS_GENERAL_PURPOSE_H

#define ADDITION_MODE		 1   // for supplement_cross_sum_matrix only
#define SUBTRACTION_MODE	-1	 // for supplement_cross_sum_matrix only

#include <vector>

using namespace std;

// function performs one step of accumulation of cross-sum matrix and array of sum values for each variable
void supplement_cross_sum_matrix(
	const int wc,					     // number of variables
    const std::vector < double > & x,    // intermediate vectror having size wc
	std::vector < double > & avsumx,     // in this vector accumulates sum for each variable
	std::vector < double > & su,         // in this vector accumulates upper triangle part of cross-sum matrix
	const int f );					     // if f = 1 - add case ; f = -1 - substract case


void supplement_cross_sum_matrix(
	const int wc,
    const double * x,
	double *  avsumx,
	double *  su,
	const int f) ;

// calculates  covariation matrix
// on condition that avsumx &  su had been accumulated by supplement_cross_sum_matrix()
//
void prepare_covariation_matrix(
	const int recordnum,                  // number of variables
	const int wc,                         // intermediate vectror having size wc
	std::vector <double> & avsumx,
	std::vector <double> & su,
	std::vector <double> & d   );		  // in this vector accumulates sum for each variable

void prepare_covariation_matrix(
	const int recordnum,
	const int wc,
	double * avsumx,
	double * su,
	double *  d ) ;


// sweep operator; if flag = -1 - sweeping k-th variable; else if flag =1 - inverse sweping
void sweep_operator(
	const int wc,
	const int k,
	const int flag,
	std::vector < double > & sumxy,
	std::vector < double > & x);			// auxiliary vector needed for calculation

void sweep_operator(
	const int wc,
	const int k,
	const int flag,
	double  * sumxy,
	double  * x);			// auxiliary vector needed for calculation



inline int one_dimensional_matrix_index (const int ii,const int jj,const int wc)
{
	if ( ii>wc || jj>wc )		return -1;
	return  (jj>=ii) ? (2*wc-ii-1)*ii/2+jj  : (2*wc-jj-1)*jj/2+ii  ;
}

void making_intra_group_covariation_matrix_one_step
(	const int wcount,
	std::vector < double > & current_values,
	std::vector < double > & group_average_value,
	int  & case_group_index,
	std::vector < double > & marix_w);


double get_z_value_probfbility(const double parameter);

#endif
