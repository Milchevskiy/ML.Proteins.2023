//**********************************************************************
//      PREPARING TO CALCULATE COVARIATIION MATRIX;
//              VERSION WITHOUT PAIR frequency CALCULATION
//      if f==1 - add case ; if f==-1 deduct case
//**********************************************************************

#include <vector>

using namespace std;

//void supplement_cross_sum_matrix(    
//	const int wc, 
//        const vector < double > & x, 
//	vector < double > & avsumx,
//	vector < double > & su,
//	const int f) 
//{
//	int ij=0;
//
//	for(int i=0;i <wc ;i++) {
//		avsumx[i] += x[i]*f;
//		for(int j=i;j <wc ;j++) {
//			if (f==1) 
//				su[ij] += x[i]*x[j];
//			else if (f==-1)
//				su[ij] -= x[i]*x[j];
//			ij++;
//		}
//	}
//}


void supplement_cross_sum_matrix(    
	const int wc, 
    const double * x, 
	double *  avsumx,
	double *  su,
	const int f) 
{
	int ij=0;

	for(int i=0;i <wc ;i++) {
		avsumx[i] += x[i]*f;
		for(int j=i;j <wc ;j++) {
			su[ij] += x[i]*x[j]*f;
			ij++;
		}
	}

	/*if (f == 1)
	{
		for (int i = 0; i < wc; i++) {
			avsumx[i] += x[i];
			for (int j = i; j < wc; j++) {
				su[ij] += x[i] * x[j] ;
				ij++;
			}
		}
	}
	else if (f == -1)
	{
		for (int i = 0; i < wc; i++) {
			avsumx[i] -= x[i];
			for (int j = i; j < wc; j++) {
				su[ij] -= x[i] * x[j];
				ij++;
			}
		}
	}
*/

}

