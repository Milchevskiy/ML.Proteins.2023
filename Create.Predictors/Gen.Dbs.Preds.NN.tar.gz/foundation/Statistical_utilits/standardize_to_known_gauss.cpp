#include "standardize_to_known_gauss.h"
#include "calc_dispersion_and_average.h"

using namespace std;

void standardize_to_known_gauss (
			vector <double> & x, 
			const double av_y,
			const double si_y)
{

	double av_x, si_x;
	calc_dispersion_and_average ( 	x,	av_x, si_x); 

	int task_size = x.size(); 

	double add = av_y - av_x*si_y/si_x;
	double koef = si_y/si_x;

	for (int ii=0; ii< task_size; ii++ )
		x[ii] = x[ii]* koef + add; 
}


