#ifndef JANIREG_TEST_H
#define JANIREG_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif
 
#include <string>

class  Janireg_test: public Simple_test
{
public:
	~Janireg_test();

    void run()
    {
		is_alive_test();
	//	jack_nife_quality_estimation_test();
	//	jack_nife_optimal_quality_search_test();
	}
	void is_alive_test							();
	void jack_nife_quality_estimation_test		();
	void jack_nife_optimal_quality_search_test	();
};

#endif
