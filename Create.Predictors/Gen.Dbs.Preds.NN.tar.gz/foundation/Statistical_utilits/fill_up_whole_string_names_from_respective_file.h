#ifndef FILL_UP_WHOLE_STRING_NAMES_FROM_RESPECTIVE_FILE_H
#define FILL_UP_WHOLE_STRING_NAMES_FROM_RESPECTIVE_FILE_H

#include <string>
#include <vector>

using namespace std;

vector <string > fill_up_whole_string_names_from_respective_file ( const string & file_name );


#endif