#ifndef STANDARDIZE_FIRST_TO_SECOND_H
#define STANDARDIZE_FIRST_TO_SECOND_H

#include <vector>

using namespace std;

vector < double > standardize_first_to_second (
	vector < double > & x ,
	vector < double > & y);


double  standardize_first_to_second_for_known_moments (
	double  & x ,
	double  & av_x ,
	double  & si_x ,
	double  & av_y ,
	double  & si_y );


#endif

