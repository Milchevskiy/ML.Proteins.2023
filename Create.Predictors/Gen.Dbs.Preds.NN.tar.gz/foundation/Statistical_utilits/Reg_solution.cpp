#pragma warning( disable : 4786 )

#include "Reg_solution.h"
#include "../CommonFunc.h"
#include "Statistic_general_purpose.h"

#include <fstream>
#include <cassert>


using namespace std;

extern ofstream		log_stream;

// Variant for ready su_ & avsumx
Reg_solution::
Reg_solution (
   		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out):
 number_of_cases_       (number_of_cases),
 number_of_variables_   (number_of_variables),
 avsumx_				(avsumx),
 su_					(su),
 tolerance_				(tolerance),
 Fisher_in_				(Fisher_in ),
 Fisher_out_			(Fisher_out),
 number_of_included_    (0),
 regression_coefficient_(0),
 standard_errror_of_regression_coefficient_ (0),
 x_(0)
{
	d_				= new double [number_of_variables_]; 	 memset (d_,0,sizeof(double)	 *number_of_variables_);
	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	prepare_covariation_matrix(
		number_of_cases_,
		number_of_variables_,
		avsumx_,
		su_,
		d_)	;

	double *x		= new double [number_of_variables_]; memset (x,0,number_of_variables_*sizeof(double));
	int    *index	= new int	 [number_of_variables_]; memset (index,0,number_of_variables_*sizeof(int));

	regression_coefficient_                    = new double [number_of_variables_]; // delete in destructor
	standard_errror_of_regression_coefficient_ = new double [number_of_variables_]; // delete in destructor

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	int flag,kk,iter=0;
    while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,su_,x);

		index[kk] += -flag;
		number_of_included_		+= -flag;

		if(++iter > 2*number_of_variables_ )
			break;
	}
	for ( int ii=0;ii<number_of_variables_-1; ii++ )
	{
		if ( index[ii] == 1 )
			index_of_included_.push_back (ii);
	}

	fill_up_solution ();

	delete [] x;	delete [] index;
}

//*******************************************
Reg_solution::
Reg_solution (
   		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		const double		tolerance,
		const vector < int > & forcibly_included_index) :

 number_of_cases_       (number_of_cases),
 number_of_variables_   (number_of_variables),
 avsumx_				(avsumx),
 su_					(su),
 tolerance_				(tolerance),
 number_of_included_    (0),
 regression_coefficient_(0),
 standard_errror_of_regression_coefficient_ (0),
 x_(0),
 forcibly_included_index_ (forcibly_included_index)
{
	d_				= new double [number_of_variables_]; 	 memset (d_,0,sizeof(double)	 *number_of_variables_);
	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	prepare_covariation_matrix(
		number_of_cases_,
		number_of_variables_,
		avsumx_,
		su_,
		d_)	;

	double *x		= new double [number_of_variables_]; memset (x,0,number_of_variables_*sizeof(double));
	int    *index	= new int	 [number_of_variables_]; memset (index,0,number_of_variables_*sizeof(int));

	regression_coefficient_                    = new double [number_of_variables_]; // delete in destructor
	standard_errror_of_regression_coefficient_ = new double [number_of_variables_]; // delete in destructor

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

//	int flag,kk,iter=0;

	for ( int ii=0;ii<forcibly_included_index_.size(); ii++ )
	{
		int kk= forcibly_included_index_ [ii];
		int flag = -1;

		if (  su_ [ one_dimensional_matrix_index(  kk,  kk, number_of_variables_) ] / d_[kk] < tolerance_ )
			continue;

		sweep_operator(number_of_variables_,kk,flag,su_,x);

		index_of_included_.push_back (kk);
	}

/*

    while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,su_,x);

		index[kk] += -flag;
		number_of_included_		+= -flag;

		if(++iter > 2*number_of_variables_ )
			break;
	}
	for ( int ii=0;ii<number_of_variables_-1; ii++ )
	{
		if ( index[ii] == 1 )
			index_of_included_.push_back (ii);
	}
*/

	fill_up_solution ();

	delete [] x;	delete [] index;
}


Reg_solution::
Reg_solution (
 	    const string chewed_data_file_name,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out ):
 tolerance_				(tolerance),
 Fisher_in_				(Fisher_in ),
 Fisher_out_			(Fisher_out),
 number_of_included_    (0),
 regression_coefficient_(0),
 standard_errror_of_regression_coefficient_ (0),
 x_(0)
{
	ifstream regdata_stream ( chewed_data_file_name.c_str() ,ios::binary);
	if ( ! regdata_stream )
	{
		log_stream << "Reg_solution : ERROR		-  can't read datafie for constructor" << endl;
		cout       << "Reg_solution : ERROR		-  can't read datafie for constructor" << endl;
		exit (1);
	}

//	assign_predictor_names_from_file		(chewed_data_file_name);
//	assign_name_of_dependent_from_file	(chewed_data_file_name);

	//regdata_stream.write ( (char* ) & contact_record_size_ ,	sizeof (int)  );



	regdata_stream.read ( (char* ) & number_of_variables_,	sizeof (int)  );
	regdata_stream.read ( (char* ) & number_of_cases_,	sizeof (int)  );

	avsumx_			= new double [number_of_variables_]; 	 memset (avsumx_,0,sizeof(double)*number_of_variables_);
	d_				= new double [number_of_variables_]; 	 memset (d_,0,sizeof(double)	 *number_of_variables_);

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;
	su_				= new double [upper_triange_matrix_size_]; 	 memset (su_,			0,sizeof(double)*upper_triange_matrix_size_);

	regdata_stream.read ( (char* )  avsumx_,			number_of_variables_* sizeof (double)  );
	regdata_stream.read ( (char* )  su_,				upper_triange_matrix_size_			* sizeof (double)  );

	prepare_covariation_matrix(
		number_of_cases_,
		number_of_variables_,
		avsumx_,
		su_,
		d_)	;

	double *x		= new double [number_of_variables_]; memset (x,0,number_of_variables_*sizeof(double));
	int    *index	= new int	 [number_of_variables_]; memset (index,0,number_of_variables_*sizeof(int));

	regression_coefficient_                    = new double [number_of_variables_]; // delete in destructor
	standard_errror_of_regression_coefficient_ = new double [number_of_variables_]; // delete in destructor

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	int flag,kk,iter=0;
    while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,su_,x);

		index[kk] += -flag;
		number_of_included_		+= -flag;

		if(++iter > 2*number_of_variables_ )
			break;
	}
	for ( int ii=0;ii<number_of_variables_-1; ii++ )
	{
		if ( index[ii] == 1 )
			index_of_included_.push_back (ii);
	}

	fill_up_solution ();

	delete [] x;	delete [] index;

	regdata_stream.close();
}

void Reg_solution::
assign_predictor_names_from_file		( const string chewed_data_file_name)
{
	//string true_file_name = new_extension_file_name_from_tail ( chewed_data_file_name, "predictor_names" );

	string true_file_name = chewed_data_file_name;

	ifstream name_stream ( true_file_name.c_str() );
	if ( ! name_stream )
	{
		log_stream << "assign_predictor_names_from_file		: ERROR		-  can't read predictor_names" << endl;
		cout       << "assign_predictor_names_from_file		: ERROR		-  can't read predictor_names" << endl;
		exit (1);
	}

	predictor_names_.resize(0);
	string current_line;
	while ( getline(name_stream,current_line,'\n' ) )
		predictor_names_.push_back (current_line);

	name_stream.close();

}
void Reg_solution::
assign_name_of_dependent_from_file	( const string chewed_data_file_name )
{

//	string true_file_name = new_extension_file_name_from_tail ( chewed_data_file_name, "dependent_names" );
	string true_file_name = chewed_data_file_name ;

	ifstream name_stream ( true_file_name.c_str() );
	if ( ! name_stream )
	{
		log_stream << "assign_predictor_names_from_file		: ERROR		-  can't read predictor_names" << endl;
		cout       << "assign_predictor_names_from_file		: ERROR		-  can't read predictor_names" << endl;
		exit (1);
	}


	name_stream >> name_of_dependent_ ;

	name_stream.close();
}


Reg_solution::
Reg_solution (
  		const int	number_of_cases,
		const int	number_of_variables,
		double *	avsumx,
		double *	su,
		double *	d,
		const double		tolerance,
		const double		Fisher_in,
		const double		Fisher_out,
		const vector < string > & predictor_names,
		const string			& name_of_dependent) :

 number_of_cases_		(number_of_cases),
 number_of_variables_	(number_of_variables),
 avsumx_				(avsumx),
 su_					(su),
 d_						(d),
 tolerance_				(tolerance),
 Fisher_in_				(Fisher_in ),
 Fisher_out_			(Fisher_out),
 predictor_names_       (predictor_names),
 name_of_dependent_     (name_of_dependent),
 number_of_included_    (0),
 regression_coefficient_(0),
 standard_errror_of_regression_coefficient_ (0),
 x_(0)
{
	double *x		= new double [number_of_variables_]; memset (x,0,number_of_variables_*sizeof(double));
	int    *index	= new int	 [number_of_variables_]; memset (index,0,number_of_variables_*sizeof(int));

	regression_coefficient_                    = new double [number_of_variables_]; // delete in destructor
	standard_errror_of_regression_coefficient_ = new double [number_of_variables_]; // delete in destructor

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	int flag,kk,iter=0;
    while ( pedantic_selvar  (flag,kk) )
	{
		sweep_operator(number_of_variables_,kk,flag,su_,x);

		index[kk] += -flag;
		number_of_included_		+= -flag;

		if(++iter > 2*number_of_variables_ )
			break;
	}
	for ( int ii=0;ii<number_of_variables_-1; ii++ )
	{
		if ( index[ii] == 1 )
			index_of_included_.push_back (ii);
	}

	fill_up_solution ();

	delete [] x;	delete [] index;
}
Reg_solution::
Reg_solution  (
  			const int	number_of_cases,
			const int	number_of_variables,
			double *	avsumx,
			double *	su,
			double *	d,
			const double		tolerance,
			const vector < int > & forcibly_included_index )


// number_of_cases_		(number_of_cases),
 //number_of_variables_	(number_of_variables)
 //avsumx_				(avsumx),
 //su_					(su),
 //d_						(d),
// tolerance_				(tolerance),
 //forcibly_included_index_ (forcibly_included_index),
 //number_of_included_    (0),
 //regression_coefficient_(0),
 //standard_errror_of_regression_coefficient_ (0),
 //x_(0)

{
/*
 	x_		= new double [number_of_variables_];
	memset (x_,0,number_of_variables_*sizeof(double));
//	index_	= new int	 [number_of_variables_]; memset (index_,0,number_of_variables_*sizeof(int));

	regression_coefficient_                    = new double [number_of_variables_]; // delete in destructor
	standard_errror_of_regression_coefficient_ = new double [number_of_variables_]; // delete in destructor

	upper_triange_matrix_size_ = number_of_variables_*(number_of_variables_+1)/2;

	for ( int ii=0;ii<forcibly_included_index_.size(); ii++ )
	{
		int kk= forcibly_included_index_ [ii];
		int flag = -1;

		if (  su_ [ one_dimensional_matrix_index(  kk,  kk, number_of_variables_) ] / d[kk] < tolerance_ )
			continue;

		sweep_operator(number_of_variables_,kk,flag,su_,x_);

		index_of_included_.push_back (kk);
	}

	fill_up_solution ();
*/
}


void Reg_solution:: refresh (
		const int	number_of_cases,
		double *	avsumx,
		double *	su,
		double *	d)
{

	number_of_cases_ = number_of_cases;

	prepare_covariation_matrix(
		number_of_cases_,
		number_of_variables_,
		avsumx_,
		su_,
		d_)	;


	for ( int ii=0;ii<forcibly_included_index_.size(); ii++ )
	{
		int kk= forcibly_included_index_ [ii];
		int flag = -1;

		if (  su_ [ one_dimensional_matrix_index(  kk,  kk, number_of_variables_) ] / d[kk] < tolerance_ )
			continue;

		sweep_operator(number_of_variables_,kk,flag,su_,x_);

		index_of_included_.push_back (kk);
	}

	fill_up_solution ();

}

Reg_solution::
~Reg_solution ()
{


	if ( regression_coefficient_ )
	{
		delete [] 	regression_coefficient_;
		regression_coefficient_ = 0;
	}
	if (standard_errror_of_regression_coefficient_ )
	{
		delete [] 		standard_errror_of_regression_coefficient_;
		standard_errror_of_regression_coefficient_ = 0;
	}

	if (x_)
	{
		delete [] 		x_;
		x_ = 0;
	}

	if (d_)
	{
		delete [] 		d_;
		d_ = 0;
	}


}

bool Reg_solution::
pedantic_selvar (
	int & FLAG,
	int & K)
{
	double * A = su_;
	double * D = d_;
	int M  = number_of_variables_;
	int N  = number_of_cases_;
	int NP = number_of_included_;
	double TOL = tolerance_;
	double FIN = Fisher_in_;

	double FOUT = Fisher_out_;
	int ID = number_of_variables_ - 1;

	int KP=0,KN;
	double V;

	static double VERY_SMALL_POSITIVE_VALUE = epsilon_float();

			int check = one_dimensional_matrix_index(  ID,  ID,  number_of_variables_);

	double VN =  - FOUT* A [ one_dimensional_matrix_index(  ID,  ID,  number_of_variables_) ];
	double VP = 0;
	for (int I=0;I<M;I++)
	{
		if ( I == ID )
			continue;
		if ( fabs ( A [ one_dimensional_matrix_index(  I,  I, number_of_variables_) ] )  < VERY_SMALL_POSITIVE_VALUE  )
			continue;

		int itmp=min(I,ID);
		int jtmp=max(I,ID);

				int i_check		= one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ;
				int i_check1	=  one_dimensional_matrix_index(  I,     I,     number_of_variables_) ;


				double  d_check = A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_)  ];
				double  d_check1 = A [ one_dimensional_matrix_index(  I,     I,     number_of_variables_) ];


		 V =  A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ] *
		      A [ one_dimensional_matrix_index(  itmp,  jtmp,  number_of_variables_) ] /
		      A [ one_dimensional_matrix_index(  I,     I,     number_of_variables_) ] ;

		if ( V <= VN )
			continue;
		if ( V <   0 )
			goto label2;
		if ( V <= VP )
			continue;
		if (  A [ one_dimensional_matrix_index(  I,  I, number_of_variables_) ] / D[I] < TOL )
			continue;
		VP = V;
		KP = I;
		continue;
label2:
		VN = V;
		KN = I;

	}

	FLAG = 0;
	if ( (N -NP -2)*VP >= FIN* ( A [ one_dimensional_matrix_index(  ID,    ID,    number_of_variables_)] -VP)  )
		FLAG = -1;
	if( -(N -NP -1)*VN <  FOUT*  A [ one_dimensional_matrix_index(  ID,    ID,    number_of_variables_) ] )
		FLAG = 1;
	K = KP;
	if (FLAG ==1)
		K = KN;

	if (FLAG)
		return true;
	else
		return false;
}

void     Reg_solution::
fill_up_solution ()
{
   static double Minimal_Accuracy = epsilon_float();

   int dependent=number_of_variables_ - 1;

   int  ij=one_dimensional_matrix_index(dependent,dependent,number_of_variables_);
   double ms=su_[ij]/( number_of_cases_- number_of_included_ - 1 );

   double LostSquareSum=su_[ij];

   double rss=d_[dependent]-su_[ij];
   double rms=rss/number_of_included_;

   absolute_term_ = avsumx_[dependent];

  // for( int i=0;i<number_of_variables_;i++)
   int number_of_included = index_of_included_.size();

   for( int kk=0;kk<number_of_included ;kk++)
   {
	 int i= index_of_included_ [kk];
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);
		double check = Minimal_Accuracy*Minimal_Accuracy;
//     if(su_[ij]<  -Minimal_Accuracy*Minimal_Accuracy  )
//	 {
       int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
       absolute_term_  -= avsumx_[i]*su_[ij1];
//   }
   }

   memset(regression_coefficient_,0,number_of_variables_*sizeof (double)  );

//   for(i=0;i<number_of_variables_;i++)
// {
   int kk;
   for(  kk=0;kk<number_of_included ;kk++)
   {
	 int i= index_of_included_ [kk];

     int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);

       regression_coefficient_[i]=su_[ij1];
       standard_errror_of_regression_coefficient_[i]= ms*(-su_[ij]);
       standard_errror_of_regression_coefficient_[i]=
		  // ( standard_errror_of_regression_coefficient_[i] > Minimal_Accuracy/10000 ) ?
		  ( standard_errror_of_regression_coefficient_[i] > Minimal_Accuracy*Minimal_Accuracy*Minimal_Accuracy*Minimal_Accuracy) ?
		        sqrt( standard_errror_of_regression_coefficient_[i]) : -1;  // ** it shows accuracy fault

   }

}


/*
void     Reg_solution::
fill_up_solution ()
{
   static double Minimal_Accuracy = epsilon_float();

		double test_Minimal_Accuracy = Minimal_Accuracy;

   int dependent=number_of_variables_ - 1;

   int  ij=one_dimensional_matrix_index(dependent,dependent,number_of_variables_);
   double ms=su_[ij]/( number_of_cases_- number_of_included_ - 1 );

   double LostSquareSum=su_[ij];

   double rss=d_[dependent]-su_[ij];
   double rms=rss/number_of_included_;

   absolute_term_ = avsumx_[dependent];

   for( int i=0;i<number_of_variables_;i++)
   {
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);
		double check = Minimal_Accuracy*Minimal_Accuracy;
     if(su_[ij]<  -Minimal_Accuracy*Minimal_Accuracy  )
	 {
       int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
       absolute_term_  -= avsumx_[i]*su_[ij1];
     }
   }

   for(i=0;i<number_of_variables_;i++)
   {
     int ij1=one_dimensional_matrix_index(i,dependent,number_of_variables_);
     ij=one_dimensional_matrix_index(i,i,number_of_variables_);

	 if( su_[ij]  < -Minimal_Accuracy*Minimal_Accuracy)
	 {
       regression_coefficient_[i]=su_[ij1];
       standard_errror_of_regression_coefficient_[i]= ms*(-su_[ij]);
       standard_errror_of_regression_coefficient_[i]=
		  // ( standard_errror_of_regression_coefficient_[i] > Minimal_Accuracy/10000 ) ?
		  ( standard_errror_of_regression_coefficient_[i] > Minimal_Accuracy*Minimal_Accuracy) ?
		        sqrt( standard_errror_of_regression_coefficient_[i]) : -1;  // ** it shows accuracy fault

     }
     else                    regression_coefficient_[i]=0;
   }

}
*/
void Reg_solution::
show_reg_model ( const string & filename,
				const double plain_correlation
				/*const double *virgin_avsumx*/ )
{
	fill_up_solution ();

	ofstream  result_stream ( filename.c_str() );
	if ( ! result_stream )	{	cout << "can't find file " << filename << endl;
		assert (  result_stream );		exit (1);	}

	result_stream  << "DEPENDENT :  " << name_of_dependent_ << endl;

	PutVa ("F_VAL",		result_stream,10, 1,'l');


	PutVa ("    INDEX",		result_stream,10, 5,'l');
	PutVa ("REG_COEF",	result_stream,10,1,'l');
	PutVa ("ST_ERR_RE",	result_stream,10,1,'l');
//	PutVa ("AVERAGE",	result_stream,10,1,'l');
	result_stream << endl;

	cout << "INCLUDED INDEX SIZE: " <<  index_of_included_.size() << endl;

	for (int ii = 0; ii <  index_of_included_.size(); ii++)
	{

		int check = index_of_included_[ii];

		double Single_var_Fisher_statistics
			= (regression_coefficient_ [ index_of_included_[ii] ] /standard_errror_of_regression_coefficient_[ index_of_included_[ii] ] ) *
			  (regression_coefficient_ [ index_of_included_[ii] ] /standard_errror_of_regression_coefficient_[ index_of_included_[ii] ] );
		PutVaDouble (Single_var_Fisher_statistics  ,
			result_stream ,10, 3,'r'); result_stream << " ";

		PutVa( index_of_included_[ii]+1,result_stream ,6,4 ,'r');result_stream << " ";


		PutVaDouble (regression_coefficient_ [ index_of_included_[ii] ],
			result_stream ,9, 6,'r');result_stream << " ";

		PutVaDouble (standard_errror_of_regression_coefficient_ [ index_of_included_[ii] ],
			result_stream ,9, 3,'r');result_stream << " ";

//		PutVaDouble (virgin_avsumx [ index_of_included_[ii] ],
//			result_stream ,10, 3,'r');result_stream << " ";

		result_stream << " # " << predictor_names_ [ index_of_included_[ii] ] ;


		result_stream<< endl;

	}

	result_stream  << "ABSOLUTE_TERM :";
	PutVaDouble (absolute_term_,result_stream ,10, 3,'r');
	result_stream<< endl;


	result_stream  << "PLAIN CORRELATION:";
	PutVaDouble (plain_correlation,result_stream ,10, 3,'r');
	result_stream<< endl;


	result_stream  << "NUMBER_OF_CASES:		"	<< number_of_cases_		<< endl;
	result_stream  << "NUMBER_OF_VARIABLES: "	<< number_of_variables_	<< endl;
	result_stream  << "NUMBER_OF_INCLUDED:	"	<< number_of_included_	<< endl;

}


void Reg_solution::
show_reg_model ( const string & filename,
				const double plain_correlation,
				const double *virgin_avsumx )
{
	fill_up_solution ();

	ofstream  result_stream ( filename.c_str() );
	if ( ! result_stream )	{	cout << "can't find file " << filename << endl;
		assert (  result_stream );		exit (1);	}

	result_stream  << "DEPENDENT :  " << name_of_dependent_ << endl;

	PutVa ("F_VAL",		result_stream,10, 1,'l');


	PutVa ("    INDEX",		result_stream,10, 5,'l');
	PutVa ("REG_COEF",	result_stream,10,1,'l');
	PutVa ("ST_ERR_RE",	result_stream,10,1,'l');
	PutVa ("AVERAGE",	result_stream,10,1,'l');
	result_stream << endl;



	for (int ii = 0; ii <  index_of_included_.size(); ii++)
	{

		double Single_var_Fisher_statistics
			= (regression_coefficient_ [ index_of_included_[ii] ] /standard_errror_of_regression_coefficient_[ index_of_included_[ii] ] ) *
			  (regression_coefficient_ [ index_of_included_[ii] ] /standard_errror_of_regression_coefficient_[ index_of_included_[ii] ] );
		PutVaDouble (Single_var_Fisher_statistics  ,
			result_stream ,10, 3,'r'); result_stream << " ";

		PutVa( index_of_included_[ii]+1,result_stream ,6,4 ,'r');result_stream << " ";


		PutVaDouble (regression_coefficient_ [ index_of_included_[ii] ],
			result_stream ,9, 6,'r');result_stream << " ";

		PutVaDouble (standard_errror_of_regression_coefficient_ [ index_of_included_[ii] ],
			result_stream ,9, 3,'r');result_stream << " ";

		PutVaDouble (virgin_avsumx [ index_of_included_[ii] ],
			result_stream ,10, 3,'r');result_stream << " ";

		result_stream << " # " << predictor_names_ [ index_of_included_[ii] ] ;


		result_stream<< endl;

	}

	result_stream  << "ABSOLUTE_TERM :";
	PutVaDouble (absolute_term_,result_stream ,10, 3,'r');
	result_stream<< endl;


	result_stream  << "PLAIN CORRELATION:";
	PutVaDouble (plain_correlation,result_stream ,10, 3,'r');
	result_stream<< endl;


	result_stream  << "NUMBER_OF_CASES:		"	<< number_of_cases_		<< endl;
	result_stream  << "NUMBER_OF_VARIABLES: "	<< number_of_variables_	<< endl;
	result_stream  << "NUMBER_OF_INCLUDED:	"	<< number_of_included_	<< endl;

}

void Reg_solution::
show_reg_model_plain ( const string & filename)
{
	fill_up_solution ();

	ofstream  result_stream ( filename.c_str() );
	if ( ! result_stream )	{	cout << "can't find file " << filename << endl;
		assert (  result_stream );		exit (1);	}

	result_stream  << "DEPENDENT :  " << name_of_dependent_ << endl;

	PutVa ("F_VAL",		result_stream,10, 1,'l');


	PutVa ("    INDEX",		result_stream,10, 5,'l');
	PutVa ("REG_COEF",	result_stream,10,1,'l');
	PutVa ("ST_ERR_RE",	result_stream,10,1,'l');
//	PutVa ("AVERAGE",	result_stream,10,1,'l');
	result_stream << endl;



	for (int ii = 0; ii <  index_of_included_.size(); ii++)
	{

		double Single_var_Fisher_statistics
			= (regression_coefficient_ [ index_of_included_[ii] ] /standard_errror_of_regression_coefficient_[ index_of_included_[ii] ] ) *
			  (regression_coefficient_ [ index_of_included_[ii] ] /standard_errror_of_regression_coefficient_[ index_of_included_[ii] ] );
		PutVaDouble (Single_var_Fisher_statistics  ,
			result_stream ,10, 3,'r'); result_stream << " ";

		PutVa( index_of_included_[ii]+1,result_stream ,6,4 ,'r');result_stream << " ";


		PutVaDouble (regression_coefficient_ [ index_of_included_[ii] ],
			result_stream ,9, 6,'r');result_stream << " ";

		PutVaDouble (standard_errror_of_regression_coefficient_ [ index_of_included_[ii] ],
			result_stream ,9, 3,'r');result_stream << " ";

		//PutVaDouble (virgin_avsumx [ index_of_included_[ii] ],			result_stream ,10, 3,'r');result_stream << " ";

		result_stream << " # " << predictor_names_ [ index_of_included_[ii] ] ;


		result_stream<< endl;

	}

	result_stream  << "ABSOLUTE_TERM :";
	PutVaDouble (absolute_term_,result_stream ,10, 3,'r');
	result_stream<< endl;

/*
	result_stream  << "PLAIN CORRELATION:";
	PutVaDouble (plain_correlation,result_stream ,10, 3,'r');
	result_stream<< endl;
*/

	result_stream  << "NUMBER_OF_CASES:		"	<< number_of_cases_		<< endl;
	result_stream  << "NUMBER_OF_VARIABLES: "	<< number_of_variables_	<< endl;
	result_stream  << "NUMBER_OF_INCLUDED:	"	<< number_of_included_	<< endl;

}


double Reg_solution::
make_single_prediction ( const double * record )
{
	double sum = absolute_term_;
	for (int jj=0;jj<number_of_variables_ - 1 ;jj++)
		sum  += record[jj]*regression_coefficient_[jj];

	return sum;
}

double Reg_solution::
make_single_prediction ( const vector <double>  & record )
{
	double sum = absolute_term_;
	for (int jj=0;jj<number_of_variables_ - 1 ;jj++)
		sum  += record[jj]*regression_coefficient_[jj];

	return sum;
}
