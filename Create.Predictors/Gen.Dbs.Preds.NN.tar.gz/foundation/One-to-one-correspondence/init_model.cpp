// Generates BioPolymerMechanics model. Trivial case: all aminoacids are GLY
#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"


Model *  init_model ( const int len_seq)
{
	Model* model = new Model;

	model->join_aminoacid("Gly",1);	
	for (int ii=0;ii<len_seq-1;ii++)
		model->join_aminoacid("Gly",0);

// check
//	initial_atom = core_atoms.front();
	vector < Atom * > core_atoms = model->get_core_atoms();
	Atom * initial_atom = core_atoms.front();

	vector < double > matrix; matrix.resize(9);
	matrix[0]=1;
	matrix[4]=1;
	matrix[8]=1;
	initial_atom->set_rotation_matrix(matrix);
	initial_atom->set_x(0);
	initial_atom->set_y(0);
	initial_atom->set_z(0);

	model->calc_cartesain_coordinates ( initial_atom );

	return model;

}
