#ifndef OPT_PRECURSOR_TEST_H
#define OPT_PRECURSOR_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  One_to_one_correspondence_test: public Simple_test
{
public:
	~One_to_one_correspondence_test();

    void run()
    {
		check_distance_tostandard_conformations_test();
	//	coord_in_cluster_system_by_dihedral_test();
		//init_objects_for_single_point_test ();   // ������ �� ����� 
//		init_start_conformation_test();
//cartesian_to_cluster_system_test();

//void init_objects_for_single_point_test ();

//		vlada();


	}
	void check_distance_tostandard_conformations_test();
	void coord_in_cluster_system_by_dihedral_test();
	void init_objects_for_single_point_test ();
	void constructor_only_test();
	void positioning_chain_by_clasters_set_test();
	void claster_motif_torsion_set__test();
	void init_start_conformation_test();
	void init_start_conformation_test_ready_for_server_test();
	void cartesian_to_cluster_system_test();
	void vlada();
};

#endif
