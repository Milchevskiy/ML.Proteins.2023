#pragma warning( disable : 4786 )

#include "One_to_one_correspondence_test.h"

#include "One_to_one_correspondence.h"

#include "../CommonFunc.h"

#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"

#include "../Censorship.h"
//#include "../handle_det_distance_set.h"   // ��� ������� read_det_distance_set()


#include "../Censorship.h"
#include "../Fragment_base/fill_up_fragment_torsion_angles.h"


#include "../Fragment_base/Chain_binary.h"
//#include "../Abu_Maimonides_Rambam.h"

#include "../Cluster_set/Cluster_set.h"

#include <cassert>


/*
void refresh_cartesian_by_dihedral (
	Model *model,
	vector <double> & phi_set,
	vector <double> & psi_set,
	vector <double> & ome_set,
	double *chain_coord);
*/
using namespace std;

extern Censorship configuration;

extern ofstream log_stream;

One_to_one_correspondence_test::
~One_to_one_correspondence_test()
{
	cout << "One_to_one_correspondence_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void One_to_one_correspondence_test::
init_start_conformation_test()
{


	int length = 5;
	Model *model_a = init_model(length) ;
	Model *model_b = init_model(length) ;

	model_a->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������
	model_b->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number ();
	vector < double >  phi_set;	phi_set.resize(length);
	vector < double  > psi_set;	psi_set.resize(length);
	vector < double  > ome_set;	ome_set.resize(length);


	double *chain_coord_a = new double [length*9];
	double *chain_coord_b = new double [length*9];
// INIT a-helix structure
	for ( unsigned ii=0; ii<length; ii++ )
	{
		phi_set[ii] = -0.8;//-0.994;
		psi_set[ii] = -0.6;
		ome_set[ii] = Pi;
	}

//	double *chain_coord = new double [len_seq*9];

	refresh_cartesian_by_dihedral (
		model_a,
		phi_set,
		psi_set,
		ome_set,
		chain_coord_a );
//***********

// INIT b-sheet structure
	for ( unsigned ii=0; ii<length; ii++ )
	{
		phi_set[ii] = -2.35;//-0.994;
		psi_set[ii] =  2.35;
		ome_set[ii] = Pi;
	}

	refresh_cartesian_by_dihedral (
		model_b,
		phi_set,
		psi_set,
		ome_set,
		chain_coord_b);
//***********

	string a_helix = string ("D:/Didona/Test/")  + string ("a_helix_by_One_to_one_correspondence_test") + string(".pdb");
	string b_sheet = string ("D:/Didona/Test/")  + string ("b_sheet_by_One_to_one_correspondence_test") + string(".pdb");
	model_a->save_as(a_helix);
	model_b->save_as(b_sheet);

	vector < double >  cont_torsion_set_a;	cont_torsion_set_a.resize(3*length);
	vector < double >  cont_torsion_set_b;	cont_torsion_set_b.resize(3*length);

	fill_up_fragment_torsion_angles (
		chain_coord_a,
		length,
		cont_torsion_set_a,
		'r');


	fill_up_fragment_torsion_angles (
		chain_coord_b,
		length,
		cont_torsion_set_b,
		'r');


	string tors_a_b = string ("D:/Didona/Test/")  + string ("tors_a_b") + string(".txt");
	ofstream  out( tors_a_b.c_str() );
	if ( ! out)
	{
		log_stream << tors_a_b << endl;
		cout       << tors_a_b << endl;
		exit (1);
	}

	for (int ii=0;ii<cont_torsion_set_a.size();ii++)
		PutVaDouble (cont_torsion_set_a[ii],out,10,3,'l');

	out << endl;

	for (int ii=0;ii<cont_torsion_set_b.size();ii++)
		PutVaDouble (cont_torsion_set_b[ii],out,10,3,'l');

	out << endl;


	Chain_binary chain_a ("ALPHA",length,chain_coord_a);
	Chain_binary chain_b ("BETTA",length,chain_coord_b);

	int sequence_length = 5;


	//vector < vector < std::string > > model_a->get_sequence();

	string  cluster_set_name = string ("30_5a_20");
	Cluster_set *cls = new Cluster_set  (	cluster_set_name,COMMON_USAGE_CLUSTER_SET_MODE);
	int number_of_classes	= cls->number_of_classes();
	int fragment_length		 = cls->fragment_length();
	double ** claster_motif_coordinates  = cls->get_claster_motif_coordinates();


	vector < vector < double > >  	coord_in_cluster_system_a =
		chain_a.positioning_chain_by_clasters_set (
				claster_motif_coordinates,
				fragment_length,
				number_of_classes,
				sequence_length) ;

	vector < vector < double > >  	coord_in_cluster_system_b =
		chain_b.positioning_chain_by_clasters_set (
				claster_motif_coordinates,
				length,
				number_of_classes,
				sequence_length) ;


	delete [] chain_coord_a;
	delete [] chain_coord_b;

	delete cls;

}

void One_to_one_correspondence_test::
cartesian_to_cluster_system_test()
{

	string  cluster_set_name = string("30_5a_20");
	One_to_one_correspondence ooc_ob(cluster_set_name);


	int chain_length = 5;
	Model *model_a = init_model(chain_length);
	model_a->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number();
	vector < double >  phi_set;	phi_set.resize(chain_length);
	vector < double  > psi_set;	psi_set.resize(chain_length);
	vector < double  > ome_set;	ome_set.resize(chain_length);

	string filename = string("D:/Didona/Test/") + string("cartesian_to_cluster_system_test") + string(".txt");

	ofstream  out(filename.c_str() );
	if (!out)
	{
		log_stream << filename << endl;
		cout << filename << endl;
		exit(1);
	}



	double *chain_coord_a = new double[chain_length * 9];

	for (int kk = -180; kk < 180; kk++)
	{

	double phi_grad = kk;
	double phi_rad = phi_grad * Pi / 180;

	for (int jj = -180; jj < 180; jj++)
	{
		double psi_grad = jj;
		double psi_rad = psi_grad * Pi / 180;


		double *chain_coord_a = new double[chain_length * 9];

		for (unsigned ii = 0; ii < chain_length; ii++)
		{
			phi_set[ii] = phi_rad;;
			psi_set[ii] = psi_rad;
			ome_set[ii] = Pi;
		}

		//	double *chain_coord = new double [len_seq*9];

		refresh_cartesian_by_dihedral(
			model_a,
			phi_set,
			psi_set,
			ome_set,
			chain_coord_a);


		vector < vector < double > >   coord_in_cluster_system;

		ooc_ob.cartesian_to_cluster_system(
			coord_in_cluster_system,
			chain_coord_a,
			chain_length);


		PutVaDouble(phi_grad, out, 5, 3, 'l');   out << '\t';
		PutVaDouble(psi_grad, out, 5, 3, 'l');	out << ":\t\t";

		for (int ii = 0; ii < coord_in_cluster_system.size(); ii++)
		{
			for (int jj = 0; jj < coord_in_cluster_system[ii].size(); jj++)
				PutVaDouble(coord_in_cluster_system[ii][jj], out, 10, 3, 'l');

			out << endl;
		}
	}

}
	delete model_a;


}

/*
void Opt_precursor_test::
constructor_only_test()
{
	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);
}


void Opt_precursor_test::
void Opt_precursor_test::
positioning_chain_by_clasters_set_test()
{
//	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);

	int len_seq = 7;
	Model *model = init_model(len_seq) ;  // ��� ������ 7 ��� �� ALa

	model->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number ();
	vector < double >  phi_set;	phi_set.resize(len_seq);
	vector < double  > psi_set;	psi_set.resize(len_seq);
	vector < double  > ome_set;	ome_set.resize(len_seq);

	for ( unsigned ii=0; ii<len_seq; ii++ )
	{
		phi_set[ii] = -0.8;//-0.994;
		psi_set[ii] = -0.6;
		ome_set[ii] = Pi;
	}

	double *chain_coord = new double [len_seq*9];

	refresh_cartesian_by_dihedral (
		model,
		phi_set,
		psi_set,
		ome_set,
		chain_coord);

	vector < vector < double > >  observation =
		opt_pre.positioning_chain_by_clasters_set (
			chain_coord,
			len_seq);


		ofstream  out( "DIR_tests//Opt_precursor_test_positioning_chain_by_clasters_set_test");
		if ( ! out)
		{
			log_stream << "DIR_tests//Opt_precursor_test_positioning_chain_by_clasters_set_test: " << "ERROR -  can't create " << endl;
			cout       << "DIR_tests//Opt_precursor_test_positioning_chain_by_clasters_set_test: " << "ERROR -  can't create " << endl;
			exit (1);
		}


	string Calc_cartesain_coordinates_test_locaction = string ("D:/Agony/DIR_tests/")  + string ("positioning_chain_by_clasters_set_test") + string(".pdb");
	model->save_as(Calc_cartesain_coordinates_test_locaction);


	for (unsigned ii = 0;  ii < observation.size();  ii++ )
	{
		for (unsigned kk = 0;  kk < observation[ii].size();  kk++ )
			PutVaDouble (observation[ii][kk],out,8,4,'l');

		out << endl;

	}

	delete [] chain_coord;
	delete model;

}

void Opt_precursor_test::
claster_motif_torsion_set__test()
{

	ofstream  out( "DIR_tests//claster_motif_torsion_set__test");
	if ( ! out)
	{
		log_stream << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		cout       << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		exit (1);
	}


	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);
	vector < vector < double > > claster_motif_torsion_set= opt_pre.get_claster_motif_torsion_set();

	for (unsigned kk=0;kk<claster_motif_torsion_set.size(); kk++)
	{
		for (unsigned jj=0; jj < claster_motif_torsion_set[kk].size(); jj++)
		{
			PutVaDouble (claster_motif_torsion_set[kk][jj], out,10,4,'r');
		}
		out << endl;
	}


	out << endl;out << endl;out << endl;

	vector < vector <double> >  phi_motif = opt_pre.get_phi_motif();
	vector < vector <double> >  psi_motif = opt_pre.get_psi_motif();
	vector < vector <double> >  ome_motif = opt_pre.get_ome_motif();

	for (unsigned kk=0;kk<claster_motif_torsion_set.size(); kk++)
	{
		for (unsigned jj=0; jj < 5 ; jj++)
		{

			PutVaDouble ( ome_motif[kk][jj], out,10,4,'r');
			PutVaDouble ( phi_motif[kk][jj], out,10,4,'r');
			PutVaDouble ( psi_motif[kk][jj], out,10,4,'r');
		}
		out << endl;
	}
}


void Opt_precursor_test::
init_start_conformation_test()
{

	string cur_PDB_ID = "2BF9A";
	ofstream  out( "DIR_tests//claster_motif_torsion_set__test");
	if ( ! out)
	{
		log_stream << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		cout       << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		exit (1);
	}

	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);

	string path_to_predicted_dist_data_file = 		configuration.option_meaning("Path_to_Model_store") +
		string("Model_c30_2") + 		string ("/cross_sum/") + cur_PDB_ID +
		 string (".predicted_dist_data") ;


	{
	Abu_Maimonides_Rambam mr ( "Model_c30_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();
	mr.make_prediction_by_external_PDB(cur_PDB_ID);
	mr.compare_ready_observation_prediction (cur_PDB_ID);
	}

	vector < vector < double > > prediction = read_det_distance_set_DIR (path_to_predicted_dist_data_file );

	int len_seq = prediction.size() + 5 - 1 ;
	Model *model = opt_pre.init_model(len_seq) ;  // ��� ������ len_seq  ��� �� ALa
	model->init_phi_psi_owega_backbone_set ();


	opt_pre.init_start_conformation(model,prediction);

	model->save_as(string("DIR_tests//") + cur_PDB_ID + string ("_pred.pdb") );

	delete model ;
}

void Opt_precursor_test::
init_start_conformation_test_ready_for_server_test()
{
	string outputfilename = string("DIR_tests//") + string("init_start_conformation_test_ready_for_server_test");
	string sequence = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGPPGPPGPPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

}
***/
/*

void One_to_one_correspondence_test::vlada()
  {


  	ifstream  in( "MoGene-2_0-st-v1.mm10.probe.tab" );
	if ( ! in)
	{
		exit (1);
	}


  	ofstream  out( "MoGene-2_0-st-v1.mm10.probe___.txt" );
	if ( ! out)
	{
		exit (1);
	}
//	1         2          3       4   5               6        7       8     9      10                        11     12
//831543	17210850	1362	515	build-38/mm10	chr1	3102029	3102053	+	CGTTCAAAATTTAGTGTATGTGTTG	Sense	main
//17210850	1362	515	3102029	CGTTCAAAATTTAGTGTATGTGTTG	Sense

	string current_line;
//	getline( in  , current_line, '\n' );
	while( getline( in  , current_line, '\n' ) )
	{

		string s1,s2,s3,s4,s5,s6,s7,s8,s9,s10,s11,s12,s13;
		istringstream ist (current_line);
		ist>> s1>> s2>>s3>>s4>>s5>>s6>>s7>>s8>>s9>>s10>>s11>>s12>>s13;
		out << s2 <<"\t" << s3 <<"\t" <<s4 <<"\t" <<s7 <<"\t" <<s10 <<"\t" <<s11 <<endl;

	}



  }
  */

void One_to_one_correspondence_test::
init_objects_for_single_point_test ()
{

	int chain_length = 5;
	Model *model_a = init_model(chain_length) ;
	model_a->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number ();
	vector < double >  phi_set;	phi_set.resize(chain_length);
	vector < double  > psi_set;	psi_set.resize(chain_length);
	vector < double  > ome_set;	ome_set.resize(chain_length);


	double *chain_coord_a = new double [chain_length*9];

		for ( unsigned ii=0; ii<chain_length; ii++ )
	{
		phi_set[ii] = -1.13;//-0.994;
		psi_set[ii] = -0.68;
		ome_set[ii] = Pi;
	}

//	double *chain_coord = new double [len_seq*9];

	refresh_cartesian_by_dihedral (
		model_a,
		phi_set,
		psi_set,
		ome_set,
		chain_coord_a );

	One_to_one_correspondence  ooc_ob(string ("30_5a_20"));
//	vector < double >   coord_in_cluster_system;

	vector < vector < double > >  	coord_in_cluster_system;


	ooc_ob.cartesian_to_cluster_system		(
	   coord_in_cluster_system,
	   chain_coord_a,
	   chain_length);

	Model *model = init_model(chain_length) ;  // ������ �����  fragment_length_  = sequence_length

	ooc_ob.init_objects_for_single_point (
	  coord_in_cluster_system[0],
	  model);

	model->calc_cartesain_coordinates();

	/*fill_up_fragment_torsion_angles (
		chain_coord_a,
		length,
		cont_torsion_set_a,
		'r');
*/
	string check_model_path = string ("D:/Didona/Test/")  + string ("init_objects_for_single_point_test") + string(".pdb");
	model->save_as(check_model_path);


	double **claster_motif_coordinates = ooc_ob.get_claster_motif_coordinates () ;

	vector <double>  cont_torsion_set_claster;
	vector <double>  cont_torsion_main_chain;

	fill_up_fragment_torsion_angles (
		claster_motif_coordinates[0],
		chain_length,
		cont_torsion_set_claster,
		'r');

	double *main_chain_coordinates = get_main_chain_coordinates (model);

	fill_up_fragment_torsion_angles (
		main_chain_coordinates ,
		chain_length,
		cont_torsion_main_chain,
		'r');

	string check_model_path1 = string ("D:/Didona/Test/")  + string ("init_objects_for_single_point_test_compare_dihedral") ;
	ofstream  out( check_model_path1.c_str() );
	if ( ! out)
	{
		cout       << check_model_path << endl;
		exit (1);
	}

	for (int ii=0;ii<cont_torsion_main_chain.size();ii++)
		PutVaDouble (cont_torsion_set_claster[ii],out,10,3,'l');
	out << endl;

	for (int ii=0;ii<cont_torsion_main_chain.size();ii++)
		PutVaDouble (cont_torsion_main_chain[ii],out,10,3,'l');
	out << endl;

}

void One_to_one_correspondence_test::
coord_in_cluster_system_by_dihedral_test()
{

	string  cluster_set_name = string ("30_5a_20");
	One_to_one_correspondence ooc_ob(cluster_set_name);

	vector < vector < double > >   coord_in_cluster_system;


	int chain_length = 5;
	Model *model = init_model(chain_length) ;
	model->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number ();
	vector < double >  phi_set;	phi_set.resize(chain_length);
	vector < double  > psi_set;	psi_set.resize(chain_length);
	vector < double  > ome_set;	ome_set.resize(chain_length);


	double *chain_coord = new double [chain_length*9];

	for ( unsigned ii=0; ii<chain_length; ii++ )
	{
		phi_set[ii] = -0.994;//-0.994;
		psi_set[ii] = -0.68;
		ome_set[ii] = Pi;
	}

//	double *chain_coord = new double [len_seq*9];

	refresh_cartesian_by_dihedral (
		model,
		phi_set,
		psi_set,
		ome_set,
		chain_coord );

	vector < double >  cont_torsion_set;

	fill_up_fragment_torsion_angles (
		chain_coord,
		chain_length,
		cont_torsion_set,
		'r');

	//���  ��� ���� ���� ��� ��� cont_torsion_set �������

	 ooc_ob.coord_in_cluster_system_by_dihedral (
		coord_in_cluster_system,
		cont_torsion_set,
		model,
		chain_coord	);  // ������ ���� �������� ������ �������

    ofstream  out( "D:/Didona/Test/coord_in_cluster_system_by_dihedral_test");
	if ( ! out)
	{
		log_stream << "DIR_tests//coord_in_cluster_system_by_dihedral_test " << "ERROR -  can't create " << endl;
		cout       << "DIR_tests//coord_in_cluster_system_by_dihedral_test " << "ERROR -  can't create " << endl;
		exit (1);
	}

	for (int ii=0;ii<cont_torsion_set.size();ii++)
		PutVaDouble (cont_torsion_set[ii],out,10,3,'l');
	out << endl;


	for (int ii=0;ii<coord_in_cluster_system.size();ii++)
	{
		for (int jj=0;jj<coord_in_cluster_system[ii].size();jj++)
			PutVaDouble (coord_in_cluster_system[ii][jj],out,10,3,'l');

		out << endl;
	}
}





struct Conf_standard
{
	string name;
	double phi_d;;
	double psi_d;;

};

void One_to_one_correspondence_test::
check_distance_tostandard_conformations_test()
{

	string  cluster_set_name = string("30_5a_20");
	One_to_one_correspondence ooc_ob(cluster_set_name);


	int chain_length = 5;
	Model *model_a = init_model(chain_length);
	model_a->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number();
	vector < double >  phi_set;	phi_set.resize(chain_length);
	vector < double  > psi_set;	psi_set.resize(chain_length);
	vector < double  > ome_set;	ome_set.resize(chain_length);

	string filename = string("D:/Didona/Test/") + string("check_distance_tostandard_conformations_test") + string(".txt");

	ofstream  out(filename.c_str());
	if (!out)
	{
		log_stream << filename << endl;
		cout << filename << endl;
		exit(1);
	}

	vector <Conf_standard> vecosta;

	Conf_standard cu_obj;

	cu_obj.name = "alpha";
	cu_obj.phi_d = -57;
	cu_obj.psi_d = -47;
	vecosta.push_back(cu_obj);

	cu_obj.name = "betta_parall";
	cu_obj.phi_d = -119;
	cu_obj.psi_d = 113;
		vecosta.push_back(cu_obj);

	cu_obj.name = "betta_anti";
	cu_obj.phi_d = -139;
	cu_obj.psi_d = 136;
		vecosta.push_back(cu_obj);

	cu_obj.name = "3/10";
	cu_obj.phi_d = -49;
		cu_obj.psi_d = -26;
		vecosta.push_back(cu_obj);

	cu_obj.name = "polyproline";
	cu_obj.phi_d = -79;
	cu_obj.psi_d = 150;
		vecosta.push_back(cu_obj);

	cu_obj.name = "collagen";
	cu_obj.phi_d = -51;
	cu_obj.psi_d = 153;
		vecosta.push_back(cu_obj);


	double *chain_coord_a = new double[chain_length * 9];

	for (int kk = 0; kk < vecosta.size(); kk++)
	{

		double phi_grad = vecosta[kk].phi_d;
		double phi_rad = phi_grad * Pi / 180;

		double psi_grad = vecosta[kk].psi_d;;
		double psi_rad = psi_grad * Pi / 180;


		double *chain_coord_a = new double[chain_length * 9];

		for (unsigned ii = 0; ii < chain_length; ii++)
		{
			phi_set[ii] = phi_rad;;
			psi_set[ii] = psi_rad;
			ome_set[ii] = Pi;
		}

		//	double *chain_coord = new double [len_seq*9];

		refresh_cartesian_by_dihedral(
			model_a,
			phi_set,
			psi_set,
			ome_set,
			chain_coord_a);


		vector < vector < double > >   coord_in_cluster_system;

		ooc_ob.cartesian_to_cluster_system(
			coord_in_cluster_system,
			chain_coord_a,
			chain_length);

		PutVa(vecosta[kk].name, out, 5, 3, 'l');
		PutVaDouble(vecosta[kk].phi_d, out, 5, 3, 'l');   out << '\t';
		PutVaDouble(vecosta[kk].psi_d, out, 5, 3, 'l');	out << ":\t\t";
		out << endl;

		for (int ii = 0; ii < coord_in_cluster_system.size(); ii++)
		{
			for (int jj = 0; jj < coord_in_cluster_system[ii].size(); jj++)
				PutVa(jj, out, 10, 3, 'l');
			out << endl;
			for (int jj = 0; jj < coord_in_cluster_system[ii].size(); jj++)
				PutVaDouble(coord_in_cluster_system[ii][jj], out, 10, 3, 'l');

			out << endl;
			out << endl;
		}


	}
	delete model_a;


}
