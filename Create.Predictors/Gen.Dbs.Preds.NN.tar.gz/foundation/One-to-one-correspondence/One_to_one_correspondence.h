// 
#ifndef ONE_TO_ONE_CORRESPONDENCE_H
#define ONE_TO_ONE_CORRESPONDENCE_H

#include <string>
#include <vector>

class  Cluster_set; 

class  Model ;

using namespace std;

// �������� � ����������� ���� �������� cluster_set_name 
class One_to_one_correspondence
{
public:

	One_to_one_correspondence();
	One_to_one_correspondence(const string &cluster_set_name);

   ~One_to_one_correspondence();
   
   
   void cluster_system_to_cartesian(
	   const vector < vector < double > >  & coord_in_cluster_system,
	   double *chain_coord );

/*    void cartesian_to_cluster_system(
	   vector < vector < double > >  & coord_in_cluster_system,
	   const double *chain_coord );
*/

	void cartesian_to_cluster_system(
	   vector < vector < double > >  & coord_in_cluster_system,
	   double *chain_coord,
	   const int chain_length);

	void  cluster_system_to_cartesian_single_point(		// ������ ��� ������������ ��������� ������ fragment_length_
	   const  vector < double >   & coord_in_cluster_system,
	   double *chain_coord );


	void init_objects_for_single_point (
	  const  vector < double >   & coord_in_cluster_system,
	  Model *model );

	double **get_claster_motif_coordinates () const {return claster_motif_coordinates_;}

	void coord_in_cluster_system_by_dihedral (
		vector < vector < double > >  & coord_in_cluster_system,
		vector < double >  cont_torsion_set,
		Model *model,
		double *chain_coord	);


private:
	
	Cluster_set *cls_ ;
	int number_of_classes_;
	int fragment_length_;

	double ** claster_motif_coordinates_; 

	string cluster_set_name_;

};



#endif
