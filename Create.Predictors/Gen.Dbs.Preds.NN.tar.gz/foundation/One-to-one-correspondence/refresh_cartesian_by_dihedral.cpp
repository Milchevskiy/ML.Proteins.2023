#pragma warning( disable : 4786 )

#include "One_to_one_correspondence_test.h"

#include "../CommonFunc.h"

#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"

#include <cassert>



void refresh_cartesian_by_dihedral (
	Model *model,
	vector <double> & phi_set,
	vector <double> & psi_set,
	vector <double> & ome_set,
	double *chain_coord)
{
	unsigned int seqlen = phi_set.size();
	assert (seqlen == psi_set.size() );	assert (seqlen == ome_set.size() );

	model->set_phi_set(phi_set);
	model->set_psi_set(psi_set);
	model->set_ome_set(ome_set);

	model->calc_cartesain_coordinates();


	vector < Atom * > backbone_set = model->get_core_atoms();
	int counter = 0;
	for ( int ii=0;ii<backbone_set.size(); ii++ )
	{
		chain_coord[counter]=	backbone_set[ii]->x();
		counter++;

		chain_coord[counter]=	backbone_set[ii]->y();
		counter++;

		chain_coord[counter]=	backbone_set[ii]->z();
		counter++;
	}

}

double * get_main_chain_coordinates(
	Model *model)
{
	model->calc_cartesain_coordinates();
	vector < Atom * > backbone_set = model->get_core_atoms();

	double *chain_coord = new double [backbone_set.size()];

	int counter = 0;
	for ( int ii=0;ii<backbone_set.size(); ii++ )
	{
		chain_coord[counter]=	backbone_set[ii]->x();  counter++;
		chain_coord[counter]=	backbone_set[ii]->y();	counter++;
		chain_coord[counter]=	backbone_set[ii]->z();	counter++;
	}

	return chain_coord ;

}
