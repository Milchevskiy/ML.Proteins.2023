#pragma warning( disable : 4786 )

#include "One_to_one_correspondence_test.h"

#include "../CommonFunc.h"

#include "../BioPolymerMechanics/foundation/Model.h"
#include "../BioPolymerMechanics/foundation/Core_iterator.h"
#include "../BioPolymerMechanics/foundation/Atom.h"

#include "../Censorship.h"
//#include "../handle_det_distance_set.h"   // ��� ������� read_det_distance_set()


#include "../Censorship.h"

//#include "../Abu_Maimonides_Rambam.h"

#include <fstream>
#include <cassert>


Model * init_model(const int len_seq);
void refresh_cartesian_by_dihedral (
	Model *model,
	vector <double> & phi_set,
	vector <double> & psi_set,
	vector <double> & ome_set,
	double *chain_coord);



using namespace std;



extern Censorship configuration;

extern ofstream log_stream;

One_to_one_correspondence_test::
~One_to_one_correspondence_test()
{
	cout << "One_to_one_correspondence_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}
/*
void Opt_precursor_test::
constructor_only_test()
{
	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);
}
*/
/*
void Opt_precursor_test::
positioning_chain_by_clasters_set_test()
{
//	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);

	int len_seq = 7;
	Model *model = init_model(len_seq) ;  // ��� ������ 7 ��� �� ALa

	model->init_phi_psi_owega_backbone_set();  // ��� �-� ����� ����  set_phi_set() � ����. � ����� backbone coordinates ���� � ������ ����� ��������

	double Pi = Pythagorean_Number ();
	vector < double >  phi_set;	phi_set.resize(len_seq);
	vector < double  > psi_set;	psi_set.resize(len_seq);
	vector < double  > ome_set;	ome_set.resize(len_seq);

	for ( unsigned ii=0; ii<len_seq; ii++ )
	{
		phi_set[ii] = -0.8;//-0.994;
		psi_set[ii] = -0.6;
		ome_set[ii] = Pi;
	}

	double *chain_coord = new double [len_seq*9]; 

	refresh_cartesian_by_dihedral ( 
		model,
		phi_set,
		psi_set,
		ome_set,
		chain_coord);

	vector < vector < double > >  observation =
		opt_pre.positioning_chain_by_clasters_set ( 
			chain_coord, 
			len_seq);


		ofstream  out( "DIR_tests//Opt_precursor_test_positioning_chain_by_clasters_set_test");
		if ( ! out)	
		{	
			log_stream << "DIR_tests//Opt_precursor_test_positioning_chain_by_clasters_set_test: " << "ERROR -  can't create " << endl;
			cout       << "DIR_tests//Opt_precursor_test_positioning_chain_by_clasters_set_test: " << "ERROR -  can't create " << endl;
			exit (1);	
		}

	
	string Calc_cartesain_coordinates_test_locaction = string ("D:/Agony/DIR_tests/")  + string ("positioning_chain_by_clasters_set_test") + string(".pdb");
	model->save_as(Calc_cartesain_coordinates_test_locaction);


	for (unsigned ii = 0;  ii < observation.size();  ii++ )
	{
		for (unsigned kk = 0;  kk < observation[ii].size();  kk++ )
			PutVaDouble (observation[ii][kk],out,8,4,'l');

		out << endl;

	}
	
	delete [] chain_coord;
	delete model;


}

void Opt_precursor_test::
claster_motif_torsion_set__test()
{

	ofstream  out( "DIR_tests//claster_motif_torsion_set__test");
	if ( ! out)	
	{	
		log_stream << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		cout       << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		exit (1);	
	}


	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);
	vector < vector < double > > claster_motif_torsion_set= opt_pre.get_claster_motif_torsion_set();

	for (unsigned kk=0;kk<claster_motif_torsion_set.size(); kk++)
	{
		for (unsigned jj=0; jj < claster_motif_torsion_set[kk].size(); jj++)
		{
			PutVaDouble (claster_motif_torsion_set[kk][jj], out,10,4,'r');
		}
		out << endl;
	}


	out << endl;out << endl;out << endl;

	vector < vector <double> >  phi_motif = opt_pre.get_phi_motif();
	vector < vector <double> >  psi_motif = opt_pre.get_psi_motif();
	vector < vector <double> >  ome_motif = opt_pre.get_ome_motif();

	for (unsigned kk=0;kk<claster_motif_torsion_set.size(); kk++)
	{
		for (unsigned jj=0; jj < 5 ; jj++)
		{

			PutVaDouble ( ome_motif[kk][jj], out,10,4,'r');
			PutVaDouble ( phi_motif[kk][jj], out,10,4,'r');
			PutVaDouble ( psi_motif[kk][jj], out,10,4,'r');
		}
		out << endl;
	}
}


void Opt_precursor_test::
init_start_conformation_test()
{

	string cur_PDB_ID = "2BF9A";
	ofstream  out( "DIR_tests//claster_motif_torsion_set__test");
	if ( ! out)	
	{	
		log_stream << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		cout       << "DIR_tests//claster_motif_torsion_set__test: " << "ERROR -  can't create " << endl;
		exit (1);	
	}

	Opt_precursor opt_pre ("first",OPT_PRECURSOR_STANDARD_MODE);

	string path_to_predicted_dist_data_file = 		configuration.option_meaning("Path_to_Model_store") + 	
		string("Model_c30_2") + 		string ("/cross_sum/") + cur_PDB_ID +
		 string (".predicted_dist_data") ;


	{
	Abu_Maimonides_Rambam mr ( "Model_c30_2", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();
	mr.make_prediction_by_external_PDB(cur_PDB_ID);
	mr.compare_ready_observation_prediction (cur_PDB_ID); 
	}

	vector < vector < double > > prediction = read_det_distance_set_DIR (path_to_predicted_dist_data_file );

	int len_seq = prediction.size() + 5 - 1 ;
	Model *model = opt_pre.init_model(len_seq) ;  // ��� ������ len_seq  ��� �� ALa
	model->init_phi_psi_owega_backbone_set ();  


	opt_pre.init_start_conformation(model,prediction);

	model->save_as(string("DIR_tests//") + cur_PDB_ID + string ("_pred.pdb") );
	
	delete model ;
}

void Opt_precursor_test::
init_start_conformation_test_ready_for_server_test()
{
	string outputfilename = string("DIR_tests//") + string("init_start_conformation_test_ready_for_server_test"); 
	string sequence = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGPPGPPGPPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

}
*/