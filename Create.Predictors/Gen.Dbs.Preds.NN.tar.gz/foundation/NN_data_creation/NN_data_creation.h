#ifndef NN_DATA_REATION_H_INCLUDED
#define NN_DATA_REATION_H_INCLUDED

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

using namespace std;

class  NN_data_creation: public Simple_test
{
public:
	~NN_data_creation();

    void run()
    {
        simple_example_NN_data_creation();
	}

    void simple_example_NN_data_creation() ;

};



#endif // MASSIVEPREDICTORANALYSIS_H_INCLUDED
