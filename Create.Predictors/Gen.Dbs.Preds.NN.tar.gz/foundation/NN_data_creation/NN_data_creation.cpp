#pragma warning( disable : 4786 )

#include <fstream>


#include "NN_data_creation.h"


#include <cassert>
#include <iostream>
#include <vector>

#include "../Main_model/Abu_Maimonides_Rambam.h"

using namespace std;

extern ofstream log_stream;

NN_data_creation::
~NN_data_creation()
{
	cout << "NN_data_reation PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void NN_data_creation::simple_example_NN_data_creation()
{
/*    {
        Abu_Maimonides_Rambam mr ( "NN_data_creation", fast_FILL_UP_MODEL_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
    }
*/

    {
        Abu_Maimonides_Rambam mr ( "NN_data_creation", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
        mr.prepare_NN_data_for_AI();
    }


}
