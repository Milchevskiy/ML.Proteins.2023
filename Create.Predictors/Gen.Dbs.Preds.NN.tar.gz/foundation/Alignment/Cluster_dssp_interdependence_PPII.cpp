#include "Cluster_dssp_interdependence_PPII.h"
//#include "Cluster_dssp_interdependence.h"

#include "../Fragment_base/accepted_chain_data.h"

#include "../Chain_store/DSSP_binary.h"
#include "../Censorship.h"

#include "../Main_model/handle_det_distance_set.h"
#include "Class_assignment_profile.h"
#include <iostream>

#include "../Sheduler.h"
#include "../Censorship.h"
#include "../CommonFunc.h"
#include "../Cluster_set/Cluster_set.h"

#include "../Pair_int_double.h"
#include "../get_nearest_claster_index.h"

#include "../Main_model/Abu_Maimonides_Rambam.h"

#include <cassert>


extern ofstream log_stream;
extern Censorship configuration;

Cluster_dssp_interdependence_PPII::
Cluster_dssp_interdependence_PPII(
	const string & Cluster_dssp_interdependence_name,
	Cluster_dssp_interdependence_operating_modes run_mode) :
	cluster_dssp_interdependence_name_PPII_(Cluster_dssp_interdependence_name),
	cap_o_(0),
	sheduler_(0),
	inverse_distance_segmentation_ration_(0)
{
	sheduler_ = new Sheduler(configuration.option_meaning("Path_to_Cluster_dssp_interdependence_PPII") + Cluster_dssp_interdependence_name + string("/") + string("sheduler"));

	model_name_ = sheduler_->option_meaning("MAIN_MODEL_NAME");

// ���� ��������� ����� �� �������� TEMPLATE_CHAIN_ID_LIST_
//	string binary_file_name = sheduler_->option_meaning("ACCEPTED_CHAIN_LIST");
//	fill_up_accepted_chain_data(
//		template_chain_ID_list_,
//		template_chain_lenth_,
//		binary_file_name);
// 


/*
	string store_file_name = configuration.option_meaning("Path_to_Cluster_dssp_interdependence_PPII") + Cluster_dssp_interdependence_name + string("/") +
								sheduler_->option_meaning("SEQUENCE_AND_DSSP_PPII_SOURCE_FASTA");

	fill_up_chain_sequence_DSSP_PPII_data(
		template_chain_ID_list_,
		template_chain_lenth_,
		store_file_name,
		ID_to_sequence_map_,
		ID_to_dssp_PPII_map_);
*/

	string path_to_SeqDssp_PPII_data = configuration.option_meaning("Path_to_Cluster_dssp_interdependence_PPII") +
		cluster_dssp_interdependence_name_PPII_ + string("/") +
		string("SeqDssp_PPII.data/");

	string list_file = path_to_SeqDssp_PPII_data + string("list");

	ifstream list_stream(list_file.c_str());
	if (!list_stream)
	{
		log_stream << "Not found " << list_file << endl;
		cout << "Not found " << list_file << endl;
		throw "Not found LIST file";
	}
	string word;
	while (list_stream >> word)
		template_chain_ID_list_.push_back(word);
	int t_size = template_chain_ID_list_.size();
	for (int kk = 0; kk < t_size; kk++)
	{
		string cu_fina = path_to_SeqDssp_PPII_data + template_chain_ID_list_[kk];
		ifstream cu_stream(cu_fina.c_str());
		if (!cu_stream)
		{
			log_stream << "Not found " << cu_fina << endl;
			cout << "Not found " << cu_fina << endl;
			throw "Not found LIST file";
		}
		string sequence;
		string dssp_PPII;

		cu_stream >> sequence;
		cu_stream >> dssp_PPII;
		ID_to_sequence_map_[template_chain_ID_list_[kk]] = sequence;
		ID_to_dssp_PPII_map_[template_chain_ID_list_[kk]] = dssp_PPII;

	}

	path_to_current_model_store_
		= configuration.option_meaning("Path_to_Model_store") + model_name_ + string("/cross_sum/");

	// Only to remind number_of_classes_ 
	string cluster_set_name_ = sheduler_->option_meaning("CLUSTER_SET_NAME");
	cls_ = new Cluster_set(cluster_set_name_, COMMON_USAGE_CLUSTER_SET_MODE);
	number_of_classes_ = cls_->number_of_classes();

	inverse_distance_segmentation_ration_ = atoi(sheduler_->option_meaning("INVERSE_DISTANCE_SEGMENTATION_RATION").c_str());

	// ���� � ����������� ����� ���������� 
	cap_o_ = new Class_assignment_profile(model_name_, COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	eight_letter_number_size_ = 10; //!!!!!!!1

	switch (run_mode)
	{

	case FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES:
		
		fill_up_probability_cluster_for_dssp_PPII();
		break;
	case COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES:
		//init_parameters_for_prediction();
		break;
	default:
		log_stream << "Inadmissible run mode for Maimonides_Rambam class" << endl;
		cout << "Inadmissible run mode for Maimonides_Rambam class" << endl;
		throw;
	}

}

void Cluster_dssp_interdependence_PPII::
fill_up_chain_sequence_DSSP_PPII_data(
	vector < string >		& template_chain_ID_list_,
	vector < int >			& template_chain_lenth_,
	const string			& store_file_name,
	map <string, string>	& ID_to_sequence_map_,
	map <string, string>	& ID_to_dssp_PPII_map_)
{

	ifstream in(store_file_name.c_str());
	if (!in)
	{
		log_stream	<< "Not found " << store_file_name << endl;
		cout		<< "Not found " << store_file_name << endl;
		throw "Not found FASTA file";
	}

	string current_line="";
	int counter = 0;

	vector <string> all_lines;
	vector <int>  header_indexes;
	while (getline(in, current_line, '\n'))
	{
		all_lines.push_back(current_line);

		if (current_line[0] == '>')
			header_indexes.push_back(counter);
		counter++;
	}

	int step_nu = header_indexes.size() - 1;
	for (int ii = 0; ii < step_nu; ii++)
	{
		string current_PDB_chain_ID;
		string current_protein_name;
		int current_seqlen;

		handle_PPII_fasta_header(
			all_lines[header_indexes[ii]],
			current_PDB_chain_ID,
			current_protein_name,
			current_seqlen);

		string current_sequence = "\0";
		string current_DSSP_PPII = "\0";

		int shift_by_one_step = header_indexes[ii + 1] - header_indexes[ii]-1 ;
		for (int kk = header_indexes[ii]+1; kk < header_indexes[ii] + shift_by_one_step/2+1; kk++)
		{
			current_sequence += all_lines[kk];
		}
		for (int kk = header_indexes[ii] + shift_by_one_step / 2+1; kk < header_indexes[ii] + shift_by_one_step+1; kk++)
		{
			current_DSSP_PPII += all_lines[kk];
		}

		ID_to_sequence_map_[current_PDB_chain_ID] = current_sequence;
		ID_to_dssp_PPII_map_[current_PDB_chain_ID] = current_DSSP_PPII;

		assert(current_DSSP_PPII.size() == current_DSSP_PPII.size());
	}
}

void Cluster_dssp_interdependence_PPII::
fill_up_probability_cluster_for_dssp_PPII()
{
	int MAX_SIZE_FOR_PROFILE = 10000;

	int *predicted_profile = new int[MAX_SIZE_FOR_PROFILE];

	d_predicted_probability_dssp_for_cluster_.resize(inverse_distance_segmentation_ration_);

	for (int kk = 0; kk<inverse_distance_segmentation_ration_; kk++)
	{
		d_predicted_probability_dssp_for_cluster_[kk].resize(number_of_classes_);
		for (int ttt = 0; ttt<number_of_classes_; ttt++)
		{
			d_predicted_probability_dssp_for_cluster_[kk][ttt].resize(eight_letter_number_size_);
		}
	}


	//for (int ii = 0; ii < template_chain_ID_list_.size(); ii++)
	for (int ii = 0; ii < 3300; ii++)
	{
		string  template_pdb_id = template_chain_ID_list_[ii];

		string  sequence;
		string  extended_DSSP_sequence;


		vector < vector < vector <double> > >  d_predicted_local_probability_dssp_for_cluster;

		d_handle_single_chain_PPII(
			template_pdb_id,
			string(".dist_data_predicted"),
			d_predicted_local_probability_dssp_for_cluster,
			sequence,
			extended_DSSP_sequence,
			predicted_profile);


		d_print_protocol_PPII(
			d_predicted_local_probability_dssp_for_cluster,
			template_pdb_id,
			sequence,
			extended_DSSP_sequence,
			predicted_profile);


		for (int ttt = 0; ttt<inverse_distance_segmentation_ration_; ttt++)
		{
			for (int kk = 0; kk<number_of_classes_; kk++)
			{
				for (int jj = 0; jj<eight_letter_number_size_; jj++)
				{
//					d_observed_probability_dssp_for_cluster_[ttt][kk][jj] +=
//						d_observed_local_probability_dssp_for_cluster[ttt][kk][jj];

					double test = d_predicted_local_probability_dssp_for_cluster[ttt][kk][jj];
					double test1 = d_predicted_probability_dssp_for_cluster_[ttt][kk][jj];

					d_predicted_probability_dssp_for_cluster_[ttt][kk][jj] +=
						d_predicted_local_probability_dssp_for_cluster[ttt][kk][jj];
				}
			}
		}
		cout << ii<< '\t' << template_chain_ID_list_[ii] << endl;
	}
//	d_print_trivial_result(string("d_result"));


	d_print_trivial_result_PPII(
		"d_result");



	delete[] predicted_profile;
}


void Cluster_dssp_interdependence_PPII::
d_print_trivial_result_PPII(
	const string & result_file_name)
{
	
	string path_to_protocol_file =
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence_PPII") +
		cluster_dssp_interdependence_name_PPII_ +
		string("/") + string("protocol") + string("/") +
		result_file_name + string(".d_simple_protocol");

	ofstream protocol_stream(path_to_protocol_file.c_str(), ios::binary);

	if (!protocol_stream) {
		log_stream << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file << endl;
		cout << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file << endl;
		exit(1);
	}

	protocol_stream << "Cluster No/DSSP class    ";
	PutVa("H", protocol_stream, 12, 1, 'l');
	PutVa("G", protocol_stream, 12, 1, 'l');
	PutVa("I", protocol_stream, 12, 1, 'l');
	PutVa("E", protocol_stream, 12, 1, 'l');
	PutVa("B", protocol_stream, 12, 1, 'l');
	PutVa("S", protocol_stream, 12, 1, 'l');
	PutVa("T", protocol_stream, 12, 1, 'l');
	PutVa("-", protocol_stream, 12, 1, 'l');
	PutVa("_", protocol_stream, 12, 1, 'l');
	PutVa("P", protocol_stream, 12, 1, 'l');

	protocol_stream << endl;


	//vector < vector < vector <double> > >  d_observed_probability_dssp_for_cluster_;
	//vector < vector < vector <double> > >  d_predicted_probability_dssp_for_cluster_;

	for (int kk = 0; kk<number_of_classes_; kk++)
	{
		for (int ttt = 0; ttt<inverse_distance_segmentation_ration_; ttt++)
		{
			PutVa(kk, protocol_stream, 15, 1, 'l');
			PutVa(ttt, protocol_stream, 10, 1, 'l');

			for (int jj = 0; jj<eight_letter_number_size_; jj++)
			{
				double test = d_predicted_probability_dssp_for_cluster_[ttt][kk][jj];
				PutVaDouble(
					d_predicted_probability_dssp_for_cluster_[ttt][kk][jj],
					protocol_stream, 12, 2, 'l');

			}
			protocol_stream << endl;
		}

	}

	protocol_stream << "_______________________________________________________________________" << endl;
	//// ��� ��� ��������
//	vector < vector <int> >  d_observed_class_occurence_counter; d_observed_class_occurence_counter.resize(inverse_distance_segmentation_ration_);
	vector < vector <int> >  d_predicted_class_occurence_counter; d_predicted_class_occurence_counter.resize(inverse_distance_segmentation_ration_);

	for (int ii = 0; ii<inverse_distance_segmentation_ration_; ii++)
	{
//		d_observed_class_occurence_counter[ii].resize(number_of_classes_);
		d_predicted_class_occurence_counter[ii].resize(number_of_classes_);
	}

	for (int kk = 0; kk<number_of_classes_; kk++)
	{
		for (int ttt = 0; ttt<inverse_distance_segmentation_ration_; ttt++)
		{
			for (int jj = 0; jj<eight_letter_number_size_; jj++)
			{
//				d_observed_class_occurence_counter[ttt][kk] += (int)d_observed_probability_dssp_for_cluster_[ttt][kk][jj];
				d_predicted_class_occurence_counter[ttt][kk] += (int)d_predicted_probability_dssp_for_cluster_[ttt][kk][jj];
			}
		}
	}

	protocol_stream << "Cluster No/DSSP class    ";
	PutVa("H", protocol_stream, 12, 1, 'l');
	PutVa("G", protocol_stream, 12, 1, 'l');
	PutVa("I", protocol_stream, 12, 1, 'l');
	PutVa("E", protocol_stream, 12, 1, 'l');
	PutVa("B", protocol_stream, 12, 1, 'l');
	PutVa("S", protocol_stream, 12, 1, 'l');
	PutVa("T", protocol_stream, 12, 1, 'l');
	PutVa("-", protocol_stream, 12, 1, 'l');
	PutVa("_", protocol_stream, 12, 1, 'l');
	PutVa("P", protocol_stream, 12, 1, 'l');

	protocol_stream << endl;

	for (int kk = 0; kk<number_of_classes_; kk++)
	{
		for (int ttt = 0; ttt<inverse_distance_segmentation_ration_; ttt++)
		{
			PutVa(kk, protocol_stream, 15, 1, 'l');
			PutVa(ttt, protocol_stream, 10, 1, 'l');

			for (int jj = 0; jj<eight_letter_number_size_; jj++)
			{
				if (d_predicted_class_occurence_counter[ttt][kk] == 0)
					PutVa(
						"0", protocol_stream, 12, 0, 'l');
				else
					PutVaDouble(
						d_predicted_probability_dssp_for_cluster_[ttt][kk][jj] / d_predicted_class_occurence_counter[ttt][kk],
						protocol_stream, 12, 4, 'l');

			}
			protocol_stream << endl;
		}
	}
}

void Cluster_dssp_interdependence_PPII::
d_print_protocol_PPII(
	//vector < vector < vector <double> > >  &	d_observed_local_probability_dssp_for_cluster,
	vector < vector < vector <double> > >  &	d_predicted_local_probability_dssp_for_cluster,
	const string & template_pdb_id,
	string & sequence,
	string & extended_DSSP_sequence,
	//int *observed_profile,
	int *predicted_profile)
{

	path_to_current_model_store_ =
		configuration.option_meaning("Path_to_Model_store") + model_name_ + string("/cross_sum/");

	string path_to_protocol_file =
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence_PPII") +
		cluster_dssp_interdependence_name_PPII_ +
		string("/") + string("protocol") + string("/") +
		template_pdb_id +
		string(".d_simple_protocol");

	ofstream protocol_stream(path_to_protocol_file.c_str(), ios::binary);

	if (!protocol_stream) {
		log_stream << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file << endl;
		cout << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file << endl;
		exit(1);
	}

	int seqlen = sequence.size();
	int dssp_len = extended_DSSP_sequence.size();

	if (seqlen - dssp_len == 1)
		extended_DSSP_sequence += '_';

	assert(sequence.size() == extended_DSSP_sequence.size());

	int seq_len = sequence.size();

	for (int ii = 0; ii< 2; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	for (int ii = 0; ii<seq_len - 4; ii++)
	{
		protocol_stream << sequence[ii + 2] << "\t" << extended_DSSP_sequence[ii + 2] << "\t";
		PutVa(predicted_profile[ii], protocol_stream, 5, 2, 'l');
	//	PutVa(observed_profile[ii], protocol_stream, 5, 2, 'l');
		protocol_stream << endl;
	}
	for (int ii = seq_len - 2; ii< seq_len; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	protocol_stream << "____________________________________________________________________________" << endl;


	protocol_stream << "Cluster No/DSSP class    ";
	PutVa("H", protocol_stream, 12, 1, 'l');
	PutVa("G", protocol_stream, 12, 1, 'l');
	PutVa("I", protocol_stream, 12, 1, 'l');
	PutVa("E", protocol_stream, 12, 1, 'l');
	PutVa("B", protocol_stream, 12, 1, 'l');
	PutVa("S", protocol_stream, 12, 1, 'l');
	PutVa("T", protocol_stream, 12, 1, 'l');
	PutVa(" ", protocol_stream, 12, 1, 'l');
	PutVa("_", protocol_stream, 12, 1, 'l');
	PutVa("P", protocol_stream, 12, 1, 'l');
	protocol_stream << endl;

	//	vector < vector < vector <double> > >  &	d_observed_local_probability_dssp_for_cluster,
	//	vector < vector < vector <double> > >  &	d_predicted_local_probability_dssp_for_cluster,

	for (int kk = 0; kk<number_of_classes_; kk++)
	{
		for (int ttt = 0; ttt<inverse_distance_segmentation_ration_; ttt++)
		{
			PutVa(kk, protocol_stream, 15, 1, 'l');
			PutVa(ttt, protocol_stream, 10, 1, 'l');

			for (int jj = 0; jj<eight_letter_number_size_; jj++)
			{
				PutVaDouble(
					d_predicted_local_probability_dssp_for_cluster[ttt][kk][jj],
					protocol_stream, 12, 2, 'l');

			}

			protocol_stream << endl;
		}
	}

}


void Cluster_dssp_interdependence_PPII::  // �� �� ��� � handle_single_chain()  �� ������������ (�� ��� �������) "����������� �� �����������".
d_handle_single_chain_PPII(
	const string & template_pdb_id,
	const string & extension_suffix,
	vector < vector < vector <double> > > & d_local_probability_cluster_for_dssp,
	string & sequence,
	string & extended_DSSP_sequence,
	int *profile)
{


	d_local_probability_cluster_for_dssp.resize(inverse_distance_segmentation_ration_);
	for (int kk = 0; kk<inverse_distance_segmentation_ration_; kk++)
	{
		d_local_probability_cluster_for_dssp[kk].resize(number_of_classes_);
		for (int ttt = 0; ttt<number_of_classes_; ttt++)
		{
			d_local_probability_cluster_for_dssp[kk][ttt].resize(eight_letter_number_size_);
		}
	}

/*
	DSSP_binary pdb_ID_dssp(template_pdb_id, COMMON_USAGE);
	extended_DSSP_sequence = pdb_ID_dssp.get_extended_DSSP_sequence();
	sequence = pdb_ID_dssp.get_sequence();
*/
// � ������ � PPII ��� �����

	extended_DSSP_sequence	=  ID_to_dssp_PPII_map_	[template_pdb_id];
	sequence				=	 ID_to_sequence_map_[template_pdb_id];


	string current_distance_file_name = path_to_current_model_store_ + template_pdb_id + extension_suffix; // string (".dist_data");

	vector < vector < double > > det_distance_set =
		read_det_distance_set(current_distance_file_name);
	int length = det_distance_set.size();

	//	int *profile = new int [length];
	memset(profile, 0, length*sizeof(int));
	cap_o_->make_class_assignment_profile(
		det_distance_set,
		profile);

//	int size_by_dssp = pdb_ID_dssp.get_sequence().size();
//	int size_distance_set = det_distance_set.size();

// � ������ � PPII ��� �����
	int size_by_dssp = sequence.size();
	int size_distance_set = det_distance_set.size();
 	assert((size_by_dssp - 4) == size_distance_set);

	int shift = 2;

	for (int ii = 0; ii< size_distance_set; ii++)
	{
		int index_dssp;
		char ch = extended_DSSP_sequence[ii + shift];
		switch (ch)
		{
		case 'H': index_dssp = 0; break;
		case 'G': index_dssp = 1; break;
		case 'I': index_dssp = 2; break;
		case 'E': index_dssp = 3; break;
		case 'B': index_dssp = 4; break;
		case 'S': index_dssp = 5; break;
		case 'T': index_dssp = 6; break;
		case  '-': index_dssp = 7; break;
		case '_': index_dssp = 8; break;
		case 'P': index_dssp = 9; break;

		default:
			cout << extended_DSSP_sequence[ii + shift] << "strange DSSP class" << endl;
		}
		int index_cluster = profile[ii];

		if (index_cluster == -1)
			continue;        	// for observed cluster only

		double inv_distance = det_distance_set[ii][index_cluster + number_of_classes_];
	//	int segment_index = get_inverse_distance_segment_index(inv_distance);

		int segment_index = get_inverse_distance_segment_index(
			inv_distance,
			inverse_distance_segmentation_ration_);


		d_local_probability_cluster_for_dssp[segment_index][index_cluster][index_dssp] ++;
	}


}

