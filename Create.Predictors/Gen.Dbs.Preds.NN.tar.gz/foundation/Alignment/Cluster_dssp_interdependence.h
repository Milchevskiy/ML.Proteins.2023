#ifndef CLUSTER_DSSP_INTERDEPENDENCE_H
#define CLUSTER_DSSP_INTERDEPENDENCE_H

#include <string>
#include <fstream>
#include <map>
#include <vector>

#ifndef CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES_H
#define CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES_H

enum Cluster_dssp_interdependence_operating_modes
{
	COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES,
	FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES,
} ;
#endif

enum Prediction_mode
{
	THREE_LETTER_BY_READY_CLUSTER_PROFILE,
	EIGHT_LETTER_BY_READY_CLUSTER_PROFILE,
} ;



using namespace std;

class Class_assignment_profile;
class Sheduler;
class Cluster_set;

class Pair_int_double;


class  Cluster_dssp_interdependence
{
public:
	Cluster_dssp_interdependence(const string &cluster_dssp_interdependence_name, Cluster_dssp_interdependence_operating_modes run_mode) ;

	void fill_up_artless_probability_cluster_for_dssp();

	void fill_up_probability_cluster_for_dssp();

	// read parameters from file
	void get_trivial_cluster_preference (
		vector <vector <double> > & predicted_artless_probability_dssp_for_cluster );
	void get_trivial_cluster_preference (
		vector <vector <double> > & predicted_artless_probability_dssp_for_cluster,
		string & dssp_eight_names);

	vector < vector < Pair_int_double > > 	get_key_for_trivial_dssp_prediction (
			vector <vector <double> > & artless_probability_cluster_for_dssp);

	vector < vector < vector < Pair_int_double > > >  get_key_for_d_dssp_prediction (
			vector < vector < vector <double> > > & d_probability_dssp_for_cluster_);

	string  	trivial_eight_letter_prediction_by_ready_cluster_profile  (
		int *predicted_profile,
		int length,  // size of predicted_profile  (LENGHT OF SEQUENCE - 4 )
		vector < vector < Pair_int_double > > & key_for_trivial_dssp_prediction,
		string & dssp_eight_names);


	string 	predict_dssp_eight_letter (
			vector < vector < double > > & predicted_det_distance_set);

//	string 	predict_dssp_eight_letter_by_sequence (
	//	const string & sequence );

	string
		predict_dssp_eight_letter_by_sequence (
			const string & sequence,
			vector <double> &prob_value);



	string 	d_predict_dssp_eight_letter (
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < vector < Pair_int_double > > > & d_key_for_dssp_prediction);

	// �� �� ��� � ����������, ������ � prob_value
	string
	d_predict_dssp_eight_letter_and_prob_value (
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < vector < Pair_int_double > > > & d_key_for_dssp_prediction,
		vector <double> &prob_value);

	string 	predict_dssp_eight_letter (
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < Pair_int_double > > & key_for_trivial_dssp_prediction );


	string  compare_dssp_prediction_for_known_structure (
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < double > > & observed_det_distance_set,
		Prediction_mode pmode);

	void print_predicted_observed_comparison_for_ready_prediction	( const string & template_pdb_id);
	void d_print_predicted_observed_comparison_for_ready_prediction ( const string & template_pdb_id);


	vector <string> get_template_chain_ID_list () const { return template_chain_ID_list_;}

	int get_inverse_distance_segment_index (const double inv_distance_value);

	//void print_cluster_preference(); // �������� cluster preference

	void
d_print_trivial_result (	// the same like print_trivial_result taking into account distance distribution
	const string & result_file_name);


private:

	Sheduler		*sheduler_;

	string cluster_dssp_interdependence_name_;

// model name relating to regression  model creating distance to cluster prediction
//	"second_model_advanced"  for example
	string model_name_;
	string path_to_current_model_store_	;

	string dssp_eight_names_;

//	void handle_single_chain_for_observed(const string & template_pdb_id);
//	void handle_single_chain_for_predicted(const string & template_pdb_id);

void handle_single_chain(
	const string & template_pdb_id,
	const string & extension_suffix,
	vector <vector <double> > & local_artless_probability_cluster_for_dssp,
	string & sequence,
	string & extended_DSSP_sequence,
	int *profile);

void   // �� �� ��� � handle_single_chain()  �� ������������ (�� ��� �������) "����������� �� �����������".
d_handle_single_chain(
	const string & template_pdb_id,
	const string & extension_suffix,
	vector < vector < vector <double> > > & d_local_probability_cluster_for_dssp,
	string & sequence,
	string & extended_DSSP_sequence,
	int *profile);

void print_protocol (
	vector <vector <double> > observed_local_artless_probability_dssp_for_cluster,
	vector <vector <double> > predicted_artless_probability_dssp_for_cluster,
	const string & template_pdb_id,
	string & sequence,
	string & extended_DSSP_sequence,
	int *observed_profile,
	int *predicted_profile);

void
d_print_protocol (
	vector < vector < vector <double> > >  &	d_observed_local_probability_dssp_for_cluster,
	vector < vector < vector <double> > >  &	d_predicted_local_probability_dssp_for_cluster,
	const string & template_pdb_id,
	string & sequence,
	string & extended_DSSP_sequence,
	int *observed_profile,
	int *predicted_profile);

/*
void Cluster_dssp_interdependence::
d_print_trivial_result (	// the same like print_trivial_result taking into account distance distribution
	const string & result_file_name);
*/
void print_trivial_result (  // print predicted_artless_probability_dssp_for_cluster_
	const string & result_file_name);

void init_parameters_for_prediction();
void init_trivial_cluster_preference ();		// assigns predicted & observed !!!
void init_cluster_preference ();

void init_key_for_trivial_dssp_prediction ();	// assigns predicted & observed !!!
void init_key_for_dssp_prediction ();			// assigns predicted & observed !!!


//int get_inverse_distance_segment_index (const double inv_distance_value);


// ������ �� ����� ��������� � �������� ������� ���� ����������� � ������ dssp
	vector < vector <double> > observed_artless_probability_dssp_for_cluster_;
	vector < vector <double> > predicted_artless_probability_dssp_for_cluster_;

	vector < vector < Pair_int_double > > key_for_trivial_dssp_prediction_;
	vector < vector < Pair_int_double > > key_for_trivial_dssp_prediction_by_observed_;

// �� ��, ��� � ����, �� ������ ������ ���������� �������� ��������� ���������� (����������� �� �����������)
// ��������� ������� ����� ���� ��������� ����� ���� ������ ������ ��� ������. ��� ��������� �������� ��������� �� ������� [0,1] ������� �� �������.

	vector < vector < vector <double> > >  d_observed_probability_dssp_for_cluster_;
	vector < vector < vector <double> > >  d_predicted_probability_dssp_for_cluster_;

	vector < vector < vector < Pair_int_double > > > d_key_for_dssp_prediction_;
	vector < vector < vector < Pair_int_double > > > d_key_for_dssp_prediction_by_observed_;

	int inverse_distance_segmentation_ration_;


//	vector <int>

//	local_artless_probability_cluster_for_dssp
// array size CLUSTER_NUMBER (30)  X   DSSP class number (3)

//	vector <int>  observed_counter_;
//	vector <int>  predicted_counter_;

	vector <string> template_chain_ID_list_;
	vector <int >	template_chain_lenth_;

	Class_assignment_profile *cap_o_;

	Cluster_set  *cls_;

	int number_of_classes_ ;
	int eight_letter_number_size_;

};

double calcQ8 (
		string & extended_DSSP_sequence,
		const string & dssp_eight_letter_prediction,
		const string & is_structure_present);

double calcQ3 (
		string & extended_DSSP_sequence,
		string & dssp_eight_letter_prediction,
		const string & is_structure_present);

string reduce_8letter_to_3letter ( string & dssp_sequence_8 );

#endif
