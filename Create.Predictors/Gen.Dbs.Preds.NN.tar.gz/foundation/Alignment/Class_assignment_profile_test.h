#ifndef CLASS_ASSIGNMENT_PROFILE_TEST_H
#define CLASS_ASSIGNMENT_PROFILE_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Class_assignment_profile_test: public Simple_test
{
public:
	~Class_assignment_profile_test();

    void run()
    {
//		fill_up_test ();
//		get_observed_index_set_test () ;
		compare_predicted_and_observed_assignment_test();
	}
	void fill_up_test();
	void get_observed_index_set_test() ;
	void compare_predicted_and_observed_assignment_test();

};

#endif 


