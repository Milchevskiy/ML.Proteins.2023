#include "../CommonFunc.h"

using namespace std;

void handle_PPII_fasta_header(
	const string current_line,
	string & PDB_chain_ID,
	string & protein_name,
	int & seqlen)
{

	char cu_char = '\0';
	string buff;
	istringstream ist(current_line);
	while (ist >> cu_char)			// read pdbID
	{
		if (cu_char == ';')
			break;
		if(cu_char!='>')
			PDB_chain_ID += cu_char;
	}
	while (ist >> cu_char)			// read chainID
	{
		if (cu_char == ';')
			break;
		PDB_chain_ID += cu_char;
	}
	while (ist >> cu_char)			// read pdbID
	{
		if (cu_char == ';')
			break;
		protein_name += cu_char;
	}

	while (ist >> cu_char)			// read pdbID
	{
		if (cu_char == ';')
			break;
		buff += cu_char;
	}

	seqlen = atoi(buff.c_str());
}