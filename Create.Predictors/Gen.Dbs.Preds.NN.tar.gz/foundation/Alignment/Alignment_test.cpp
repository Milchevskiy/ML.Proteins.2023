#pragma warning( disable : 4786 )

#include "Alignment_test.h"
#include "Alignment.h"

#include "../CommonFunc.h"
#include "../Sheduler.h"
#include "../Censorship.h"

#include "Class_assignment_profile.h"


using namespace std;

extern ofstream log_stream;
extern Censorship configuration;


Alignment_test::
~Alignment_test()
{
	cout << "Alignment_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Alignment_test::
	pairwise_alignment_test()
{
//	1A4SA
//	1F52A  - template

	string alignment_model_name = string("Al_1");
	Alignment ali_o(alignment_model_name);

	string model_name = ali_o.get_model_name();
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	string pdb_ID =  string("1A4SA");
	vector <int> pred_index_set		= cap_o.get_predicted_index_set(pdb_ID);

	string template_pdb_id =  string("3EK1A");
	vector <int> template_index_set	 = cap_o.get_observed_index_set  (template_pdb_id);


	vector <vector < Afinity_sample > > local_Afinity_base =
		ali_o.pairwise_alignment(  // ���� ������ �������  local_Afinity_base
			pred_index_set,
			template_pdb_id,
			template_index_set	 );

	double threshold = 7;

	string output_file_name = string ("Test/pairwise_alignment_test.")+pdb_ID;

	ali_o.print_pairwise_alignment_result (
		local_Afinity_base,
		threshold,
		pdb_ID,
		template_pdb_id,
		output_file_name);



/*
	ali_o.analyse_local_afinity_base (
		threshold,
		pdb_ID,
		template_pdb_id);
*/
/*
	vector <int>		 start_position_array;
	vector <int>		 template_start_position_array;
	vector <double>		 afinity_array;

	ali_o.get_undigested_alignment_by_local_Afinity_base (
		local_Afinity_base,
		start_position_array,
		template_start_position_array,
		afinity_array );
*/


}



void Alignment_test::
first_dummy_test ()
{
	string alignment_model_name = string("Al_1");
	Alignment ali_o(alignment_model_name);

	string model_name = ali_o.get_model_name();
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);
		//string pdb_ID =  string("1AWDA");

//		string pdb_ID =  string("2AKFA");
//		string pdb_ID =  string("2AKFA");//		string pdb_ID =  string("2AKFA");
	//string pdb_ID =  string("1P9GA");
//	string pdb_ID =  string("2AJ6A");

	//string pdb_ID =  string("2AIQA");

	//
	//string pdb_ID =  string("1A4SA");

	string pdb_ID =  string("1A4SA");

	//string pdb_ID =  string("1FIOA");

	 vector <int> index_set_predicted = cap_o.get_predicted_index_set(pdb_ID);
	 ali_o.fill_up_coincidence_data(index_set_predicted) ;


	string output_file_name = string ("Test/first_dummy_test.")+pdb_ID;
	ali_o.show_Afinity_map_and_analyze_known_structure(
		pdb_ID,
		output_file_name);

	vector < Pair_string_double > descending_by_afinity_sample_pdb_id =
		ali_o.Analyse_afinity_base (pdb_ID);

	string output_file_name1 = string ("Test/first_dummy_test.")+pdb_ID+string(".sorted_pdb_id_by_afinity");
	ofstream  out( output_file_name1.c_str());
	if ( ! out)	{
		log_stream << output_file_name1 << "ERROR -  can't create file" << endl;
		cout       << output_file_name1 << "ERROR -  can't create file" << endl;
		throw;
	}
	for (int ii=0; ii<descending_by_afinity_sample_pdb_id.size();ii++)
	{
		out << descending_by_afinity_sample_pdb_id[ii].index() << "\t";
		out << descending_by_afinity_sample_pdb_id[ii].value() << endl;
	}
}

void Alignment_test::
fill_up_dispersion_and_mean_test ()
{

	string alignment_model_name = string("Al_1");
	Alignment ali_o(alignment_model_name);

	string model_name = ali_o.get_model_name();
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	string pdb_ID =  string("1A4SA");

	 vector <int> index_set_predicted = cap_o.get_predicted_index_set(pdb_ID);
//	 ali_o.fill_up_coincidence_data(index_set_predicted) ;

	double sum_average,sum_sigma;
	int sum_counter;


	 ali_o.fill_up_dispersion_and_mean(
		index_set_predicted,
	 	sum_average,
		sum_sigma,
		sum_counter) ;

	string output_file_name = string ("Test/fill_up_dispersion_and_mean_test.")+pdb_ID;

	ofstream  out( output_file_name.c_str());
	if ( ! out)	{
		log_stream << output_file_name << "ERROR -  can't create file" << endl;
		cout       << output_file_name << "ERROR -  can't create file" << endl;
		throw;
	}


	out << 	 	sum_average		<< endl;
	out << 	 	sum_sigma		<< endl;
	out << 	 	sum_counter		<< endl;

}


/*
void Alignment_test::check_average_and_dispersion()
{
	string alignment_model_name = string("Al_1");
	Alignment ali_o(alignment_model_name);

	string model_name = ali_o.get_model_name();
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	string pdb_ID =  string("1A4SA");


}
*/

void Alignment_test::fill_up_coincidence_data_for_new_PDB_test (	)

{
	string alignment_model_name = string("Al_1");
	Alignment ali_o(alignment_model_name);

	string model_name = ali_o.get_model_name();
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	string pdb_ID =  string("2lr8A");
	ali_o.fill_up_coincidence_data_for_new_PDB (pdb_ID);


	string output_file_name = string ("Test/fill_up_coincidence_data_for_new_PDB_test");
	ali_o.show_Afinity_map_and_analyze_known_structure(
		pdb_ID,
		output_file_name);



}

