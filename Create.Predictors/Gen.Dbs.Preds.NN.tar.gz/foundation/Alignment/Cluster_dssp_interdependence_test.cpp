#pragma warning( disable : 4786 )

#include "Cluster_dssp_interdependence_test.h"
#include "Cluster_dssp_interdependence.h"
//#include "Frequency_extrapolation_ZIP.h"

#include "../Censorship.h"
#include "../CommonFunc.h"

#include <fstream>
#include <iostream>
#include <cassert>

#include "../Pair_int_double.h"
#include "../Main_model/handle_det_distance_set.h"
#include "Class_assignment_profile.h"
#include "../Chain_store/DSSP_binary.h"

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

Cluster_dssp_interdependence_test::~Cluster_dssp_interdependence_test()
{
    cout << "Cluster_dssp_interdependence_test passed: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Cluster_dssp_interdependence_test::
predict_dssp_eight_letter_by_sequence_test ()
{
    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);
//1DD3C
    string sequence = string ("NECVSKGFGCLPQSDCPQEARLSYGGCSTVCCDLSKLTGCKGKGGECNPLDRQCKELQAESASCGKGQKCCVWL");

    vector <double> prob_value;
    string  dssp_eight_letter =	di_oject.predict_dssp_eight_letter_by_sequence (
                                    sequence,
                                    prob_value);

    string  dssp_tri_letter =  reduce_8letter_to_3letter ( dssp_eight_letter );


    string path_to_output_file = string("D:/Didona/Test/predict_dssp_eight_letter_by_sequence" );
    ofstream out ( path_to_output_file.c_str());

    if ( ! out )
    {
        cout		<< "ERROR -  can't create " << path_to_output_file << endl;
        log_stream	<< "ERROR -  can't create " << path_to_output_file << endl;
        throw;
    }
    out  << sequence[0] << endl;
    out  << sequence[1] << endl;

    int size_dssp_seq = dssp_eight_letter.size();
    for (int ii=0; ii<size_dssp_seq; ii++)
    {
        out  << sequence[ii+2] << "\t" << dssp_eight_letter[ii] << "\t" << dssp_tri_letter [ii] << "\t" << prob_value[ii] << endl;
    }
    out  << sequence[size_dssp_seq+2] << endl;
    out  << sequence[size_dssp_seq+3] << endl;
}

void Cluster_dssp_interdependence_test::
d_print_predicted_observed_comparison_for_ready_prediction_test()
{
    string template_pdb_id = "3NQBA";

    Cluster_dssp_interdependence di_oject(
        string ("Second_by_DSSP_30_model"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    di_oject.d_print_predicted_observed_comparison_for_ready_prediction(template_pdb_id);


    vector <string> template_chain_ID_list = di_oject.get_template_chain_ID_list();
// fix
    for (int ii=0; ii < template_chain_ID_list.size(); ii++)
    {
        string  template_pdb_id = template_chain_ID_list[ii];
        di_oject.d_print_predicted_observed_comparison_for_ready_prediction(template_pdb_id);
        cout << ii << " " << template_pdb_id  << endl;
    }





}
void Cluster_dssp_interdependence_test::
get_key_for_d_dssp_prediction_test ()
{
    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    di_oject.d_print_trivial_result(string("d_check_result") );

}
void Cluster_dssp_interdependence_test::
get_inverse_distance_segment_index_test()
{
    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    vector <double> inv_value;
    inv_value.push_back(0.1);
    inv_value.push_back(0.11);
    inv_value.push_back(0.21);
    inv_value.push_back(0.31);
    inv_value.push_back(0.41);
    inv_value.push_back(0.5);
    inv_value.push_back(0.61);
    inv_value.push_back(0.71);
    inv_value.push_back(0.81);
    inv_value.push_back(0.91);
    inv_value.push_back(1);
    inv_value.push_back(1.1);
    inv_value.push_back(1.1);
    inv_value.push_back(-1);

    for (int ii=0; ii<inv_value.size(); ii++)
    {
        int curren_index = di_oject.get_inverse_distance_segment_index(inv_value[ii]);
        cout << inv_value[ii] << "\t" << curren_index << endl;
    }

}

void Cluster_dssp_interdependence_test::
print_predicted_observed_comparison_for_ready_prediction_test()
{

    string template_pdb_id = "4DZNA";

    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    di_oject.print_predicted_observed_comparison_for_ready_prediction(template_pdb_id);


    vector <string> template_chain_ID_list = di_oject.get_template_chain_ID_list();
    for (int ii=0; ii < template_chain_ID_list.size(); ii++)
    {
        string  template_pdb_id = template_chain_ID_list[ii];
        di_oject.print_predicted_observed_comparison_for_ready_prediction(template_pdb_id);
        cout << ii << " " << template_pdb_id  << endl;
    }



}

void Cluster_dssp_interdependence_test::
trivial_eight_letter_prediction_by_ready_cluster_profile_test()
{

    string template_pdb_id = "1FR3A";

    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    string path_to_current_model_store
        = configuration.option_meaning("Path_to_Model_store")  + string ("second_model_advanced") + string ("/cross_sum/")  ;

    string extension_suffix = string (".dist_data_predicted");
    string current_distance_file_name = path_to_current_model_store + template_pdb_id + extension_suffix; // string (".dist_data");

    vector < vector < double > > predicted_det_distance_set =
        read_det_distance_set (current_distance_file_name);
    int length = predicted_det_distance_set.size();

    string model_name = string ("second_model_advanced");

    Class_assignment_profile *cap_o = new Class_assignment_profile (model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

    int *profile = new int [length];
    memset(profile,0,length*sizeof (int ) );
    cap_o-> make_class_assignment_profile (
        predicted_det_distance_set,
        profile);


    vector <vector <double> >  predicted_artless_probability_dssp_for_cluster;
    string  dssp_eight_names;
    di_oject.get_trivial_cluster_preference (
        predicted_artless_probability_dssp_for_cluster,
        dssp_eight_names);

//	vector <vector <double> >  predicted_artless_probability_dssp_for_cluster;
    vector < vector < Pair_int_double > > key_for_trivial_dssp_prediction =
        di_oject.get_key_for_trivial_dssp_prediction (
            predicted_artless_probability_dssp_for_cluster);

    string  predicted_extended_DSSP_sequence =
        di_oject.trivial_eight_letter_prediction_by_ready_cluster_profile  (
            profile,
            length,  // size of predicted_profile  (LENGHT OF SEQUENCE - 4 )
            key_for_trivial_dssp_prediction,
            dssp_eight_names);

    DSSP_binary pdb_ID_dssp (template_pdb_id,COMMON_USAGE);

    string extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
    string sequence					= pdb_ID_dssp.get_sequence();

    string path_to_output_file = string("D:/Didona/Test/trivial_eight_letter_prediction_by_ready_cluster_profile_test." + template_pdb_id );
    ofstream out ( path_to_output_file.c_str());


    if ( ! out )
    {
        cout		<< "ERROR -  can't create " << path_to_output_file << endl;
        log_stream	<< "ERROR -  can't create " << path_to_output_file << endl;
        throw;
    }
    for (int ii=0; ii<length; ii++ )
    {
        out<< sequence[ii+2] << "\t";
        out<< extended_DSSP_sequence[ii+2] << "\t";
        out<< profile[ii] << "\t";
        out<< predicted_extended_DSSP_sequence[ii]<< "\t";
        out<< endl;
    }



    delete [] profile;
    delete cap_o;
}

void Cluster_dssp_interdependence_test::
single_test()
{
    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);



}



void Cluster_dssp_interdependence_test::
fill_up_test ()
{
    Cluster_dssp_interdependence di_oject(
        string ("First"),
        FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    //di_oject.fill_up_artless_probability_cluster_for_dssp();
}

void Cluster_dssp_interdependence_test::
fill_up_probability_cluster_for_dssp_test ()
{

//	Cluster_dssp_interdependence di_oject(
//		string ("First"),
//		FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    Cluster_dssp_interdependence di_oject(
        string ("Second_by_DSSP_30_model"),
        FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);


    ///////di_oject.fill_up_probability_cluster_for_dssp();
}



void Cluster_dssp_interdependence_test::
get_trivial_cluster_preference_test()
{
    Cluster_dssp_interdependence di_oject(
        string ("First"),
        COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

    vector <vector <double> >  predicted_artless_probability_dssp_for_cluster;
    string dssp_eight_names;
    di_oject.get_trivial_cluster_preference(
        predicted_artless_probability_dssp_for_cluster,
        dssp_eight_names);


    vector < vector < Pair_int_double > > key_for_trivial_dssp_prediction =
        di_oject.get_key_for_trivial_dssp_prediction(
            predicted_artless_probability_dssp_for_cluster) ;

    int number_of_classes = key_for_trivial_dssp_prediction.size();
    assert (number_of_classes==30);

    int eight_letter_number_size = dssp_eight_names.size();
    assert (eight_letter_number_size==9);

    string path_to_output_file = string("D:/Didona/Test/key_for_trivial_dssp_prediction_test");
    ofstream out ( path_to_output_file.c_str());

    if ( ! out )
    {
        cout		<< "ERROR -  can't create " << path_to_output_file << endl;
        log_stream	<< "ERROR -  can't create " << path_to_output_file << endl;
        throw;
    }


    for (int ii=0; ii<key_for_trivial_dssp_prediction.size(); ii++)
    {
        PutVa( ii, out,3,1,'l');
        out << ": \t";
        for (int jj=0; jj<eight_letter_number_size; jj++)
        {
            //Pair_int_double local = key_for_trivial_dssp_prediction[ii][jj];

            int index = key_for_trivial_dssp_prediction[ii][jj].index();
            double value = key_for_trivial_dssp_prediction[ii][jj].value();


            PutVa(			index, out,3,1,'l');
            PutVaDouble(	value, out,6,3,'l');
        }
        out << endl;
    }

}
