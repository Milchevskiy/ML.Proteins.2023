#ifndef CLUSTER_DSSP_INTERDEPENDENCE_PPII_TEST_H
#define CLUSTER_DSSP_INTERDEPENDENCE_PPII_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Cluster_dssp_interdependence_PPII_test : public Simple_test
{
public:
	~Cluster_dssp_interdependence_PPII_test();

	void run()
	{
		fill_up_probability_cluster_for_dssp_test();

//		fill_up_chain_sequence_DSSP_PPII_data_test();

//LEGACY unchecked ************
		//	predict_dssp_eight_letter_by_sequence_test ();
		//d_print_predicted_observed_comparison_for_ready_prediction_test();
		//get_key_for_d_dssp_prediction_test (); // check correct reading dssp_prediction_test from file


		//fill_up_probability_cluster_for_dssp_test ();
		//	get_inverse_distance_segment_index_test();
		//print_predicted_observed_comparison_for_ready_prediction_test();
		//	trivial_eight_letter_prediction_by_ready_cluster_profile_test();  
		//get_trivial_cluster_preference_test();  
		//fill_up_test ();
		//	single_test();
//******* LEGACY unchecked 
	}
	void fill_up_chain_sequence_DSSP_PPII_data_test();
	void fill_up_probability_cluster_for_dssp_test();

};

#endif 


#pragma once
