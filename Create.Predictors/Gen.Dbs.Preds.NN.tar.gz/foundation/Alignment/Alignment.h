#ifndef ALIGNMENT_H
#define ALIGNMENT_H

//#include "Base_coward.h"

#include	<map>
#include	<vector>
#include	<string>

#include "../Pair_string_double.h"


using namespace std;
// ��� ��� �� ����������� ������� ��� ���������� ��������� ���������
class Afinity_sample
{
public:
	Afinity_sample (
		const double afinity,const string &sample_pdb_ID,const int position_in_sample):
			afinity_(afinity),
			sample_pdb_ID_(sample_pdb_ID),
			position_in_sample_(position_in_sample) { }

	double	get_afinity				() const { return afinity_; }
	string	get_sample_pdb_ID		() const { return sample_pdb_ID_; }
	int		get_position_in_sample	() const { return position_in_sample_; }


// for sort utility it's necessary comparison operator
	friend bool     operator >  (  const Afinity_sample & v1,const Afinity_sample & v2 )
	{ return ( v1.get_afinity() > v2.get_afinity() ) ; }
	friend bool     operator <  (  const Afinity_sample & v1,const Afinity_sample & v2 )
	{ return ( v1.get_afinity() < v2.get_afinity() ) ; }
	friend bool     operator == (  const Afinity_sample & v1,const Afinity_sample & v2 )
	{ return ( v1.get_afinity() == v2.get_afinity() ) ; }

private:
	double afinity_;
	string sample_pdb_ID_;
	int position_in_sample_;
};

#endif


class Sheduler;
class Class_assignment_profile;


class Alignment
{
public:
	 Alignment() {}
	Alignment(
		const string & alignment_model_name);

	~Alignment() ;


	void fill_up_coincidence_data_for_new_PDB (
		const string &pdb_id);


	void fill_up_coincidence_data (
		const string & sequense);  // run prediction before start alignment

	void fill_up_coincidence_data ( // use ready prediction from  file
		const vector <int> & nearest_index_set);

	string get_model_name()				const {return model_name_; }
	string get_alignment_model_name()	const {return alignment_model_name_; }

	//vector <int> nearest_index_set;

	void fill_up_coincidence_data_single_template_chain (
		const vector <int> & pred_index_set,
		const string & template_pdb_id);

//	void fill_up_coincidence_data(
//		const vector <int> & pred_index_set);

	void show_Afinity_map_and_analyze_known_structure(
		const string & pdb_ID);

	void show_Afinity_map_and_analyze_known_structure(
		const string & pdb_ID,
		const string & output_file_name);

	// ���� �� � private
	vector < Pair_string_double > Analyse_afinity_base (const string & pdb_ID);

	void dispersion_and_mean_preparation (
		const vector <int> & pred_index_set,
		const int position,
		const string & template_pdb_id,
		const vector <int> & template_index_set,
		double	& sum_average,
		double	& sum_sigma,
		int		& sum_counter);

	void fill_up_dispersion_and_mean_single_template_chain (
		const vector <int> & pred_index_set,
		const string & template_pdb_id,
		double	& sum_average,
		double	& sum_sigma,
		int		& sum_counter);

	void fill_up_dispersion_and_mean(
		const vector <int> & pred_index_set,
		double	& sum_average,
		double	& sum_sigma,
		int		& sum_counter);


	vector <vector < Afinity_sample > >
		pairwise_alignment (
			const vector <int> & pred_index_set,
			const string & template_pdb_id,
			const vector <int> & template_index_set	 );

	vector <int>  analyse_local_afinity_base (
		vector <vector < Afinity_sample > > & local_Afinity_base,
		const double threshold,
		const string & pdb_ID,
		const string & template_pdb_id);


	void  print_pairwise_alignment_result (
		vector <vector < Afinity_sample > > & local_Afinity_base,
		const double threshold,
		const string & pdb_ID,
		const string & template_pdb_id,
		const string & output_file_name);



private:

	string	alignment_model_name_;
	string	model_name_;

	Sheduler		*sheduler_;

	//Class_assignment_profile *cap_o_;

	Class_assignment_profile *class_assignment_profile_;

	int alignment_fragment_length_;      // fragment_length for alignment

	string path_to_class_assinment_profile_store_;   // store for claster-like marking for learninf set.

	vector <string> target_PDB_ID_;      // A list of PDB chain used as template for alignment.


//	vector <map <int, vector < Afinity_sample > > > Afinity_base_;


	 vector <vector < Afinity_sample > >  Afinity_base_;

	 string path_to_score_matrix_file_;


	double lowest_threshold_;

	vector <string> template_chain_ID_list_;
	vector <int >	template_chain_lenth_;

	double student_threshold_;
	double max_accepted_neighbour_in_base_;

void calc_values (
		const vector <int> & pred_index_set,
		const int position,
		const string & template_pdb_id,
		const vector <int> & template_index_set );

void calc_values_for_pairwise_alignment (
		const vector <int> & pred_index_set,
		const int position,
		const string & template_pdb_id,
		const vector <int> & template_index_set,
		vector <vector < Afinity_sample > > &local_Afinity_base);

void get_appropriate_score_matrix ();
vector <vector <double> > score_matrix_;


void Aget_undigested_alignment_by_local_Afinity_base (
	vector <vector < Afinity_sample > > & local_Afinity_base,
	vector <int>		& start_position_array,
	vector <int>		& template_start_position_array,
	vector <double>		& afinity_array );


	  //const  vector < vector < double > >   & Chain_Prime_Constants,
	  //vector < vector < double > >			& sophisticated_variables) ;

	Alignment ( const Alignment& );
	void operator = ( const Alignment& );
};


