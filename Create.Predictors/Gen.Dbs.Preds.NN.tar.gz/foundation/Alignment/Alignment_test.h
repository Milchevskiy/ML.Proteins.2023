#ifndef ALIGNMENT_TEST_H
#define ALIGNMENT_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class  Alignment_test: public Simple_test
{
public:
	~Alignment_test();

    void run()
    {
		//pairwise_alignment_test(); // ����� 
//		first_dummy_test ();
	//	fill_up_coincidence_data_for_new_PDB_test ();
		//fill_up_dispersion_and_mean_test();
	}
	void pairwise_alignment_test();
	void first_dummy_test ();
	void fill_up_coincidence_data_for_new_PDB_test ();
	void fill_up_dispersion_and_mean_test();

};

#endif
