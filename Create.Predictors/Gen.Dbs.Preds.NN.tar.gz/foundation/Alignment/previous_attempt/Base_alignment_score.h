#ifndef BASE_ALIGNMENT_SCORE_H
#define BASE_ALIGNMENT_SCORE_H

#include	<string>
#include	<vector>
#include	<map>

using namespace std;

using namespace std; 

class  Base_alignment_score
{
public:
	  
	Base_alignment_score(): 
	  value_( 0 ),
	  is_subsidiary_ (false)
	  {}

	virtual			~Base_alignment_score() ;
	virtual			Base_alignment_score* clone (const string & task_string, map   < string, int >&	co_task_variable_name_to_index   ) const					= 0;

	virtual			double    calc_value ( 
							const int   position_in_chain,			/// let it be the serial number of the first position of fragment
							int	var_set_cursor, 
					  		vector < vector < double > >			& database_dist_set,		// ���������� ������� ����
							vector < vector < double > >			& sophisticated_variables // ���������� ����������
						   						)   = 0;


	double			get_value		() const { return value_; } 

//	bool			is_subsidiary () const { return is_subsidiary_; }

protected:	
	double	value_;
	string	name_;
	bool    is_subsidiary_;
};

#endif