#ifndef EXACT_FIT_CLUSER_NUMBER_H
#define EXACT_FIT_CLUSER_NUMBER_H

#ifndef BASE_ALIGNMENT_SCORE_H
#include "Base_alignment_score.h"
#endif

#include <string>
#include <vector>

using namespace std;

class  Exact_fit_cluser_number: public Base_alignment_score
{
public:

	Exact_fit_cluser_number() {} ;

	explicit Exact_fit_cluser_number( 	const string			& task_string,
				map   < string, int	>	&	co_task_variable_name_to_index );

	//explicit Dull_Sum		( const string & task_string  );

    Base_alignment_score*			clone	( const string & task_string, map   < string, int	>	&	co_task_variable_name_to_index  ) const;


	double    calc_value ( 
				const int   position_in_chain/// let it be the serial number of the first position of fragment
						//  int	var_set_cursor, 
						//	vector < vector < double > >   & sophisticated_variables    
						) ;

	
protected:
	
	string	variable_name_in_list_; // ��� ���������� ��� ������� ������ ������

//	int		left_border_ ;
//	int		right_border_ ;

//	double  power_ ;

//	int		property_ID_;

//	char	fabs_mode_;

	Exact_fit_cluser_number(const Exact_fit_cluser_number&);
	Exact_fit_cluser_number& operator = (const Exact_fit_cluser_number&);
};

#endif
