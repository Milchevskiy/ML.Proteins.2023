#include "../CommonFunc.h"
#include "../Censorship.h"
#include "../Sheduler.h"
#include "Alignment_task.h"


#include "../Main_model/handle_det_distance_set.h" 

extern ofstream log_stream;
extern Censorship configuration;

 
Alignment_task::
Alignment_task( 
	const string & name, 
	const Alignment_task_operating_modes run_mode  ):
		name_(name),
		sheduler_(0),
		main_model_(0)
{
	//init( name, run_mode  );

	sheduler_		= new Sheduler     ( configuration.option_meaning("Path_to_Alignment")  + name_ + string ("/") + string ("sheduler") ) ;


	path_to_marking_prediction_store_ = 
		configuration.option_meaning("Path_to_Model_store") + 	name_ + string ("/") + 
		"cross_sum";


}

// class Base_score

vector < vector < double > >  Alignment_task::find_nearest_short_structure (
	vector < vector < double > >  & probe,
	vector <string> & template_chain_list)
{
	for (int ii=0; ii< template_chain_list.size(); ii++)
	{
		vector < vector < double > >  observed_base = read_det_distance_set (
			template_chain_list[ii], path_to_marking_prediction_store_ ,
			string (".dist_data") );

	// c ����� ����� ������
	//	vector <double> resemblance = make_resemblance_vector (probe,observed_base);


	}

}

/*
vector <double> make_resemblance_vector  (
	vector < vector < double > >  & probe,
	vector < vector < double > >  & observed_base 	)
{
	return 0;  // ����� 
	vector <double> score_vector;
	int curr_compare_number = observed_base.size()-probe.size()+1;
	score_vector.resize(curr_compare_number);

	for (int ii=0;ii<curr_compare_number;ii++)
	{


	}

}

*/