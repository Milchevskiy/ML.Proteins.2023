#include "Base_alignment_score.h"

Base_alignment_score::~Base_alignment_score()  
{
}

