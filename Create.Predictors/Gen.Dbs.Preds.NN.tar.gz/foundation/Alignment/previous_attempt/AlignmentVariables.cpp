
#pragma warning( disable : 4786 )

#include "AlignmentVariables.h"
/*
#include "Sum_of_ready.h"
#include "Dull_Sum.h"
#include "c_FourierSmoothed.h"
#include "Coastline.h"
#include "Chain_property_log.h"
#include "Chain_normalized_property.h"
#include "c_FourierSmoothed_ml_len.h"

#include "../WiseVariables/Prime_contants_for_chain.h" 
*/
#include <iostream>
#include <fstream>  
#include <cassert> 
#include <sstream> 


extern ofstream log_stream;

typedef   map < string, Base_alignment_score * > MAP_SEQUENCEMAP_TOVALUE ;
typedef   map < string, int >           MAP_NAME_TO_INDEX ;

AlignmentVariables:: 
AlignmentVariables( const string & Sequence_to_values_file_name)
{
	ifstream  in_stream( Sequence_to_values_file_name.c_str() );
	if ( ! in_stream)	
	{	
		cout       << "can't find file "  << Sequence_to_values_file_name << endl;
		log_stream << "can't find file "  << Sequence_to_values_file_name << endl;
		assert (  in_stream);		
		exit (1);	
	}

	vector < string >   all_mapped_definite_task ;

	string current_line;
	while ( getline(in_stream,current_line,'\n' ) )
	{
		if (   current_line[0] == '/'  || 
		       current_line[0] == '#'  || 
		       current_line[0] == ' '  || 
		       current_line[0] == '\n' || 
		       current_line[0] == '\0'  )
		  continue;

		all_mapped_definite_task.push_back( current_line );
	}

	number_of_variables_ = all_mapped_definite_task.size();

	init_known_templates_map ();


	int size = all_mapped_definite_task.size();
///	values_.resize( size );
	number_of_variables_ = size;
 
    MAP_SEQUENCEMAP_TOVALUE ::iterator theIterator_MAP_SEQUENCEMAP_TOVALUE;
	MAP_NAME_TO_INDEX       ::iterator theIterator_MAP_NAME_TO_INDEX;  

	for (int ii=0;ii<size;ii++)
	{
		istringstream ist ( all_mapped_definite_task[ii] );

		string current_procedure_key_word, dummy, current_task_name ;
		ist >> current_procedure_key_word >> dummy >> current_task_name;

		theIterator_MAP_SEQUENCEMAP_TOVALUE = known_templates_map_SequenceMap_toValue_.find ( current_procedure_key_word  );
		if ( theIterator_MAP_SEQUENCEMAP_TOVALUE == known_templates_map_SequenceMap_toValue_.end() )
		{
			log_stream << " WiseSequenceTranslator ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			cout       << " WiseSequenceTranslator ERROR: dummy keyword " <<  current_procedure_key_word << endl;
			exit(1);
		}
		else 
		{
			Base_alignment_score * current_derived_object = known_templates_map_SequenceMap_toValue_[current_procedure_key_word]->clone(all_mapped_definite_task[ii],coward_variable_name_to_index_);
			array_derived_SequenceMap_toValues_.push_back(  current_derived_object );

			if ( current_task_name != "DUMB" && current_task_name != "dumb") 
			{
				if  ( coward_variable_name_to_index_.end() != coward_variable_name_to_index_.find ( current_task_name )  ) 
				{
					log_stream << " WiseSequenceTranslator ERROR: twice assigned variable name: " <<  current_task_name << endl;
					cout       << " WiseSequenceTranslator ERROR: twice assigned variable name: " <<  current_task_name << endl;
					exit(1);

				}
				else 
					coward_variable_name_to_index_ [ current_task_name ] = ii;
			}
		}
	}
}

/*
void   AlignmentVariables:: calc_values (
	  int position, 
	  const  vector < vector < double > >   & probe_dist_set,			// ���������� ������������ ��������� 
	   vector < vector < double > >			& database_dist_set,		// ���������� ������� ����
	   vector < vector < double > >			& sophisticated_variables) ;// ���������� ���������� ��� �����
{

//	for (int ii=0;ii<number_of_variables_ ;ii++)
//	{
//		array_derived_SequenceMap_toValues_[ii]->calc_value (
//					position,  
//					ii, 
//					Chain_Prime_Constants,
//					sophisticated_variables    ) ;
//
//
//	
//	}
	
} 
*/


void  AlignmentVariables:: calc_values (
	  int position, 
	  const  vector < vector < double > >   & probe_dist_set,			// ���������� ������������ ��������� 
	   vector < vector < double > >			& database_dist_set,		// ���������� ������� ����
	   vector < vector < double > >			& sophisticated_variables) // ���������� ����������
{

		for (int ii=0;ii<number_of_variables_ ;ii++)
	{

// ��� ��� ����������
//		array_derived_SequenceMap_toValues_[ii]->calc_value (
//					position,  
//					ii, 
//					Chain_Prime_Constants,
//					sophisticated_variables    ) ;

		}


}

void  AlignmentVariables:: 
init_known_templates_map ()
{
	/*
	Dull_Sum*  Dull_Sum_pointer  =									new		Dull_Sum( );
	known_templates_map_SequenceMap_toValue_["Dull_Sum"]			=		Dull_Sum_pointer  ;

	Sum_of_ready*  Sum_of_ready_pointer  =							new		Sum_of_ready( );
	known_templates_map_SequenceMap_toValue_["Sum_of_ready"]		=		Sum_of_ready_pointer  ;

	c_FourierSmoothed* c_FourierSmoothed_pointer					= new	c_FourierSmoothed ();
	known_templates_map_SequenceMap_toValue_["c_FourierSmoothed"]	=		c_FourierSmoothed_pointer; 

	Coastline* Coastline_pointer	= new	Coastline();
	known_templates_map_SequenceMap_toValue_["Coastline"]	=		Coastline_pointer; 

	Chain_property_log* Chain_property_log_pointer					= new	Chain_property_log();
	known_templates_map_SequenceMap_toValue_["Chain_property_log"]	=		Chain_property_log_pointer	; 

	c_FourierSmoothed_ml_len* c_FourierSmoothed_ml_len_pointer					= new	c_FourierSmoothed_ml_len();
	known_templates_map_SequenceMap_toValue_["c_FourierSmoothed_ml_len"]	=		c_FourierSmoothed_ml_len_pointer	; 

	Chain_normalized_property* Chain_normalized_property_pointer					= new	Chain_normalized_property();
	known_templates_map_SequenceMap_toValue_["Chain_normalized_property"]	=		Chain_normalized_property_pointer	; 

	*/
}


