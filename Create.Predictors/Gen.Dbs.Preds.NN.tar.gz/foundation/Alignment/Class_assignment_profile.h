#ifndef CLASS_ASSIGNMENT_PROFILE_H
#define CLASS_ASSIGNMENT_PROFILE_H

#include "Class_assignment_profile_operating_modes.h"

#include <string>
#include <vector>

class	Censorship;
class	Sheduler;

using namespace std;

class  Class_assignment_profile
{
public:
	~Class_assignment_profile(){};
   Class_assignment_profile () {};

	Class_assignment_profile(
		const string & name,
		const Class_assignment_profile_operating_modes run_mode ) ;

	vector <int> get_observed_index_set  (const string &pdb_ID);
	vector <int> get_predicted_index_set  (const string &pdb_ID);

	void fill_up();

	void 	make_class_assignment_profile ( 
		vector < vector < double > > & det_distance_set,
		int * profile);

private:
	string name_;
	string path_to_store_;
	string path_to_current_model_store_;  // store for *.dist_data 


};
#endif	