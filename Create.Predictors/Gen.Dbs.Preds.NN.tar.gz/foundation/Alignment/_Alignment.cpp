#pragma warning( disable : 4786 )
#pragma warning( disable : 4018 )

#include "Alignment.h"

#include "../Sheduler.h"
#include "../Censorship.h"
#include "../CommonFunc.h"
#include "../Fragment_base/accepted_chain_data.h"

#include "Class_assignment_profile.h"

#include "../CommonFunc.h"

#include <cassert>
#include <iostream>
#include <cmath>

#include <algorithm>

#include <fstream>

#include "../Chain_store/DSSP_binary.h"

#include "../Main_model/Abu_Maimonides_Rambam.h"

#include "../Fragment_base/Chain_binary.h"

#include "../Statistical_utilits/calc_dispersion_and_average.h"

#include "../Pair_string_double.h"

using namespace std;

extern ofstream log_stream;
extern Censorship configuration;

Alignment::Alignment(
	const string & alignment_model_name) :
		alignment_model_name_(alignment_model_name),
		sheduler_(0),
		class_assignment_profile_(0)
{


	sheduler_		= new Sheduler     ( configuration.option_meaning("Path_to_Alignment")  + alignment_model_name + string ("/") + string ("sheduler") ) ;

	model_name_ = sheduler_->option_meaning ("MAIN_MODEL_NAME");

	alignment_fragment_length_ = atoi( (sheduler_->option_meaning ("ALIGNMENT_FRAGMENT_LENGTH") ).c_str() );

	path_to_class_assinment_profile_store_ = configuration.option_meaning("Path_to_Model_store")+ string("Class_assignment_profile/") ;

	lowest_threshold_   = atof( sheduler_->option_meaning ("LOWEST_THRESHOLD").c_str() );

	path_to_score_matrix_file_= sheduler_->option_meaning ("PATH_TO_SCORE_MATRIX_FILE");

	student_threshold_						= atof( sheduler_->option_meaning ("STUDENT_THRESHOLD").c_str() );
	max_accepted_neighbour_in_base_			= atof( sheduler_->option_meaning ("MAX_ACCEPTED_NEIGHBOUR_IN_BASE").c_str() );


//	string binary_file_name ("accepted_chain_list.bin");
	string binary_file_name ("accepted_chain_list.bin.true");

	fill_up_accepted_chain_data (
		template_chain_ID_list_,
		template_chain_lenth_,
		binary_file_name);

	class_assignment_profile_ = new Class_assignment_profile(model_name_,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	get_appropriate_score_matrix ();
}

Alignment::~Alignment()
{
	 if ( sheduler_  )
		delete sheduler_ ;

 	 if ( class_assignment_profile_  )
		delete class_assignment_profile_ ;
}

void Alignment::fill_up_coincidence_data_for_new_PDB (
	const string &pdb_id)
{
	Abu_Maimonides_Rambam mr ( "second_model_advanced", COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	mr.make_prediction_by_external_PDB(pdb_id);

	string extension1= string(".predicted_dist_data");
	//string extension2= string(".dist_data");
	vector < vector < double > > pred_distance_set  =
		mr.read_det_distance_set (pdb_id,extension1);

	Chain_binary * chain = 	new Chain_binary ( pdb_id );
	string sequence = chain->get_sequence();
	delete chain;

	Class_assignment_profile cap_o(model_name_,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	int length = pred_distance_set.size();
	int *profile = new int [length];
	cap_o.make_class_assignment_profile (
		pred_distance_set,
		profile);

	vector <int> predicted_index_set; predicted_index_set.resize(length);
	for (int ii=0;ii<length;ii++)
		predicted_index_set[ii] = profile[ii];
	delete [] profile;

	fill_up_coincidence_data ( predicted_index_set );
}

void Alignment::fill_up_coincidence_data (
	const string & sequence)
{

	Abu_Maimonides_Rambam mr ( model_name_, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;
	charming_Reg_solution  * current_crs = mr.init_together_model ();

			vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
			sequence,
			current_crs	);

//	delete current_crs;

		int length = predicted_det_distance_set.size();
		int *profile = new int [length];


		Class_assignment_profile cap_o(model_name_,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

		cap_o.make_class_assignment_profile (
			predicted_det_distance_set,
			profile);

		vector <int> predicted_index_set; predicted_index_set.resize(length);
		for (int ii=0;ii<length;ii++)
			predicted_index_set[ii] = profile[ii];

		delete [] profile;

		fill_up_coincidence_data(predicted_index_set) ;

}


void Alignment::fill_up_coincidence_data(
	const vector <int> & pred_index_set)
{

	//get_appropriate_score_matrix ();

	// INITIALTE Afinity_base_
//	Afinity_sample empty_sample(0,string("emptyPDB"),-1);
//	vector < Afinity_sample >  initial;
//	initial.push_back(empty_sample);

	Afinity_base_.resize(pred_index_set.size());

//	for (int kk=0; kk<pred_index_set.size();kk++)
//	{
//		Afinity_base_[kk] = initial;
//	}
//	Afinity_base_.push_back(single_element_Afinity_base);  //

// DUMMY TEST			template_chain_ID_list_.resize(0);
// DUMMY TEST			template_chain_ID_list_.push_back("1F52A");


	for (int ii=0;ii<template_chain_ID_list_.size();ii++)
	{
		string  template_pdb_id = template_chain_ID_list_[ii];
		fill_up_coincidence_data_single_template_chain (
			pred_index_set,
			template_pdb_id);

		cout << ii << "\t" << template_pdb_id << endl;
	}
}
//***************
void Alignment::fill_up_dispersion_and_mean(
	const vector <int> & pred_index_set,
	double	& sum_average,
	double	& sum_sigma,
	int		& sum_counter)
{
	sum_average	=0;
	sum_sigma	=0;
	sum_counter	=0;

	//get_appropriate_score_matrix ();

	Afinity_base_.resize(pred_index_set.size());

	for (int ii=0;ii<template_chain_ID_list_.size();ii++)
	{
		string  template_pdb_id = template_chain_ID_list_[ii];

		fill_up_dispersion_and_mean_single_template_chain (
			pred_index_set,
			template_pdb_id,
			sum_average,
			sum_sigma,
			sum_counter);

		cout << ii << "\t" << template_pdb_id << " "  ;
		cout << sum_average	/ sum_counter << " " ;
		cout << sum_sigma	/ sum_counter << endl ;
	}

	sum_average	/=	sum_counter;
	sum_sigma	/=	sum_counter;
}

void Alignment::
	fill_up_coincidence_data_single_template_chain (
		const vector <int> & pred_index_set,
		const string & template_pdb_id)
{

	vector <int> template_index_set = class_assignment_profile_->get_observed_index_set(template_pdb_id);

	for (int ii=0;ii< pred_index_set.size() - alignment_fragment_length_ +1 ; ii++)
	{
		    int position = ii;  // position in analysed sequence
			calc_values (
				pred_index_set,
				position,
				template_pdb_id,
				template_index_set);
	}

}
//*****************************
void Alignment::
	fill_up_dispersion_and_mean_single_template_chain (
		const vector <int> & pred_index_set,
		const string & template_pdb_id,
		double	& sum_average,
		double	& sum_sigma,
		int		& sum_counter)

{

	vector <int> template_index_set = class_assignment_profile_->get_observed_index_set(template_pdb_id);

	for (int ii=0;ii< pred_index_set.size() - alignment_fragment_length_ +1 ; ii++)
	{
		    int position = ii;  // position in analysed sequence
			dispersion_and_mean_preparation (
				pred_index_set,
				position,
				template_pdb_id,
				template_index_set,
				sum_average,
				sum_sigma,
				sum_counter);
	}

}


void Alignment::calc_values (
		const vector <int> & pred_index_set,
		const int position,
		const string & template_pdb_id,
		const vector <int> & template_index_set	 )
{
	int size_index_set = pred_index_set.size();
	int end_pos = min (size_index_set,position+alignment_fragment_length_);

	if (( end_pos - position ) < alignment_fragment_length_ )
		return ;

	vector<double> xx; xx.resize(alignment_fragment_length_);

	double coeff = Pythagorean_Number () / score_matrix_.size();
	double d_class_number = (double) score_matrix_.size();

	int iter_number = template_index_set.size()- alignment_fragment_length_ +1 ;
	for (int jj=0;jj<iter_number ;jj++)
	{
		xx.assign(alignment_fragment_length_, 0);

		double dummy_afinity =0;
		for (int kk=0;kk<alignment_fragment_length_;kk++)
		{
			if (template_index_set[jj+kk]==-1)
				continue;

			int pred_index = pred_index_set[position+kk];
			int temp_index = template_index_set[jj+kk];

			double curent_score = score_matrix_
				[  pred_index ]
				[  temp_index ];

			double add	= cos ( ( d_class_number- curent_score)  * coeff) *
					fabs (cos ( ( d_class_number- curent_score)  * coeff) ) ;
			dummy_afinity += add ;

			xx[kk]=add;
		}

		double average,sigma;

		calc_dispersion_and_average (xx,average,sigma);

		//FIX Nu == 0 here !!!
		// ���������� �������� � ���� �� ������� ������� 0.065 � 0.577
		double common_average = 0.065;
		double common_sigma = 0.577;

		double Student_value = average * sqrt (double (alignment_fragment_length_) )/
			sqrt( sigma*sigma + common_sigma*common_sigma) ;


		if (Student_value  > student_threshold_)
		{
			Afinity_sample current_sample(Student_value, template_pdb_id ,jj);

			if (Afinity_base_[position].size() >= max_accepted_neighbour_in_base_)
			{
				sort(	Afinity_base_[position].begin(),Afinity_base_[position].end() );
				Afinity_base_[position][0] = current_sample;
			}
			else
				Afinity_base_[position].push_back(current_sample);

		}
	}

}

/*
void Alignment::
	handle_Afinity_base_by_Student_value (
		const int position,
		const double Student_value )
{


}
*/
void Alignment::dispersion_and_mean_preparation (
		const vector <int> & pred_index_set,
		const int position,
		const string & template_pdb_id,
		const vector <int> & template_index_set,
		double	& sum_average,
		double	& sum_sigma,
		int		& sum_counter)
{
	int size_index_set = pred_index_set.size();
	int end_pos = min (size_index_set,position+alignment_fragment_length_);

	if (( end_pos - position ) < alignment_fragment_length_ )
		return ;

	vector<double> xx; xx.resize(alignment_fragment_length_);

	double coeff = Pythagorean_Number () / score_matrix_.size();
	double d_class_number = (double) score_matrix_.size();

	int iter_number = template_index_set.size()- alignment_fragment_length_ +1 ;
	for (int jj=0;jj<iter_number ;jj++)
	{

		xx.assign(alignment_fragment_length_, 0);

		double dummy_afinity =0;
		for (int kk=0;kk<alignment_fragment_length_;kk++)
		{
			if (template_index_set[jj+kk]==-1)
				continue;

			int pred_index = pred_index_set[position+kk];
			int temp_index = template_index_set[jj+kk];

			double curent_score = score_matrix_
				[  pred_index ]
				[  temp_index   ];

			double add = cos ( ( d_class_number- curent_score)  * coeff) *
					fabs (cos ( ( d_class_number- curent_score)  * coeff) ) ;
			dummy_afinity += add ;

			xx[kk]=add;
		}

		double average,sigma;

		calc_dispersion_and_average (xx,average,sigma);

		sum_average +=average;
		sum_sigma	+=sigma;
		sum_counter++;

	}

}


vector < Pair_string_double > Alignment::Analyse_afinity_base (const string & pdb_ID)
{

	map <string,double> sample_pdb_ID_to_joint_afinity;

	int pred_index_length = Afinity_base_.size();
	for (int ii=0;ii<pred_index_length - alignment_fragment_length_ +1 ;ii++)
	{
		for (int kk=0;kk<max_accepted_neighbour_in_base_;kk++)
		{
			string sample_pdb_ID = Afinity_base_[ii][kk].get_sample_pdb_ID();
			if (sample_pdb_ID == pdb_ID)
				continue;

			double current_afinity = Afinity_base_[ii][kk].get_afinity();
			double previous_joint_afinity;

			string curr_sample_pdb_ID = Afinity_base_[ii][kk].get_sample_pdb_ID();
			if ( sample_pdb_ID_to_joint_afinity.find(curr_sample_pdb_ID) == sample_pdb_ID_to_joint_afinity.end()  )
			{
				sample_pdb_ID_to_joint_afinity[curr_sample_pdb_ID] = current_afinity;
			}
			else
			{
				previous_joint_afinity = sample_pdb_ID_to_joint_afinity[curr_sample_pdb_ID];
				sample_pdb_ID_to_joint_afinity[curr_sample_pdb_ID] = previous_joint_afinity + current_afinity;
			}

		}
		cout << ii << endl;
	}


	vector < Pair_string_double > sample_pdb_id_and_afinity;

	typedef map < string, double > MAP_STRING_DOUBLE;
	MAP_STRING_DOUBLE::const_iterator theIterator;

	int counter =0;
	for ( theIterator = sample_pdb_ID_to_joint_afinity.begin();theIterator != sample_pdb_ID_to_joint_afinity.end();theIterator ++ )
	{
		string key		=	(*theIterator).first ;
		double value	=   (*theIterator).second ;

		Pair_string_double current_pair (key,value);

		sample_pdb_id_and_afinity.push_back ( Pair_string_double (key,value));
	}

	sort(	sample_pdb_id_and_afinity.begin(),	sample_pdb_id_and_afinity.end() );

	vector < Pair_string_double > descending_by_afinity_sample_pdb_id;

	for (int ii=sample_pdb_id_and_afinity.size()-1 ;ii>=0; ii--)
	{
		descending_by_afinity_sample_pdb_id.push_back(sample_pdb_id_and_afinity[ii]);
//		log_stream <<  sample_pdb_id_and_afinity[ii].index() << "\t";
//		log_stream <<  sample_pdb_id_and_afinity[ii].value() << endl;
	}

	return descending_by_afinity_sample_pdb_id;
}

//
/*
void Alignment::prediction_by_Afinity_base_only ()
{

}
*/
// FIX


void Alignment::
	show_Afinity_map_and_analyze_known_structure(
		const string & pdb_ID,
		const string & output_file_name)
{

// FIX
	int shift = 2; //in out model widows = 5;

	ofstream  out( output_file_name.c_str());

	if ( ! out)	{
		log_stream << output_file_name << "ERROR -  can't create file" << endl;
		cout       << output_file_name << "ERROR -  can't create file" << endl;
		cout       << "get_observed_index_set_test : ERROR -  can't create file" << endl;
		throw;
	}

	DSSP_binary pdb_ID_dssp (pdb_ID,COMMON_USAGE) ;

	string pdb_ID_sequence					= pdb_ID_dssp.get_sequence();
	string pdb_ID_extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
	string pdb_ID_tri_letter_DSSP_sequence	= pdb_ID_dssp.get_tri_letter_DSSP_sequence();


	map < string, DSSP_binary * >  map_PDB_ID_dssp_binary;


//	typedef   map < string, DSSP_binary * > MAP_PDBID_TO_DSSP_BINARY; ;


	out << "target PDB_ID: " << pdb_ID << endl<< endl;
	int index_set_length = Afinity_base_.size();

	DSSP_binary  *curr_dssp_first_time, *curr_dssp;
	for (int ii=0;ii<index_set_length-alignment_fragment_length_+1;ii++)
	{
		sort(	Afinity_base_[ii].begin(),	Afinity_base_[ii].end() );

		out << "postion " << ii << endl;

		string pdb_ID_sequence_fragment					= pdb_ID_sequence.					substr(ii + shift,alignment_fragment_length_);
		string pdb_ID_extended_DSSP_sequence_fragment	= pdb_ID_extended_DSSP_sequence.	substr(ii + shift,alignment_fragment_length_);
		string pdb_ID_tri_letter_DSSP_sequence_fragment	= pdb_ID_tri_letter_DSSP_sequence.	substr(ii + shift,alignment_fragment_length_);

		out << "Known structure: " << pdb_ID << endl;
		out << pdb_ID_sequence_fragment	<< endl;
		out << pdb_ID_extended_DSSP_sequence_fragment<< endl;
		out << pdb_ID_tri_letter_DSSP_sequence_fragment	<< endl;

		for (int kk=Afinity_base_[ii].size()-1 ;kk>=0; kk--)
		{
			out << "\t" <<
			Afinity_base_[ii][kk].get_afinity()			<<	"\t" <<
			Afinity_base_[ii][kk].get_sample_pdb_ID()	<<	"\t" <<
			Afinity_base_[ii][kk].get_position_in_sample()<<	endl;


			int position_in_sample = Afinity_base_[ii][kk].get_position_in_sample();

			if (position_in_sample == -1)
				continue;

			string curr_PDB_ID = Afinity_base_[ii][kk].get_sample_pdb_ID();
			if ( map_PDB_ID_dssp_binary.find(curr_PDB_ID) == map_PDB_ID_dssp_binary.end()  )
			{
				curr_dssp_first_time = new DSSP_binary(curr_PDB_ID,COMMON_USAGE);
				map_PDB_ID_dssp_binary[curr_PDB_ID] = curr_dssp_first_time;
			}

			curr_dssp = map_PDB_ID_dssp_binary[curr_PDB_ID];

			string sequence					= curr_dssp->get_sequence();
			string extended_DSSP_sequence	= curr_dssp->get_extended_DSSP_sequence();
			string tri_letter_DSSP_sequence	= curr_dssp->get_tri_letter_DSSP_sequence();

//? ����������� � shift ��� sequence
			string sequence_fragment					= sequence.substr(position_in_sample + shift,alignment_fragment_length_);
			string extended_DSSP_sequence_fragment		= extended_DSSP_sequence.substr(position_in_sample + shift,alignment_fragment_length_);
			string tri_letter_DSSP_sequence_fragment	= tri_letter_DSSP_sequence. substr(position_in_sample + shift,alignment_fragment_length_);

			out << sequence_fragment  << endl;
			out << extended_DSSP_sequence_fragment << endl;
			out << tri_letter_DSSP_sequence_fragment << endl;

/*			map<int,char>  sequence_by_DSSP			=	curr_dssp->get_serial_index_to_amino_acid_name();
			map<int,char>  extended_DSSP_sequence	=	curr_dssp->get_serial_index_to_DSSP();


			int position_in_sample = Afinity_base_[ii][kk].get_position_in_sample();

			int fr_start = position_in_sample + shift;
			int fr_end   = fr_start + alignment_fragment_length_;
			for ( int zzz= fr_start;zzz<fr_end;zzz++ )
						out<< sequence_by_DSSP[zzz];
			out<< endl;

			for ( int zzz= fr_start;zzz<fr_end;zzz++ )
						out<< extended_DSSP_sequence	[zzz];
			out<< endl;
*/
	/*		string fragment_sequence_by_DSSP		=	sequence_by_DSSP.substr(
											position_in_sample + shift,alignment_fragment_length_);
			string fragment_extended_DSSP_sequence	=	extended_DSSP_sequence.substr(
											position_in_sample + shift,alignment_fragment_length_);

			cout << fragment_sequence_by_DSSP << endl;
			cout << fragment_extended_DSSP_sequence << endl;
	*/

		}
	}
}
void Alignment::get_appropriate_score_matrix ()
{
//FIX FIX

	ifstream in_stream ( path_to_score_matrix_file_.c_str() );

	if ( ! in_stream )	{
		log_stream	 << "ERROR -  can't find score_matrix_file" << path_to_score_matrix_file_<< endl;
		cout		 << "ERROR -  can't find score_matrix_file" << path_to_score_matrix_file_<< endl;
		exit (1);
	}

	string current_line;
	getline( in_stream, current_line, '\n' );
	int matrix_size;

	in_stream >> matrix_size;

	score_matrix_.resize(matrix_size);

	double val ;

	int ii,jj;
	for ( ii=0;ii<matrix_size;ii++)
	{
		score_matrix_[ii].resize(matrix_size);
		for ( jj=0;jj<matrix_size;jj++)
		{
			in_stream >> val;
			score_matrix_[ii][jj] = val;
		}
	}
}

vector <vector < Afinity_sample > >  Alignment::
	pairwise_alignment (
		const vector <int> & pred_index_set,
		const string & template_pdb_id,
		const vector <int> & template_index_set	 )
{
	//vector <int> template_index_set = class_assignment_profile_->get_observed_index_set(template_pdb_id);

	vector <vector <double>>  Afinity_matrix;
	int row_size = pred_index_set.size()		- alignment_fragment_length_ +1;
	int col_size = template_index_set.size()	- alignment_fragment_length_ +1;

	vector <vector < Afinity_sample > > local_Afinity_base;

	for (int ii=0;ii< pred_index_set.size() - alignment_fragment_length_ +1 ; ii++)
	{
		    int position = ii;  // position in analysed sequence
			calc_values_for_pairwise_alignment (
				pred_index_set,
				position,
				template_pdb_id,
				template_index_set,
				local_Afinity_base );
	}

	return local_Afinity_base;

}

void Alignment::get_undigested_alignment_by_local_Afinity_base (
	vector <vector < Afinity_sample > > & local_Afinity_base,
	vector <int>		& start_position_array,
	vector <int>		& template_start_position_array,
	vector <double>		& afinity_array )
{
	//vector <int> length_array;


	int local_Afinity_base_size = local_Afinity_base.size();

	for (int kk=0; kk< local_Afinity_base_size; kk++)
	{
		int test = local_Afinity_base[kk].size();
		if( test  != 0 )
		{
			int start_position		= kk;
			int postiton_in_sample	= local_Afinity_base[kk][test-1].get_position_in_sample();
			double afinity			= local_Afinity_base[kk][test-1].get_afinity();


			start_position_array			.push_back(start_position);
			template_start_position_array	.push_back(postiton_in_sample);
			afinity_array					.push_back(afinity);

		}
	}

	for (int tt=0;tt<start_position_array.size();tt++)
	{
		cout << start_position_array			[tt] << "\t";
		cout << template_start_position_array	[tt] << "\t";
		cout << afinity_array					[tt] << endl;

	}
}

void Alignment::calc_values_for_pairwise_alignment (
		const vector <int> & pred_index_set,
		const int position,
		const string & template_pdb_id,
		const vector <int> & template_index_set,
		vector <vector < Afinity_sample > > &local_Afinity_base)
{

// Allocate Afinity_base_;
	local_Afinity_base.resize(pred_index_set.size());

	int size_index_set = pred_index_set.size();
	int end_pos = min (size_index_set,position+alignment_fragment_length_);

	if (( end_pos - position ) < alignment_fragment_length_ )
		return ;

	vector<double> xx; xx.resize(alignment_fragment_length_);

	double coeff = Pythagorean_Number () / score_matrix_.size();
	double d_class_number = (double) score_matrix_.size();

	int iter_number = template_index_set.size()- alignment_fragment_length_ +1 ;
	for (int jj=0;jj<iter_number ;jj++)
	{
		xx.assign(alignment_fragment_length_, 0);

		double dummy_afinity =0;
		for (int kk=0;kk<alignment_fragment_length_;kk++)
		{
			if (template_index_set[jj+kk]==-1)
				continue;

			int pred_index = pred_index_set[position+kk];
			int temp_index = template_index_set[jj+kk];

			double curent_score = score_matrix_
				[  pred_index ]
				[  temp_index ];

			double add	= cos ( ( d_class_number- curent_score)  * coeff) *
					fabs (cos ( ( d_class_number- curent_score)  * coeff) ) ;
			dummy_afinity += add ;

			xx[kk]=add;
		}

		double average,sigma;

		calc_dispersion_and_average (xx,average,sigma);

		//FIX Nu == 0 here !!!
		// ���������� �������� � ���� �� ������� ������� 0.065 � 0.577
		double common_average = 0.065;
		double common_sigma = 0.577;

		double Student_value = average * sqrt (double (alignment_fragment_length_) )/
			sqrt( sigma*sigma + common_sigma*common_sigma) ;


		if (Student_value  > student_threshold_)
		{
			Afinity_sample current_sample(Student_value, template_pdb_id ,jj);

			if (local_Afinity_base[position].size() >= max_accepted_neighbour_in_base_)
			{
				sort(	local_Afinity_base[position].begin(),local_Afinity_base[position].end() );
				local_Afinity_base[position][0] = current_sample;
			}
			else
				local_Afinity_base[position].push_back(current_sample);
		}

	}

}
void  Alignment::print_pairwise_alignment_result (
		vector <vector < Afinity_sample > > & local_Afinity_base,
		const double threshold,
		const string & pdb_ID,
		const string & template_pdb_id,
		const string & output_file_name )
{
	DSSP_binary pdb_ID_dssp (pdb_ID,COMMON_USAGE) ;
	string pdb_ID_sequence					= pdb_ID_dssp.get_sequence();
	string pdb_ID_extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
	string pdb_ID_tri_letter_DSSP_sequence	= pdb_ID_dssp.get_tri_letter_DSSP_sequence();

	DSSP_binary template_pdb_id_dssp (template_pdb_id,COMMON_USAGE) ;
	string template_pdb_id_sequence					= template_pdb_id_dssp.get_sequence();
	string template_pdb_id_extended_DSSP_sequence	= template_pdb_id_dssp.get_extended_DSSP_sequence();
	string template_pdb_id_tri_letter_DSSP_sequence	= template_pdb_id_dssp.get_tri_letter_DSSP_sequence();

	vector <int> pred_index_set			= class_assignment_profile_->get_observed_index_set(pdb_ID);
	vector <int> template_index_set = class_assignment_profile_->get_observed_index_set(template_pdb_id);

	ofstream  out( output_file_name.c_str());
	if ( ! out)	{
		log_stream << "print_pairwise_alignment_result : ERROR -  can't create file" << endl;
		cout       << "print_pairwise_alignment_result : ERROR -  can't create file" << endl;
		throw;
	}

	// Print original sequence and dssp
	int pdb_ID_sequence_size = pdb_ID_sequence.size();
	for (int ii=0; ii< pdb_ID_sequence.size(); ii++ )
	{
		PutVa(pdb_ID_sequence[ii],out,3,1,'l');
	}
	out << endl;

//	int shift = 2;
//	for (int kk=0;kk<shift;kk++)
//		PutVa("   ",out,3,1,'l');

	int pdb_ID_tri_letter_DSSP_sequence_size = pdb_ID_tri_letter_DSSP_sequence.size();
	for (int ii=0; ii< pdb_ID_tri_letter_DSSP_sequence_size ; ii++ )
	{
		PutVa(pdb_ID_tri_letter_DSSP_sequence[ii],out,3,1,'l');
	}
	out << endl;

	string coincidece_sequnce;		coincidece_sequnce.	resize(pdb_ID_sequence.size());
	string coincidence_tri_letter_DSSP_sequence;			coincidence_tri_letter_DSSP_sequence.	resize(pdb_ID_extended_DSSP_sequence.size() );

	for (int ii=0;ii<pdb_ID_sequence.size();ii++)
		coincidece_sequnce[ii]='-';

	for (int ii=0;ii<coincidence_tri_letter_DSSP_sequence.size();ii++)
		coincidence_tri_letter_DSSP_sequence [ii]='-';


	for (int ii=0;ii< pred_index_set.size() - alignment_fragment_length_ +1 ; ii++)
	{
		int coincidence_size = local_Afinity_base[ii].size();
		if ( coincidence_size > 1 )
			cout << "VAH! " << endl;
		else if (coincidence_size==0)
			continue;

		double afinity = local_Afinity_base[ii][coincidence_size-1].get_afinity();

		if (afinity > threshold)
		{
			int position_in_sample = local_Afinity_base[ii][coincidence_size-1].get_position_in_sample();
			for ( int kk=0; kk < alignment_fragment_length_; kk++ )
			{
//				coincidece_sequnce[ii+kk+shift] = template_pdb_id_sequence[position_in_sample+kk+shift];
//				coincidence_tri_letter_DSSP_sequence [ii+kk] = template_pdb_id_tri_letter_DSSP_sequence[position_in_sample+kk];

				coincidece_sequnce[ii+kk] = template_pdb_id_sequence[position_in_sample+kk];
				coincidence_tri_letter_DSSP_sequence [ii+kk] = template_pdb_id_tri_letter_DSSP_sequence[position_in_sample+kk];


			}
		}
		cout << ii << endl;
	}


	int coincidence_sequence_size = coincidece_sequnce.size();


	for (int ii=0; ii< coincidence_sequence_size; ii++ )
	{
		PutVa(coincidece_sequnce[ii],out,3,1,'l');
	}
	out << endl;

	//int shift = 2;
//	for (int kk=0;kk<shift;kk++)
//		PutVa("   ",out,3,1,'l');

	int coincidence_tri_letter_DSSP_sequence_size = coincidence_tri_letter_DSSP_sequence.size();
	for (int ii=0; ii< coincidence_tri_letter_DSSP_sequence_size; ii++ )
	{
		PutVa(coincidence_tri_letter_DSSP_sequence[ii],out,3,1,'l');
	}
	out << endl;
}


// ������ ����� ��� �������. ���� ����� ����� ������������. ����� ��� ��� ���� ���� ��� � local_Afinity_base
vector <int>  Alignment::analyse_local_afinity_base (
		vector <vector < Afinity_sample > > & local_Afinity_base,
		const double threshold,
		const string & pdb_ID,
		const string & template_pdb_id)
{
	vector <int>		 start_position_array;
	vector <int>		 template_start_position_array;
	vector <double>		 afinity_array;

	get_undigested_alignment_by_local_Afinity_base (
		local_Afinity_base,
		start_position_array,
		template_start_position_array,
		afinity_array );

	int local_Afinity_base_size = local_Afinity_base.size();
	vector <int>  complement_position;	complement_position.resize(local_Afinity_base_size);

	int prev_start_position		= -1;
	int prev_postion_in_sample	= -1;

	for (int kk=0; kk< local_Afinity_base_size; kk++)
	{
		int test = local_Afinity_base[kk].size();
		if( test  != 0 )
		{
			int start_position		= kk;
			int postiton_in_sample	= local_Afinity_base[kk][test-1].get_position_in_sample();
			double afinity			= local_Afinity_base[kk][test-1].get_afinity();

			start_position_array			.push_back(start_position);
			template_start_position_array	.push_back(postiton_in_sample);
			afinity_array					.push_back(afinity);

			if ( prev_start_position = -1 ) // first occuoccurrence
			{
				complement_position[kk]=1;
				prev_start_position		= start_position;
				prev_postion_in_sample	= postiton_in_sample;
			}
			else
			{
				if ( ( prev_start_position -  start_position)  == ( prev_postion_in_sample - postiton_in_sample) )
				{  // continue  complementarity
					complement_position[kk]=1;
					prev_start_position		= start_position;
					prev_postion_in_sample	= postiton_in_sample;
				}
				else  // not continue complementarity
				{
					complement_position[kk]=0;
					prev_start_position		= -1;
					prev_postion_in_sample	= -1;
				}

			}
		}
		else
		{
			complement_position[kk] = -1;
			prev_start_position		= -1;
			prev_postion_in_sample	= -1;
		}
	}
	return complement_position;
}
