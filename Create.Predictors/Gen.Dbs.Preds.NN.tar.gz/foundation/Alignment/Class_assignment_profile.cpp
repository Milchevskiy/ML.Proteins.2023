#include "Class_assignment_profile.h"

#include "../Censorship.h"
#include "../Fragment_base/accepted_chain_data.h"
#include "../Main_model/handle_det_distance_set.h"

#include "../get_nearest_claster_index.h"

#include <iostream>
#include <cassert>

extern ofstream log_stream;
extern Censorship configuration;

Class_assignment_profile::
	Class_assignment_profile(
		const string & name,
		const Class_assignment_profile_operating_modes run_mode ) 
{
	name_			= name;
	path_to_store_	
		= configuration.option_meaning("Path_to_Model_store")  + name_ + string ("/") + string ("Class_assignment_profile") + string ("/")  ;

	
	path_to_current_model_store_	
		= configuration.option_meaning("Path_to_Model_store")  + name_ + string ("/cross_sum/")  ;


	switch ( run_mode  )
	{

		case COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES: 
			//init_storage ();
			break;
		case FILL_UP_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES:
			fill_up();
			break;
		default :
			log_stream	<< "Class_assignment_profile class" << endl;
			cout		<< "Class_assignment_profile class" << endl;
			exit (-1);
	}



}

void Class_assignment_profile::fill_up()
{
	vector <string> accepted_chain_ID_list;
	vector <int >	accepted_chain_lenth;
	
//	string binary_file_name ("accepted_chain_list.bin");
	string binary_file_name ("accepted_chain_list.bin.true");

	fill_up_accepted_chain_data ( 
		accepted_chain_ID_list, 
		accepted_chain_lenth,
		binary_file_name);

	//FOR OBSERVED 
	for (unsigned int ii=0; ii<accepted_chain_ID_list.size(); ii++ )
	{
		string current_distance_file_name = path_to_current_model_store_ + accepted_chain_ID_list[ii]+ string (".dist_data");
		
		vector < vector < double > > det_distance_set = 
			read_det_distance_set (current_distance_file_name);

		int length = det_distance_set.size();
		int *profile = new int [length];

		make_class_assignment_profile ( 
			det_distance_set,
			profile);

		string binary_file_name = path_to_store_ + accepted_chain_ID_list[ii] + string (".class_assignment_profile_observed");

		ofstream binary_stream ( binary_file_name.c_str(),ios::binary );

		if ( ! binary_stream )	{	
			log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			exit (1);	
		}

		binary_stream.write( (char* ) profile, length*sizeof (int) );		

		delete [] profile;
		cout << ii << "\t" << accepted_chain_ID_list[ii] << " for observed" << endl;
		binary_stream.close();
	}


	//FOR PREDICTED 
	for (unsigned int ii=0; ii<accepted_chain_ID_list.size(); ii++ )
	{
		string current_distance_file_name = path_to_current_model_store_ + accepted_chain_ID_list[ii]+ string (".dist_data_predicted");
		
		vector < vector < double > > det_distance_set = 
			read_det_distance_set (current_distance_file_name);

		int length = det_distance_set.size();
		int *profile = new int [length];

		make_class_assignment_profile ( 
			det_distance_set,
			profile);

		string binary_file_name = path_to_store_ + accepted_chain_ID_list[ii] + string (".class_assignment_profile_predicted");

		ofstream binary_stream ( binary_file_name.c_str(),ios::binary );

		if ( ! binary_stream )	{	
			log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			exit (1);	
		}

		binary_stream.write( (char* ) profile, length*sizeof (int) );		

		delete [] profile;
		cout << ii << "\t" << accepted_chain_ID_list[ii] << " for predicted" << endl;
		binary_stream.close();
	}
}

void Class_assignment_profile::
	make_class_assignment_profile ( 
		vector < vector < double > > & det_distance_set,
		int * profile)
{
	// fix ��� �� ������ ����� ����. ���� �� � aBU_m..rAMBAM ��������
//FIX FIX ��� ��-�� �������� ������ ���� 	
//	Distance_to_MC          0  DUMB 1  
//Distance_to_MC_norm     0  DUMB 1  
	
	//int number_of_clasters = det_distance_set[0].size()/2;

	int number_of_clasters = 30; // FIX!!!!!!!!!!!
	assert (number_of_clasters ==30 );

	vector <double> d_claster;	d_claster.resize (number_of_clasters);

	for (int ii=0;ii< det_distance_set.size(); ii++ )
	{
		for (int kk=0;kk<number_of_clasters;kk++)
		{
			d_claster[kk] =  - det_distance_set[ii][number_of_clasters + kk];
		}
		int nearest_index = get_nearest_claster_index(			d_claster );
		if (det_distance_set[ii][0] == -1 )
			nearest_index = -1;

		profile[ii]= nearest_index;
	}
}
/*
vector <int> Class_assignment_profile::
get_predicted_index_set  (const string &pdb_ID)
{
	string binary_file_name = path_to_store_ + pdb_ID + string (".predicted_class_assignment_profile");

	ifstream binary_stream ( binary_file_name.c_str(),ios::binary );

	if ( ! binary_stream )	{	
		log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
		cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
		exit (1);	
	}

}

*/


vector <int> Class_assignment_profile::
get_observed_index_set  (const string &pdb_ID)
{

		string binary_file_name = path_to_store_ + pdb_ID + string (".class_assignment_profile_observed");

		ifstream binary_stream ( binary_file_name.c_str(),ios::binary );

		if ( ! binary_stream )	{	
			log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			exit (1);	
		}


		binary_stream.seekg(0,ios::end);
		//int file_length = binary_stream.tellg();
		streamoff file_length = binary_stream.tellg();
		
		int size_of_index_vector = ( (int) file_length ) / sizeof(int);
			
		binary_stream.seekg(0,ios::beg);

		int *t_arr	= new int [size_of_index_vector	]; 	memset (t_arr	,0,size_of_index_vector*sizeof(int));

		binary_stream.read ( (char* )	t_arr,		size_of_index_vector * sizeof(double));

		vector <int> index_set;  index_set.resize(size_of_index_vector);
		
		for (int ii=0;ii<size_of_index_vector;ii++)
			index_set[ii] = t_arr[ii];

		delete [] t_arr;

		return index_set;
}



vector <int> Class_assignment_profile::
get_predicted_index_set  (const string &pdb_ID)
{
		string binary_file_name = path_to_store_ + pdb_ID + string (".class_assignment_profile_predicted");

		ifstream binary_stream ( binary_file_name.c_str(),ios::binary );

		if ( ! binary_stream )	{	
			log_stream	 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			cout		 << "ERROR -  can't create binary file" << binary_file_name<< endl;
			exit (1);	
		}

		binary_stream.seekg(0,ios::end);
		//int file_length = binary_stream.tellg();
		streamoff file_length = binary_stream.tellg();
		
		int size_of_index_vector = ( (int) file_length ) / sizeof(int);
			
		binary_stream.seekg(0,ios::beg);

		int *t_arr	= new int [size_of_index_vector	]; 	memset (t_arr	,0,size_of_index_vector*sizeof(int));

		binary_stream.read ( (char* )	t_arr,		size_of_index_vector * sizeof(double));

		vector <int> index_set;  index_set.resize(size_of_index_vector);
		
		for (int ii=0;ii<size_of_index_vector;ii++)
			index_set[ii] = t_arr[ii];

		delete [] t_arr;

		return index_set;
}