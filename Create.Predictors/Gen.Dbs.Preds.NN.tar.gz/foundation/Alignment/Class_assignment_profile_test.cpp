#include "Class_assignment_profile_test.h"
#include "Class_assignment_profile.h"
#include <iostream>
#include <fstream>
#include <cstdlib>

extern ofstream log_stream;

Class_assignment_profile_test::
~Class_assignment_profile_test()
{
	cout << "Class_assignment_profile_test PASSED: " <<"  failed: " << get_failed() <<  "	passed: " << get_passed() << endl;
}

void Class_assignment_profile_test::
fill_up_test ()
{
	string model_name = string("second_model_advanced");
	Class_assignment_profile (model_name,FILL_UP_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);
}

void Class_assignment_profile_test::
get_observed_index_set_test  ()
{
	string model_name = string("second_model_advanced");
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	string pdb_ID = "16VPA";
	vector <int> index_set = cap_o.get_observed_index_set(pdb_ID);

	ofstream  out( "Test/get_observed_index_set_test");

	if ( ! out)	{
		log_stream << "get_observed_index_set_test : ERROR -  can't create file" << endl;
		cout       << "get_observed_index_set_test : ERROR -  can't create file" << endl;
		exit (1);
	}

	out << pdb_ID << endl;
	for (int ii=0;ii<index_set.size();ii++)
	{
		out << index_set[ii] << endl;
	}
}
void Class_assignment_profile_test::
compare_predicted_and_observed_assignment_test()
{

	string model_name = string("second_model_advanced");
	Class_assignment_profile cap_o(model_name,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	string pdb_ID = "2WWZC";

	vector <int> index_set_observed  = cap_o.get_observed_index_set (pdb_ID);
	vector <int> index_set_predicted = cap_o.get_predicted_index_set(pdb_ID);

	ofstream  out( "Test/compare_predicted_and_observed_assignment_test");

	if ( ! out)	{
		log_stream << "compare_predicted_and_observed_assignment_test : ERROR -  can't create file" << endl;
		cout       << "compare_predicted_and_observed_assignment_test : ERROR -  can't create file" << endl;
		exit (1);
	}

	out << pdb_ID << endl;
	test_("size of observed and predictted set must be equal", index_set_observed.size() == index_set_predicted.size() );
	for (int ii=0;ii<index_set_observed.size();ii++)
	{
		out << index_set_predicted[ii] << "\t";
		out << index_set_observed[ii] << endl;
	}



}

