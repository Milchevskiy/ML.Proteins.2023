#include <cassert>

int get_inverse_distance_segment_index(
	const double inv_distance_value,
	const int inverse_distance_segmentation_ration)
{
	assert(inv_distance_value >= 0);

	double step_value = 1.0 / inverse_distance_segmentation_ration;
	for (int kk = 0; kk<inverse_distance_segmentation_ration; kk++)
	{
		double  lower_val = step_value*kk;
		double  upper_val = step_value*(kk + 1);
		if (inv_distance_value >= lower_val    &&	inv_distance_value <= upper_val)
			return kk;
	}
	return (inverse_distance_segmentation_ration - 1);
}