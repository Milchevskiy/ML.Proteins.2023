#include "Cluster_dssp_interdependence.h"

#include "../Fragment_base/accepted_chain_data.h"

#include "../Chain_store/DSSP_binary.h"
#include "../Censorship.h"

#include "../Main_model/handle_det_distance_set.h"
#include "Class_assignment_profile.h"
#include <iostream>

#include "../Sheduler.h"
#include "../Censorship.h"
#include "../CommonFunc.h"
#include "../Cluster_set/Cluster_set.h"

#include "../Pair_int_double.h"
#include "../get_nearest_claster_index.h"

#include "../Main_model/Abu_Maimonides_Rambam.h"

#include <cassert>

extern ofstream log_stream;
extern Censorship configuration;

Cluster_dssp_interdependence::
Cluster_dssp_interdependence(
	const string & Cluster_dssp_interdependence_name, 
	Cluster_dssp_interdependence_operating_modes run_mode):
	cluster_dssp_interdependence_name_ (Cluster_dssp_interdependence_name),
  cap_o_	(0),
  sheduler_	(0),
  inverse_distance_segmentation_ration_(0)
{
	sheduler_		= new Sheduler     ( configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + Cluster_dssp_interdependence_name + string ("/") + string ("sheduler") ) ;

	model_name_ = sheduler_->option_meaning ("MAIN_MODEL_NAME");

	string binary_file_name  = sheduler_->option_meaning ("ACCEPTED_CHAIN_LIST");

	fill_up_accepted_chain_data ( 
		template_chain_ID_list_, 
		template_chain_lenth_,
		binary_file_name);

	path_to_current_model_store_	
		= configuration.option_meaning("Path_to_Model_store")  + model_name_ + string ("/cross_sum/")  ;

// Only to remind number_of_classes_ 
	string cluster_set_name_ =   sheduler_->option_meaning("CLUSTER_SET_NAME");
	cls_ = new Cluster_set  (	cluster_set_name_,COMMON_USAGE_CLUSTER_SET_MODE);
	number_of_classes_ = cls_->number_of_classes();

	inverse_distance_segmentation_ration_ = atoi ( sheduler_->option_meaning("INVERSE_DISTANCE_SEGMENTATION_RATION").c_str() );

// ���� � ����������� ����� ���������� 
	cap_o_ = new Class_assignment_profile (model_name_,COMMON_USAGE_CLASS_ASSIGNMENT_PROFILE_OPERATING_MODES);

	eight_letter_number_size_ = 9 ; //!!!!!!!1

	switch ( run_mode  )
	{

		case FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES: 
			//fill_up_artless_probability_cluster_for_dssp();
			fill_up_probability_cluster_for_dssp();
			break;
		case COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES:
			init_parameters_for_prediction();
	//		init_key_for_dssp_prediction ();
			break;
		default :
			log_stream	<< "Inadmissible run mode for Maimonides_Rambam class" << endl;
			cout		<< "Inadmissible run mode for Maimonides_Rambam class" << endl;
			throw;
	}

}
void Cluster_dssp_interdependence::
init_parameters_for_prediction()
{
	//	init_trivial_cluster_preference ();  // assigns predicted & observed !!!
	//	init_key_for_trivial_dssp_prediction ();// assigns predicted & observed !!!
			//vector <vector <double> > & artless_probability_cluster_for_dssp);
		init_cluster_preference ();
		init_key_for_dssp_prediction ();

		dssp_eight_names_ = "HGIEBST-?";
}

void Cluster_dssp_interdependence::
init_key_for_dssp_prediction ()	// assigns predicted & observed !!!
{
	d_key_for_dssp_prediction_ = 
		get_key_for_d_dssp_prediction (
			d_predicted_probability_dssp_for_cluster_);

	d_key_for_dssp_prediction_by_observed_=
		get_key_for_d_dssp_prediction (
			d_observed_probability_dssp_for_cluster_);
}


void Cluster_dssp_interdependence::
init_key_for_trivial_dssp_prediction ()	// assigns predicted & observed !!!
{


	key_for_trivial_dssp_prediction_ = 	
		get_key_for_trivial_dssp_prediction ( 
				predicted_artless_probability_dssp_for_cluster_);

	key_for_trivial_dssp_prediction_by_observed_ = 
				get_key_for_trivial_dssp_prediction ( 
					observed_artless_probability_dssp_for_cluster_);




}

/*
void Cluster_dssp_interdependence::init_cluster_preference ()
{
	string path_to_source_file = 
	configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
	cluster_dssp_interdependence_name_ + string ("/") + string ("cluster_preference");

	ifstream in ( path_to_source_file.c_str());

	if ( ! in)	{	
		log_stream	 << "ERROR -  can't find " << path_to_source_file << endl;
		cout		 << "ERROR -  can't find " << path_to_source_file << endl;
		throw;	
	}

	predicted_artless_probability_dssp_for_cluster_.	resize(number_of_classes_);
	observed_artless_probability_dssp_for_cluster_.		resize(number_of_classes_);;;
	for (int kk=0;kk<number_of_classes_;kk++)
	{
		predicted_artless_probability_dssp_for_cluster_		[kk].resize(eight_letter_number_size_);;
		observed_artless_probability_dssp_for_cluster_		[kk].resize(eight_letter_number_size_);;
	}
	

	string current_line;
	getline( in, current_line, '\n' );  // First dummy line

	string temp;
	istringstream ist (current_line);
//Cluster No/DSSP class    H           G           I           E           B           S           T           C           ?           
	ist >> temp ;ist >> temp ;ist >> temp ;
	
	for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		ist >> temp ;

	int current_cluster_id; 
	for (int ii =0; ii< number_of_classes_; ii++ )
	{
		in >> current_cluster_id;
		assert (current_cluster_id == ii);
		for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		{
			in >> predicted_artless_probability_dssp_for_cluster_[ii][kk] 
			   >> observed_artless_probability_dssp_for_cluster_ [ii][kk]		;
		}
	}
}
*/

void Cluster_dssp_interdependence::init_cluster_preference ()
{
	string path_to_source_file = 
	configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
	cluster_dssp_interdependence_name_ + string ("/") + string ("cluster_preference");

	ifstream in ( path_to_source_file.c_str());

	if ( ! in)	{	
		log_stream	 << "ERROR -  can't find " << path_to_source_file << endl;
		cout		 << "ERROR -  can't find " << path_to_source_file << endl;
		throw;	
	}
/*
	predicted_artless_probability_dssp_for_cluster_.	resize(number_of_classes_);
	observed_artless_probability_dssp_for_cluster_.		resize(number_of_classes_);;;
	for (int kk=0;kk<number_of_classes_;kk++)
	{
		predicted_artless_probability_dssp_for_cluster_		[kk].resize(eight_letter_number_size_);;
		observed_artless_probability_dssp_for_cluster_		[kk].resize(eight_letter_number_size_);;
	}
*/	

	d_observed_probability_dssp_for_cluster_.resize(inverse_distance_segmentation_ration_);
	d_predicted_probability_dssp_for_cluster_.resize(inverse_distance_segmentation_ration_);

	for (int kk=0;kk<inverse_distance_segmentation_ration_;kk++)
	{
		d_observed_probability_dssp_for_cluster_	[kk].resize(number_of_classes_);
		d_predicted_probability_dssp_for_cluster_	[kk].resize(number_of_classes_);
		for (int ttt=0;ttt<number_of_classes_;ttt++)
		{
			d_observed_probability_dssp_for_cluster_	[kk][ttt].resize(eight_letter_number_size_);
			d_predicted_probability_dssp_for_cluster_	[kk][ttt].resize(eight_letter_number_size_);
		}
	}


	string current_line;
	getline( in, current_line, '\n' );  // First dummy line

	string temp;
	istringstream ist (current_line);
//Cluster No/DSSP class    H           G           I           E           B           S           T           C           ?           
	ist >> temp ;ist >> temp ;ist >> temp ;
	
	for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		ist >> temp ;

	int current_cluster_id,current_distance_index; 
	for (int ii =0; ii< number_of_classes_; ii++ )
	{
		for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
		{
			in >> current_cluster_id >> current_distance_index;
			assert (current_cluster_id == ii);
			assert (current_distance_index == ttt);
			for (int kk=0;kk<eight_letter_number_size_ ;kk++)
			{
				in >> d_predicted_probability_dssp_for_cluster_[ttt][ii][kk] 
				   >> d_observed_probability_dssp_for_cluster_ [ttt][ii][kk]		;
			}
		}
	}
}


void Cluster_dssp_interdependence::init_trivial_cluster_preference ()
{
	string path_to_source_file = 
	configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
	cluster_dssp_interdependence_name_ + string ("/") + string ("trivial_cluster_preference");

	ifstream in ( path_to_source_file.c_str());

	if ( ! in)	{	
		log_stream	 << "ERROR -  can't find " << path_to_source_file << endl;
		cout		 << "ERROR -  can't find " << path_to_source_file << endl;
		throw;	
	}

	predicted_artless_probability_dssp_for_cluster_.	resize(number_of_classes_);
	observed_artless_probability_dssp_for_cluster_.		resize(number_of_classes_);;;
	for (int kk=0;kk<number_of_classes_;kk++)
	{
		predicted_artless_probability_dssp_for_cluster_		[kk].resize(eight_letter_number_size_);;
		observed_artless_probability_dssp_for_cluster_		[kk].resize(eight_letter_number_size_);;
	}
	

	string current_line;
	getline( in, current_line, '\n' );  // First dummy line

	string temp;
	istringstream ist (current_line);
//Cluster No/DSSP class    H           G           I           E           B           S           T           C           ?           
	ist >> temp ;ist >> temp ;ist >> temp ;
	
	for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		ist >> temp ;

	int current_cluster_id; 
	for (int ii =0; ii< number_of_classes_; ii++ )
	{
		in >> current_cluster_id;
		assert (current_cluster_id == ii);
		for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		{
			in >> predicted_artless_probability_dssp_for_cluster_[ii][kk] 
			   >> observed_artless_probability_dssp_for_cluster_ [ii][kk]		;
		}
	}
}
// �� �� ��� fill_up_artless_probability_cluster_for_dssp() 
// �� ������������ (�� ��� �������) "����������� �� �����������". ��� ������ ������. ��� ���� ���������� ��� ���������� �������� �� 0 �� 0.1 - ������ ����� 0 ���
void Cluster_dssp_interdependence::
fill_up_probability_cluster_for_dssp()
{

	int MAX_SIZE_FOR_PROFILE = 10000;

	int *observed_profile	= new int [MAX_SIZE_FOR_PROFILE];
	int *predicted_profile	= new int [MAX_SIZE_FOR_PROFILE];

	d_observed_probability_dssp_for_cluster_.resize(inverse_distance_segmentation_ration_);
	d_predicted_probability_dssp_for_cluster_.resize(inverse_distance_segmentation_ration_);

	for (int kk=0;kk<inverse_distance_segmentation_ration_;kk++)
	{
		d_observed_probability_dssp_for_cluster_	[kk].resize(number_of_classes_);
		d_predicted_probability_dssp_for_cluster_	[kk].resize(number_of_classes_);
		for (int ttt=0;ttt<number_of_classes_;ttt++)
		{
			d_observed_probability_dssp_for_cluster_	[kk][ttt].resize(eight_letter_number_size_);
			d_predicted_probability_dssp_for_cluster_	[kk][ttt].resize(eight_letter_number_size_);
		}
	}

	for (int ii=0;ii < template_chain_ID_list_.size();ii++)
//	for (int ii=0;ii < 10000;ii++)
	{
		string  template_pdb_id = template_chain_ID_list_[ii];

		string  sequence; 
		string  extended_DSSP_sequence;

		vector < vector < vector <double> > >  d_observed_local_probability_dssp_for_cluster; 

			d_handle_single_chain(
				template_pdb_id,
				string (".dist_data"),
				d_observed_local_probability_dssp_for_cluster,
				sequence,
				extended_DSSP_sequence,
				observed_profile);


		vector < vector < vector <double> > >  d_predicted_local_probability_dssp_for_cluster; 
		d_handle_single_chain(
				template_pdb_id,
				string (".dist_data_predicted"),
				d_predicted_local_probability_dssp_for_cluster,
				sequence,
				extended_DSSP_sequence,
				predicted_profile);

		d_print_protocol (
			d_observed_local_probability_dssp_for_cluster,
			d_predicted_local_probability_dssp_for_cluster,
			template_pdb_id,
			sequence,
			extended_DSSP_sequence,
			observed_profile,
			predicted_profile);



//		vector < vector < vector <double> > >  d_observed_probability_dssp_for_cluster_;
//		vector < vector < vector <double> > >  d_predicted_probability_dssp_for_cluster_;

		for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
		{
			for (int kk=0;kk<number_of_classes_;kk++)
			{
				for (int jj=0;jj<eight_letter_number_size_;jj++)
				{
					d_observed_probability_dssp_for_cluster_			[ttt][kk][jj] += 
						d_observed_local_probability_dssp_for_cluster	[ttt][kk][jj];

					double test  = d_predicted_local_probability_dssp_for_cluster	[ttt][kk][jj];
					double test1 = d_predicted_probability_dssp_for_cluster_			[ttt][kk][jj];

					d_predicted_probability_dssp_for_cluster_			[ttt][kk][jj] += 
						d_predicted_local_probability_dssp_for_cluster	[ttt][kk][jj];
				}
			} 
		}
		cout << ii << "\t" << template_pdb_id << endl;
	}

	d_print_trivial_result(string("d_result") );

	delete [] observed_profile;
	delete [] predicted_profile;
/// 
}
void Cluster_dssp_interdependence::  // �� �� ��� � handle_single_chain()  �� ������������ (�� ��� �������) "����������� �� �����������".
d_handle_single_chain(
	const string & template_pdb_id,
	const string & extension_suffix,
	vector < vector < vector <double> > > & d_local_probability_cluster_for_dssp,
	string & sequence,
	string & extended_DSSP_sequence,
	int *profile) 
{
	

	d_local_probability_cluster_for_dssp.resize(inverse_distance_segmentation_ration_);
	for (int kk=0;kk<inverse_distance_segmentation_ration_;kk++)
	{
		d_local_probability_cluster_for_dssp[kk].resize(number_of_classes_);
		for (int ttt=0;ttt<number_of_classes_;ttt++)
		{
			d_local_probability_cluster_for_dssp[kk][ttt].resize(eight_letter_number_size_);
		}
	}

	DSSP_binary pdb_ID_dssp (template_pdb_id,COMMON_USAGE);

	extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
	sequence				= pdb_ID_dssp.get_sequence();

	string current_distance_file_name = path_to_current_model_store_ + template_pdb_id + extension_suffix; // string (".dist_data");
		
	vector < vector < double > > det_distance_set = 
	read_det_distance_set (current_distance_file_name);
	int length = det_distance_set.size();

	//	int *profile = new int [length];
	memset(profile,0,length*sizeof (int ) );
	cap_o_-> make_class_assignment_profile ( 
			det_distance_set,
			profile);

	int size_by_dssp		= pdb_ID_dssp.get_sequence().size();
	int size_distance_set	= det_distance_set.size();

	assert ( (size_by_dssp-4) == size_distance_set);

	int shift = 2;

	for (int ii=0; ii< size_distance_set; ii++)
	{
		int index_dssp;
		char ch=extended_DSSP_sequence[ii+shift] ;
		switch (ch) 
		{
			case 'H' : index_dssp = 0; break;
			case 'G' : index_dssp = 1; break; 
			case 'I' : index_dssp = 2; break;
			case 'E' : index_dssp = 3; break;
			case 'B' : index_dssp = 4; break;
			case 'S' : index_dssp = 5; break;
			case 'T' : index_dssp = 6; break;
			case  '-': index_dssp = 7; break;
			case '?' : index_dssp = 8; break;

			default : 
				cout << extended_DSSP_sequence[ii+shift] <<  "strange DSSP class" << endl;
		}
		int index_cluster = profile[ii];

		if ( index_cluster == -1 ) 
			continue;        	// for observed cluster only

		double inv_distance = det_distance_set[ii][index_cluster+number_of_classes_];
		int segment_index = get_inverse_distance_segment_index (inv_distance);
		d_local_probability_cluster_for_dssp[segment_index][index_cluster][index_dssp] ++ ;
	}


}
void Cluster_dssp_interdependence::
fill_up_artless_probability_cluster_for_dssp()
{
	int MAX_SIZE_FOR_PROFILE = 10000;

	int *observed_profile	= new int [MAX_SIZE_FOR_PROFILE];
	int *predicted_profile	= new int [MAX_SIZE_FOR_PROFILE];


	observed_artless_probability_dssp_for_cluster_.	resize(number_of_classes_);
	predicted_artless_probability_dssp_for_cluster_.resize(number_of_classes_);;

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		observed_artless_probability_dssp_for_cluster_	[kk].resize(eight_letter_number_size_);
		predicted_artless_probability_dssp_for_cluster_	[kk].resize(eight_letter_number_size_);;
	}

	for (int ii=0;ii < template_chain_ID_list_.size();ii++)
	{
		string  template_pdb_id = template_chain_ID_list_[ii];

		string  sequence; 
		string  extended_DSSP_sequence;

		vector <vector <double> > observed_local_artless_probability_dssp_for_cluster; 
		handle_single_chain(
				template_pdb_id,
				string (".dist_data"),
				observed_local_artless_probability_dssp_for_cluster,
				sequence,
				extended_DSSP_sequence,
				observed_profile);

		vector <vector <double> > predicted_local_artless_probability_dssp_for_cluster; 
		handle_single_chain(
				template_pdb_id,
				string (".dist_data_predicted"),
				predicted_local_artless_probability_dssp_for_cluster,
				sequence,
				extended_DSSP_sequence,
				predicted_profile);

		print_protocol (
			observed_local_artless_probability_dssp_for_cluster,
			predicted_local_artless_probability_dssp_for_cluster,
			template_pdb_id,
			sequence,
			extended_DSSP_sequence,
			observed_profile,
			predicted_profile);

		for (int kk=0;kk<number_of_classes_;kk++)
		{
			for (int jj=0;jj<eight_letter_number_size_;jj++)
			{
				observed_artless_probability_dssp_for_cluster_	[kk][jj] += 
					observed_local_artless_probability_dssp_for_cluster[kk][jj];
				predicted_artless_probability_dssp_for_cluster_	[kk][jj] += 
					predicted_local_artless_probability_dssp_for_cluster[kk][jj];
			}
		}


		cout << ii << "\t" << template_pdb_id << endl;


	}

	print_trivial_result (string ("trivail_result") );

	delete [] observed_profile;
	delete [] predicted_profile;
}


void Cluster_dssp_interdependence::
d_print_trivial_result (
	const string & result_file_name)
{

	string path_to_protocol_file =  
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
		cluster_dssp_interdependence_name_ + 
		string ("/") + string ("protocol") + string ("/")+
		result_file_name + 		string (".d_simple_protocol");

	ofstream protocol_stream ( path_to_protocol_file.c_str(),ios::binary );

	if ( ! protocol_stream  )	{	
		log_stream	 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		cout		 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		exit (1);	
	}

	protocol_stream << "Cluster No/DSSP class    " ;
	PutVa ("H",protocol_stream,12,1,'l');
	PutVa ("G",protocol_stream,12,1,'l');
	PutVa ("I",protocol_stream,12,1,'l');
	PutVa ("E",protocol_stream,12,1,'l');
	PutVa ("B",protocol_stream,12,1,'l');
	PutVa ("S",protocol_stream,12,1,'l');
	PutVa ("T",protocol_stream,12,1,'l');
	PutVa (" ",protocol_stream,12,1,'l');
	PutVa ("?",protocol_stream,12,1,'l');
	protocol_stream << endl;


	//vector < vector < vector <double> > >  d_observed_probability_dssp_for_cluster_;
	//vector < vector < vector <double> > >  d_predicted_probability_dssp_for_cluster_;

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
		{
			PutVa (kk,protocol_stream,15,1,'l');
			PutVa (ttt,protocol_stream,10,1,'l');

			for (int jj=0;jj<eight_letter_number_size_;jj++)
			{
				double test = d_predicted_probability_dssp_for_cluster_[ttt][kk][jj];
				PutVaDouble( 
					d_predicted_probability_dssp_for_cluster_[ttt][kk][jj],
					protocol_stream,5,2,'l');
				protocol_stream << "[";
				PutVaDouble( 
					d_observed_probability_dssp_for_cluster_[ttt][kk][jj],
					protocol_stream,5,2,'l');
				protocol_stream << "]";

			}
			protocol_stream << endl;
		}

	}

	protocol_stream << "_______________________________________________________________________"  << endl;
//// ��� ��� ��������
	vector < vector <int> >  d_observed_class_occurence_counter; d_observed_class_occurence_counter.resize(inverse_distance_segmentation_ration_);
	vector < vector <int> >  d_predicted_class_occurence_counter; d_predicted_class_occurence_counter.resize(inverse_distance_segmentation_ration_);

	for (int ii=0;ii<inverse_distance_segmentation_ration_;ii++)
	{
		d_observed_class_occurence_counter[ii].resize(number_of_classes_);
		d_predicted_class_occurence_counter [ii].resize(number_of_classes_);
	}

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
		{
			for (int jj=0;jj<eight_letter_number_size_;jj++)
			{
				d_observed_class_occurence_counter  [ttt][kk] += (int) d_observed_probability_dssp_for_cluster_ [ttt][kk][jj];
				d_predicted_class_occurence_counter [ttt][kk] += (int) d_predicted_probability_dssp_for_cluster_[ttt][kk][jj];
			}
		}
	}

	protocol_stream << "Cluster No/DSSP class    " ;
	PutVa ("H",protocol_stream,12,1,'l');
	PutVa ("G",protocol_stream,12,1,'l');
	PutVa ("I",protocol_stream,12,1,'l');
	PutVa ("E",protocol_stream,12,1,'l');
	PutVa ("B",protocol_stream,12,1,'l');
	PutVa ("S",protocol_stream,12,1,'l');
	PutVa ("T",protocol_stream,12,1,'l');
	PutVa (" ",protocol_stream,12,1,'l');
	PutVa ("?",protocol_stream,12,1,'l');
	protocol_stream << endl;

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
		{
			PutVa (kk,protocol_stream,15,1,'l');
			PutVa (ttt,protocol_stream,10,1,'l');

			for (int jj=0;jj<eight_letter_number_size_;jj++)
			{
				if ( d_predicted_class_occurence_counter[ttt][kk] == 0 )
					PutVa( 
					"0",protocol_stream,5,4,'l');
				else
					PutVaDouble( 
						d_predicted_probability_dssp_for_cluster_[ttt][kk][jj]/d_predicted_class_occurence_counter[ttt][kk],
						protocol_stream,5,4,'l');

				protocol_stream << "[";
				if ( d_observed_class_occurence_counter[ttt][kk] == 0 )
					PutVa( 
					"0",protocol_stream,5,4,'l');
				else
					PutVaDouble( 
						d_observed_probability_dssp_for_cluster_[ttt][kk][jj]/d_observed_class_occurence_counter[ttt][kk],
						protocol_stream,5,4,'l');
				protocol_stream << "]";
			}
			protocol_stream << endl;
		}
	}
}

void Cluster_dssp_interdependence::
print_trivial_result (
	const string & result_file_name)
{

	string path_to_protocol_file =  
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
		cluster_dssp_interdependence_name_ + 
		string ("/") + string ("protocol") + string ("/")+
		result_file_name + 		string (".simple_protocol");

	ofstream protocol_stream ( path_to_protocol_file.c_str(),ios::binary );

	if ( ! protocol_stream  )	{	
		log_stream	 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		cout		 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		exit (1);	
	}

	protocol_stream << "Cluster No/DSSP class    " ;
	PutVa ("H",protocol_stream,12,1,'l');
	PutVa ("G",protocol_stream,12,1,'l');
	PutVa ("I",protocol_stream,12,1,'l');
	PutVa ("E",protocol_stream,12,1,'l');
	PutVa ("B",protocol_stream,12,1,'l');
	PutVa ("S",protocol_stream,12,1,'l');
	PutVa ("T",protocol_stream,12,1,'l');
	PutVa (" ",protocol_stream,12,1,'l');
	PutVa ("?",protocol_stream,12,1,'l');
	protocol_stream << endl;
	for (int kk=0;kk<number_of_classes_;kk++)
	{
		PutVa (kk,protocol_stream,25,1,'l');
		for (int jj=0;jj<eight_letter_number_size_;jj++)
		{
			PutVaDouble( 
				predicted_artless_probability_dssp_for_cluster_[kk][jj],
				protocol_stream,5,2,'l');
			protocol_stream << "[";
			PutVaDouble( 
				observed_artless_probability_dssp_for_cluster_[kk][jj],
				protocol_stream,5,2,'l');
			protocol_stream << "]";

		}
		protocol_stream << endl;
	}

	protocol_stream << "_______________________________________________________________________"  << endl;

	vector <int> observed_class_occurence_counter; observed_class_occurence_counter.resize(number_of_classes_);
	vector <int> predicted_class_occurence_counter;predicted_class_occurence_counter.resize(number_of_classes_);

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		for (int jj=0;jj<eight_letter_number_size_;jj++)
		{
			observed_class_occurence_counter[kk] += (int) observed_artless_probability_dssp_for_cluster_[kk][jj];
			predicted_class_occurence_counter[kk] += (int) predicted_artless_probability_dssp_for_cluster_[kk][jj];
		}
	}

	protocol_stream << "Cluster No/DSSP class    " ;
	PutVa ("H",protocol_stream,12,1,'l');
	PutVa ("G",protocol_stream,12,1,'l');
	PutVa ("I",protocol_stream,12,1,'l');
	PutVa ("E",protocol_stream,12,1,'l');
	PutVa ("B",protocol_stream,12,1,'l');
	PutVa ("S",protocol_stream,12,1,'l');
	PutVa ("T",protocol_stream,12,1,'l');
	PutVa (" ",protocol_stream,12,1,'l');
	PutVa ("?",protocol_stream,12,1,'l');
	protocol_stream << endl;

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		PutVa (kk,protocol_stream,25,1,'l');
		for (int jj=0;jj<eight_letter_number_size_;jj++)
		{
			PutVaDouble( 
				predicted_artless_probability_dssp_for_cluster_[kk][jj]/predicted_class_occurence_counter[kk],
				protocol_stream,5,4,'l');
			protocol_stream << "[";
			PutVaDouble( 
				observed_artless_probability_dssp_for_cluster_[kk][jj]/observed_class_occurence_counter[kk],
				protocol_stream,5,4,'l');
			protocol_stream << "]";
		}
		protocol_stream << endl;

	}
}
void Cluster_dssp_interdependence::
d_print_protocol (
	vector < vector < vector <double> > >  &	d_observed_local_probability_dssp_for_cluster,
	vector < vector < vector <double> > >  &	d_predicted_local_probability_dssp_for_cluster,
	const string & template_pdb_id,
	string & sequence,
	string & extended_DSSP_sequence,
	int *observed_profile,
	int *predicted_profile)
{

	path_to_current_model_store_	= 
		configuration.option_meaning("Path_to_Model_store")  + model_name_ + string ("/cross_sum/")  ;

	string path_to_protocol_file =  
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
		cluster_dssp_interdependence_name_ + 
		string ("/") + string ("protocol") + string ("/")+
		template_pdb_id + 
		string (".d_simple_protocol");

	ofstream protocol_stream ( path_to_protocol_file.c_str(),ios::binary );

	if ( ! protocol_stream  )	{	
		log_stream	 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		cout		 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		exit (1);	
	}

	assert (sequence.size() == extended_DSSP_sequence.size() );
	int seq_len = sequence.size();

	for (int ii=0; ii< 2; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	for ( int ii=0; ii<seq_len-4; ii++ )
	{
		protocol_stream << sequence[ii+2] << "\t" << extended_DSSP_sequence[ii+2] << "\t" ;
		PutVa (predicted_profile[ii],protocol_stream,5,2,'l');
		PutVa (observed_profile	[ii],protocol_stream,5,2,'l');
		protocol_stream << endl;
	}
	for (int ii=seq_len-2; ii< seq_len; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	protocol_stream << "____________________________________________________________________________" << endl;


	protocol_stream << "Cluster No/DSSP class    " ;
	PutVa ("H",protocol_stream,12,1,'l');
	PutVa ("G",protocol_stream,12,1,'l');
	PutVa ("I",protocol_stream,12,1,'l');
	PutVa ("E",protocol_stream,12,1,'l');
	PutVa ("B",protocol_stream,12,1,'l');
	PutVa ("S",protocol_stream,12,1,'l');
	PutVa ("T",protocol_stream,12,1,'l');
	PutVa (" ",protocol_stream,12,1,'l');
	PutVa ("?",protocol_stream,12,1,'l');
	protocol_stream << endl;

//	vector < vector < vector <double> > >  &	d_observed_local_probability_dssp_for_cluster,
//	vector < vector < vector <double> > >  &	d_predicted_local_probability_dssp_for_cluster,

	for (int kk=0;kk<number_of_classes_;kk++)
	{
		for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
		{
			PutVa (kk,protocol_stream,15,1,'l');
			PutVa (ttt,protocol_stream,10,1,'l');

			for (int jj=0;jj<eight_letter_number_size_;jj++)
			{
				PutVaDouble( 
					d_predicted_local_probability_dssp_for_cluster[ttt][kk][jj],
					protocol_stream,5,2,'l');
				protocol_stream << "[";
				PutVaDouble( 
					d_observed_local_probability_dssp_for_cluster[ttt][kk][jj],
					protocol_stream,5,2,'l');
				protocol_stream << "]";

			}

			protocol_stream << endl;
		}
	}

}



void Cluster_dssp_interdependence::
print_protocol (
	vector <vector <double> > observed_local_artless_probability_dssp_for_cluster,
	vector <vector <double> > predicted_local_artless_probability_dssp_for_cluster,
	const string & template_pdb_id,
	string & sequence,
	string & extended_DSSP_sequence,
	int *observed_profile,
	int *predicted_profile)
{
	path_to_current_model_store_	
	= configuration.option_meaning("Path_to_Model_store")  + model_name_ + string ("/cross_sum/")  ;

	string path_to_protocol_file =  
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
		cluster_dssp_interdependence_name_ + 
		string ("/") + string ("protocol") + string ("/")+
		template_pdb_id + 
		string (".simple_protocol");

	ofstream protocol_stream ( path_to_protocol_file.c_str(),ios::binary );

	if ( ! protocol_stream  )	{	
		log_stream	 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		cout		 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		exit (1);	
	}

	assert (sequence.size() == extended_DSSP_sequence.size() );
	int seq_len = sequence.size();

	for (int ii=0; ii< 2; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	for ( int ii=0; ii<seq_len-4; ii++ )
	{
		protocol_stream << sequence[ii+2] << "\t" << extended_DSSP_sequence[ii+2] << "\t" ;
		PutVa (predicted_profile[ii],protocol_stream,5,2,'l');
		PutVa (observed_profile	[ii],protocol_stream,5,2,'l');
		protocol_stream << endl;
	}
	for (int ii=seq_len-2; ii< seq_len; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	protocol_stream << "____________________________________________________________________________" << endl;

	protocol_stream << "Cluster No/DSSP class    " ;
	PutVa ("H",protocol_stream,12,1,'l');
	PutVa ("G",protocol_stream,12,1,'l');
	PutVa ("I",protocol_stream,12,1,'l');
	PutVa ("E",protocol_stream,12,1,'l');
	PutVa ("B",protocol_stream,12,1,'l');
	PutVa ("S",protocol_stream,12,1,'l');
	PutVa ("T",protocol_stream,12,1,'l');
	PutVa (" ",protocol_stream,12,1,'l');
	PutVa ("?",protocol_stream,12,1,'l');
	protocol_stream << endl;
	for (int kk=0;kk<number_of_classes_;kk++)
	{
		PutVa (kk,protocol_stream,25,1,'l');
		for (int jj=0;jj<eight_letter_number_size_;jj++)
		{
			PutVaDouble( 
				predicted_local_artless_probability_dssp_for_cluster[kk][jj],
				protocol_stream,5,2,'l');
			protocol_stream << "[";
			PutVaDouble( 
				observed_local_artless_probability_dssp_for_cluster[kk][jj],
				protocol_stream,5,2,'l');
			protocol_stream << "]";

		}
		protocol_stream << endl;
	}
}


void Cluster_dssp_interdependence::
handle_single_chain(
	const string & template_pdb_id,
	const string & extension_suffix,
	vector <vector <double> > & local_artless_probability_cluster_for_dssp,
	string & sequence,
	string & extended_DSSP_sequence,
	int *profile) 
{

	local_artless_probability_cluster_for_dssp.resize(number_of_classes_);
	
//	vector <vector <double> > local_predicted_artless_probability_cluster_for_dssp.resize(number_of_classes_);;

	
	for (int ii=0;ii<number_of_classes_;ii++)
	{
		local_artless_probability_cluster_for_dssp[ii].resize(eight_letter_number_size_);
//		local_predicted_artless_probability_cluster_for_dssp[ii].resize(eight_letter_number_size_);;
	}
	DSSP_binary pdb_ID_dssp (template_pdb_id,COMMON_USAGE);

	extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
	sequence				= pdb_ID_dssp.get_sequence();

	string current_distance_file_name = path_to_current_model_store_ + template_pdb_id + extension_suffix; // string (".dist_data");
		
	vector < vector < double > > det_distance_set = 
	read_det_distance_set (current_distance_file_name);
	int length = det_distance_set.size();

//	int *profile = new int [length];
	memset(profile,0,length*sizeof (int ) );
	cap_o_-> make_class_assignment_profile ( 
			det_distance_set,
			profile);

	int size_by_dssp		= pdb_ID_dssp.get_sequence().size();
	int size_distance_set	= det_distance_set.size();

	assert ( (size_by_dssp-4) == size_distance_set);

	int shift = 2;

	for (int ii=0; ii< size_distance_set; ii++)
	{
		int index_dssp;
		char ch=extended_DSSP_sequence[ii+shift] ;
		switch (ch) 
		{
			case 'H' : index_dssp = 0; break;
			case 'G' : index_dssp = 1; break; 
			case 'I' : index_dssp = 2; break;
			case 'E' : index_dssp = 3; break;
			case 'B' : index_dssp = 4; break;
			case 'S' : index_dssp = 5; break;
			case 'T' : index_dssp = 6; break;
			case  '-': index_dssp = 7; break;
			case '?' : index_dssp = 8; break;

			default : 
				cout << extended_DSSP_sequence[ii+shift] <<  "strange DSSP class" << endl;
		}
		int index_cluster = profile[ii];

		if ( index_cluster == -1 ) 
			continue;             // for observed cluster only

		local_artless_probability_cluster_for_dssp[index_cluster][index_dssp] ++ ;
	}
//	delete [] profile;
}
// ��������. ������ init.. ()
void Cluster_dssp_interdependence::get_trivial_cluster_preference (
	vector <vector <double> > & predicted_artless_probability_dssp_for_cluster,
	string & dssp_eight_names)
{

	string path_to_source_file = 
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
	    cluster_dssp_interdependence_name_ + string ("/") + string ("trivial_cluster_preference");

	ifstream in ( path_to_source_file.c_str());

	if ( ! in)	{	
		log_stream	 << "ERROR -  can't find " << path_to_source_file << endl;
		cout		 << "ERROR -  can't find " << path_to_source_file << endl;
		throw;	
	}

	string output_file_name = "D:/Didona/Test/get_trivial_cluster_preference_test";
	ofstream out ( output_file_name .c_str());

	if ( ! out )	{	
		log_stream	 << "ERROR -  can't CREATE  " << output_file_name<< endl;
		cout		 << "ERROR -  can't CREATE  " << output_file_name<< endl;
		throw;	
	}

	
	predicted_artless_probability_dssp_for_cluster.resize(number_of_classes_);;
	for (int kk=0;kk<number_of_classes_;kk++)
		predicted_artless_probability_dssp_for_cluster	[kk].resize(eight_letter_number_size_);;
	

	string current_line;
	getline( in, current_line, '\n' );  // First dummy line

	string temp;
	dssp_eight_names.resize(eight_letter_number_size_ );
	istringstream ist (current_line);
//Cluster No/DSSP class    H           G           I           E           B           S           T           C           ?           
	ist >> temp ;ist >> temp ;ist >> temp ;
	
	for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		ist >> dssp_eight_names[kk];

	int current_cluster_id; 
	for (int ii =0; ii< number_of_classes_; ii++ )
	{
		in >> current_cluster_id;
		assert (current_cluster_id == ii);
		double dummy;
		for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		{
			in >> predicted_artless_probability_dssp_for_cluster[ii][kk] >> dummy;
		}

	}
	for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		out << "\t" << dssp_eight_names[kk];
	out << endl;


	for (int ii =0; ii< number_of_classes_; ii++ )
	{
		out  << ii ;

		for (int kk=0;kk<eight_letter_number_size_ ;kk++)
		{
			out << "\t" << predicted_artless_probability_dssp_for_cluster[ii][kk] ;
		}
		out << endl;
	}
}
vector < vector < Pair_int_double > > Cluster_dssp_interdependence::
get_key_for_trivial_dssp_prediction (
	vector <vector <double> > & artless_probability_cluster_for_dssp)
{
	vector < vector < Pair_int_double > > key_for_trivial_dssp_prediction;

	
	for (int ii =0; ii< number_of_classes_; ii++ )
	{
		vector < Pair_int_double > indexed_dist_store = get_sorted_indexed_dist_store (artless_probability_cluster_for_dssp [ii] );

		key_for_trivial_dssp_prediction.push_back ( indexed_dist_store  )  ;
	}

	return key_for_trivial_dssp_prediction;
}

//!!! D_ version for distinguishing prediction by distance 
vector < vector < vector < Pair_int_double > > >  Cluster_dssp_interdependence::
get_key_for_d_dssp_prediction (
	vector < vector < vector <double> > > & d_probability_dssp_for_cluster)
{
	vector < vector < vector < Pair_int_double > > > key_for_dssp_prediction;


	for (int ttt=0;ttt<inverse_distance_segmentation_ration_;ttt++)
	{
		vector < vector < Pair_int_double > >  temporary_for_fixed_ttt; temporary_for_fixed_ttt.resize(0);

		for (int ii =0; ii< number_of_classes_; ii++ )
		{
			vector < Pair_int_double > indexed_dist_store = get_sorted_indexed_dist_store (d_probability_dssp_for_cluster [ttt][ii] );

			temporary_for_fixed_ttt.push_back ( indexed_dist_store  )  ;
		}
		key_for_dssp_prediction.push_back(temporary_for_fixed_ttt);

	}
	return key_for_dssp_prediction;
}

// returns eight-class dssp prepdiction
string  Cluster_dssp_interdependence::
	trivial_eight_letter_prediction_by_ready_cluster_profile  (
		int *predicted_profile,
		int length,  // size of predicted_profile  (LENGHT OF SEQUENCE - 4 )  
		vector < vector < Pair_int_double > > & key_for_trivial_dssp_prediction,
		string & dssp_eight_names)
{
//	int *profile = new int [length];
//	memset(predicted_profile,0,length*sizeof (int ) );

	string trivial_eight_letter_prediction;
	trivial_eight_letter_prediction.resize(length+4);  // �� ����� �� ��� ������ ������� (���� ������������ � �������. ������)

	for (int ii=0; ii<length;ii++)
	{
		int predicted_index = predicted_profile[ii];

		int last_in_sorted_list = eight_letter_number_size_ -1 ; // ������������� �� �����������, ��������
		int    current_dssp_index		= key_for_trivial_dssp_prediction [predicted_index][last_in_sorted_list].index();
		double  current_prob_value	= key_for_trivial_dssp_prediction [predicted_index][last_in_sorted_list].value();

		trivial_eight_letter_prediction[ii] = dssp_eight_names[current_dssp_index];
	}

	return trivial_eight_letter_prediction;
}

string Cluster_dssp_interdependence::
	d_predict_dssp_eight_letter (	
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < vector < Pair_int_double > > > & d_key_for_dssp_prediction)
{

	int length = predicted_det_distance_set.size();
	int *profile = new int [length];

	memset(profile,0,length*sizeof (int ) );
	cap_o_-> make_class_assignment_profile ( 
			predicted_det_distance_set,
			profile);

	string eight_letter_prediction; 	eight_letter_prediction.resize(length);

	for (int ii=0; ii<length;ii++)
	{
		int predicted_index = profile[ii];

			int ttttt= predicted_det_distance_set[0].size();
		int distance_index = get_inverse_distance_segment_index (
				predicted_det_distance_set[ii][predicted_index + number_of_classes_]);

		int last_in_sorted_list = eight_letter_number_size_ -1 ; // ������������� �� �����������, ��������
		int    current_dssp_index		= d_key_for_dssp_prediction [distance_index][predicted_index][last_in_sorted_list].index();
		double  current_prob_value		= d_key_for_dssp_prediction [distance_index][predicted_index][last_in_sorted_list].value();

		eight_letter_prediction[ii] = dssp_eight_names_[current_dssp_index];
	}

	delete [] profile;
	return eight_letter_prediction;
}


string Cluster_dssp_interdependence::
	d_predict_dssp_eight_letter_and_prob_value (	
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < vector < Pair_int_double > > > & d_key_for_dssp_prediction,
		vector <double> &prob_value)
{

	int length = predicted_det_distance_set.size();
	int *profile = new int [length];

	prob_value.resize(length);

	memset(profile,0,length*sizeof (int ) );
	cap_o_-> make_class_assignment_profile ( 
			predicted_det_distance_set,
			profile);

	string eight_letter_prediction; 	eight_letter_prediction.resize(length);

	for (int ii=0; ii<length;ii++)
	{
		int predicted_index = profile[ii];

			int ttttt= predicted_det_distance_set[0].size();
		int distance_index = get_inverse_distance_segment_index (
				predicted_det_distance_set[ii][predicted_index + number_of_classes_]);

		int last_in_sorted_list = eight_letter_number_size_ -1 ; // ������������� �� �����������, ��������
		int    current_dssp_index		= d_key_for_dssp_prediction [distance_index][predicted_index][last_in_sorted_list].index();
		double  current_prob_value		= d_key_for_dssp_prediction [distance_index][predicted_index][last_in_sorted_list].value();

		prob_value[ii] = current_prob_value	;
		eight_letter_prediction[ii] = dssp_eight_names_[current_dssp_index];
	}

	delete [] profile;
	return eight_letter_prediction;
}



string Cluster_dssp_interdependence::
	predict_dssp_eight_letter (	
		vector < vector < double > > & predicted_det_distance_set,
		vector < vector < Pair_int_double > > & key_for_trivial_dssp_prediction )
{
	

	int length = predicted_det_distance_set.size();
	int *profile = new int [length];

	memset(profile,0,length*sizeof (int ) );
	cap_o_-> make_class_assignment_profile ( 
			predicted_det_distance_set,
			profile);

	string trivial_eight_letter_prediction;
	trivial_eight_letter_prediction.resize(length);

	for (int ii=0; ii<length;ii++)
	{
		int predicted_index = profile[ii];

		int last_in_sorted_list = eight_letter_number_size_ -1 ; // ������������� �� �����������, ��������
		int    current_dssp_index		= key_for_trivial_dssp_prediction [predicted_index][last_in_sorted_list].index();
		double  current_prob_value	= key_for_trivial_dssp_prediction [predicted_index][last_in_sorted_list].value();

		trivial_eight_letter_prediction[ii] = dssp_eight_names_[current_dssp_index];
	}

	delete [] profile;
	return trivial_eight_letter_prediction;
}

string 	Cluster_dssp_interdependence::
predict_dssp_eight_letter_by_sequence (
	const string & sequence,
	vector <double> &prob_value)
{
	Abu_Maimonides_Rambam mr ( model_name_, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

	charming_Reg_solution  * current_crs = mr.init_together_model ();

	vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence (
		sequence,
		current_crs);


	string dssp_eight_letter = d_predict_dssp_eight_letter_and_prob_value (	
		predicted_det_distance_set,
		d_key_for_dssp_prediction_,
		prob_value);

	delete current_crs;

	return dssp_eight_letter;

}


void Cluster_dssp_interdependence::
d_print_predicted_observed_comparison_for_ready_prediction ( 
	const string & template_pdb_id)	
{
	DSSP_binary pdb_ID_dssp (template_pdb_id,COMMON_USAGE);

	string extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
	string sequence					= pdb_ID_dssp.get_sequence();

	string current_distance_file_name_observed = path_to_current_model_store_ + template_pdb_id + string (".dist_data");
	vector < vector < double > > det_distance_set_observed = 
		read_det_distance_set (current_distance_file_name_observed);

	int length_observed = det_distance_set_observed.size();
	string is_structure_present; is_structure_present.resize(length_observed);

	for (int ii=0;ii<length_observed ;ii++)
	{
		if (det_distance_set_observed [ii][0] == -1 )
			is_structure_present[ii]='n';
		else 
			is_structure_present[ii]='y';
	}

	string current_distance_file_name_predicted = path_to_current_model_store_ + template_pdb_id + string (".dist_data_predicted");
	vector < vector < double > > det_distance_set_predicted = 
		read_det_distance_set (current_distance_file_name_predicted );

	int length_predicted = det_distance_set_predicted .size();

	string 	dssp_eight_letter_prediction = 	d_predict_dssp_eight_letter (
		det_distance_set_predicted,
		d_key_for_dssp_prediction_ );

	string 	dssp_eight_letter_prediction_by_observed = d_predict_dssp_eight_letter (	
		det_distance_set_predicted,
		d_key_for_dssp_prediction_by_observed_ );

	string path_to_protocol_file =  
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
		cluster_dssp_interdependence_name_ + 
		string ("/") + string ("protocol") + string ("/")+
		template_pdb_id + 		string (".d_prediction_protocol");

	ofstream protocol_stream ( path_to_protocol_file.c_str(),ios::binary );

	if ( ! protocol_stream  )	{	
		log_stream	 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		cout		 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		exit (1);	
	}

	string extended_DSSP_sequence_3						= reduce_8letter_to_3letter ( extended_DSSP_sequence);
	string dssp_eight_letter_prediction_3				= reduce_8letter_to_3letter ( dssp_eight_letter_prediction);
	string dssp_eight_letter_prediction_by_observed_3	= reduce_8letter_to_3letter ( dssp_eight_letter_prediction_by_observed);

	assert (sequence.size() == extended_DSSP_sequence.size() );
	int seq_len = sequence.size();

	for (int ii=0; ii< 2; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	for ( int ii=0; ii<seq_len-4; ii++ )
	{
		protocol_stream << sequence[ii+2] << "\t" << extended_DSSP_sequence[ii+2] << "\t" ;
		PutVa (dssp_eight_letter_prediction[ii],protocol_stream,5,2,'l');
		PutVa (dssp_eight_letter_prediction_by_observed	[ii],protocol_stream,5,2,'l');
		PutVa (is_structure_present[ii],protocol_stream,3,2,'l');

		PutVa (extended_DSSP_sequence_3			[ii+2],				protocol_stream,2,1,'l');
		PutVa (dssp_eight_letter_prediction_3	[ii],				protocol_stream,2,1,'l');
		PutVa (dssp_eight_letter_prediction_by_observed_3[ii],		protocol_stream,2,1,'l');

		protocol_stream << endl;
	}
	for (int ii=seq_len-2; ii< seq_len; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	protocol_stream << "____________________________________________________________________________" << endl;

	double q8 = calcQ8 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction,
		is_structure_present);

	double q8_by_obseved = calcQ8 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction_by_observed,
		is_structure_present);


	double q3 = calcQ3 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction,
		is_structure_present);

	double q3_by_obseved = calcQ3 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction_by_observed,
		is_structure_present);

	protocol_stream << "Q8 by predicted dssp-cluster inderdependence and by observed one" << endl;
	PutVa (q8 ,protocol_stream,8,3,'l');
	PutVa (q8_by_obseved ,protocol_stream,8,3,'l');
	protocol_stream << endl; 
	protocol_stream << "Q3 by predicted dssp-cluster inderdependence and by observed one" << endl;
	PutVa (q3 ,protocol_stream,8,3,'l');
	PutVa (q3_by_obseved ,protocol_stream,8,3,'l');

}


void Cluster_dssp_interdependence::
print_predicted_observed_comparison_for_ready_prediction ( 
	const string & template_pdb_id)	
{
	DSSP_binary pdb_ID_dssp (template_pdb_id,COMMON_USAGE);

	string extended_DSSP_sequence	= pdb_ID_dssp.get_extended_DSSP_sequence();
	string sequence					= pdb_ID_dssp.get_sequence();

	string current_distance_file_name_observed = path_to_current_model_store_ + template_pdb_id + string (".dist_data");
	vector < vector < double > > det_distance_set_observed = 
		read_det_distance_set (current_distance_file_name_observed);

	int length_observed = det_distance_set_observed.size();
	string is_structure_present; is_structure_present.resize(length_observed);

	for (int ii=0;ii<length_observed ;ii++)
	{
		if (det_distance_set_observed [ii][0] == -1 )
			is_structure_present[ii]='n';
		else 
			is_structure_present[ii]='y';
	}

	string current_distance_file_name_predicted = path_to_current_model_store_ + template_pdb_id + string (".dist_data_predicted");
	vector < vector < double > > det_distance_set_predicted = 
		read_det_distance_set (current_distance_file_name_predicted );

	int length_predicted = det_distance_set_predicted .size();

	string 	dssp_eight_letter_prediction = predict_dssp_eight_letter (	
		det_distance_set_predicted,
		key_for_trivial_dssp_prediction_ );

	string 	dssp_eight_letter_prediction_by_observed = predict_dssp_eight_letter (	
		det_distance_set_predicted,
		key_for_trivial_dssp_prediction_by_observed_ );

	string path_to_protocol_file =  
		configuration.option_meaning("Path_to_Cluster_dssp_interdependence")  + 
		cluster_dssp_interdependence_name_ + 
		string ("/") + string ("protocol") + string ("/")+
		template_pdb_id + 		string (".prediction_protocol");

	ofstream protocol_stream ( path_to_protocol_file.c_str(),ios::binary );

	if ( ! protocol_stream  )	{	
		log_stream	 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		cout		 << "ERROR -  can't create protocol file (Cluster_dssp_interdependence clacc)" << path_to_protocol_file<< endl;
		exit (1);	
	}

	string extended_DSSP_sequence_3						= reduce_8letter_to_3letter ( extended_DSSP_sequence);
	string dssp_eight_letter_prediction_3				= reduce_8letter_to_3letter ( dssp_eight_letter_prediction);
	string dssp_eight_letter_prediction_by_observed_3	= reduce_8letter_to_3letter ( dssp_eight_letter_prediction_by_observed);

	assert (sequence.size() == extended_DSSP_sequence.size() );
	int seq_len = sequence.size();

	for (int ii=0; ii< 2; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	for ( int ii=0; ii<seq_len-4; ii++ )
	{
		protocol_stream << sequence[ii+2] << "\t" << extended_DSSP_sequence[ii+2] << "\t" ;
		PutVa (dssp_eight_letter_prediction[ii],protocol_stream,5,2,'l');
		PutVa (dssp_eight_letter_prediction_by_observed	[ii],protocol_stream,5,2,'l');
		PutVa (is_structure_present[ii],protocol_stream,3,2,'l');

		PutVa (extended_DSSP_sequence_3			[ii+2],				protocol_stream,2,1,'l');
		PutVa (dssp_eight_letter_prediction_3	[ii],				protocol_stream,2,1,'l');
		PutVa (dssp_eight_letter_prediction_by_observed_3[ii],		protocol_stream,2,1,'l');

		protocol_stream << endl;
	}
	for (int ii=seq_len-2; ii< seq_len; ii++)
		protocol_stream << sequence[ii] << "\t" << extended_DSSP_sequence[ii] << "\t" << endl;

	protocol_stream << "____________________________________________________________________________" << endl;

	double q8 = calcQ8 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction,
		is_structure_present);

	double q8_by_obseved = calcQ8 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction_by_observed,
		is_structure_present);





	double q3 = calcQ3 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction,
		is_structure_present);

	double q3_by_obseved = calcQ3 (
		extended_DSSP_sequence,
		dssp_eight_letter_prediction_by_observed,
		is_structure_present);

	protocol_stream << "Q8 by predicted dssp-cluster inderdependence and by observed one" << endl;
	PutVa (q8 ,protocol_stream,8,3,'l');
	PutVa (q8_by_obseved ,protocol_stream,8,3,'l');
	protocol_stream << endl; 
	protocol_stream << "Q3 by predicted dssp-cluster inderdependence and by observed one" << endl;
	PutVa (q3 ,protocol_stream,8,3,'l');
	PutVa (q3_by_obseved ,protocol_stream,8,3,'l');

}
int Cluster_dssp_interdependence::
get_inverse_distance_segment_index (const double inv_distance_value)
{
	assert 	(inv_distance_value >= 0 );

	double step_value= 1.0/inverse_distance_segmentation_ration_;
	for (int kk=0;kk<inverse_distance_segmentation_ration_;kk++)
	{
		double  lower_val = step_value*kk;
		double  upper_val = step_value*(kk+1);
		if (inv_distance_value >= lower_val    &&	inv_distance_value <= upper_val )
			return kk;
	}
	return ( inverse_distance_segmentation_ration_ -1 );
}

double calcQ8 (
		 string & extended_DSSP_sequence,
		const string & dssp_eight_letter_prediction,
		const string & is_structure_present)
{
	int seq_len = extended_DSSP_sequence.size();

	for (int ii=0;ii<seq_len;ii++)
	{
		if (extended_DSSP_sequence [ii]==' ')
			extended_DSSP_sequence [ii]='C';
	}

	int coincidence = 0;
	int true_structure_counter = 0;

	for ( int ii=0; ii<seq_len-4; ii++ )
	{
		if (is_structure_present[ii]=='y')
			true_structure_counter ++;
		else 
			continue;

		if (extended_DSSP_sequence[ii+2]==dssp_eight_letter_prediction[ii])
			coincidence++;
	}
	double q8 = (double) coincidence/true_structure_counter; 

	return q8;
	
}

double calcQ3 (
		string & extended_DSSP_sequence,
		string & dssp_eight_letter_prediction,
		const string & is_structure_present)
{

	int seq_len = extended_DSSP_sequence.size();

	for (int ii=0;ii<seq_len;ii++)
	{
		if (extended_DSSP_sequence [ii]==' ')
			extended_DSSP_sequence [ii]='C';
	}


	string extended_DSSP_sequence_3			= reduce_8letter_to_3letter ( extended_DSSP_sequence);
	string dssp_eight_letter_prediction_3	= reduce_8letter_to_3letter ( dssp_eight_letter_prediction);

	int coincidence = 0;
	int true_structure_counter = 0;

	for ( int ii=0; ii<seq_len-4; ii++ )
	{
		if (is_structure_present[ii]=='y')
			true_structure_counter ++;
		else 
			continue;

		if (extended_DSSP_sequence_3[ii+2]==dssp_eight_letter_prediction_3[ii])
			coincidence++;
	}
	double q3 = (double) coincidence/true_structure_counter; 

	return q3;
}


string reduce_8letter_to_3letter ( string & dssp_sequence_8 )
{
	int length = dssp_sequence_8.size();

	string dssp_sequence_3;  dssp_sequence_3.resize(length);

	for (int ii=0; ii<length; ii++)
	{
		switch (dssp_sequence_8[ii]) 
		{
			case 'H' : 	case 'G' : 	case 'I' : 
				dssp_sequence_3[ii] = 'H'; break;

			case 'E' :	case 'B' : 
				dssp_sequence_3[ii] = 'E'; break;

			case 'S' : 	case 'T' : 	case  ' ': 	case  '-': 
				dssp_sequence_3[ii] = '-'; break;
			case '?' : dssp_sequence_3[ii] = '?';
				break;
			default : 
				cout << dssp_sequence_8[ii] <<  "strange DSSP class" << endl;
		}
	}
	return dssp_sequence_3;
}
