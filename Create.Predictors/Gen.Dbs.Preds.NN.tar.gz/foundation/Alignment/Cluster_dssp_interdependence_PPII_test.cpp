#pragma warning( disable : 4786 )

#include "Cluster_dssp_interdependence_PPII_test.h"
#include "Cluster_dssp_interdependence_PPII.h"
#include "Cluster_dssp_interdependence.h"

#include "../Censorship.h"
#include "../CommonFunc.h"

#include <fstream>
#include <iostream> 
#include <cassert>

#include "../Pair_int_double.h"
#include "../Main_model/handle_det_distance_set.h"
#include "Class_assignment_profile.h"
#include "../Chain_store/DSSP_binary.h"

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

Cluster_dssp_interdependence_PPII_test::~Cluster_dssp_interdependence_PPII_test()
{
	cout << "Cluster_dssp_interdependence_PPII_test  passed: " << "  failed: " << get_failed() << "	passed: " << get_passed() << endl;
}


void Cluster_dssp_interdependence_PPII_test::
fill_up_chain_sequence_DSSP_PPII_data_test()
{
	Cluster_dssp_interdependence_PPII di_oject(
		string("ppii_1"),
		COMMON_USAGE_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);


	map <string, string>	ID_to_sequence_map =
		di_oject.get_ID_to_sequence_map(); 

	map <string, string>	ID_to_dssp_PPII_map = 
		di_oject.get_ID_to_dssp_PPII_map();
	


	string path_to_output_file = string("D:/Didona/Test/fill_up_chain_sequence_DSSP_PPII_data_test");
	ofstream out(path_to_output_file.c_str());
	if (!out) {
		cout << "ERROR -  can't create " << path_to_output_file << endl;
		log_stream << "ERROR -  can't create " << path_to_output_file << endl;
		throw;
	}

	string path_to_bad_chain_list = string("D:/Didona/Test/bad_chain_list");
	ofstream bc_strm(path_to_bad_chain_list.c_str());
	if (!bc_strm) {
		cout << "ERROR -  can't create " << path_to_bad_chain_list << endl;
		log_stream << "ERROR -  can't create " << path_to_bad_chain_list << endl;
		throw;
	}


	string path_to_seq_DSSP_PPII_store = string("D:/Didona/Store/Cluster_dssp_interdependence_PPII/ppii_1/SeqDssp_PPII.data/");

	typedef map < string, string > MAP_STRING_STRING;
	MAP_STRING_STRING::const_iterator theIterator;


	int counter = 0;
	for (theIterator = ID_to_sequence_map.begin(); theIterator != ID_to_sequence_map.end(); theIterator++)
	{
		string		key = (*theIterator).first;
		string	value = (*theIterator).second;

		std::size_t found = value.find("-");
		if (found != std::string::npos)
		{
			bc_strm << key << "  symbol -  " << endl;
			continue;
		}

//		cout << key << "\t" << value << endl;
	out << key << "\t" << value << endl;

		string seq_dssp_path = path_to_seq_DSSP_PPII_store + key;
		ofstream se_str(seq_dssp_path.c_str());
		if (!se_str) {
			cout << "ERROR -  can't create " << seq_dssp_path << endl;
			log_stream << "ERROR -  can't create " << seq_dssp_path << endl;
			throw;
		}

		string dssp_PPII = ID_to_dssp_PPII_map[key];

		se_str << value << endl;
		se_str << dssp_PPII << endl;

	}


}

void Cluster_dssp_interdependence_PPII_test::
fill_up_probability_cluster_for_dssp_test()
{

	Cluster_dssp_interdependence_PPII di_oject(
		string("ppii_1"),
		FILL_UP_CLUSTER_DSSP_INTERDEPENDENCE_OPERATING_MODES);

}


