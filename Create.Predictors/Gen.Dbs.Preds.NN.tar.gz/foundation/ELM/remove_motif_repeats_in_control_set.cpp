#include "some_usefull_util_for_elm_task.h"

using namespace std;

extern ofstream log_stream;

map < string, vector<int> > remove_motif_repeats_in_control_set(
	map < string, Unipot_like > & motif_unambiguous,
	map < string, Unipot_like > & control_unambiguous)
{

	map < string, vector<int> >  corrected_control_StartPointsMap;

	typedef   map < string, Unipot_like > MAP_STRING_TO_UNIPROT_LIKE;
	MAP_STRING_TO_UNIPROT_LIKE::iterator theIterator;

	int counter = 0;
	for (theIterator = control_unambiguous.begin(); theIterator != control_unambiguous.end(); theIterator++)
	{
		string id_unambiguous_control = (*theIterator).first;
		Unipot_like cu_control_item = (*theIterator).second;

		if (motif_unambiguous.find(id_unambiguous_control) != motif_unambiguous.end())
		{
			log_stream	<< counter << "   " << id_unambiguous_control << " ignored" << endl;
			cout		 << counter << "   " << id_unambiguous_control << " ignored" << endl;
			counter++;
			continue;  // ��� ��� �����. ����� �� ������
		}

		int start = control_unambiguous[id_unambiguous_control].start;
		string id = control_unambiguous[id_unambiguous_control].id;

		vector <int> current_index_set; current_index_set.resize(0);
// ��� ����������� � 
		if (corrected_control_StartPointsMap.find(id) != corrected_control_StartPointsMap.end())
		{
			current_index_set = corrected_control_StartPointsMap[id];
		}
		else
		{
			;  // to debug check only
		}

		current_index_set.push_back(start);
		corrected_control_StartPointsMap[id] = current_index_set;
	}

	return corrected_control_StartPointsMap;
}