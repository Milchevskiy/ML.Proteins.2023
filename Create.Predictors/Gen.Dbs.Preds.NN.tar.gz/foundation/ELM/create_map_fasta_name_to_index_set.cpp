#include "some_usefull_util_for_elm_task.h"

using namespace std;

extern ofstream log_stream;



map < string, vector<int> > create_map_fasta_name_to_index_set(
	vector <Unipot_like>  & some_set)
{
	map < string, vector<int> > StartPointsMap;
	int current_index;
	int set_size = some_set.size();
	for (int ii = 0; ii < set_size; ii++)
	{
		vector <int>  current_index_set;
		string id = some_set[ii].id;  // here id is a fasta file name

		current_index = some_set[ii].start;

		if (StartPointsMap.find(id) != StartPointsMap.end())
		{
			current_index_set = StartPointsMap[id];
		}
		else
		{
			;  // to debug check only
		}

	//	current_index_set.push_back(current_index);
		current_index_set.push_back(current_index);
		StartPointsMap[id] = current_index_set;
	}
	return StartPointsMap;
}