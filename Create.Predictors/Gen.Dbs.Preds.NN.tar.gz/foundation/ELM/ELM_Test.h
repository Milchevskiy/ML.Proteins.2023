#ifndef ELM_TEST_H
#define ELM_TEST_H

#ifndef SIMPLE_TEST_H
#include "../Simple_test.h"

#endif

#include <string>

class ELM_Test : public Simple_test
{
public:
	~ELM_Test();

	void run()
	{
//		dummy_preparing_ELM_data_for_DA(); // Create data for discriminant analysis (olf version no uniport data)
//		check_motif_unipreds();				// remove extra instances ( matches but not motif)
		//remove_extra_control_cases();
	//	gently_rename_motif_files();    // ������� ���, ����� ����� ����� ����� ���������� ��������


		prepare_ELM_data_by_vlada_style_input(); //MAIN module for creating data !!!!!
	//	prepare_structure_data_by_vlada_style_input();

//		prepare_vlada_style_list_file_for_motif();
		
	}
	void dummy_preparing_ELM_data_for_DA();
	void check_motif_unipreds();
	void remove_extra_control_cases();
	void gently_rename_motif_files();
	void prepare_ELM_data_by_vlada_style_input();
	void prepare_structure_data_by_vlada_style_input();
	void prepare_vlada_style_list_file_for_motif();
};

#endif

//vec.erase(vec.begin() + idx);