#ifndef PREPARE_ELM_DATA_H
#define PREPARE_ELM_DATA_H

using namespace std;

class Prepare_elm_data
{
public:
	Prepare_elm_data(
		const string & name,
		const int left_shift,	
		const int right_shift);



};

#endif
