#include "some_usefull_util_for_elm_task.h"
#include "save_as_fasta.h"
#include "../CommonFunc.h"

#include "../iupred/uipred_perehodnik.h"

#include <cassert>

bool is_standard_one_letter_aminoacid_sequence(const string & current_sequence);


extern ofstream protocol_stream;


vector < vector <double> > single_set_for_ELM_data_for_DA(
	const string & path_to_prediction_store,
	const string & path_to_motif_store	,
	map < string, vector<int> > & StartPointsMap,
	CowardVariables *cowa_creator_,
	string & is_motif)
{
	ofstream check_stream;

	string  output_file("check_stream");
	check_stream.open(output_file.c_str()); // fix log or not log

	char *path_to_fasta_file_c;
	path_to_fasta_file_c = (char *) new char[1000];

//	configuration.init("D:/Didona/config");

	typedef   map < string, vector <int> > MAP_SEQUENCEMAP_TO_VECTOR_INT;
	MAP_SEQUENCEMAP_TO_VECTOR_INT::iterator theIterator;


	vector <vector <double> > da_set;
	int counter=0;
	for (theIterator = StartPointsMap.begin(); theIterator != StartPointsMap.end(); theIterator++)
	{
	string key = (*theIterator).first;
		vector <int> indexes = (*theIterator).second;

		string path_to_fasta_file = path_to_motif_store + key + string(".fasta");

		string fasta_head, sequence;
		read_fasta(
			path_to_fasta_file,
			fasta_head,
			sequence);

		bool is_standard_aa_seq_flag = is_standard_one_letter_aminoacid_sequence(sequence);
		if (!is_standard_aa_seq_flag)
		{
			check_stream << counter << " IGNORE! besides of stange_aa in" << "\t" << path_to_fasta_file << endl;
			continue;
		}


// cut extra part of full path
		string temp = "";
		for (int kk = path_to_fasta_file.size() - 1; kk >= 0; kk--)		{
			if (path_to_fasta_file[kk] == '/')		break;
			temp += path_to_fasta_file[kk];		}

		string fasta_file_name = "";
		for (int kk = temp.size() - 1; kk >= 0; kk--)			fasta_file_name += temp[kk];

		cout << counter << "  " << fasta_file_name << endl;

// prepare iupred variables

		memset(path_to_fasta_file_c, 0, 1000*sizeof(char));
		int kkk;
		for (kkk = 0; kkk < path_to_fasta_file.size(); kkk++)
			path_to_fasta_file_c[kkk] = path_to_fasta_file[kkk];

		//path_to_fasta_file_c[kkk] = 0;


// ������! 500 ��� ����������� � ������
	//	vector <vector <double> > Se_en = iupred_perehodnik_c1(	path_to_fasta_file_c );

	//	delete [] path_to_fasta_file_c;



		string path_to_iupred_file = new_extension_file_name(path_to_fasta_file, "iup");
//��� ������� ������� ��� ���� � ����� �� *.iup
		string sequence_by_iupred;
		vector <double>  Se_en = get_iupred_prediction_from_file(
									path_to_iupred_file,
									sequence_by_iupred);

		assert(sequence_by_iupred == sequence);

		// ��� �������
		string path_to_prediction_binary_file = path_to_prediction_store + key + string(".dist_data_predicted");
		cowa_creator_->set_path_to_current_prediction(path_to_prediction_binary_file);

		cowa_creator_->refresh_predicted_distance_set();


		vector < vector < double > > sophisticated_variables;
		cowa_creator_->process_chain(sequence);
		sophisticated_variables = cowa_creator_->get_sophisticated_variables();
		bool break_flag = false;
	//	int shift = 2; // AttENSION.
		for (int ii = 0; ii < indexes.size(); ii++)
		{
			int start_pos = indexes[ii] - 1;
			if (start_pos<0 || start_pos > sequence.size() - 6) {
				break_flag = true;
				cout << "ignore:" << "  " << fasta_file_name << " " << indexes[ii] << endl;
				cout << "ignore:" << "  " << fasta_file_name << " " << indexes[ii] << endl;
				break;
			}

// calc iupred_value
			double Sum_0 = 0;
			double Sum_1 = 0;
			for (int kkk = start_pos; kkk < start_pos + 6; kkk++)
			{
				Sum_0 += Se_en[kkk];
			}


			double  Sum_0_p2 = Sum_0*Sum_0;
			double  Sum_0_p3 = Sum_0*Sum_0*Sum_0;


			sophisticated_variables[indexes[ii]].push_back(Sum_0);
			sophisticated_variables[indexes[ii]].push_back(Sum_0_p2);
			sophisticated_variables[indexes[ii]].push_back(Sum_0_p3);

			da_set.push_back(sophisticated_variables[indexes[ii]]);

			string suspicious_sequence = sequence.substr(start_pos, 6);

			//!!!! protocol_stream << indexes [ii] << is_motif << fasta_head << "\t" << endl;
			protocol_stream << is_motif << '\t';
			protocol_stream << suspicious_sequence << '\t';

			protocol_stream << fasta_file_name << '\t';
			protocol_stream << indexes[ii] <<"  " << '\t\t\t';
			protocol_stream << fasta_head << endl;

		}
		counter++;

		check_stream << counter << "\t" << fasta_file_name << endl;

		if (counter % 100 == 0)
			cout << counter << endl;
	}
	return da_set;
};


