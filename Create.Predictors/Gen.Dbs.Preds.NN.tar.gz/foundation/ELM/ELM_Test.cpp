#include "ELM_Test.h"

#include <fstream>
#include "save_as_fasta.h"
#include "some_usefull_util_for_elm_task.h"

#include "../CowardVariables/CowardVariables.h"
#include "../CommonFunc.h"

#include "../Main_model/Abu_Maimonides_Rambam.h"

using namespace std;

extern ofstream log_stream;
//extern Censorship configuration;
ofstream protocol_stream;



int  prepare_structure_data_for_by_elm_data(
	const string & path_to_motif_store,
	map < string, vector<int> > & StartPointsMap,
	const string & model_name,
	string & is_motif);


//int  prepare_structure_data_for_by_elm_data(	const string & path_to_motif_store);

//int make_structural_data(const string & path_to_motif_store);



void read_Vlada_style_catalogue(
	const string & path_to_Vlada_style_catalogue,
	vector <Unipot_like> & control_set,
	ifstream  & in);

map < string, vector <Unipot_like> > fill_up_fragment_seq_to_contol_set(
	vector <Unipot_like>  control_set);

void print_maps_fragments_store(
	const string & path_to_maps_to_fragments_directory,
	const string & path_to_maps_to_fasta_store,
	map < string, vector <Unipot_like> > & target_map);

map < string, Unipot_like >  create_unambiguous_map(
	vector <Unipot_like>  & some_set);


map < string, vector<int> > create_map_fasta_name_to_index_set(
	vector <Unipot_like>  & some_set);


ELM_Test::
~ELM_Test()
{
	cout << "ELM_Test PASSED: " << "  failed: " << get_failed() << "	passed: " << get_passed() << endl;
}
/*
void ELM_Test::prepare_structure_data_by_vlada_style_input()
{

	string model_name = "new_generation_model_2";

//	string path_motif_catalogue = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/iupred_scores/motif_no_iupreds.txt";
//	string path_to_motif_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/";


	string path_control_catalogue = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control_from_uniprot_humanOnly/iupred_scores/bm_really_filtered_tillUIPRED.txt";
	string path_motif_catalogue = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/iupred_scores/motif_no_iupreds.txt";

	string path_to_motif_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/";
	string path_to_control_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control_from_uniprot_humanOnly/";


	ifstream in_motif(path_motif_catalogue.c_str());
	if (!in_motif) {
		log_stream << "ERROR -  can't read file" << path_motif_catalogue << endl;
		cout << "ERROR -  can't read file" << path_motif_catalogue << endl;
		throw "ERROR - can't readfile Vlada_style_catalogue ";
	}

	ifstream in_control(path_control_catalogue.c_str());
	if (!in_control) {
		log_stream << "ERROR -  can't read file" << path_control_catalogue << endl;
		cout << "ERROR -  can't read file" << path_control_catalogue << endl;
		throw "ERROR - can't readfile Vlada_style_catalogue ";
	}

	vector <Unipot_like>  control_set;
	vector <Unipot_like>  motif_set;

	read_Vlada_style_catalogue(
		path_motif_catalogue,
		motif_set,
		in_motif);

	read_Vlada_style_catalogue(
		path_control_catalogue,
		control_set,
		in_control);


	map < string, Unipot_like >  motif_unambiguous = create_unambiguous_map(motif_set);
	map < string, vector<int> >motif_StartPointsMap = create_map_fasta_name_to_index_set(motif_set);

	int added_structer_number_MOTIF = prepare_structure_data_for_by_elm_data(
		path_to_motif_store,
		motif_StartPointsMap,
		model_name,
		const string("MOTIF") );

//	int  ttt = prepare_structure_data_for_by_elm_data(
//		path_motif_catalogue);
	//int added_structer_number = make_structural_data(path_motif_catalogue);

//	map < string, Unipot_like >  motif_unambiguous = create_unambiguous_map(motif_set);
	map < string, Unipot_like >  control_unambiguous = create_unambiguous_map(control_set);

	//map < string, vector<int> >motif_StartPointsMap = create_map_fasta_name_to_index_set(motif_set);
	map < string, vector<int> >control_StartPointsMap = create_map_fasta_name_to_index_set(control_set);


	map < string, vector<int> > corrected_control_StartPointsMap = remove_motif_repeats_in_control_set(
		motif_unambiguous,
		control_unambiguous);

	int added_structer_number_CONTROL = prepare_structure_data_for_by_elm_data(
		path_to_control_store,
		corrected_control_StartPointsMap,
		model_name,
		string("MOTIF"));



}
*/

void ELM_Test::prepare_ELM_data_by_vlada_style_input()
{

	string path_to_prediction_store = "D:/Didona/Store/Model_store/new_generation_model_2/cross_sum/";

	//string path_control_catalogue = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control_from_uniprot_humanOnly/iupred_scores/bm_really_filtered_tillUIPRED.txt";
	string path_control_catalogue = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control/control_made_by_pdb.txt";


	string path_motif_catalogue		= "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/iupred_scores/motif_no_iupreds.txt";

	string path_to_motif_store		= "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/";
	string path_to_control_store	= "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control/";

	// HERE PATH to ready data file created by predictor variables
	string path_to_ready_DA_data = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/model5_contol_by_pdb/DA_data.txt";


	string path_to_protocol = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/model5_contol_by_pdb/protocol_ID.txt";

	ifstream in_motif(path_motif_catalogue.c_str());
	if (!in_motif) {
		log_stream << "ERROR -  can't read file" << path_motif_catalogue << endl;
		cout << "ERROR -  can't read file" << path_motif_catalogue << endl;
		throw "ERROR - can't readfile Vlada_style_catalogue ";
	}

	ifstream in_control(path_control_catalogue.c_str());
	if (!in_control) {
		log_stream << "ERROR -  can't read file" << path_control_catalogue << endl;
		cout << "ERROR -  can't read file" << path_control_catalogue << endl;
		throw "ERROR - can't readfile Vlada_style_catalogue ";
	}

	vector <Unipot_like>  control_set;
	vector <Unipot_like>  motif_set;

	read_Vlada_style_catalogue(
		path_motif_catalogue,
		motif_set,
		in_motif);

	read_Vlada_style_catalogue(
		path_control_catalogue,
		control_set,
		in_control);

	// ����� ����� �������� ������������ � ������ ������� � ��������
	map < string, Unipot_like >  motif_unambiguous		= create_unambiguous_map(motif_set);
	map < string, Unipot_like >  control_unambiguous	= create_unambiguous_map(control_set);

	map < string, vector<int> >motif_StartPointsMap		= create_map_fasta_name_to_index_set(motif_set);
	map < string, vector<int> >control_StartPointsMap	= create_map_fasta_name_to_index_set(control_set);


	map < string, vector<int> > corrected_control_StartPointsMap = remove_motif_repeats_in_control_set(
		motif_unambiguous,
		control_unambiguous);

	string path_to_cowardvariables_task_file = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/model5_contol_by_pdb/DA_data.names";

	CowardVariables *cowa_creator_ = new CowardVariables(path_to_cowardvariables_task_file);



	protocol_stream.open(path_to_protocol.c_str());
	if (!protocol_stream) {
		log_stream << "ERROR -  can't create file" << path_to_protocol << endl;
		cout << "ERROR -  can't create file" << path_to_protocol << endl;
		throw "ERROR - can't create file for DA_data";
	}

	vector < vector <double> > sophisticated_variables_motif =
		single_set_for_ELM_data_for_DA(
			path_to_prediction_store,
			path_to_motif_store,
			motif_StartPointsMap,
			cowa_creator_,
			string("MOTIF"));

	vector < vector <double> > sophisticated_variables_control =
		single_set_for_ELM_data_for_DA(
			path_to_prediction_store,
			path_to_control_store,
			corrected_control_StartPointsMap,
			cowa_creator_,
			string("CONTROL"));

	int number_of_variables = cowa_creator_->get_number_of_variables();
	number_of_variables = sophisticated_variables_control[0].size();


	delete cowa_creator_;


	ofstream out(path_to_ready_DA_data.c_str());
	if (!out) {
		log_stream << "ERROR -  can't create file" << path_to_ready_DA_data << endl;
		cout << "ERROR -  can't create file" << path_to_ready_DA_data << endl;
		throw "ERROR - can't create file for DA_data";
	}

	int number_of_classes = 2;
	int number_of_motif_cases = sophisticated_variables_motif.size();
	int number_of_control_cases = sophisticated_variables_control.size();
	int number_of_cases = number_of_motif_cases + number_of_control_cases;

	PutVa(number_of_classes, out, 5, 3, 'r');
	PutVa(number_of_cases, out, 10, 3, 'r');
	PutVa(number_of_variables, out, 5, 3, 'r');
	out << endl;

	int current_class_index = 0;
	for (int ii = 0; ii < number_of_motif_cases; ii++)
	{
		PutVa(current_class_index, out, 5, 3, 'r');
		for (int kk = 0; kk < number_of_variables; kk++)
		{
			PutVaDouble(sophisticated_variables_motif[ii][kk], out, 12, 6, 'r');
			out << " ";
		}

		out << endl;
	}
	current_class_index = 1;
	for (int ii = 0; ii < number_of_control_cases; ii++)
	{
		PutVa(current_class_index, out, 5, 3, 'r');
		for (int kk = 0; kk < number_of_variables; kk++)
		{
			PutVaDouble(sophisticated_variables_control[ii][kk], out, 12, 6, 'r');
			out << " ";
		}

		out << endl;
	}

}

map < string, Unipot_like >  create_unambiguous_map(
	vector <Unipot_like>  & some_set)
{
	map < string, Unipot_like > unambiguous_map;

	for (int ii = 0; ii < some_set.size(); ii++)
	{

		stringstream ss;
		ss << some_set[ii].start;;
		string s_start = ss.str();

		string key_unambiguous =
			some_set[ii].fragment_seq + string("_") +
			some_set[ii].id + string("_") +
			s_start;

		unambiguous_map[key_unambiguous] = some_set[ii];
	}

	return unambiguous_map;

}

void ELM_Test::gently_rename_motif_files()
{
	string path_to_motif_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/";
	string path_to_motif_StartPointsMap = path_to_motif_store + string("StartPointsMap");

	string path_to_new_motif_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/motif/iupred_scores/";
	string path_to_Vlada_style_catalogue = path_to_new_motif_store + string("motif_no_iupreds.txt");


	ofstream out(path_to_Vlada_style_catalogue.c_str());  // File for storing regular expression starts in motif containing instances
	if (!out) {
		log_stream << "ERROR -  can't create file" << path_to_Vlada_style_catalogue << endl;
		cout << "ERROR -  can't create file" << path_to_Vlada_style_catalogue << endl;
		throw "ERROR - can't reate Vlada_style_catalogue ";
	}





	map < string, vector<int> >StartPointsMap;

	int total_motiff_number =
		fill_up_StartPointsMap(
			path_to_motif_StartPointsMap,
			StartPointsMap);

	typedef   map < string, vector <int> > MAP_SEQUENCEMAP_TO_VECTOR_INT;
	MAP_SEQUENCEMAP_TO_VECTOR_INT::iterator theIterator;


	vector <vector <double> > da_set;
	int counter = 0;
	for (theIterator = StartPointsMap.begin(); theIterator != StartPointsMap.end(); theIterator++)
	{
		string key = (*theIterator).first;
		vector <int> indexes = (*theIterator).second;

		string path_to_fasta_file = path_to_motif_store + key + string(".fasta");

		string fasta_head, sequence;
		read_fasta(
			path_to_fasta_file,
			fasta_head,
			sequence);


		string new_id;
		{
			string word;
			istringstream ist(fasta_head);

			getline(ist, word, '|');
			getline(ist, word, '|');
			getline(ist, new_id, ' ');
		}

		string head_part;
		{
			istringstream ist(fasta_head);
			getline(ist, head_part, ' ');
		}


		string path_to_fasta_file_vlada_style = path_to_new_motif_store + new_id + string(".fasta");

		save_as_fasta(
			path_to_fasta_file_vlada_style,
			fasta_head,
			sequence);

//1433B_HUMAN PNATQP 108 114 sp | P31946 | 1433B_HUMAN 0.12241666666666666
		for (int ii = 0; ii < indexes.size(); ii++)
		{
			string fragment_sequence = sequence.substr(indexes[ii]-1, 6);
			out << new_id << " ";
			out << fragment_sequence << " ";
			out << indexes[ii]-1 << " ";
			out << indexes[ii]+5 << " ";
			out << head_part << " ";
			out << "0.0" << endl;
		}

	}

}
void ELM_Test::remove_extra_control_cases()
{
	string path_to_Vlada_style_catalogue = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control_from_uniprot_humanOnly/iupred_scores/control3_iupreds.txt";

	ifstream in(path_to_Vlada_style_catalogue.c_str());
	if (!in) {
		log_stream << "ERROR -  can't create file" << path_to_Vlada_style_catalogue << endl;
		cout << "ERROR -  can't create file" << path_to_Vlada_style_catalogue << endl;
		throw "ERROR - can't readfile Vlada_style_catalogue ";
	}

	vector <Unipot_like>  control_set;

	read_Vlada_style_catalogue(
		path_to_Vlada_style_catalogue,
		control_set,
		in);

	map < string, vector <Unipot_like> > fragment_seq_to_contol_set =
		fill_up_fragment_seq_to_contol_set(control_set);

	string path_to_maps_to_fragments_directory = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control_from_uniprot_humanOnly/iupred_scores/map_to_fragments/";

	string path_to_maps_to_fasta_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control_from_uniprot_humanOnly/";
	print_maps_fragments_store(
		path_to_maps_to_fragments_directory,
		path_to_maps_to_fasta_store,
		fragment_seq_to_contol_set);


}


void read_Vlada_style_catalogue(
	const string & path_to_Vlada_style_catalogue,
	vector <Unipot_like> & control_set,
	ifstream  & in)
{
	string id;
	string fragment_seq;
	int start;
	int end;
	string fasta_head;
	double iupred_fragment;

	Unipot_like current_object;

	int counter = 0;
	while (in >> id >> fragment_seq >> start >> end >> fasta_head >> iupred_fragment)
	{
		current_object.id = id;;
		current_object.fragment_seq=fragment_seq;
		current_object.start=start;
		current_object.end = end;
		current_object.fasta_head= fasta_head;
		current_object.iupred_fragment=iupred_fragment;

		current_object.u_status = PRINCIPAL;

		control_set.push_back(current_object);

		counter++;
	}
	cout << "set size: " << counter << endl;

}

map < string, vector <Unipot_like> >
fill_up_fragment_seq_to_contol_set(vector <Unipot_like>  control_set)
{
	map < string, vector <Unipot_like> >  target_map;

	int set_size = control_set.size();
	for (int ii = 0; ii < set_size; ii++)
	{
		vector <Unipot_like>  curr_object;
		string fragment_seq = control_set[ii].fragment_seq;
		if (target_map.find(fragment_seq) == target_map.end())
		{
			curr_object.push_back(control_set[ii]);
		}
		else
		{
			curr_object = target_map[fragment_seq];
			curr_object.push_back(control_set[ii]);
		}
		target_map[fragment_seq] = curr_object;

	}
	return target_map;
}

void print_maps_fragments_store(
	const string & path_to_maps_to_fragments_directory,
	const string & path_to_maps_to_fasta_store,
	map < string, vector <Unipot_like> > & target_map)
{
	typedef map < string, vector <Unipot_like> >  MAP_STRING_TO_VECTOR_UNIPROT_LIKE;
	MAP_STRING_TO_VECTOR_UNIPROT_LIKE::const_iterator theIterator;

	int counter = 0;
	for (theIterator = target_map.begin(); theIterator != target_map.end(); theIterator++)
	{
		string					key		= (*theIterator).first;
		vector <Unipot_like> 	value	= (*theIterator).second;

		string path_to_current_fragment_analysis = path_to_maps_to_fragments_directory + key;
		ofstream out_stream(path_to_current_fragment_analysis.c_str());
		if (!out_stream) {
			log_stream	<< "ERROR -  can't create file" << path_to_current_fragment_analysis << endl;
			cout		<< "ERROR -  can't create file" << path_to_current_fragment_analysis << endl;
			throw		"ERROR - can't create fragment_analysis ";
		}
		out_stream << key << ": " << value.size() << " instances" << endl;

		for (int ii = 0; ii < value.size(); ii++)
		{
			string id = value[ii].id;
			string path_to_fasta_file = path_to_maps_to_fasta_store + id+string(".fasta");

			string  fasta_head, sequence;

			read_fasta(
				path_to_fasta_file,
				fasta_head,
				sequence);

			for (int kk = 0; kk < sequence.size(); kk++)
				sequence[kk] = tolower(sequence[kk]);

			for (int kk = value[ii].start; kk < value[ii].end; kk++)
				sequence[kk] = toupper(sequence[kk]);

			out_stream << fasta_head << endl;
			out_stream << value[ii].start << " " << value[ii].end << endl;
			out_stream << sequence << endl <<  endl;
		}
	}
}

void ELM_Test::prepare_vlada_style_list_file_for_motif()
{
	string path_to_control_store = "D:/PredictorFactory/Store/ELM/MOD_N-GLC_1/control/";
	string path_to_control_StartPointsMap = path_to_control_store + string("StartPointsMap");

	map < string, vector<int> >StartPointsMap;

	int total_motiff_number =
		fill_up_StartPointsMap(
			path_to_control_StartPointsMap,
			StartPointsMap);

	string catalogue_control_made_by_pdb = path_to_control_store + string("control_made_by_pdb.txt");

	ofstream out(catalogue_control_made_by_pdb.c_str());
	if (!out) {
		log_stream << "ERROR -  can't create file" << catalogue_control_made_by_pdb << endl;
		cout << "ERROR -  can't create file" << catalogue_control_made_by_pdb << endl;
		throw "ERROR - can't create Vlada_style_catalogue ";
	}

	typedef   map < string, vector <int> > MAP_SEQUENCEMAP_TO_VECTOR_INT;
	MAP_SEQUENCEMAP_TO_VECTOR_INT::iterator theIterator;

	int counter = 0;
	for (theIterator = StartPointsMap.begin(); theIterator != StartPointsMap.end(); theIterator++)
	{
		string key = (*theIterator).first;
		vector <int> indexes = (*theIterator).second;

		string path_to_fasta_file = path_to_control_store + key + string(".fasta");

		string fasta_head, sequence;
		read_fasta(
			path_to_fasta_file,
			fasta_head,
			sequence);

		for (int ii = 0; ii < indexes.size(); ii++)
		{
			if (indexes[ii] < 2)
				continue;
			string fragment_sequence = sequence.substr(indexes[ii] - 1, 6);
			out << key << " ";
			out << fragment_sequence << " ";
			out << indexes[ii] - 1 << " ";
			out << indexes[ii] + 5 << " ";
			out << "made_of_pdb_content__" << key << " ";
			out << "0.0" << endl;
		}
	}
}
