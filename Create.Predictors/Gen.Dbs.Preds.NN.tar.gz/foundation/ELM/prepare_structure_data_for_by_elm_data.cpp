#include "some_usefull_util_for_elm_task.h"
#include "save_as_fasta.h"
#include "../CommonFunc.h"
#include "../Censorship.h"

#include "../iupred/uipred_perehodnik.h"

#include "../Main_model/Abu_Maimonides_Rambam.h"

#include <cassert>

bool is_standard_one_letter_aminoacid_sequence(const string & current_sequence);

extern ofstream protocol_stream;

extern Censorship configuration;
extern ofstream log_stream;

int  prepare_structure_data_for_by_elm_data(
	const string & path_to_motif_store,
	map < string, vector<int> > & StartPointsMap,
	const string & model_name,
	string & is_motif)
{
	Abu_Maimonides_Rambam mr(model_name, COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES);
	charming_Reg_solution  * current_crs = mr.init_together_model();

	ofstream check_stream;
	string  output_file("check_stream");
	check_stream.open(output_file.c_str()); // fix log or not log

	char *path_to_fasta_file_c;
	path_to_fasta_file_c = (char *) new char[1000];

	//	configuration.init("D:/Didona/config");

	typedef   map < string, vector <int> > MAP_SEQUENCEMAP_TO_VECTOR_INT;
	MAP_SEQUENCEMAP_TO_VECTOR_INT::iterator theIterator;

	vector <vector <double> > da_set;
	int counter = 0;
	for (theIterator = StartPointsMap.begin(); theIterator != StartPointsMap.end(); theIterator++)
	{
		string key = (*theIterator).first;
		vector <int> indexes = (*theIterator).second;

		string path_to_fasta_file = path_to_motif_store + key + string(".fasta");

		string fasta_head, sequence;
		read_fasta(
			path_to_fasta_file,
			fasta_head,
			sequence);

		bool is_standard_aa_seq_flag = is_standard_one_letter_aminoacid_sequence(sequence);
		if (!is_standard_aa_seq_flag)
		{
			check_stream << counter << " IGNORE! besides of stange_aa in" << "\t" << path_to_fasta_file << endl;
			continue;
		}

		vector <vector <double> > predicted_det_distance_set = mr.make_prediction_by_sequence(
			sequence,
			current_crs);

//		bool break_flag = false;
// ********************** WRITE LOCAL  *.DIST_DATA FILE ************************
		string current_distance_file_name =
			configuration.option_meaning("Path_to_Model_store") +
			model_name +
			"/cross_sum/" +
			key +
			".dist_data_predicted";

		ofstream distdata_stream(current_distance_file_name.c_str(), ios::binary);
		if (!distdata_stream)
		{
			log_stream << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name << endl;
			cout << "make_cross_sum_binary_files	(): ERROR -  can't create " << current_distance_file_name << endl;

			exit(1);
		}

		mr.write_distdata_for_regression(
			distdata_stream,
			predicted_det_distance_set);

		distdata_stream.close();
		//*******************************************************************************
	
		counter++;

		check_stream << counter << "\t" << key << endl;

		if (counter % 100 == 0)
			cout << counter << endl;
	}
	delete current_crs;

	return counter;
};
