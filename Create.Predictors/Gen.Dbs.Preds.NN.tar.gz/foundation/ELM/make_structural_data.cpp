#include "../CommonFunc.h"


int make_structural_data(const string & path_to_motif_store)
{
	return 0;
}