#ifndef GITHUB_UTIL_INCLUDED
#define GITHUB_UTIL_INCLUDED

#include <string>

using namespace std;

void make_predictor_file_set_by_naked_sequence_ (
    string &sequence,
    const string &path_for_pytorch_data,
    const string &predictor_file_name   );

void make_predictor_file_set_by_fasta_sequence(
    const string &path_to_sourcefilename,
	const string &path_for_pytorch_data,
	const string &predictor_file_name);

void make_predictor_file_set_by_seq_sequence(
    const string &path_to_sourcefilename,
	const string &path_for_pytorch_data,
	const string &predictor_file_name);


void usage_print ()	;

#endif // GITHUB_UTIL_INCLUDED
