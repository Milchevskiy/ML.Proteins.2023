
#include <iostream>

using namespace std;

void usage_print ()
{
    cout << "USAGE:" << endl;
    cout << "   Pred_PB_SS [option]input-file " << endl<< endl;

    cout << "   option:"<<endl<< endl;
    cout << "       -c : get sequence from commad line"<<endl;
    cout << "           example: Pred_PB_SS -cALPPPGGGGLSLSLSLS"<<endl<< endl;

    cout << "       -f : get sequence from fasta file"<<endl;
    cout << "           example: Pred_PB_SS -f1A0TP.fasta"<<endl<< endl;

    cout << "       -s : get sequence from seq file ()"<<endl;
    cout << "           example: Pred_PB_SS -s1A0TP.seq"<<endl;

    exit(-1);


}
