#include "../Main_model/Abu_Maimonides_Rambam.h"

#include "../Censorship.h"

#include <fstream>
#include <iostream>
#include <cassert>

//#include "../Fragment_base/Chain_binary.h"
#include "../CommonFunc.h"

//#include "../pb16_to_index.h"

#ifndef GET_NEAREST_CLASTER_INDEX_H
#define GET_NEAREST_CLASTER_INDEX_H

int get_nearest_claster_index( 	const vector <double> & distance_set );

#endif

#ifndef AMINOACID_TO_INDEX_H
#define AMINOACID_TO_INDEX_H

int aminoacid_to_index ( const char aa );
//log_stream  << " FTER Abu_Maimonides_Rambam CONSTRUCTOR" << endl;log_stream  << " FTER Abu_Maimonides_Rambam CONSTRUCTOR" << endl;
#endif

using namespace std;

extern Censorship configuration;
extern ofstream log_stream;

void make_predictor_file_set_by_naked_sequence_ (
    string &sequence,
    const string &path_for_pytorch_data,
    const string &predictor_file_name   )
{
/*    string path_to_outputfilename = path_for_pytorch_data + predictor_file_name + "X.dat";

    ofstream result_out( path_to_outputfilename .c_str() ,ios::binary);
	if ( ! result_out	)
	{
		log_stream << "ERROR: outputfilename    can't create " << path_to_outputfilename<< endl;
		cout       << "ERROR: outputfilename    can't create " << path_to_outputfilename<< endl;
		exit (1);
	}
*/
   log_stream <<" In prediction_by_sequence_for_server(): naked sequence:" <<  sequence << endl;

   Abu_Maimonides_Rambam mr("test_new_approach_4",COMMON_USAGE_ABU_MAIMONIDES_RAMBAM_OPERATING_MODES) ;

    mr.make_predictor_file_set_by_sequence (
        sequence,
        path_for_pytorch_data,
        predictor_file_name);

}
