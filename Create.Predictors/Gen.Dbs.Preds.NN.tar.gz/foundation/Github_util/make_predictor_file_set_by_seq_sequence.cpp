#include <string>
#include <fstream>
#include <iostream>


#include "Github_util.h"


extern ofstream log_stream;

void make_predictor_file_set_by_seq_sequence(
    const string &path_to_sourcefilename,
	const string &path_for_pytorch_data,
	const string &predictor_file_name)
{

	//string path_to_sourcefilename = 	string ("/ServerTmp/") +  sourcefilename;
	ifstream in( path_to_sourcefilename.c_str() );
	if ( ! in	)
	{
		cout                << "ERROR: outputfilename    can't create " << path_to_sourcefilename<< endl;
		log_stream	        << "ERROR: outputfilename    can't create " << path_to_sourcefilename<< endl;
		exit (1);
	}

	string current_line;
	string sequence;
	string head;

/*	getline( in  , head, '\n' );
	if (head[0] != '>')
	{
	  cout << "Wrong fasta format -  stange head line:"  << head << endl;
	  exit (-1);
    }
    else if (head.size() == 0)
    {
	  cout << "Wrong fasta file - empty file" << endl;
	  exit (-1);
    }

*/

    char ch;
	while(  in >> ch )
	{
        if ( ch ==' ' || ch == '\n' || ch == '\t')
            continue;
        else
			sequence += ch;
	}



     make_predictor_file_set_by_naked_sequence_ (
        sequence,
        path_for_pytorch_data,
        predictor_file_name   );



}
