#ifndef MAKE_CLASTER_MOTIF_BY_DIHEDRAL_SET_H 
#define MAKE_CLASTER_MOTIF_BY_DIHEDRAL_SET

#include <vector>
#include <string>

using namespace std;
	
double ** make_claster_motif_by_dihedral_set( 
	string & path_to_dihedral_store,
	int & number_of_classes,
	int & fragment_length);

#endif